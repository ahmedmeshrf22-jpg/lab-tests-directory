import { auth, db } from './firebase.js';
import { doc, getDoc, setDoc } from 'firebase/firestore';

// V118 security-hardened schema, backward compatible with Android/Windows V117.
const RAW_CHUNK_BYTES = 420 * 1024;
const MAX_FILE_BYTES = 6 * 1024 * 1024;
const MAX_CHUNKS = 64;
const META_PREFIX = 'resultmeta_';
const CHUNK_PREFIX = 'resultchunk_';

function sanitizeName(name = '', mime = '') {
  const fallback = mime === 'application/pdf' ? 'result.pdf' : mime.includes('png') ? 'result.png' : mime.includes('webp') ? 'result.webp' : mime.includes('heic') || mime.includes('heif') ? 'result.heic' : mime.includes('avif') ? 'result.avif' : 'result.jpg';
  const clean = String(name || fallback).replace(/[\\/:*?"<>|\x00-\x1f]+/g, '_').replace(/\s+/g, ' ').trim();
  return (clean || fallback).slice(0, 120);
}

function bytesToBase64(bytes) {
  let binary = '';
  const step = 32 * 1024;
  for (let i = 0; i < bytes.length; i += step) {
    const part = bytes.subarray(i, Math.min(i + step, bytes.length));
    binary += String.fromCharCode(...part);
  }
  return btoa(binary);
}

function base64ToBytes(text) {
  const binary = atob(String(text || ''));
  const out = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) out[i] = binary.charCodeAt(i);
  return out;
}

function parseRef(storedRef = '') {
  const text = String(storedRef || '').trim();
  if (!text.startsWith('fsr:')) return null;
  const match = text.match(/^fsr:\/+(?:\/)?([^/]+)\/([^/?#]+)/i);
  if (!match) return null;
  const customerId = decodeURIComponent(match[1]);
  const fileId = decodeURIComponent(match[2]);
  if (!/^[A-Za-z0-9_-]{12,80}$/.test(fileId)) return null;
  return { customerId, fileId };
}

function ascii(bytes, start, len) {
  return String.fromCharCode(...bytes.subarray(start, start + len));
}

function detectedMime(bytes) {
  if (bytes.length >= 5 && ascii(bytes,0,5) === '%PDF-') return 'application/pdf';
  if (bytes.length >= 3 && bytes[0]===0xff && bytes[1]===0xd8 && bytes[2]===0xff) return 'image/jpeg';
  if (bytes.length >= 8 && [0x89,0x50,0x4e,0x47,0x0d,0x0a,0x1a,0x0a].every((v,i)=>bytes[i]===v)) return 'image/png';
  if (bytes.length >= 12 && ascii(bytes,0,4)==='RIFF' && ascii(bytes,8,4)==='WEBP') return 'image/webp';
  if (bytes.length >= 12 && ascii(bytes,4,4)==='ftyp') {
    const brand=ascii(bytes,8,4).toLowerCase();
    if (['heic','heix','hevc','hevx','mif1','msf1'].includes(brand)) return 'image/heic';
    if (['avif','avis'].includes(brand)) return 'image/avif';
  }
  return '';
}

async function sha256Hex(bytes) {
  const digest = new Uint8Array(await crypto.subtle.digest('SHA-256', bytes));
  return [...digest].map(x=>x.toString(16).padStart(2,'0')).join('');
}

export function isFirestoreResultRef(storedRef = '') {
  return !!parseRef(storedRef);
}

export async function uploadResultFile(file, customerId, orderId, displayName = '') {
  const user = auth.currentUser;
  if (!user) throw new Error('سجل الدخول أولاً');
  if (!customerId || !orderId) throw new Error('بيانات الطلب غير مكتملة');
  if (!file) throw new Error('اختر صورة أو PDF للنتيجة');

  const size = Number(file.size || 0);
  if (size <= 0) throw new Error('الملف فارغ');
  if (size > MAX_FILE_BYTES) throw new Error('حجم الملف أكبر من 6 MB');

  const bytes = new Uint8Array(await file.arrayBuffer());
  if (!bytes.length) throw new Error('الملف فارغ');
  if (bytes.length > MAX_FILE_BYTES) throw new Error('حجم الملف أكبر من 6 MB');

  const realMime = detectedMime(bytes);
  if (!realMime) throw new Error('محتوى الملف ليس صورة أو PDF صالحًا');
  const declared = String(file.type || '').toLowerCase();
  if (declared && declared !== 'application/octet-stream') {
    const declaredKind = declared === 'application/pdf' ? 'pdf' : declared.startsWith('image/') ? 'image' : '';
    const realKind = realMime === 'application/pdf' ? 'pdf' : 'image';
    if (!declaredKind || declaredKind !== realKind) throw new Error('نوع الملف المعلن لا يطابق محتواه الحقيقي');
  }

  const fileId = crypto.randomUUID().replaceAll('-', '');
  const safeName = sanitizeName(displayName || file.name, realMime);
  const activityPath = ['customers', String(customerId), 'activity'];
  const chunkCount = Math.ceil(bytes.length / RAW_CHUNK_BYTES);
  if (chunkCount <= 0 || chunkCount > MAX_CHUNKS) throw new Error('حجم ملف النتيجة غير مدعوم');
  const digest = await sha256Hex(bytes);

  for (let index = 0; index < chunkCount; index++) {
    const start = index * RAW_CHUNK_BYTES;
    const end = Math.min(start + RAW_CHUNK_BYTES, bytes.length);
    const encoded = bytesToBase64(bytes.subarray(start, end));
    const chunkId = `${CHUNK_PREFIX}${fileId}_${String(index).padStart(3, '0')}`;
    await setDoc(doc(db, ...activityPath, chunkId), {
      type: 'result_file_chunk',
      file_id: fileId,
      order_id: String(orderId),
      chunk_index: index,
      chunk_count: chunkCount,
      data_b64: encoded,
      actor_uid: user.uid,
      actor_email: user.email || ''
    });
  }

  await setDoc(doc(db, ...activityPath, `${META_PREFIX}${fileId}`), {
    type: 'result_file_meta',
    file_id: fileId,
    order_id: String(orderId),
    file_name: safeName,
    mime_type: realMime,
    size_bytes: bytes.length,
    chunk_count: chunkCount,
    sha256: digest,
    sha256_hex: digest,
    upload_complete: true,
    actor_uid: user.uid,
    actor_email: user.email || '',
    file_created_ms: Date.now()
  });

  return {
    ref: `fsr:/${encodeURIComponent(String(customerId))}/${encodeURIComponent(fileId)}`,
    name: safeName,
    mime: realMime,
    size: bytes.length,
    chunks: chunkCount,
    sha256: digest
  };
}

export async function readResultFile(storedRef) {
  const parsed = parseRef(storedRef);
  if (!parsed) throw new Error('مرجع ملف النتيجة غير صالح');
  const { customerId, fileId } = parsed;
  const activityPath = ['customers', customerId, 'activity'];

  const metaSnap = await getDoc(doc(db, ...activityPath, `${META_PREFIX}${fileId}`));
  if (!metaSnap.exists()) throw new Error('ملف النتيجة غير موجود');
  const meta = metaSnap.data() || {};
  if (meta.type !== 'result_file_meta' || String(meta.file_id || '') !== fileId) throw new Error('بيانات ملف النتيجة غير موثوقة');
  if (Object.prototype.hasOwnProperty.call(meta,'upload_complete') && meta.upload_complete !== true) throw new Error('رفع ملف النتيجة لم يكتمل');

  const orderId = String(meta.order_id || '');
  const name = sanitizeName(meta.file_name || 'result.pdf', meta.mime_type || 'application/pdf');
  const mime = String(meta.mime_type || 'application/pdf').toLowerCase();
  const chunkCount = Number(meta.chunk_count || 0);
  const expectedSize = Number(meta.size_bytes || 0);
  const expectedDigest = String(meta.sha256 || meta.sha256_hex || '').toLowerCase();
  if (!(mime === 'application/pdf' || mime.startsWith('image/'))) throw new Error('نوع ملف النتيجة غير صالح');
  if (!Number.isInteger(chunkCount) || chunkCount <= 0 || chunkCount > MAX_CHUNKS) throw new Error('بيانات ملف النتيجة غير مكتملة');
  if (expectedSize <= 0 || expectedSize > MAX_FILE_BYTES) throw new Error('حجم ملف النتيجة غير صالح');
  if (expectedDigest && !/^[a-f0-9]{64}$/.test(expectedDigest)) throw new Error('بصمة ملف النتيجة غير صالحة');

  const parts = [];
  let total = 0;
  for (let index = 0; index < chunkCount; index++) {
    const chunkId = `${CHUNK_PREFIX}${fileId}_${String(index).padStart(3, '0')}`;
    const snap = await getDoc(doc(db, ...activityPath, chunkId));
    if (!snap.exists()) throw new Error('جزء من ملف النتيجة غير موجود');
    const x=snap.data() || {};
    if (x.type !== 'result_file_chunk' || String(x.file_id || '') !== fileId || Number(x.chunk_index) !== index || Number(x.chunk_count) !== chunkCount || (orderId && String(x.order_id || '') !== orderId)) {
      throw new Error('بيانات جزء من ملف النتيجة غير موثوقة');
    }
    const encoded = String(x.data_b64 || '');
    if (!encoded) throw new Error('جزء من ملف النتيجة غير موجود');
    let part;
    try { part = base64ToBytes(encoded); } catch { throw new Error('تعذر قراءة ملف النتيجة'); }
    parts.push(part);
    total += part.length;
    if (total > MAX_FILE_BYTES) throw new Error('حجم ملف النتيجة غير صالح');
  }
  if (total !== expectedSize) throw new Error('ملف النتيجة غير مكتمل، حاول مرة أخرى');

  const bytes = new Uint8Array(total);
  let offset = 0;
  for (const part of parts) { bytes.set(part, offset); offset += part.length; }
  if (expectedDigest && await sha256Hex(bytes) !== expectedDigest) throw new Error('فشل التحقق من سلامة ملف النتيجة');
  const actualMime=detectedMime(bytes);
  if (!actualMime || (mime === 'application/pdf') !== (actualMime === 'application/pdf')) throw new Error('محتوى ملف النتيجة لا يطابق نوعه');
  return { bytes, name, mime:actualMime, customerId, fileId, sha256: expectedDigest || await sha256Hex(bytes) };
}
