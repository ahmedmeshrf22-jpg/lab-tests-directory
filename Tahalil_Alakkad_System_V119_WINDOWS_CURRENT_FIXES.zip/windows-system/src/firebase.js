import { initializeApp, deleteApp } from 'firebase/app';
import { getAuth, signInWithEmailAndPassword, signOut, updatePassword, setPersistence, browserSessionPersistence } from 'firebase/auth';
import { initializeFirestore, persistentLocalCache, persistentSingleTabManager, getFirestore, collection, getDocs, query, limit } from 'firebase/firestore';

export const firebaseConfig = {
  apiKey: 'AIzaSyBtP9PtXl35oTZPR5npNWsnMLnsJ3qiduY',
  authDomain: 'tahalil-alakkad.firebaseapp.com',
  projectId: 'tahalil-alakkad',
  storageBucket: 'tahalil-alakkad.firebasestorage.app',
  messagingSenderId: '266327573884',
  appId: '1:266327573884:web:c457f66f054582bb4290f9'
};
export const MANAGER_UID = 'Wps5Y19pZSbeGooEzFfW5UFsshq2';
export const ADMIN_GATE_EMAIL = 'tahalil.admin.gate.v60@tahali.com';
export const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const authPersistenceReady = setPersistence(auth, browserSessionPersistence).catch(() => {});
export const db = initializeFirestore(app, { localCache: persistentLocalCache({ tabManager: persistentSingleTabManager() }) });

let adminContext = null;
export function getAdminDb(){ return adminContext?.db || null; }
export function adminIsUnlocked(){ return !!adminContext?.auth?.currentUser; }
export async function unlockAdminFirebase(derivedPassword){
  await lockAdminFirebase();
  const a = initializeApp(firebaseConfig, `admin-${Date.now()}-${Math.random().toString(36).slice(2)}`);
  const aAuth = getAuth(a);
  try{
    const cred = await signInWithEmailAndPassword(aAuth, ADMIN_GATE_EMAIL, derivedPassword);
    if((cred.user.email||'').trim().toLowerCase()!==ADMIN_GATE_EMAIL) throw new Error('تعذر التحقق من حساب الإدارة');
    const adb = getFirestore(a);
    await getDocs(query(collection(adb,'lab2lab_prices'),limit(1)));
    adminContext={app:a,auth:aAuth,db:adb};
    return adb;
  }catch(e){ try{await signOut(aAuth)}catch{} try{await deleteApp(a)}catch{} throw e; }
}
export async function lockAdminFirebase(){
  const x=adminContext;adminContext=null;if(!x)return;
  try{await signOut(x.auth)}catch{}try{await deleteApp(x.app)}catch{}
}


export async function changeAdminFirebasePassword(currentDerived,nextDerived){
  const a=adminContext?.app, aAuth=adminContext?.auth;
  if(!a||!aAuth) throw new Error('افتح الإدارة بالـ PIN أولًا');
  const cred=await signInWithEmailAndPassword(aAuth,ADMIN_GATE_EMAIL,currentDerived);
  if(!cred.user) throw new Error('تعذر التحقق من حساب الإدارة');
  await updatePassword(cred.user,nextDerived);
}

export async function createSecondaryFirebase() {
  const name = `staff-${Date.now()}-${Math.random().toString(36).slice(2)}`;
  const secondary = initializeApp(firebaseConfig, name);
  return { app: secondary, auth: getAuth(secondary), cleanup: () => deleteApp(secondary) };
}
