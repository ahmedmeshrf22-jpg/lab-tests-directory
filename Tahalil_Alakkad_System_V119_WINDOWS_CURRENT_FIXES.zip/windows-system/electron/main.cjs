const { app, BrowserWindow, ipcMain, dialog, shell, Notification } = require('electron');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const os = require('os');

const MAX_RESULT_BYTES = 6 * 1024 * 1024;
const SAFE_EXTERNAL_PROTOCOLS = new Set(['https:']);
const SMOKE_TEST = process.env.TAHALIL_SMOKE_TEST === '1';

function identityFile() { return path.join(app.getPath('userData'), 'device-id.txt'); }
function resultTempDir() { return path.join(app.getPath('temp'), 'TahalilAlakkad', 'results'); }

function cleanupResultTemp() {
  try { fs.rmSync(resultTempDir(), { recursive: true, force: true }); } catch {}
}

function getDeviceId() {
  const file = identityFile();
  try {
    if (fs.existsSync(file)) return fs.readFileSync(file, 'utf8').trim();
    const id = crypto.createHash('sha256').update(`${crypto.randomUUID()}|${os.hostname()}|tahalil-alakkad-windows`).digest('hex').slice(0, 32);
    fs.mkdirSync(path.dirname(file), { recursive: true });
    fs.writeFileSync(file, id, { encoding: 'utf8', mode: 0o600 });
    return id;
  } catch { return crypto.createHash('sha256').update(`${os.hostname()}|fallback`).digest('hex').slice(0, 32); }
}

function safeExternalUrl(url) {
  try {
    const u = new URL(String(url || ''));
    if (!SAFE_EXTERNAL_PROTOCOLS.has(u.protocol)) throw new Error('Blocked unsafe URL scheme');
    return u.toString();
  } catch { throw new Error('رابط خارجي غير آمن أو غير صالح'); }
}

function isSafeResultBytes(bytes) {
  if (!Buffer.isBuffer(bytes) || bytes.length <= 0 || bytes.length > MAX_RESULT_BYTES) return false;
  if (bytes.length >= 5 && bytes.subarray(0,5).toString('ascii') === '%PDF-') return true;
  if (bytes.length >= 3 && bytes[0]===0xff && bytes[1]===0xd8 && bytes[2]===0xff) return true;
  if (bytes.length >= 8 && Buffer.from([0x89,0x50,0x4e,0x47,0x0d,0x0a,0x1a,0x0a]).equals(bytes.subarray(0,8))) return true;
  if (bytes.length >= 12 && bytes.subarray(0,4).toString('ascii') === 'RIFF' && bytes.subarray(8,12).toString('ascii') === 'WEBP') return true;
  if (bytes.length >= 12 && bytes.subarray(4,8).toString('ascii') === 'ftyp') return true;
  return false;
}

async function openSafeExternal(url) {
  return shell.openExternal(safeExternalUrl(url));
}

function createWindow() {
  const win = new BrowserWindow({
    width: 1440, height: 900, minWidth: 1050, minHeight: 700,
    show: false, backgroundColor: '#0b1220',
    webPreferences: {
      preload: path.join(__dirname, 'preload.cjs'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      webSecurity: true,
      allowRunningInsecureContent: false,
      webviewTag: false,
      devTools: false,
      spellcheck: false
    }
  });
  try { win.setContentProtection(true); } catch {}
  win.removeMenu();

  win.webContents.session.setPermissionRequestHandler((_wc, permission, callback, details) => {
    const requester = String(details?.requestingUrl || '');
    callback(permission === 'media' && requester.startsWith('file://'));
  });
  win.webContents.on('will-attach-webview', (event) => event.preventDefault());
  win.webContents.on('will-navigate', (event, url) => {
    if (!String(url || '').startsWith('file://')) event.preventDefault();
  });
  win.webContents.setWindowOpenHandler(({ url }) => {
    try { openSafeExternal(url); } catch {}
    return { action: 'deny' };
  });

  win.loadFile(path.join(__dirname, '..', 'dist', 'index.html'));
  win.once('ready-to-show', () => { win.maximize(); win.show(); if (SMOKE_TEST) setTimeout(() => app.quit(), 1500); });
}

ipcMain.handle('device:identity', () => ({
  id: getDeviceId(), manufacturer: 'Windows PC', model: os.hostname(), windowsVersion: os.release(), platform: os.platform()
}));

ipcMain.handle('file:saveText', async (_e, { defaultName, content }) => {
  const result = await dialog.showSaveDialog({ defaultPath: defaultName, filters: [{ name: 'Files', extensions: ['json','txt','csv'] }] });
  if (result.canceled || !result.filePath) return null;
  fs.writeFileSync(result.filePath, String(content || ''), { encoding: 'utf8', mode: 0o600 }); return result.filePath;
});

ipcMain.handle('file:print', async (event) => {
  const win = BrowserWindow.fromWebContents(event.sender);
  if (!win) return false;
  return new Promise((resolve,reject)=>{
    win.webContents.print({ silent:false, printBackground:true }, (success, reason)=> success ? resolve(true) : reject(new Error(reason || 'تعذر الطباعة')));
  });
});

ipcMain.handle('file:savePdf', async (event, { defaultName }) => {
  const win = BrowserWindow.fromWebContents(event.sender);
  if (!win) throw new Error('تعذر الوصول لنافذة البرنامج');
  const result = await dialog.showSaveDialog({ defaultPath: defaultName, filters: [{ name: 'PDF', extensions: ['pdf'] }] });
  if (result.canceled || !result.filePath) return null;
  const data = await win.webContents.printToPDF({ printBackground: true, pageSize: 'A4', margins: { marginType: 'default' } });
  fs.writeFileSync(result.filePath, data, { mode: 0o600 }); return result.filePath;
});

ipcMain.handle('file:saveDataUrl', async (_event, { defaultName, dataUrl }) => {
  const ext = (String(defaultName || '').split('.').pop() || 'png').toLowerCase();
  if (!['png','jpg','jpeg','webp'].includes(ext)) throw new Error('نوع الصورة غير مسموح');
  const result = await dialog.showSaveDialog({ defaultPath: defaultName, filters: [{ name: ext.toUpperCase(), extensions: [ext] }] });
  if (result.canceled || !result.filePath) return null;
  const base64 = String(dataUrl || '').replace(/^data:[^;]+;base64,/, '');
  const bytes = Buffer.from(base64, 'base64');
  if (bytes.length > MAX_RESULT_BYTES) throw new Error('حجم الملف أكبر من الحد الآمن');
  fs.writeFileSync(result.filePath, bytes, { mode: 0o600 });
  return result.filePath;
});

ipcMain.handle('admin:derivePassword', (_e, pin) => {
  const clean = String(pin || '').trim();
  if (!/^\d{6}$/.test(clean)) throw new Error('PIN must be 6 digits');
  let bytes = Buffer.from(`firebase|TahalilAlakkad.AdminGate.v60.2026|${clean}`, 'utf8');
  for (let i = 0; i < 40000; i++) bytes = crypto.createHash('sha256').update(bytes).digest();
  return 'Aa1!' + bytes.toString('hex').slice(0, 48);
});

ipcMain.handle('file:saveBytes', async (_event, { defaultName, bytes }) => {
  const data=Buffer.from(bytes || []);
  if (!data.length || data.length > 160 * 1024 * 1024) throw new Error('حجم النسخة الاحتياطية غير صالح');
  const result = await dialog.showSaveDialog({ defaultPath: defaultName, filters: [{ name: 'Tahalil Backup', extensions: ['tahbak'] }, { name: 'All files', extensions: ['*'] }] });
  if (result.canceled || !result.filePath) return null;
  fs.writeFileSync(result.filePath, data, { mode: 0o600 });
  return result.filePath;
});

ipcMain.handle('file:openBytes', async () => {
  const result = await dialog.showOpenDialog({ properties: ['openFile'], filters: [{ name: 'Tahalil Backup', extensions: ['tahbak'] }] });
  if (result.canceled || !result.filePaths[0]) return null;
  const filePath = result.filePaths[0];
  const st=fs.statSync(filePath);
  if (st.size <= 0 || st.size > 160 * 1024 * 1024) throw new Error('حجم ملف النسخة الاحتياطية غير صالح');
  return { filePath, name: path.basename(filePath), bytes: Array.from(fs.readFileSync(filePath)) };
});

ipcMain.handle('result:openBytes', async (_event, { defaultName, bytes }) => {
  const safe = String(defaultName || 'result.pdf').replace(/[\\/:*?"<>|\x00-\x1f]+/g, '_').slice(0, 120) || 'result.pdf';
  const data=Buffer.from(bytes || []);
  if (!isSafeResultBytes(data)) throw new Error('ملف النتيجة غير صالح أو أكبر من الحد الآمن');
  const dir = resultTempDir();
  fs.mkdirSync(dir, { recursive: true });
  const filePath = path.join(dir, `${Date.now()}_${crypto.randomBytes(6).toString('hex')}_${safe}`);
  fs.writeFileSync(filePath, data, { mode: 0o600 });
  const error = await shell.openPath(filePath);
  if (error) throw new Error(error);
  return filePath;
});

ipcMain.handle('app:notify', (_event, payload = {}) => {
  try {
    if (!Notification.isSupported()) return false;
    const title = String(payload.title || 'تحاليل العقاد').slice(0, 120);
    const body = String(payload.body || '').slice(0, 500);
    new Notification({ title, body }).show();
    return true;
  } catch { return false; }
});

ipcMain.handle('shell:showItem', (_e, filePath) => {
  if (!filePath) return false;
  const resolved=path.resolve(String(filePath));
  shell.showItemInFolder(resolved);
  return true;
});
ipcMain.handle('shell:openExternal', (_e, url) => openSafeExternal(url));

app.whenReady().then(() => { cleanupResultTemp(); createWindow(); });
app.on('before-quit', cleanupResultTemp);
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
