# Tahalil Alakkad Windows V119

- Lab reads sanitized `/lab_orders` only; private customer/order finance is denied by V119 rules.
- Embedded customer prices removed from distributable assets.
- Backup schema 2 includes result-file meta/chunks and lab mirrors; restore accepts schema 1 and 2.
- Preserves V118 Electron hardening: sandbox, context isolation, no Node integration, content protection, navigation controls, disabled devtools/webviews, safe result-file validation and temp cleanup.
- Adds CSP, session-only Firebase Auth, PBKDF2 310,000 PIN migration.
- Reads Android `sha256` and legacy Windows `sha256_hex`; writes both for cross-platform integrity.
- Builds both Portable EXE and NSIS Setup EXE from one source.
