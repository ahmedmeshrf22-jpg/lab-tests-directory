package com.example

import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.ui.DeviceUnlockScreen
import com.example.ui.LabTestsApp
import com.example.ui.LabTestsViewModel
import com.example.ui.LoginScreen
import com.example.ui.SplashScreen
import com.example.ui.theme.LabTestsTheme
import com.google.firebase.FirebaseNetworkException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.FirebaseAuthInvalidUserException
import kotlinx.coroutines.delay

class MainActivity : FragmentActivity() {

    private val viewModel: LabTestsViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val auth = FirebaseAuth.getInstance()

        setContent {
            LabTestsTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    var currentUser by remember { mutableStateOf(auth.currentUser) }
                    var isSplashActive by remember { mutableStateOf(true) }
                    var isLocallyUnlocked by remember { mutableStateOf(false) }
                    var isLoading by remember { mutableStateOf(false) }
                    var errorMessage by remember { mutableStateOf<String?>(null) }
                    var unlockError by remember { mutableStateOf<String?>(null) }

                    LaunchedEffect(Unit) {
                        delay(2000L)
                        isSplashActive = false
                    }

                    val lifecycleOwner = LocalLifecycleOwner.current

                    DisposableEffect(auth) {
                        val listener = FirebaseAuth.AuthStateListener { fAuth ->
                            currentUser = fAuth.currentUser
                            if (fAuth.currentUser == null) {
                                isLocallyUnlocked = false
                            }
                        }
                        auth.addAuthStateListener(listener)
                        onDispose {
                            auth.removeAuthStateListener(listener)
                        }
                    }

                    DisposableEffect(lifecycleOwner) {
                        val observer = LifecycleEventObserver { _, event ->
                            if (event == Lifecycle.Event.ON_STOP) {
                                if (auth.currentUser != null) {
                                    isLocallyUnlocked = false
                                }
                            } else if (event == Lifecycle.Event.ON_START) {
                                if (auth.currentUser != null && !isLocallyUnlocked && isSecurityConfiguredOnDevice()) {
                                    launchBiometricPrompt(
                                        onSuccess = {
                                            isLocallyUnlocked = true
                                            unlockError = null
                                        },
                                        onError = { unlockError = it }
                                    )
                                }
                            }
                        }
                        lifecycleOwner.lifecycle.addObserver(observer)
                        onDispose {
                            lifecycleOwner.lifecycle.removeObserver(observer)
                        }
                    }

                    when {
                        isSplashActive -> {
                            SplashScreen()
                        }

                        currentUser == null -> {
                            LoginScreen(
                                onLoginClick = { email, password ->
                                    if (email.isBlank() || password.isBlank()) {
                                        errorMessage = "يرجى إدخال البريد الإلكتروني وكلمة المرور"
                                        return@LoginScreen
                                    }
                                    isLoading = true
                                    errorMessage = null
                                    auth.signInWithEmailAndPassword(email, password)
                                        .addOnCompleteListener { task ->
                                            isLoading = false
                                            if (task.isSuccessful) {
                                                isLocallyUnlocked = true
                                            } else {
                                                val exception = task.exception
                                                errorMessage = when (exception) {
                                                    is FirebaseAuthInvalidUserException,
                                                    is FirebaseAuthInvalidCredentialsException -> "البريد الإلكتروني أو كلمة المرور غير صحيحة"
                                                    is FirebaseNetworkException -> "خطأ في الاتصال بالإنترنت. يرجى التحقق من الشبكة."
                                                    else -> exception?.localizedMessage ?: "فشل تسجيل الدخول. يرجى التأكد من البيانات."
                                                }
                                            }
                                        }
                                },
                                isLoading = isLoading,
                                errorMessage = errorMessage
                            )
                        }

                        !isLocallyUnlocked -> {
                            val isSecured = isSecurityConfiguredOnDevice()

                            LaunchedEffect(currentUser) {
                                if (isSecured) {
                                    launchBiometricPrompt(
                                        onSuccess = {
                                            isLocallyUnlocked = true
                                            unlockError = null
                                        },
                                        onError = { unlockError = it }
                                    )
                                }
                            }

                            DeviceUnlockScreen(
                                onUnlockClick = {
                                    if (isSecured) {
                                        launchBiometricPrompt(
                                            onSuccess = {
                                                isLocallyUnlocked = true
                                                unlockError = null
                                            },
                                            onError = { unlockError = it }
                                        )
                                    } else {
                                        if (isSecurityConfiguredOnDevice()) {
                                            launchBiometricPrompt(
                                                onSuccess = {
                                                    isLocallyUnlocked = true
                                                    unlockError = null
                                                },
                                                onError = { unlockError = it }
                                            )
                                        }
                                    }
                                },
                                onLogoutClick = {
                                    auth.signOut()
                                    isLocallyUnlocked = false
                                },
                                isSecurityConfigured = isSecured,
                                errorMessage = unlockError
                            )
                        }

                        else -> {
                            LabTestsApp(
                                viewModel = viewModel,
                                currentUserEmail = currentUser?.email,
                                onLogout = {
                                    auth.signOut()
                                    isLocallyUnlocked = false
                                }
                            )
                        }
                    }
                }
            }
        }
    }

    private fun isSecurityConfiguredOnDevice(): Boolean {
        val biometricManager = BiometricManager.from(this)
        val strongOrCred = BiometricManager.Authenticators.BIOMETRIC_STRONG or
                BiometricManager.Authenticators.DEVICE_CREDENTIAL
        val weakOrCred = BiometricManager.Authenticators.BIOMETRIC_WEAK or
                BiometricManager.Authenticators.DEVICE_CREDENTIAL

        return biometricManager.canAuthenticate(strongOrCred) == BiometricManager.BIOMETRIC_SUCCESS ||
                biometricManager.canAuthenticate(weakOrCred) == BiometricManager.BIOMETRIC_SUCCESS
    }

    private fun launchBiometricPrompt(
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        val executor = ContextCompat.getMainExecutor(this)
        val callback = object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                super.onAuthenticationSucceeded(result)
                onSuccess()
            }

            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                super.onAuthenticationError(errorCode, errString)
                if (errorCode != BiometricPrompt.ERROR_USER_CANCELED &&
                    errorCode != BiometricPrompt.ERROR_NEGATIVE_BUTTON &&
                    errorCode != BiometricPrompt.ERROR_CANCELED
                ) {
                    onError(errString.toString())
                }
            }
        }

        val biometricPrompt = BiometricPrompt(this, executor, callback)

        val authenticators = BiometricManager.Authenticators.BIOMETRIC_STRONG or
                BiometricManager.Authenticators.DEVICE_CREDENTIAL

        val promptInfo = BiometricPrompt.PromptInfo.Builder()
            .setTitle("فتح دليل التحاليل")
            .setSubtitle("استخدم البصمة أو رمز قفل الهاتف للمتابعة")
            .setAllowedAuthenticators(authenticators)
            .build()

        try {
            biometricPrompt.authenticate(promptInfo)
        } catch (e: Exception) {
            onError(e.localizedMessage ?: "فشل في فتح قفل الهاتف")
        }
    }
}
