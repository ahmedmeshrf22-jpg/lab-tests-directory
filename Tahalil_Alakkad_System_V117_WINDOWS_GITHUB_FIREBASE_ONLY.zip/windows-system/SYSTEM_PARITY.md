# Android V117 ↔ Windows V117 parity

Both clients use Firebase project `tahalil-alakkad` and the same order documents.

Result-file compatibility is shared: both Android and Windows store result files under `customers/{customerId}/activity` as `result_file_meta` + `result_file_chunk` documents and save an `fsr:` reference on the order. Either client can open a result uploaded by the other client.

Windows V117 also preserves the Android V117 operating rules: Abdelrahman-only one-way user switching, wide test search, soft lab cancellation, no lab financial fields, direct send-to-lab order creation, realtime synchronization, and no Firebase Storage / Cloud Functions / Supabase requirement.

Platform-specific APIs remain platform-specific: Android document scanning/biometrics stay on Android; Windows uses camera/file import, approved Windows device identity, and local PIN controls.
