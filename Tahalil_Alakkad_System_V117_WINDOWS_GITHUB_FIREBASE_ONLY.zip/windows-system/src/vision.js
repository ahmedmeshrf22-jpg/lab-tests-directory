import { app } from './firebase.js';
import { getAI, getGenerativeModel, GoogleAIBackend } from 'firebase/ai';
import { createWorker } from 'tesseract.js';
import jsQR from 'jsqr';
import * as pdfjsLib from 'pdfjs-dist/legacy/build/pdf.mjs';
import pdfWorkerUrl from 'pdfjs-dist/legacy/build/pdf.worker.mjs?url';

pdfjsLib.GlobalWorkerOptions.workerSrc = pdfWorkerUrl;
const ai = getAI(app, { backend: new GoogleAIBackend() });

async function fileToPart(file){
  const data = await new Promise((resolve,reject)=>{const r=new FileReader();r.onerror=reject;r.onload=()=>resolve(String(r.result).split(',')[1]);r.readAsDataURL(file);});
  return { inlineData:{ data, mimeType:file.type || (file.name.toLowerCase().endsWith('.pdf')?'application/pdf':'image/jpeg') } };
}
export async function smartVisionExtract(file){
  const prompt = `You are a medical document transcription system for a clinical laboratory app. Inspect the supplied document carefully, including handwritten Arabic and English. Extract ONLY laboratory tests explicitly requested or written. Do NOT diagnose, recommend, infer, or add tests. Do NOT output patient names, doctor names, diagnoses, medications, dates, phone numbers, addresses, prices, or non-laboratory investigations. Return one laboratory test per line, no bullets, no commentary. If unclear, omit it rather than guessing.`;
  const part=await fileToPart(file); let last;
  for(const name of ['gemini-3.6-flash','gemini-3.5-flash']){
    try{const model=getGenerativeModel(ai,{model:name});const res=await model.generateContent([prompt,part]);const text=res.response.text();if(text?.trim())return {mode:name,text:clean(text)};}catch(e){last=e;}
  }
  throw last || new Error('Smart Vision غير متاح');
}
function clean(s){return s.replace(/```(?:json|text)?/gi,'').replace(/```/g,'').split(/\r?\n/).map(x=>x.trim().replace(/^[-*•]+\s*/, '').replace(/^\d{1,3}[.)-]\s*/, '')).filter(Boolean).join('\n');}
async function pdfPages(file,maxPages=20,scale=2){
  const bytes=new Uint8Array(await file.arrayBuffer());
  const pdf=await pdfjsLib.getDocument({data:bytes}).promise;
  const n=Math.min(pdf.numPages,maxPages), pages=[];
  for(let i=1;i<=n;i++){
    const page=await pdf.getPage(i),vp=page.getViewport({scale});
    const canvas=document.createElement('canvas');canvas.width=Math.ceil(vp.width);canvas.height=Math.ceil(vp.height);
    const ctx=canvas.getContext('2d',{willReadFrequently:true});
    await page.render({canvasContext:ctx,viewport:vp}).promise;pages.push(canvas);
  }
  return pages;
}
export async function localOcr(file,onProgress=()=>{}){
  const isPdf=file.type==='application/pdf'||file.name?.toLowerCase().endsWith('.pdf');
  const worker=await createWorker(['eng','ara'],undefined,{logger:m=>{if(m.progress!=null)onProgress(m.progress,m.status)}});
  try{
    if(isPdf){
      const pages=await pdfPages(file,20,1.75), out=[];
      for(let i=0;i<pages.length;i++){
        onProgress(i/pages.length,`PDF page ${i+1}/${pages.length}`);
        const r=await worker.recognize(pages[i]);if(r.data.text?.trim())out.push(r.data.text);
      }
      onProgress(1,'PDF OCR complete');return out.join('\n');
    }
    if(!file.type.startsWith('image/')) throw new Error('نوع الملف غير مدعوم');
    const out=await worker.recognize(file);return out.data.text||'';
  }finally{await worker.terminate();}
}
function norm(s=''){return String(s).trim().toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[أإآ]/g,'ا').replace(/ة/g,'ه').replace(/ى/g,'ي').replace(/[^\p{L}\p{N}]+/gu,' ');}
export function matchTests(text,tests){
  const lines=text.split(/\r?\n|[,;]+/).map(x=>norm(x)).filter(x=>x.length>1); const found=new Map();
  for(const line of lines){
    let best=null,score=0;
    for(const t of tests){
      const candidates=[t.english_name,t.arabic_name,t.market_name].map(norm).filter(Boolean);
      for(const c of candidates){
        let s=0;if(line===c)s=100;else if(c.includes(line)||line.includes(c))s=85;else{const a=new Set(line.split(' ')),b=new Set(c.split(' '));const inter=[...a].filter(x=>b.has(x)&&x.length>1).length;s=inter/Math.max(1,Math.min(a.size,b.size))*70;}if(s>score){score=s;best=t;}
      }
    }
    if(best&&score>=48)found.set(best.id,{...best,matchScore:score});
  }
  return [...found.values()].sort((a,b)=>b.matchScore-a.matchScore);
}
async function qrFromCanvas(c){const ctx=c.getContext('2d',{willReadFrequently:true}),d=ctx.getImageData(0,0,c.width,c.height);return jsQR(d.data,d.width,d.height,{inversionAttempts:'attemptBoth'})?.data||'';}
export async function readQrFromImage(file){
  const isPdf=file.type==='application/pdf'||file.name?.toLowerCase().endsWith('.pdf');
  if(isPdf){for(const c of await pdfPages(file,20,2)){const q=await qrFromCanvas(c);if(q)return q;}return '';}
  if(!file.type.startsWith('image/')) throw new Error('اختار صورة أو PDF يحتوي QR');
  const url=URL.createObjectURL(file);try{const img=await new Promise((res,rej)=>{const i=new Image();i.onload=()=>res(i);i.onerror=rej;i.src=url;});const c=document.createElement('canvas');c.width=img.naturalWidth;c.height=img.naturalHeight;const ctx=c.getContext('2d',{willReadFrequently:true});ctx.drawImage(img,0,0);return qrFromCanvas(c);}finally{URL.revokeObjectURL(url);}
}
export function parseCustomerQr(payload=''){const raw=payload.trim();if(!raw.startsWith('TAHALIL_ALAKKAD_CUSTOMER|'))return null;const out={};for(const p of raw.split('|').slice(1)){const [k,...v]=p.split('=');out[k]=v.join('=');}return {id:out.ID||'',fileNumber:out.FILE||''};}
