function n(s=''){return String(s).trim().toLowerCase().replace(/[._-]+/g,' ').replace(/\s+/g,' ')}
export const COMMON_TUBES=[
 {key:'gold',label:'ذهبي Gold',name:'SST / Clot activator',use:'معظم الكيمياء والهرمونات والسيرولوجي الروتينية'},
 {key:'lavender',label:'بنفسجي Lavender',name:'EDTA',use:'CBC وHbA1c ومعظم فحوص الدم الكامل'},
 {key:'light_blue',label:'أزرق فاتح Light Blue',name:'Sodium citrate 3.2%',use:'اختبارات التجلط'},
 {key:'gray',label:'رمادي Gray',name:'Fluoride/Oxalate',use:'الجلوكوز/اللاكتات حسب SOP'},
 {key:'green',label:'أخضر Green',name:'Heparin',use:'اختبارات خاصة تعتمد البلازما المهيبرنة'},
 {key:'black',label:'أسود Black',name:'ESR citrate',use:'ESR بطريقة Westergren عند اعتماد المعمل'}
];
export function tubeForTest(test){
 const x=n(test?.english_name||test?.englishName||'');
 const spec=(specimen,tube,color,key,confidence='شائع',note='')=>({specimen,tube,color,key,confidence,note});
 if(x.includes('blood culture')||x==='sample blood culture')return spec('دم','زجاجات مزرعة دم (هوائي/لاهوائي حسب الطلب)','زجاجات مزرعة مخصصة','culture','خاص','اتبع تعليمات التعقيم وحجم السحب وترتيب الزجاجات حسب SOP المعمل.');
 if(x.includes('urine')||x.includes('(ur)')||x.includes('acetone'))return spec('بول','وعاء بول مناسب للفحص','لا توجد أنبوبة دم','urine','مؤكد','للمزرعة يفضل وعاء معقم وclean-catch حسب تعليمات المعمل.');
 if(x.includes('stool'))return spec('براز','وعاء براز نظيف/معقم حسب الفحص','لا توجد أنبوبة دم','stool','مؤكد');
 if(x.includes('semen')||x.includes('seminal')||x.includes('sperm'))return spec('سائل منوي','وعاء معقم واسع الفوهة','لا توجد أنبوبة دم','semen','مؤكد');
 if(['sputum','wound','pus c/s','swab','cervical','vaginal','ear c/s','eye c/s'].some(v=>x.includes(v)))return spec('حسب موضع العينة','وعاء/مسحة ووسط نقل مناسب للميكروبيولوجي','لا توجد أنبوبة دم','culture','خاص','نوع المسحة ووسط النقل يحدده SOP الميكروبيولوجي.');
 if(['ascitic','synovial','csf'].some(v=>x.includes(v)))return spec('سائل جسم','وعاء معقم/أنبوبة مخصصة حسب الفحص','أنبوبة خاصة — راجع SOP','special','خاص');
 if(x.includes('stone analysis'))return spec('حصوة','وعاء جاف نظيف','لا توجد أنبوبة دم','special','مؤكد');
 if(x==='cbc'||x==='haemoglobin hb'||['platelets count','total leucocytic','reticulocytic','hba1c','glycated haemoglobin','hb electrophoresis','cd4/cd8','malaria film','tacrolimus'].some(v=>x.includes(v))||['g6pd','cd4','cd8'].includes(x))return spec('دم كامل EDTA','K2EDTA / K3EDTA','بنفسجي Lavender','lavender','شائع','قد تشترط بعض الاختبارات نوع EDTA وحجم عينة محدد.');
 if(['abo','rh'].includes(x)||x.includes("coomb's direct"))return spec('دم كامل EDTA','K2EDTA / K3EDTA','بنفسجي Lavender','lavender','شائع','إذا كان بنك الدم يعتمد أنبوبة مخصصة فاتبع SOP.');
 if(['d dimer','d-dimer','prothrombin time','lupus anticoagulant','von willebrand','anti thrombin','antithrombin'].some(v=>x.includes(v))||['ptt','fibrinogen','factor v','factor vii','factor viii','protein c','protein s','fdps'].includes(x))return spec('بلازما سيترات','Sodium citrate 3.2%','أزرق فاتح Light Blue','light_blue','مؤكد','يلزم امتلاء الأنبوبة للنسبة الصحيحة بين الدم والسيترات.');
 if(x==='esr')return spec('دم كامل','Sodium citrate ESR tube (Westergren) أو EDTA حسب الجهاز','أسود ESR غالبًا','black','متغير','بعض الأنظمة تعمل من EDTA؛ اتبع SOP المعمل.');
 if(x.includes('glucose')||x.includes('blood glucose')||x==='lactate'||x.includes('alcohol in blood'))return spec('بلازما/دم حسب الطريقة','Fluoride/Oxalate أو أنبوبة معتمدة للجلوكوز','رمادي Gray','gray','شائع','قد يقبل الجهاز serum/plasma مع فصل سريع.');
 if(x.includes('acth'))return spec('بلازما EDTA','EDTA — معالجة مبردة','بنفسجي Lavender','lavender','خاص','ACTH يحتاج تبريدًا سريعًا وفصل/نقل حسب تعليمات المعمل.');
 if(x.includes('antidiuretic hormone')||x==='adh')return spec('بلازما','أنبوبة خاصة حسب طريقة القياس','أنبوبة خاصة — راجع SOP','special','خاص');
 if(x.includes('ammonia'))return spec('بلازما','أنبوبة معتمدة حسب الجهاز + تبريد فوري','أنبوبة خاصة — راجع SOP','special','خاص');
 if(x.includes('calcium (ionized)'))return spec('دم كامل/بلازما مهيبرنة','Balanced heparin / lithium heparin حسب الجهاز','أخضر Green غالبًا','green','خاص','قلل التعرض للهواء لأن تغير pH يؤثر على الكالسيوم المتأين.');
 if(x.includes('zinc')||x.includes('copper'))return spec('مصل/بلازما للعناصر النزرة','أنبوبة عناصر نزرة معتمدة','أنبوبة خاصة — راجع SOP','special','خاص');
 if(x.includes('karyotyping'))return spec('دم كامل','Sodium heparin','أخضر Green','green','شائع','متطلبات النقل والزمن مهمة.');
 if(x.includes('quantiferon')||x.includes('t.b gold'))return spec('دم كامل','QuantiFERON dedicated collection tubes','أنابيب QuantiFERON المخصصة','special','مؤكد','لا تستبدل الأنابيب المخصصة بأنبوبة روتينية.');
 if(['pcr','dna','rna','mthfr','factor v leiden','hla b27'].some(v=>x.includes(v)))return spec('دم كامل EDTA أو بلازما EDTA حسب الاختبار','EDTA','بنفسجي Lavender غالبًا','lavender','متغير','راجع SOP لكل اختبار PCR.');
 return spec('مصل Serum غالبًا','Serum Separator Tube (SST) / Clot activator','ذهبي Gold غالبًا','gold','شائع','الذهبي SST خيار روتيني شائع لمعظم الكيمياء/الهرمونات/السيرولوجي؛ SOP المعمل هو المرجع النهائي.');
}
export function preparationFor(test){const x=n(test?.english_name||'');if(x.includes('24 hrs')||x.includes('24 hr'))return 'تجميع العينة لمدة 24 ساعة حسب تعليمات المعمل.';if(x.includes('fasting'))return 'صيام حسب تعليمات الطبيب/المعمل، وغالبًا 8 ساعات عندما يكون الفحص Fasting.';if(x.includes('2 hrs p.p')||x.includes(' pp'))return 'الالتزام بتوقيت ما بعد الوجبة المكتوب في الطلب.';if(x.includes('acth am')||x.includes('cortisol am'))return 'عينة صباحية في التوقيت المحدد.';if(x.includes('acth pm')||x.includes('cortisol pm'))return 'عينة مسائية في التوقيت المحدد.';if(x.includes('c/s')||x.includes('culture'))return 'يفضل جمع عينة جيدة قبل المضاد الحيوي متى كان ذلك ممكنًا طبيًا، مع التعقيم ووسيلة النقل المناسبة.';if(x.includes('semen analysis'))return 'اتبع تعليمات المعمل بشأن مدة الامتناع وجمع كامل العينة ووقت التسليم.';return 'لا يوجد تحضير عام ثابت. راجع طلب الطبيب وتعليمات المعمل، خصوصًا للأدوية والصيام والتوقيت.'}
