import { auth, db, MANAGER_UID, createSecondaryFirebase, getAdminDb, adminIsUnlocked } from './firebase.js';
import {
  collection, collectionGroup, doc, addDoc, setDoc, updateDoc, getDoc, getDocs, onSnapshot,
  query, where, orderBy, limit, serverTimestamp, writeBatch, increment, getDocFromServer, arrayUnion
} from 'firebase/firestore';
import { signInWithEmailAndPassword, signOut, createUserWithEmailAndPassword } from 'firebase/auth';
import * as ResultStore from './resultStore.js';

export const C = { users:'users', customers:'customers', overrides:'customer_price_overrides', lab2lab:'lab2lab_prices', audits:'audit_logs', phone:'phone_registry' };
export const ROLES = {
  reception:{edit:true,discount:false,pay:false,reports:false}, cashier:{edit:true,discount:false,pay:true,reports:false},
  technician:{edit:false,discount:false,pay:false,reports:false}, supervisor:{edit:true,discount:true,pay:true,reports:true},
  manager:{edit:true,discount:true,pay:true,reports:true}, super_admin:{edit:true,discount:true,pay:true,reports:true}, lab_operator:{edit:false,discount:false,pay:false,reports:false}, staff:{edit:true,discount:false,pay:true,reports:false}
};
export function roleDefaults(role='staff'){ return ROLES[role]||ROLES.staff; }
export function isActualManager(profile){return auth.currentUser?.uid===MANAGER_UID || String(auth.currentUser?.email||profile?.email||'').trim().toLowerCase()==='abdelrahman@tahali.com';}
export function isAdmin(profile){if(profile?.__acting_as_user===true)return ['manager','super_admin'].includes(String(profile?.role||'').toLowerCase());return isActualManager(profile)||['manager','super_admin'].includes(String(profile?.role||'').toLowerCase());}
export function isLabOperator(profile){ return String(profile?.role||'').trim().toLowerCase()==='lab_operator'; }
export function adminUnlocked(){ return adminIsUnlocked(); }
export function privilegedDb(){ return auth.currentUser?.uid===MANAGER_UID ? db : (getAdminDb() || db); }
export function money(v){ return Number(v||0).toLocaleString('en-US',{maximumFractionDigits:2}); }
export function normalize(s=''){ return s.toString().trim().toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[أإآ]/g,'ا').replace(/ة/g,'ه').replace(/ى/g,'ي').replace(/[^\p{L}\p{N}]+/gu,' '); }
export function smartSearchTests(tests=[],rawQuery=''){
 const q=normalize(rawQuery), compact=q.replace(/\s+/g,''), words=q.split(/\s+/).filter(Boolean);
 if(q.length<2)return [...tests];
 const intentMap=[
  [/كبد|liver|hepatic/,['alt','ast','alp','ggt','bilirubin','albumin','pt']],
  [/كلى|كلي|kidney|renal/,['creatinine','urea','bun','egfr','uric','urine']],
  [/سكر|diabet|glucose|hba1c|glyc/,['glucose','hba1c','insulin']],
  [/غده|غدة|thyroid|درقي/,['tsh','ft4','free t4','ft3','free t3']],
  [/انيميا|انيميا|anemia|حديد|iron|خمول|تعب/,['cbc','ferritin','iron','tibc','b12','folate','vitamin d','tsh']],
  [/دهون|كوليسترول|lipid|cholesterol/,['cholesterol','triglyceride','hdl','ldl']],
  [/سيوله|سيولة|تجلط|coag|bleeding/,['pt','inr','ptt','aptt','d dimer','fibrinogen']],
  [/بروستاتا|prostate/,['psa','free psa']],
  [/حمل|pregnan|حامل/,['beta hcg','hcg']],
  [/فيتامين|vitamin|vit\b/,['vitamin d','vitamin b12','b12','folate','vitamin a','vitamin e']]
 ];
 const intentTokens=[];for(const [re,tokens] of intentMap)if(re.test(q))intentTokens.push(...tokens);
 const scored=[];
 for(const t of tests){
   const hay=normalize(`${t.search_text||''} ${t.english_name||''} ${t.arabic_name||''} ${t.market_name||''}`), hcompact=hay.replace(/\s+/g,'');
   let score=0;
   if(hay===q)score+=1000;
   if(hay.startsWith(q))score+=500;
   if(hay.includes(q))score+=350;
   if(compact.length>=2&&hcompact.includes(compact))score+=250;
   for(const w of words){if(w.length>=2&&hay.includes(w))score+=70;}
   for(const token of intentTokens){const n=normalize(token);if(hay.includes(n))score+=180;}
   if(score>0)scored.push({t,score});
 }
 return scored.sort((a,b)=>b.score-a.score||String(a.t.english_name||'').localeCompare(String(b.t.english_name||''))).map(x=>x.t);
}
export function makeOrderNumber(now,id){ const d=new Date(now); const p=n=>String(n).padStart(2,'0'); return `AK-${d.getFullYear()}${p(d.getMonth()+1)}${p(d.getDate())}-${p(d.getHours())}${p(d.getMinutes())}-${id.slice(0,5).toUpperCase()}`; }
export async function login(email,password){ return signInWithEmailAndPassword(auth,email.trim(),password); }
export async function logout(){ return signOut(auth); }
export async function getProfile(uid){ const s=await getDoc(doc(db,C.users,uid)); return s.exists()?{uid:s.id,...s.data()}:null; }
export function watchProfile(uid,cb){ return onSnapshot(doc(db,C.users,uid),s=>cb(s.exists()?{uid:s.id,...s.data()}:null),e=>cb(null,e)); }
export async function ensureDevice(uid,email,identity){
 const ref=doc(db,C.users,uid,'devices',identity.id); const s=await getDoc(ref);
 if(!s.exists()) await setDoc(ref,{uid,email:email.toLowerCase(),device_id:identity.id,manufacturer:identity.manufacturer,model:identity.model,windows_version:identity.windowsVersion,status:'pending',requested_at_ms:Date.now(),requested_at:serverTimestamp(),updated_at_ms:Date.now(),updated_at:serverTimestamp()});
 return ref;
}
export function watchDevice(uid,id,cb){ return onSnapshot(doc(db,C.users,uid,'devices',id),s=>cb(s.exists()?{id:s.id,...s.data()}:null),e=>cb(null,e)); }
export async function loadOverrides(){ const s=await getDocs(collection(db,C.overrides)); const out={}; s.forEach(d=>{ const x=d.data(); out[Number(x.id??d.id)]=Number(x.customer_price??x.customerPrice??x.price??0); }); return out; }
export async function loadLab2Lab(){ const s=await getDocs(collection(privilegedDb(),C.lab2lab)); const out={}; s.forEach(d=>{ const x=d.data(); out[Number(x.id??d.id)]=Number(x.lab_to_lab_price??x.lab2lab_price??x.price??0); }); return out; }
export async function savePrices(testId,customerPrice,lab2labPrice,admin){
 if(!admin) throw new Error('صلاحية المدير مطلوبة'); const now=Date.now();
 const pdb=privilegedDb(); const b=writeBatch(pdb); b.set(doc(pdb,C.overrides,String(testId)),{id:Number(testId),customer_price:Number(customerPrice||0),updated_at_ms:now,updated_at:serverTimestamp(),updated_by_uid:auth.currentUser.uid},{merge:true});
 if(lab2labPrice!==''&&lab2labPrice!=null)b.set(doc(pdb,C.lab2lab,String(testId)),{id:Number(testId),lab_to_lab_price:Number(lab2labPrice||0),updated_at_ms:now,updated_at:serverTimestamp(),updated_by_uid:auth.currentUser.uid},{merge:true}); await b.commit();
}
export async function listCustomers(max=300){ const s=await getDocs(query(collection(db,C.customers),orderBy('updated_at_ms','desc'),limit(max))); return s.docs.map(d=>({id:d.id,...d.data()})); }

export async function addCustomerActivity(customerId,type,title,details=''){ if(!customerId)return; const ref=doc(collection(db,C.customers,customerId,'activity')); await setDoc(ref,{type,title,details:String(details).slice(0,1500),actor_uid:auth.currentUser.uid,actor_email:auth.currentUser.email||'',created_at_ms:Date.now(),created_at:serverTimestamp()}); }
export async function loadCustomerActivity(customerId,max=150){ const s=await getDocs(query(collection(db,C.customers,customerId,'activity'),orderBy('created_at_ms','desc'),limit(max))); return s.docs.map(d=>({id:d.id,...d.data()})); }
async function duplicatePhoneOwner(number,existingId=''){ if(!number)return null; try{const r=await getDoc(doc(db,C.phone,number));if(r.exists()&&r.data().customer_id&&r.data().customer_id!==existingId)return r.data().customer_id;}catch{} for(const field of ['phone_normalized','alternate_phone_normalized']){try{const q=await getDocs(query(collection(db,C.customers),where(field,'==',number),limit(3)));const hit=q.docs.find(d=>d.id!==existingId);if(hit)return hit.id;}catch{}} return null; }
export async function saveCustomer(data,existingId=null){
 const now=Date.now(),uid=auth.currentUser.uid,email=auth.currentUser.email||'',name=String(data.name||'').trim(),phone=String(data.phone||'').trim(),alt=String(data.alternate_phone||'').trim(),pn=phoneNorm(phone),an=phoneNorm(alt);if(name.length<2)throw new Error('اكتب اسم العميل');if(pn.length<8)throw new Error('اكتب رقم واتساب صحيح');if(an&&an.length<8)throw new Error('رقم الموبايل البديل غير صحيح');if(an&&an===pn)throw new Error('رقم الموبايل البديل مطابق للرقم الأساسي');
 for(const n of [pn,an].filter(Boolean)){const owner=await duplicatePhoneOwner(n,existingId||'');if(owner)throw new Error(`رقم الموبايل ${n} مسجل بالفعل لعميل آخر`);}
 const ref=existingId?doc(db,C.customers,existingId):doc(collection(db,C.customers)),old=existingId?await getDoc(ref):null,oldData=old?.exists()?old.data():{},oldNums=[phoneNorm(oldData?.phone),phoneNorm(oldData?.alternate_phone)].filter(Boolean),newNums=[pn,an].filter(Boolean);
 const clean={file_number:data.file_number||oldData?.file_number||`C-${String(now).slice(-7)}`,name,name_search:normalize(name),phone,phone_normalized:pn,alternate_phone:alt,alternate_phone_normalized:an,age:String(data.age||''),birth_date:data.birth_date||'',gender:data.gender||'',address:data.address||'',address_search:normalize(data.address||''),notes:data.notes||'',important_alert:data.important_alert||'',tags:data.tags||[],tags_search:(data.tags||[]).map(normalize),default_discount_percent:Number(data.default_discount_percent||0),updated_at_ms:now,updated_at:serverTimestamp(),updated_by_uid:uid,updated_by_email:email};if(!existingId)Object.assign(clean,{created_at_ms:now,created_at:serverTimestamp(),created_by_uid:uid,created_by_email:email,is_blacklisted:false,blacklist_reason:'',blacklisted_at_ms:0,is_archived:false,archived_at_ms:0});
 const b=writeBatch(db);b.set(ref,clean,{merge:true});for(const n of newNums)b.set(doc(db,C.phone,n),{customer_id:ref.id,phone:n,updated_at_ms:now,updated_by_uid:uid},{merge:true});for(const n of oldNums.filter(n=>!newNums.includes(n))){try{const r=await getDoc(doc(db,C.phone,n));if(r.exists()&&r.data().customer_id===ref.id)b.delete(r.ref)}catch{}}
 await b.commit();await audit(existingId?'customer_update':'customer_create','customer',ref.id,existingId?'تعديل بيانات العميل':'إنشاء عميل',`${name} • ${clean.file_number}`,ref.id,'');await addCustomerActivity(ref.id,existingId?'customer_update':'customer_create',existingId?'تعديل بيانات العميل':'إنشاء عميل',`${name} • ${clean.file_number}`);return {id:ref.id,...clean};
}
export async function loadCustomerOrders(customerId,max=100){ const s=await getDocs(query(collection(db,C.customers,customerId,'orders'),orderBy('created_at_ms','desc'),limit(max))); return s.docs.map(d=>({id:d.id,...d.data()})); }
export async function createOrder(customer,items,{discountPercent=0,paidAmount=0,notes=''}={}){
 const now=Date.now(), uid=auth.currentUser.uid, email=auth.currentUser.email||'', ref=doc(collection(db,C.customers,customer.id,'orders'));
 const subtotal=items.reduce((a,x)=>a+Number(x.customer_price||0),0), dp=Math.max(0,Math.min(100,Number(discountPercent||0))), discount=subtotal*dp/100, total=Math.max(0,subtotal-discount), paid=Math.max(0,Math.min(total,Number(paidAmount||0))), remaining=Math.max(0,total-paid), paymentStatus=remaining<=.001?'paid':paid>0?'partial':'unpaid', orderNumber=makeOrderNumber(now,ref.id);
 const data={order_number:orderNumber,operation_id:ref.id,customer_id:customer.id,customer_file_number:customer.file_number||'',customer_name:customer.name,customer_phone:customer.phone||'',customer_age:String(customer.age||''),customer_gender:String(customer.gender||''),items,tests_count:items.length,subtotal_customer_price:subtotal,discount_amount:discount,discount_percent:dp,total_customer_price:total,payment_status:paymentStatus,workflow_status:'sent_to_lab',status_history:[{status:'sent_to_lab',at_ms:now,by_uid:uid,by_email:email}],paid_amount:paid,remaining_amount:remaining,notes:String(notes||'').trim(),created_at_ms:now,created_at:serverTimestamp(),created_by_uid:uid,created_by_email:email,updated_at_ms:now,updated_at:serverTimestamp(),updated_by_uid:uid,updated_by_email:email,edit_count:0,is_voided:false,void_reason:''};
 const b=writeBatch(db);b.set(ref,data);if(paid>0){const pr=doc(collection(ref,'payments'));b.set(pr,{operation_id:pr.id,customer_id:customer.id,order_id:ref.id,amount:paid,note:'دفعة عند إنشاء الطلب',created_at_ms:now,created_at:serverTimestamp(),created_by_uid:uid,created_by_email:email});}await b.commit();await audit('order_create','order',ref.id,'إنشاء طلب',`${orderNumber} • ${items.length} تحليل • إجمالي ${money(total)}`,customer.id,ref.id);await addCustomerActivity(customer.id,'order',`طلب جديد ${orderNumber}`,`${items.length} تحليل • تم الإرسال للمعمل`);return {id:ref.id,customerId:customer.id,...data};
}
export async function setWorkflow(customerId,orderId,status){
 const allowed=['new','sent_to_lab','processing','ready','delivered','cancelled'];if(!allowed.includes(status))throw new Error('حالة غير صحيحة');const now=Date.now(),email=auth.currentUser.email||'',uid=auth.currentUser.uid,ref=doc(db,C.customers,customerId,'orders',orderId);await updateDoc(ref,{workflow_status:status,status_history:arrayUnion({status,at_ms:now,by_uid:uid,by_email:email}),updated_at_ms:now,updated_at:serverTimestamp(),updated_by_uid:uid,updated_by_email:email,edit_count:increment(1)});await audit('order_workflow_status','order',orderId,'تحديث حالة الطلب',status,customerId,orderId);await addCustomerActivity(customerId,'order_status','تحديث حالة الطلب',status);
}
export async function collectPayment(customerId,order,amount,note=''){ amount=Number(amount||0); if(amount<=0||amount>Number(order.remaining_amount||0)+.001)throw new Error('قيمة التحصيل غير صحيحة'); const ref=doc(db,C.customers,customerId,'orders',order.id), pr=doc(collection(ref,'payments')); const paid=Number(order.paid_amount||0)+amount,total=Number(order.total_customer_price||0),remaining=Math.max(0,total-paid),status=remaining<=.001?'paid':'partial',now=Date.now(),uid=auth.currentUser.uid,email=auth.currentUser.email||''; const b=writeBatch(db); b.update(ref,{paid_amount:paid,remaining_amount:remaining,payment_status:status,updated_at_ms:now,updated_at:serverTimestamp(),updated_by_uid:uid,updated_by_email:email,edit_count:increment(1)}); b.set(pr,{operation_id:pr.id,customer_id:customerId,order_id:order.id,amount,note,created_at_ms:now,created_at:serverTimestamp(),created_by_uid:uid,created_by_email:email}); await b.commit(); await audit('payment_collect','payment',pr.id,'تحصيل دفعة',`${order.order_number} • ${money(amount)}`,customerId,order.id); await addCustomerActivity(customerId,'payment','تحصيل دفعة',`${order.order_number} • ${money(amount)}`); }
export async function voidOrder(customerId,orderId,reason){
 const clean=String(reason||'').trim();if(clean.length<3)throw new Error('اكتب سبب الإلغاء');const ref=doc(db,C.customers,customerId,'orders',orderId),now=Date.now(),uid=auth.currentUser.uid,email=auth.currentUser.email||'';await updateDoc(ref,{is_voided:true,void_reason:clean,voided_at_ms:now,voided_by_uid:uid,voided_by_email:email,workflow_status:'cancelled',status_history:arrayUnion({status:'cancelled',at_ms:now,by_uid:uid,by_email:email}),updated_at_ms:now,updated_at:serverTimestamp(),updated_by_uid:uid,updated_by_email:email,edit_count:increment(1)});await audit('order_void','order',orderId,'إلغاء طلب',clean,customerId,orderId);await addCustomerActivity(customerId,'order_void','إلغاء طلب',clean);
}
export async function audit(action,entityType,entityId,title,details,customerId='',orderId=''){
 const ref=doc(collection(db,C.audits)),now=Date.now();let acting={};
 try{const raw=localStorage.getItem('tahalil_acting_user_v117');if(raw){const p=JSON.parse(raw);if(p?.uid)acting={actor_mode:'impersonation',acting_as_uid:p.uid,acting_as_email:p.email||'',acting_as_display_name:p.display_name||''};}}catch{}
 await setDoc(ref,{operation_id:ref.id,action,entity_type:entityType,entity_id:entityId,customer_id:customerId,order_id:orderId,title,details,actor_uid:auth.currentUser.uid,actor_email:auth.currentUser.email||'',...acting,created_at_ms:now,created_at:serverTimestamp(),was_offline:!navigator.onLine});
}
export async function listWorklist(max=300){
  const start=new Date(); start.setHours(0,0,0,0);
  const cs=await getDocs(collection(db,C.customers));
  const chunks=await Promise.all(cs.docs.map(async c=>{ try{ const s=await getDocs(query(collection(db,C.customers,c.id,'orders'),where('created_at_ms','>=',start.getTime()),orderBy('created_at_ms','desc'),limit(max))); return s.docs.map(d=>({id:d.id,customerId:c.id,...d.data()})); }catch{return [];} }));
  return chunks.flat().filter(x=>!x.is_voided).sort((a,b)=>(b.created_at_ms||0)-(a.created_at_ms||0)).slice(0,max);
}
export function watchWorklist(cb,max=300){
  let stopped=false, customerUnsub=null, orderUnsubs=[], byCustomer=new Map();
  const emit=()=>{ if(stopped)return; const rows=[...byCustomer.values()].flat().filter(x=>!x.is_voided).sort((a,b)=>(b.created_at_ms||0)-(a.created_at_ms||0)).slice(0,max); cb(rows); };
  customerUnsub=onSnapshot(collection(db,C.customers),snap=>{
    orderUnsubs.forEach(u=>u()); orderUnsubs=[]; byCustomer.clear(); const start=new Date(); start.setHours(0,0,0,0);
    snap.docs.forEach(c=>{ const q=query(collection(db,C.customers,c.id,'orders'),where('created_at_ms','>=',start.getTime()),orderBy('created_at_ms','desc'),limit(max)); orderUnsubs.push(onSnapshot(q,os=>{byCustomer.set(c.id,os.docs.map(d=>({id:d.id,customerId:c.id,...d.data()})));emit();},()=>{})); }); emit();
  },e=>cb([],e));
  return ()=>{stopped=true; if(customerUnsub)customerUnsub();orderUnsubs.forEach(u=>u());};
}

function mapOrderDoc(d){const x=d.data();return {id:d.id,customerId:x.customer_id||d.ref?.parent?.parent?.id||'',...x};}
function labVisible(x){return !x.is_voided&&['sent_to_lab','processing','ready'].includes(String(x.workflow_status||''));}
function sortByUpdate(rows){return rows.sort((a,b)=>Number(b.updated_at_ms||b.created_at_ms||0)-Number(a.updated_at_ms||a.created_at_ms||0));}

export async function listLabOrders(max=200){
 if(!auth.currentUser)throw new Error('سجل الدخول أولًا');
 try{const s=await getDocs(query(collectionGroup(db,'orders'),orderBy('created_at_ms','desc'),limit(max)));return sortByUpdate(s.docs.map(mapOrderDoc).filter(labVisible)).slice(0,max);}
 catch{const s=await getDocs(collectionGroup(db,'orders'));return sortByUpdate(s.docs.map(mapOrderDoc).filter(labVisible)).slice(0,max);}
}

export function watchLabOrders(cb,max=200){
 let stopped=false,unsub=null;
 const attach=(fallback=false)=>{if(stopped)return;try{unsub?.()}catch{}const q=fallback?collectionGroup(db,'orders'):query(collectionGroup(db,'orders'),orderBy('created_at_ms','desc'),limit(max));unsub=onSnapshot(q,s=>{if(stopped)return;cb(sortByUpdate(s.docs.map(mapOrderDoc).filter(labVisible)).slice(0,max));},e=>{if(!fallback)attach(true);else cb([],e);});};
 attach(false);return()=>{stopped=true;try{unsub?.()}catch{}};
}

export function watchSharedOrders(cb,max=200){
 let stopped=false,unsub=null;
 const attach=(fallback=false)=>{if(stopped)return;try{unsub?.()}catch{}const q=fallback?collectionGroup(db,'orders'):query(collectionGroup(db,'orders'),orderBy('updated_at_ms','desc'),limit(max));unsub=onSnapshot(q,s=>{if(stopped)return;const rows=sortByUpdate(s.docs.map(mapOrderDoc)).slice(0,max);cb(rows);},e=>{if(!fallback)attach(true);else cb([],e);});};
 attach(false);return()=>{stopped=true;try{unsub?.()}catch{}};
}

export async function labAcceptOrder(order){
 const now=Date.now(),uid=auth.currentUser.uid,email=auth.currentUser.email||'',ref=doc(db,C.customers,order.customerId||order.customer_id,'orders',order.id);await updateDoc(ref,{workflow_status:'processing',status_history:arrayUnion({status:'processing',at_ms:now,by_uid:uid,by_email:email}),updated_at_ms:now,updated_at:serverTimestamp(),updated_by_uid:uid,updated_by_email:email});await audit('lab_accept_order','order',order.id,'المعمل استلم الطلب',order.order_number||'',order.customerId||order.customer_id,order.id);
}

export async function labEditOrderDetails(order,{customerName,customerPhone,customerAge,customerGender,notes}){
 const now=Date.now(),uid=auth.currentUser.uid,email=auth.currentUser.email||'',customerId=order.customerId||order.customer_id,ref=doc(db,C.customers,customerId,'orders',order.id),patch={customer_name:String(customerName||'').trim(),customer_phone:String(customerPhone||'').trim(),customer_age:String(customerAge||'').trim(),customer_gender:String(customerGender||'').trim(),notes:String(notes||'').trim(),updated_at_ms:now,updated_at:serverTimestamp(),updated_by_uid:uid,updated_by_email:email,edit_count:increment(1)};
 if(String(order.workflow_status||'')==='sent_to_lab'){patch.workflow_status='processing';patch.status_history=arrayUnion({status:'processing',at_ms:now,by_uid:uid,by_email:email},{status:'edited_by_lab',at_ms:now,by_uid:uid,by_email:email});}else patch.status_history=arrayUnion({status:'edited_by_lab',at_ms:now,by_uid:uid,by_email:email});
 await updateDoc(ref,patch);await audit('lab_order_edit','order',order.id,'تعديل الطلب بواسطة المعمل',order.order_number||'',customerId,order.id);
}

export async function labCancelOrder(order){
 const now=Date.now(),uid=auth.currentUser.uid,email=auth.currentUser.email||'',customerId=order.customerId||order.customer_id,ref=doc(db,C.customers,customerId,'orders',order.id);await updateDoc(ref,{is_voided:true,void_reason:'إلغاء بواسطة المعمل',voided_at_ms:now,voided_by_uid:uid,voided_by_email:email,workflow_status:'cancelled',status_history:arrayUnion({status:'cancelled',at_ms:now,by_uid:uid,by_email:email}),updated_at_ms:now,updated_at:serverTimestamp(),updated_by_uid:uid,updated_by_email:email});await audit('lab_order_cancel','order',order.id,'إلغاء طلب بواسطة المعمل',order.order_number||'',customerId,order.id);
}

function extForType(type,name=''){const t=String(type||'').toLowerCase(),n=String(name||'').toLowerCase();if(t==='application/pdf'||n.endsWith('.pdf'))return 'pdf';if(t.includes('png')||n.endsWith('.png'))return 'png';if(t.includes('webp')||n.endsWith('.webp'))return 'webp';return 'jpg';}
export async function labUploadResults(order,files,onProgress=()=>{}){
 if(!files?.length)throw new Error('اختر صورة أو PDF للنتيجة');
 const urls=[],names=[],customerId=order.customerId||order.customer_id;let i=0;
 for(const file of files){
   const type=String(file.type||'').toLowerCase(),ext=extForType(type,file.name),name=`result_${i+1}.${ext}`;
   if(!(type==='application/pdf'||type.startsWith('image/')))throw new Error('الملفات المسموحة صور أو PDF فقط');
   const stored=await ResultStore.uploadResultFile(file,customerId,order.id,name);
   urls.push(stored.ref);names.push(name);i++;onProgress(i,files.length);
 }
 const now=Date.now(),uid=auth.currentUser.uid,email=auth.currentUser.email||'',ref=doc(db,C.customers,customerId,'orders',order.id);
 await updateDoc(ref,{result_urls:urls,result_names:names,result_sent_at_ms:now,result_sent_at:serverTimestamp(),result_uploaded_by_uid:uid,result_uploaded_by_email:email,workflow_status:'ready',status_history:arrayUnion({status:'ready',at_ms:now,by_uid:uid,by_email:email}),updated_at_ms:now,updated_at:serverTimestamp(),updated_by_uid:uid,updated_by_email:email});
 await audit('lab_result_send','order',order.id,'إرسال نتائج التحاليل',`${order.order_number||''} • ${files.length} ملف • Firestore chunks`,customerId,order.id);
 return {urls,names};
}
export async function readResultFile(storedRef){return ResultStore.readResultFile(storedRef);}
export function isFirestoreResultRef(storedRef){return ResultStore.isFirestoreResultRef(storedRef);}

export async function updateOrderContents(customerId,order,items,notes=''){
 if(!Array.isArray(items)||!items.length)throw new Error('لازم يكون في تحليل واحد على الأقل');const subtotal=items.reduce((a,x)=>a+Number(x.customer_price||0),0),dp=Math.max(0,Math.min(100,Number(order.discount_percent||0))),discount=subtotal*dp/100,total=Math.max(0,subtotal-discount),paid=Math.max(0,Math.min(total,Number(order.paid_amount||0))),remaining=Math.max(0,total-paid),paymentStatus=remaining<=.001?'paid':paid>0?'partial':'unpaid',now=Date.now(),uid=auth.currentUser.uid,email=auth.currentUser.email||'',ref=doc(db,C.customers,customerId,'orders',order.id);await updateDoc(ref,{items,tests_count:items.length,subtotal_customer_price:subtotal,discount_amount:discount,discount_percent:dp,total_customer_price:total,payment_status:paymentStatus,paid_amount:paid,remaining_amount:remaining,notes:String(notes||'').trim(),status_history:arrayUnion({status:'edited_by_clinic',at_ms:now,by_uid:uid,by_email:email}),updated_at_ms:now,updated_at:serverTimestamp(),updated_by_uid:uid,updated_by_email:email,edit_count:increment(1)});await audit('order_content_edit','order',order.id,'تعديل محتوى الطلب',`${order.order_number||''} • ${items.length} تحليل`,customerId,order.id);await addCustomerActivity(customerId,'order_update',`تعديل ${order.order_number||''}`,`${items.length} تحليل`);
}

export async function getDevice(uid,id){ const s=await getDoc(doc(db,C.users,uid,'devices',id)); return s.exists()?{id:s.id,...s.data()}:null; }
export async function listUsers(){ const pdb=privilegedDb(); const s=await getDocs(collection(pdb,C.users)); return s.docs.map(d=>({uid:d.id,...d.data()})); }
export async function createStaff({email,password,display_name,role,enabled=true}){ if(!/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^A-Za-z0-9]).{10,}$/.test(String(password))) throw new Error('كلمة المرور يجب أن تكون 10+ أحرف وتحتوي Upper + Lower + رقم + رمز'); const sec=await createSecondaryFirebase(); try{ const cred=await createUserWithEmailAndPassword(sec.auth,email,password); const p=roleDefaults(role),now=Date.now(); await setDoc(doc(privilegedDb(),C.users,cred.user.uid),{email:email.toLowerCase(),display_name,role,enabled,can_edit_customers:p.edit,can_discount:p.discount,can_collect_payments:p.pay,can_view_sales_reports:p.reports,created_at_ms:now,created_at:serverTimestamp(),updated_at_ms:now,updated_at:serverTimestamp()}); return cred.user.uid; } finally { await sec.cleanup(); } }
export async function updateUser(uid,patch){ const pdb=privilegedDb(); await setDoc(doc(pdb,C.users,uid),{...patch,updated_at_ms:Date.now(),updated_at:serverTimestamp()},{merge:true}); }
export async function listDevices(){ const s=await getDocs(collectionGroup(privilegedDb(),'devices')); return s.docs.map(d=>({id:d.id,uid:d.ref.parent.parent.id,...d.data()})); }
export async function setDevice(uid,id,status){ const pdb=privilegedDb(),now=Date.now(); if(status==='approved'){const ds=await getDocs(collection(pdb,C.users,uid,'devices'));const b=writeBatch(pdb);for(const d of ds.docs)if(d.id!==id&&d.data().status==='approved')b.set(d.ref,{status:'revoked',revoked_at_ms:now,updated_at_ms:now,updated_at:serverTimestamp(),updated_by_uid:auth.currentUser.uid},{merge:true});b.set(doc(pdb,C.users,uid,'devices',id),{status:'approved',approved_at_ms:now,approved_at:serverTimestamp(),approved_by_uid:auth.currentUser.uid,updated_at_ms:now,updated_at:serverTimestamp(),updated_by_uid:auth.currentUser.uid},{merge:true});await b.commit();}else await setDoc(doc(pdb,C.users,uid,'devices',id),{status,updated_at_ms:now,updated_at:serverTimestamp(),updated_by_uid:auth.currentUser.uid},{merge:true}); }
export async function listAudits(max=300){ const s=await getDocs(query(collection(privilegedDb(),C.audits),orderBy('created_at_ms','desc'),limit(max))); return s.docs.map(d=>({id:d.id,...d.data()})); }
export async function report(fromMs,toMs){ const s=await getDocs(query(collectionGroup(privilegedDb(),'orders'),where('created_at_ms','>=',fromMs),where('created_at_ms','<=',toMs),orderBy('created_at_ms','desc'))); return s.docs.map(d=>({id:d.id,customerId:d.ref.parent.parent.id,...d.data()})).filter(x=>!x.is_voided); }

export async function getCustomer(customerId){ const s=await getDoc(doc(db,C.customers,customerId)); return s.exists()?{id:s.id,...s.data()}:null; }
export async function updateOrderDetails(customerId,order,{discountPercent,paidAmount,notes}){
  const subtotal=Number(order.subtotal_customer_price||0), dp=Math.max(0,Math.min(100,Number(discountPercent||0))), discount=subtotal*dp/100, total=Math.max(0,subtotal-discount), paid=Math.max(0,Math.min(total,Number(paidAmount||0))), remaining=Math.max(0,total-paid), paymentStatus=remaining<=.001?'paid':paid>0?'partial':'unpaid', now=Date.now();
  const ref=doc(db,C.customers,customerId,'orders',order.id); await updateDoc(ref,{discount_amount:discount,discount_percent:dp,total_customer_price:total,payment_status:paymentStatus,paid_amount:paid,remaining_amount:remaining,notes:String(notes||'').trim(),updated_at_ms:now,updated_at:serverTimestamp(),updated_by_uid:auth.currentUser.uid,updated_by_email:auth.currentUser.email||'',edit_count:increment(1)}); await audit('order_update','order',order.id,'تعديل طلب',`${order.order_number} • إجمالي ${money(total)}`,customerId,order.id); await addCustomerActivity(customerId,'order_update',`تعديل ${order.order_number}`,`إجمالي ${money(total)}`);
}
export async function loadPayments(customerId,orderId){ const s=await getDocs(query(collection(db,C.customers,customerId,'orders',orderId,'payments'),orderBy('created_at_ms','desc'),limit(100))); return s.docs.map(d=>({id:d.id,...d.data()})); }
export async function setCustomerAdminState(customerId,patch){ const now=Date.now();await setDoc(doc(db,C.customers,customerId),{...patch,updated_at_ms:now,updated_at:serverTimestamp(),updated_by_uid:auth.currentUser.uid,updated_by_email:auth.currentUser.email||''},{merge:true}); }


export async function probeSystemHealth(){
  const started=performance.now(), checkedAt=Date.now();
  if(!navigator.onLine)return {firebaseReachable:false,latencyMs:null,checkedAt,message:'الجهاز غير متصل بالإنترنت'};
  try{await getDocFromServer(doc(privilegedDb(),C.users,MANAGER_UID));return {firebaseReachable:true,latencyMs:Math.max(0,Math.round(performance.now()-started)),checkedAt:Date.now(),message:'Firebase متصل ويستجيب'};}
  catch(e){return {firebaseReachable:false,latencyMs:null,checkedAt:Date.now(),message:String(e?.message||'تعذر الوصول إلى Firebase').slice(0,160)};}
}
function phoneNorm(v=''){return String(v).replace(/\D/g,'');}
export async function scanIntegrity(maxOrders=2000){
  const pdb=privilegedDb(); const cs=await getDocs(collection(pdb,C.customers)); const customers=cs.docs.map(d=>({id:d.id,...d.data()})); const issues=[];
  const owners=new Map(); for(const c of customers.filter(x=>!x.is_archived)){for(const ph of [...new Set([phoneNorm(c.phone),phoneNorm(c.alternate_phone)].filter(Boolean))]){if(!owners.has(ph))owners.set(ph,[]);owners.get(ph).push(c);}}
  for(const [ph,arr] of owners)if(new Set(arr.map(x=>x.id)).size>1)issues.push({id:`duplicate_phone_${ph}`,type:'duplicate_customer',severity:'critical',title:'رقم موبايل مكرر',details:`${ph} مسجل لأكثر من عميل: ${arr.map(x=>`${x.name||''} (${x.file_number||''})`).join(' • ')}`});
  const os=await getDocs(query(collectionGroup(pdb,'orders'),limit(maxOrders))); const nums=new Map(),ops=new Map();
  for(const d of os.docs){const x=d.data(),num=String(x.order_number||''),op=String(x.operation_id||''),cid=String(x.customer_id||'');if(num){if(!nums.has(num))nums.set(num,[]);nums.get(num).push(d.id)}if(op){if(!ops.has(op))ops.set(op,[]);ops.get(op).push(d.id)}
    if(!num||!cid)issues.push({id:`missing_identity_${d.id}`,type:'missing_identity',severity:'critical',title:'طلب ناقص البيانات الأساسية',details:`الطلب ${num||d.id} ناقص رقم الطلب أو معرف العميل.`,entityId:d.id,documentPath:d.ref.path});
    const sub=Number(x.subtotal_customer_price||0),disc=Number(x.discount_amount||0),tot=Number(x.total_customer_price||0),paid=Number(x.paid_amount||0),rem=Number(x.remaining_amount||0),expected=Math.max(0,sub-disc);
    if(Math.abs(expected-tot)>.02||Math.abs((paid+rem)-tot)>.02||paid<-.001||rem<-.001)issues.push({id:`money_${d.id}`,type:'financial_mismatch',severity:'critical',title:'عدم تطابق حسابات طلب',details:`${num||d.id} • قبل الخصم ${money(sub)} • الخصم ${money(disc)} • الإجمالي ${money(tot)} • المدفوع ${money(paid)} • المتبقي ${money(rem)}`,entityId:d.id,documentPath:d.ref.path});
    const st=String(x.payment_status||''),exp=rem<=.01&&tot>0?'paid':paid>.01?'partial':'unpaid';if(st&&st!==exp)issues.push({id:`payment_status_${d.id}`,type:'payment_status',severity:'warning',title:'حالة دفع غير متطابقة',details:`${num||d.id} حالته ${st} بينما الأرقام تشير إلى ${exp}.`,entityId:d.id,documentPath:d.ref.path});
  }
  for(const [num,ids] of nums)if(new Set(ids).size>1)issues.push({id:`duplicate_order_${num}`,type:'duplicate_order',severity:'critical',title:'رقم طلب مكرر',details:`رقم الطلب ${num} موجود في ${new Set(ids).size} سجلات.`});
  for(const [op,ids] of ops)if(new Set(ids).size>1)issues.push({id:`duplicate_operation_${op}`,type:'duplicate_operation',severity:'critical',title:'معرف عملية مكرر',details:`Operation ID ${op} ظهر في ${new Set(ids).size} طلبات.`});
  const sorted=[...new Map(issues.map(x=>[x.id,x])).values()].sort((a,b)=>(a.severity==='critical'?0:1)-(b.severity==='critical'?0:1)||a.type.localeCompare(b.type));
  return {checkedAt:Date.now(),customersScanned:customers.length,ordersScanned:os.docs.length,issueCount:sorted.length,criticalCount:sorted.filter(x=>x.severity==='critical').length,issues:sorted};
}
export async function repairIntegrity(issue){
  if(!issue?.documentPath||!['financial_mismatch','payment_status'].includes(issue.type))throw new Error('هذه الملاحظة تحتاج مراجعة يدوية');
  const pdb=privilegedDb(),ref=doc(pdb,issue.documentPath),snap=await getDocFromServer(ref);if(!snap.exists())throw new Error('السجل لم يعد موجودا');const x=snap.data(),sub=Math.max(0,Number(x.subtotal_customer_price||0)),disc=Math.min(sub,Math.max(0,Number(x.discount_amount||0))),tot=Math.max(0,sub-disc),paid=Math.min(tot,Math.max(0,Number(x.paid_amount||0))),rem=Math.max(0,tot-paid),status=rem<=.01&&tot>0?'paid':paid>.01?'partial':'unpaid';await setDoc(ref,{discount_amount:disc,discount_percent:sub>0?disc/sub*100:0,total_customer_price:tot,paid_amount:paid,remaining_amount:rem,payment_status:status,updated_at_ms:Date.now(),updated_at:serverTimestamp(),updated_by_uid:auth.currentUser.uid,updated_by_email:auth.currentUser.email||'',integrity_repaired:true},{merge:true});await audit('integrity_repair','order',issue.entityId||'','Data Integrity Repair','Recalculated totals and payment status without deleting data.','',issue.entityId||'');return true;
}
export async function buildAdminAlerts(health=null,integrity=null){
  const out=[],now=Date.now();
  try{const ds=await listDevices(),pending=ds.filter(x=>(x.status||'pending')==='pending');if(pending.length)out.push({id:`pending_devices_${pending.length}`,severity:'warning',title:'أجهزة تنتظر الاعتماد',details:`يوجد ${pending.length} جهاز في انتظار اعتماد المدير.`,createdAt:now});}catch{}
  if(integrity?.criticalCount>0)out.push({id:`integrity_${integrity.checkedAt}`,severity:'critical',title:'مشاكل في سلامة البيانات',details:`تم اكتشاف ${integrity.criticalCount} مشكلة مهمة من إجمالي ${integrity.issueCount}.`,createdAt:integrity.checkedAt});
  if(health?.firebaseReachable===false&&navigator.onLine)out.push({id:`firebase_unreachable_${Math.floor((health.checkedAt||now)/3600000)}`,severity:'critical',title:'Firebase لا يستجيب',details:health.message||'الإنترنت متاح لكن Firebase لم يستجب.',createdAt:health.checkedAt||now});
  else if(Number(health?.latencyMs||0)>=1200)out.push({id:`firebase_slow_${Math.floor((health.checkedAt||now)/3600000)}`,severity:'warning',title:'استجابة Firebase بطيئة',details:`زمن الاستجابة الحالي ${health.latencyMs} ms.`,createdAt:health.checkedAt||now});
  try{const wl=await listWorklist(500),debt=wl.filter(x=>!x.is_voided).reduce((a,x)=>a+Number(x.remaining_amount||0),0);if(debt>0)out.push({id:`debt_${new Date().toISOString().slice(0,10)}`,severity:'info',title:'مبالغ متبقية مفتوحة',details:`إجمالي المتبقي في الطلبات المفتوحة ${money(debt)} EGP.`,createdAt:now});}catch{}
  return out;
}
