import { db, getAdminDb, auth, MANAGER_UID } from './firebase.js';
const pDb=()=>auth.currentUser?.uid===MANAGER_UID?db:(getAdminDb()||db);
import { collection, doc, getDocs, writeBatch, Timestamp, GeoPoint, Bytes } from 'firebase/firestore';
const HEADER='TAHALIL_BACKUP_V1', APP_ID='com.aistudio.labtestsdirectory.egypt', ROUNDS=180000, CHUNK=350;
const enc=new TextEncoder(), dec=new TextDecoder();
const b64=b=>{let s='';for(const v of new Uint8Array(b))s+=String.fromCharCode(v);return btoa(s)};
const fromB64=s=>{const x=atob(s),a=new Uint8Array(x.length);for(let i=0;i<x.length;i++)a[i]=x.charCodeAt(i);return a};
function safeValue(v){
 if(v==null||typeof v==='string'||typeof v==='number'||typeof v==='boolean')return v;
 if(v instanceof Timestamp)return {__type:'timestamp',millis:v.toMillis()};
 if(v instanceof GeoPoint)return {__type:'geopoint',lat:v.latitude,lng:v.longitude};
 if(v instanceof Bytes)return {__type:'blob',base64:v.toBase64()};
 if(v?.path&&typeof v.path==='string'&&v.firestore)return {__type:'reference',path:v.path};
 if(Array.isArray(v))return v.map(safeValue);
 if(typeof v==='object'){const o={};for(const [k,x] of Object.entries(v))o[k]=safeValue(x);return o;}return String(v);
}
function restoreValue(v){if(Array.isArray(v))return v.map(restoreValue);if(v&&typeof v==='object'){if(v.__type==='timestamp')return Timestamp.fromMillis(Number(v.millis||0));if(v.__type==='geopoint')return new GeoPoint(Number(v.lat),Number(v.lng));if(v.__type==='blob')return Bytes.fromBase64String(String(v.base64||''));if(v.__type==='reference')return doc(pDb(),String(v.path));const o={};for(const [k,x] of Object.entries(v))o[k]=restoreValue(x);return o;}return v;}
async function derive(password,salt){const base=await crypto.subtle.importKey('raw',enc.encode(password),'PBKDF2',false,['deriveKey']);return crypto.subtle.deriveKey({name:'PBKDF2',hash:'SHA-256',salt,iterations:ROUNDS},base,{name:'AES-GCM',length:256},false,['encrypt','decrypt']);}
async function encrypt(plain,password){const salt=crypto.getRandomValues(new Uint8Array(16)),iv=crypto.getRandomValues(new Uint8Array(12)),key=await derive(password,salt);const ct=await crypto.subtle.encrypt({name:'AES-GCM',iv,additionalData:enc.encode(HEADER),tagLength:128},key,plain);return enc.encode([HEADER,b64(salt),b64(iv),b64(ct)].join('\n'));}
async function decrypt(bytes,password){const parts=dec.decode(bytes).split('\n');if(parts.length<4||parts[0]!==HEADER)throw new Error('ملف النسخة غير صالح');const salt=fromB64(parts[1]),iv=fromB64(parts[2]),ct=fromB64(parts.slice(3).join('\n')),key=await derive(password,salt);return new Uint8Array(await crypto.subtle.decrypt({name:'AES-GCM',iv,additionalData:enc.encode(HEADER),tagLength:128},key,ct));}
const pack=(id,data)=>({id,data:safeValue(data)});
export async function createBackup(password,settings={}){
 const d=pDb(); if(String(password).length<10)throw new Error('كلمة مرور النسخة الاحتياطية لازم تكون 10 أحرف على الأقل');
 const cs=await getDocs(collection(d,'customers'));const customers=cs.docs.map(d=>pack(d.id,d.data())),orders=[],payments=[];
 for(const c of cs.docs){const os=await getDocs(collection(d,'customers',c.id,'orders'));for(const o of os.docs){orders.push({customer_id:c.id,id:o.id,data:safeValue(o.data())});const ps=await getDocs(collection(d,'customers',c.id,'orders',o.id,'payments'));ps.docs.forEach(p=>payments.push({customer_id:c.id,order_id:o.id,id:p.id,data:safeValue(p.data())}));}}
 const simple={};for(const k of ['customer_price_overrides','lab2lab_prices','phone_registry']){const s=await getDocs(collection(d,k));simple[k]=s.docs.map(d=>pack(d.id,d.data()));}
 const root={schema_version:1,application_id:APP_ID,app_version_code:87,app_version_name:'System V87 Windows',created_at_ms:Date.now(),settings,customers,orders,payments,...simple};
 const encrypted=await encrypt(enc.encode(JSON.stringify(root)),password);return {bytes:encrypted,customers:customers.length,orders:orders.length,payments:payments.length};
}
function validId(x){x=String(x||'').trim();if(!x||x.length>512||x.includes('/'))throw new Error('معرف غير صالح داخل النسخة');return x;}
export async function restoreBackup(bytes,password){
 const d=pDb(); if(String(password).length<10)throw new Error('أدخل كلمة مرور النسخة الاحتياطية الصحيحة');const plain=await decrypt(bytes,password);let root;try{root=JSON.parse(dec.decode(plain))}catch{throw new Error('تعذر قراءة النسخة الاحتياطية');}
 if(root.schema_version!==1||root.application_id!==APP_ID)throw new Error('النسخة الاحتياطية لا تخص هذا النظام أو إصدارها غير مدعوم');
 const writes=[];for(const x of root.customers||[])writes.push([doc(d,'customers',validId(x.id)),restoreValue(x.data)]);for(const x of root.orders||[])writes.push([doc(d,'customers',validId(x.customer_id),'orders',validId(x.id)),restoreValue(x.data)]);for(const x of root.payments||[])writes.push([doc(d,'customers',validId(x.customer_id),'orders',validId(x.order_id),'payments',validId(x.id)),restoreValue(x.data)]);for(const k of ['customer_price_overrides','lab2lab_prices','phone_registry'])for(const x of root[k]||[])writes.push([doc(d,k,validId(x.id)),restoreValue(x.data)]);
 for(let i=0;i<writes.length;i+=CHUNK){const b=writeBatch(d);for(const [r,d] of writes.slice(i,i+CHUNK))b.set(r,d,{merge:true});await b.commit();}
 return {documentsWritten:writes.length,customers:(root.customers||[]).length,orders:(root.orders||[]).length,payments:(root.payments||[]).length,settings:root.settings||{}};
}
