# Tahalil Alakkad Unified System V117 — Windows

Windows desktop client aligned with Android V117 and the same Firebase project `tahalil-alakkad`.

## Same system / same data
- Firebase Auth users and profiles
- Device approvals
- Customers, orders, payments and prices
- Audit history
- Firestore realtime synchronization and offline cache
- Same result references used by Android V117

## V117 zero-cost results
- No Firebase Storage dependency
- No Cloud Functions dependency
- No Supabase dependency
- Images/PDF results up to 6 MB are split into ~420 KB raw chunks and stored in Firestore
- Schema is compatible with Android V117 (`fsr:/customerId/fileId`)
- Windows reconstructs the file locally and opens it with the default PDF/image viewer
- Legacy http(s) result links remain supported

## V117 operational parity
- Wide smart test search including Arabic, English, market names and common natural-language intents
- Abdelrahman-only one-way user switching, with a clear return action and audit context
- Lab operator sees no financial fields
- Lab cancellation is soft cancel, not permanent delete
- New clinic orders are saved and sent to the lab in one action
- Realtime shared-order watcher and native Windows notifications while the app is running

## Build
Use `build-windows-system-v117-github-firebase-only.yml` in GitHub Actions. It builds a portable x64 EXE and publishes it to GitHub Releases instead of Actions Artifacts, so the Actions artifact quota is not used.
