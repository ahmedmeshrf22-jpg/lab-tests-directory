const { app, BrowserWindow, ipcMain, dialog, shell, Notification } = require('electron');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const os = require('os');

function identityFile() { return path.join(app.getPath('userData'), 'device-id.txt'); }
function getDeviceId() {
  const file = identityFile();
  try {
    if (fs.existsSync(file)) return fs.readFileSync(file, 'utf8').trim();
    const id = crypto.createHash('sha256').update(`${crypto.randomUUID()}|${os.hostname()}|tahalil-alakkad-windows`).digest('hex').slice(0, 32);
    fs.mkdirSync(path.dirname(file), { recursive: true });
    fs.writeFileSync(file, id, 'utf8');
    return id;
  } catch { return crypto.createHash('sha256').update(`${os.hostname()}|fallback`).digest('hex').slice(0, 32); }
}

function createWindow() {
  const win = new BrowserWindow({
    width: 1440, height: 900, minWidth: 1050, minHeight: 700,
    show: false, backgroundColor: '#0b1220',
    webPreferences: {
      preload: path.join(__dirname, 'preload.cjs'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true
    }
  });
  win.removeMenu();
  win.webContents.session.setPermissionRequestHandler((_wc, permission, callback) => { callback(permission === 'media'); });
  win.loadFile(path.join(__dirname, '..', 'dist', 'index.html'));
  win.once('ready-to-show', () => { win.maximize(); win.show(); });
  win.webContents.setWindowOpenHandler(({ url }) => { shell.openExternal(url); return { action: 'deny' }; });
}

ipcMain.handle('device:identity', () => ({
  id: getDeviceId(), manufacturer: 'Windows PC', model: os.hostname(), windowsVersion: os.release(), platform: os.platform()
}));
ipcMain.handle('file:saveText', async (_e, { defaultName, content }) => {
  const result = await dialog.showSaveDialog({ defaultPath: defaultName, filters: [{ name: 'Files', extensions: ['json','txt','csv'] }] });
  if (result.canceled || !result.filePath) return null;
  fs.writeFileSync(result.filePath, content, 'utf8'); return result.filePath;
});
ipcMain.handle('file:print', async (event) => {
  const win = BrowserWindow.fromWebContents(event.sender);
  if (!win) return false;
  return new Promise((resolve,reject)=>{
    win.webContents.print({ silent:false, printBackground:true }, (success, reason)=> success ? resolve(true) : reject(new Error(reason || 'تعذر الطباعة')));
  });
});

ipcMain.handle('file:savePdf', async (event, { defaultName }) => {
  const win = BrowserWindow.fromWebContents(event.sender);
  const result = await dialog.showSaveDialog({ defaultPath: defaultName, filters: [{ name: 'PDF', extensions: ['pdf'] }] });
  if (result.canceled || !result.filePath) return null;
  const data = await win.webContents.printToPDF({ printBackground: true, pageSize: 'A4', margins: { marginType: 'default' } });
  fs.writeFileSync(result.filePath, data); return result.filePath;
});

ipcMain.handle('file:saveDataUrl', async (_event, { defaultName, dataUrl }) => {
  const ext = (defaultName.split('.').pop() || 'png').toLowerCase();
  const result = await dialog.showSaveDialog({ defaultPath: defaultName, filters: [{ name: ext.toUpperCase(), extensions: [ext] }] });
  if (result.canceled || !result.filePath) return null;
  const base64 = String(dataUrl || '').replace(/^data:[^;]+;base64,/, '');
  fs.writeFileSync(result.filePath, Buffer.from(base64, 'base64'));
  return result.filePath;
});


ipcMain.handle('admin:derivePassword', (_e, pin) => {
  const clean = String(pin || '').trim();
  if (!/^\d{6}$/.test(clean)) throw new Error('PIN must be 6 digits');
  let bytes = Buffer.from(`firebase|TahalilAlakkad.AdminGate.v60.2026|${clean}`, 'utf8');
  for (let i = 0; i < 40000; i++) bytes = crypto.createHash('sha256').update(bytes).digest();
  return 'Aa1!' + bytes.toString('hex').slice(0, 48);
});

ipcMain.handle('file:saveBytes', async (_event, { defaultName, bytes }) => {
  const result = await dialog.showSaveDialog({ defaultPath: defaultName, filters: [{ name: 'Tahalil Backup', extensions: ['tahbak'] }, { name: 'All files', extensions: ['*'] }] });
  if (result.canceled || !result.filePath) return null;
  fs.writeFileSync(result.filePath, Buffer.from(bytes));
  return result.filePath;
});
ipcMain.handle('file:openBytes', async () => {
  const result = await dialog.showOpenDialog({ properties: ['openFile'], filters: [{ name: 'Tahalil Backup', extensions: ['tahbak'] }, { name: 'All files', extensions: ['*'] }] });
  if (result.canceled || !result.filePaths[0]) return null;
  const filePath = result.filePaths[0];
  return { filePath, name: path.basename(filePath), bytes: Array.from(fs.readFileSync(filePath)) };
});

ipcMain.handle('result:openBytes', async (_event, { defaultName, bytes }) => {
  const safe = String(defaultName || 'result.pdf').replace(/[\/:*?"<>|\x00-\x1f]+/g, '_').slice(0, 120) || 'result.pdf';
  const dir = path.join(app.getPath('temp'), 'TahalilAlakkad', 'results');
  fs.mkdirSync(dir, { recursive: true });
  const filePath = path.join(dir, `${Date.now()}_${safe}`);
  fs.writeFileSync(filePath, Buffer.from(bytes || []));
  const error = await shell.openPath(filePath);
  if (error) throw new Error(error);
  return filePath;
});


ipcMain.handle('app:notify', (_event, payload = {}) => {
  try {
    if (!Notification.isSupported()) return false;
    const title = String(payload.title || 'تحاليل العقاد').slice(0, 120);
    const body = String(payload.body || '').slice(0, 500);
    new Notification({ title, body }).show();
    return true;
  } catch { return false; }
});

ipcMain.handle('shell:showItem', (_e, filePath) => { if (filePath) shell.showItemInFolder(filePath); });
ipcMain.handle('shell:openExternal', (_e, url) => shell.openExternal(url));

app.whenReady().then(createWindow);
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
