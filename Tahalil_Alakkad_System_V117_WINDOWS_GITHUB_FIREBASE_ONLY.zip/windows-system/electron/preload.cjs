const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('tahalilNative', {
  getDeviceIdentity: () => ipcRenderer.invoke('device:identity'),
  deriveAdminPassword: (pin) => ipcRenderer.invoke('admin:derivePassword', pin),
  saveText: (payload) => ipcRenderer.invoke('file:saveText', payload),
  savePdf: (payload) => ipcRenderer.invoke('file:savePdf', payload),
  print: () => ipcRenderer.invoke('file:print'),
  saveDataUrl: (payload) => ipcRenderer.invoke('file:saveDataUrl', payload),
  saveBytes: (payload) => ipcRenderer.invoke('file:saveBytes', payload),
  openBytes: () => ipcRenderer.invoke('file:openBytes'),
  openResultBytes: (payload) => ipcRenderer.invoke('result:openBytes', payload),
  showItem: (filePath) => ipcRenderer.invoke('shell:showItem', filePath),
  openExternal: (url) => ipcRenderer.invoke('shell:openExternal', url),
  notify: (payload) => ipcRenderer.invoke('app:notify', payload)
});
