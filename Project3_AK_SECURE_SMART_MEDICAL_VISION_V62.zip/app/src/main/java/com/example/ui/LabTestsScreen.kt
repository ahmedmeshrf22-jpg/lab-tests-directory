package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Percent
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.LocalOffer
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.outlined.Biotech
import androidx.compose.material.icons.outlined.SearchOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.R
import com.example.data.model.AppUserProfile
import com.example.data.model.Customer
import com.example.data.model.CustomerOrder
import com.example.data.model.LabTest
import com.example.settings.LocalAppSettings
import com.example.settings.appText
import com.example.settings.tr
import com.example.util.PdfGenerator
import com.example.util.TestDocumentImport
import kotlinx.coroutines.launch

@Composable
fun LabTestsApp(
    viewModel: LabTestsViewModel,
    currentUserEmail: String? = null,
    currentUserUid: String? = null,
    onLogout: (() -> Unit)? = null
) {
    val appSettings by viewModel.appSettings.collectAsState()
    val baseDensity = LocalDensity.current
    val layoutDirection = if (appSettings.language == "en") LayoutDirection.Ltr else LayoutDirection.Rtl
    CompositionLocalProvider(
        LocalLayoutDirection provides layoutDirection,
        LocalDensity provides Density(baseDensity.density, appSettings.fontScale),
        LocalAppSettings provides appSettings
    ) {
        val searchQuery by viewModel.searchQuery.collectAsState()
        val uiState by viewModel.uiState.collectAsState()
        val selectedTests by viewModel.selectedTests.collectAsState()
        val adminUnlocked by viewModel.adminUnlocked.collectAsState()
        val actualManager by viewModel.actualManager.collectAsState()
        val isOnline by viewModel.isOnline.collectAsState()
        val pendingSyncCount by viewModel.pendingSyncCount.collectAsState()
        val lastSuccessfulSyncMillis by viewModel.lastSuccessfulSyncMillis.collectAsState()
        val pendingSharedQrUri by viewModel.pendingSharedQrUri.collectAsState()
        val lab2LabPrices by viewModel.lab2LabPrices.collectAsState()
        val customerPriceOverrides by viewModel.customerPriceOverrides.collectAsState()
        // Same UI for everyone. The real manager has direct administration access;
        // staff receives the same access only after a successful admin PIN unlock.
        val isManager = actualManager || adminUnlocked
        var priceEditorTest by remember { mutableStateOf<LabTest?>(null) }
        var showManagerDashboard by remember { mutableStateOf(false) }
        var showSettingsDialog by remember { mutableStateOf(false) }
        var showAdminSettingsDialog by remember { mutableStateOf(false) }
        var showAdminPasswordDialog by remember { mutableStateOf(false) }
        var adminPin by remember { mutableStateOf("") }
        var adminUnlocking by remember { mutableStateOf(false) }
        var adminUnlockError by remember { mutableStateOf<String?>(null) }
        var pendingAdminAction by remember { mutableStateOf<(() -> Unit)?>(null) }
        var showCustomerSystem by remember { mutableStateOf(false) }
        var showOperationsV14 by remember { mutableStateOf(false) }
        var operationsInitialPage by remember { mutableStateOf("home") }
        var operationsInitialDebtsOnly by remember { mutableStateOf(false) }
        var operationsInitialRange by remember { mutableStateOf("today") }
        // V58: every account lands on the same unified home.
        var managerMainMode by remember(currentUserUid, currentUserEmail) { mutableStateOf("home") } // home | price_search | order | catalog
        var showOrderCustomerPicker by remember { mutableStateOf(false) }
        var showOrderCheckout by remember { mutableStateOf(false) }
        var activeOrderCustomer by remember { mutableStateOf<Customer?>(null) }
        val context = LocalContext.current
        var orderStatusMessage by remember { mutableStateOf<String?>(null) }
        var orderStatusSuccess by remember { mutableStateOf(true) }
        var importingTestsDocument by remember { mutableStateOf(false) }
        val documentImportScope = rememberCoroutineScope()
        val testsDocumentLauncher = rememberLauncherForActivityResult(
            contract = ActivityResultContracts.OpenDocument()
        ) { uri ->
            if (uri != null) {
                importingTestsDocument = true
                documentImportScope.launch {
                    val result = TestDocumentImport.readTests(context, uri)
                    importingTestsDocument = false
                    result.onSuccess { readResult ->
                        val count = viewModel.applyRecognizedTestsToSearch(readResult.text)
                        orderStatusSuccess = count > 0
                        orderStatusMessage = if (count > 0) {
                            when {
                                readResult.mode == TestDocumentImport.ReadMode.SMART_VISION -> tr(
                                    "تم التعرف الذكي على $count تحليل. راجع النتائج واختار المطلوب.",
                                    "$count tests detected with smart vision. Review the results and select the required tests."
                                )
                                readResult.fallbackReason == TestDocumentImport.SmartFallbackReason.OFFLINE -> tr(
                                    "تم التعرف محليا على $count تحليل. شغّل الإنترنت لاستخدام القراءة الذكية للخط اليدوي.",
                                    "$count tests detected locally. Connect to the internet to use smart handwriting vision."
                                )
                                else -> tr(
                                    "تم التعرف محليا على $count تحليل لأن القراءة الذكية غير متاحة حاليا. راجع النتائج.",
                                    "$count tests detected locally because smart vision is currently unavailable. Review the results."
                                )
                            }
                        } else {
                            when {
                                readResult.fallbackReason == TestDocumentImport.SmartFallbackReason.OFFLINE -> tr(
                                    "تمت قراءة الملف محليا لكن لم أجد تحاليل مطابقة. شغّل الإنترنت وجرب القراءة الذكية.",
                                    "The file was read locally but no matching tests were found. Connect to the internet and try smart vision."
                                )
                                else -> tr(
                                    "تمت قراءة الملف لكن لم أجد أسماء تحاليل مطابقة لقائمة التحاليل.",
                                    "The file was read, but no test names matched the catalogue."
                                )
                            }
                        }
                    }.onFailure { error ->
                        orderStatusSuccess = false
                        orderStatusMessage = tr(
                            "تعذر قراءة التحاليل من الملف: ${error.message ?: "الملف غير واضح"}",
                            "Unable to read tests from file: ${error.message ?: "The file is unclear"}"
                        )
                    }
                }
            }
        }
        var pendingOutputOrder by remember { mutableStateOf<CustomerOrder?>(null) }
        var pendingOutputCustomer by remember { mutableStateOf<Customer?>(null) }

        // Android system Back follows the in-app navigation stack instead of
        // dropping the user out of the current workflow/root screen.
        BackHandler(enabled = true) {
            when {
                pendingOutputOrder != null -> { pendingOutputOrder = null; pendingOutputCustomer = null }
                orderStatusMessage != null -> orderStatusMessage = null
                showOrderCheckout -> showOrderCheckout = false
                showOrderCustomerPicker -> showOrderCustomerPicker = false
                showCustomerSystem -> showCustomerSystem = false
                showOperationsV14 -> showOperationsV14 = false
                showManagerDashboard -> showManagerDashboard = false
                showAdminPasswordDialog -> { showAdminPasswordDialog = false; pendingAdminAction = null; adminUnlockError = null }
                showAdminSettingsDialog -> showAdminSettingsDialog = false
                showSettingsDialog -> showSettingsDialog = false
                managerMainMode != "home" -> {
                    managerMainMode = "home"
                    viewModel.clearSearch()
                }
                else -> Unit
            }
        }

        LaunchedEffect(currentUserEmail, currentUserUid) {
            viewModel.onAuthenticatedUserChanged(currentUserEmail, currentUserUid)
        }

        // Staff privileged surfaces close when the PIN session locks. The real manager
        // remains authorized by the signed-in manager account and never needs the PIN.
        LaunchedEffect(isManager) {
            if (!isManager) {
                showOperationsV14 = false
                showAdminSettingsDialog = false
                showManagerDashboard = false
                priceEditorTest = null
            }
        }

        // V39: when Android shares an image/PDF receipt to the app, open Customer Files.
        // The dialog consumes the URI and resolves the QR after login/unlock is complete.
        LaunchedEffect(pendingSharedQrUri) {
            if (!pendingSharedQrUri.isNullOrBlank()) showCustomerSystem = true
        }

        // V41 Focused Workspace navigation. The active task owns the screen;
        // every other task lives in the collapsed “More” section at the bottom.
        val openPriceWorkspace: () -> Unit = {
            viewModel.clearSearch()
            managerMainMode = "price_search"
        }
        val openOrderWorkspace: () -> Unit = {
            viewModel.clearSearch()
            managerMainMode = "order"
        }
        val openCustomersWorkspace: () -> Unit = { showCustomerSystem = true }
        val openCatalogWorkspace: () -> Unit = {
            viewModel.clearSearch()
            managerMainMode = "catalog"
        }
        val requireAdmin: (() -> Unit) -> Unit = { action ->
            if (isManager) {
                action()
            } else {
                pendingAdminAction = action
                adminPin = ""
                adminUnlockError = null
                showAdminPasswordDialog = true
            }
        }
        val openAdminPage: (String) -> Unit = { page ->
            requireAdmin {
                operationsInitialPage = page
                operationsInitialDebtsOnly = false
                operationsInitialRange = "today"
                showOperationsV14 = true
            }
        }
        val openAdminWorkspace: () -> Unit = { openAdminPage("home") }
        val openSettingsWorkspace: () -> Unit = { showSettingsDialog = true }
        val openAdminSettings: () -> Unit = { requireAdmin { showAdminSettingsDialog = true } }
        // V44: a staff-first visual shortcut. It opens the same order workspace,
        // then starts OCR immediately so the employee does not hunt for the import action.
        val openImportWorkspace: () -> Unit = {
            viewModel.clearSearch()
            managerMainMode = "order"
            testsDocumentLauncher.launch(arrayOf("image/*", "application/pdf"))
        }

        Scaffold(
            topBar = {
                Column {
                    TopHeader(
                        onLogout = onLogout,
                        // V55: settings stays a fixed gear in the top header for staff and manager.
                        showSettings = true,
                        onSettings = { showSettingsDialog = true },
                        showHome = managerMainMode != "home",
                        onHome = {
                            managerMainMode = "home"
                            viewModel.clearSearch()
                        }
                    )
                    // Keep the focused manager search clean; only surface sync status there
                    // when it actually needs attention (offline or pending writes).
                    val focusedManagerSearch = managerMainMode == "price_search"
                    if (!focusedManagerSearch || !isOnline || pendingSyncCount > 0) {
                        SyncStatusBar(
                            isOnline = isOnline,
                            pendingCount = pendingSyncCount,
                            lastSyncMillis = lastSuccessfulSyncMillis
                        )
                    }
                }
            },
            containerColor = if (appSettings.darkMode) Color(0xFF0B1220) else Color(0xFFF4F7FB)
        ) { paddingValues ->
            if (managerMainMode == "home") {
                ManagerHomeDashboard(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(paddingValues),
                    onSearch = openPriceWorkspace,
                    onNewOrder = openOrderWorkspace,
                    onImportTests = openImportWorkspace,
                    onCustomers = openCustomersWorkspace,
                    onQr = openCustomersWorkspace,
                    onAvailableTests = openCatalogWorkspace,
                    onAdminPage = openAdminPage,
                    onAdminSettings = openAdminSettings,
                    onSettings = openSettingsWorkspace,
                    onLockAdmin = { viewModel.lockAdmin() },
                    adminAccess = isManager,
                    showLockAdmin = adminUnlocked && !actualManager
                )
            } else {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(paddingValues)
                        .padding(horizontal = 14.dp)
                ) {
                    Spacer(modifier = Modifier.height(14.dp))

                    // V41: the selected task becomes the whole workspace.
                    // Related tools stay visible; unrelated navigation moves to “More” at the bottom.
                    val currentWorkspaceMode = managerMainMode
                    val showManagerWorkspaceActions = true

                    if (currentWorkspaceMode == "price_search") {
                        FocusedWorkspaceHeader(
                            icon = Icons.Default.Search,
                            title = appText("استعلام عن أسعار التحاليل", "Test price inquiry"),
                            subtitle = appText(
                                "البحث والقراءة من صورة أو PDF ونتائج الأسعار كلها في شاشة واحدة",
                                "Search, image/PDF reading and price results in one workspace"
                            ),
                            accent = Color(0xFF007E89)
                        )
                        Spacer(modifier = Modifier.height(10.dp))

                        SearchBox(
                            query = searchQuery,
                            onQueryChange = { viewModel.onQueryChanged(it) },
                            onClear = { viewModel.clearSearch() },
                            onImportDocument = {
                                testsDocumentLauncher.launch(arrayOf("image/*", "application/pdf"))
                            },
                            importingDocument = importingTestsDocument
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        MainContent(
                            uiState = uiState,
                            selectedTests = selectedTests,
                            isManager = isManager,
                            lab2LabPrices = lab2LabPrices,
                            customerPriceOverrides = customerPriceOverrides,
                            activeOrderCustomer = null,
                            onChooseCustomer = {},
                            onClearCustomer = {},
                            onSaveCustomerOrder = {},
                            onSelectTest = {},
                            onRemoveTest = {},
                            onEditPrices = { test -> requireAdmin { priceEditorTest = test } },
                            allowOrderSelection = false,
                            bottomContent = {
                                WorkspaceMoreSection(
                                    currentMode = "price_search",
                                    showManagerActions = showManagerWorkspaceActions,
                                    onOrder = openOrderWorkspace,
                                    onPrice = openPriceWorkspace,
                                    onCustomers = openCustomersWorkspace,
                                    onCatalog = openCatalogWorkspace,
                                    onSettings = openSettingsWorkspace,
                                    onAdmin = openAdminWorkspace
                                )
                            }
                        )
                    } else if (currentWorkspaceMode == "catalog") {
                        AvailableTestsScreen(
                            viewModel = viewModel,
                            isManager = isManager,
                            customerPriceOverrides = customerPriceOverrides,
                            lab2LabPrices = lab2LabPrices,
                            onEditPrices = { test -> requireAdmin { priceEditorTest = test } },
                            bottomContent = {
                                WorkspaceMoreSection(
                                    currentMode = "catalog",
                                    showManagerActions = showManagerWorkspaceActions,
                                    onOrder = openOrderWorkspace,
                                    onPrice = openPriceWorkspace,
                                    onCustomers = openCustomersWorkspace,
                                    onCatalog = openCatalogWorkspace,
                                    onSettings = openSettingsWorkspace,
                                    onAdmin = openAdminWorkspace
                                )
                            }
                        )
                    } else {
                        FocusedWorkspaceHeader(
                            icon = Icons.Default.AddCircle,
                            title = appText("طلب جديد", "New order"),
                            subtitle = appText(
                                "العميل + التحاليل + قراءة صورة/PDF + الحفظ في نفس شاشة العمل",
                                "Customer, tests, image/PDF reading and saving in one workspace"
                            ),
                            accent = Color(0xFF7C3AED)
                        )
                        Spacer(modifier = Modifier.height(10.dp))

                        OrderWorkspaceCustomerBar(
                            customer = activeOrderCustomer,
                            onChooseCustomer = { showOrderCustomerPicker = true },
                            onOpenCustomerFiles = openCustomersWorkspace,
                            onClearCustomer = { activeOrderCustomer = null }
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        SearchBox(
                            query = searchQuery,
                            onQueryChange = { viewModel.onQueryChanged(it) },
                            onClear = { viewModel.clearSearch() },
                            onImportDocument = {
                                testsDocumentLauncher.launch(arrayOf("image/*", "application/pdf"))
                            },
                            importingDocument = importingTestsDocument
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        MainContent(
                            uiState = uiState,
                            selectedTests = selectedTests,
                            isManager = isManager,
                            lab2LabPrices = lab2LabPrices,
                            customerPriceOverrides = customerPriceOverrides,
                            activeOrderCustomer = activeOrderCustomer,
                            onChooseCustomer = { showOrderCustomerPicker = true },
                            onClearCustomer = { activeOrderCustomer = null },
                            onSaveCustomerOrder = {
                                if (activeOrderCustomer != null && selectedTests.isNotEmpty()) {
                                    showOrderCheckout = true
                                }
                            },
                            onSelectTest = { test -> viewModel.addSelectedTest(test) },
                            onRemoveTest = { testId -> viewModel.removeSelectedTest(testId) },
                            onEditPrices = { test -> requireAdmin { priceEditorTest = test } },
                            allowOrderSelection = true,
                            bottomContent = {
                                WorkspaceMoreSection(
                                    currentMode = "order",
                                    showManagerActions = showManagerWorkspaceActions,
                                    onOrder = openOrderWorkspace,
                                    onPrice = openPriceWorkspace,
                                    onCustomers = openCustomersWorkspace,
                                    onCatalog = openCatalogWorkspace,
                                    onSettings = openSettingsWorkspace,
                                    onAdmin = openAdminWorkspace
                                )
                            }
                        )
                    }
                }
            }
        }


        if (showOperationsV14 && isManager) {
            OperationsV14Dialog(
                viewModel = viewModel,
                isManager = isManager,
                initialPage = operationsInitialPage,
                initialDebtsOnly = operationsInitialDebtsOnly,
                initialRange = operationsInitialRange,
                onDismiss = { showOperationsV14 = false }
            )
        }

        if (showCustomerSystem) {
            CustomerSystemDialog(
                viewModel = viewModel,
                selectedTests = selectedTests,
                onDismiss = { showCustomerSystem = false },
                onStartOrderForCustomer = { customer ->
                    activeOrderCustomer = customer
                    showCustomerSystem = false
                    managerMainMode = "order"
                            orderStatusMessage = "تم اختيار ${customer.name}. اختار التحاليل واحفظ الطلب."
                    orderStatusSuccess = true
                },
                initialQrUri = pendingSharedQrUri,
                onInitialQrConsumed = { uri -> viewModel.consumeSharedQrUri(uri) }
            )
        }

        if (showOrderCustomerPicker) {
            CustomerOrderFlowDialog(
                viewModel = viewModel,
                selectedTests = selectedTests,
                onDismiss = { showOrderCustomerPicker = false },
                onCustomerSelected = { customer ->
                    activeOrderCustomer = customer
                    showOrderCustomerPicker = false
                    orderStatusSuccess = true
                    orderStatusMessage = "تم ربط الطلب بالعميل ${customer.name}"
                    managerMainMode = "order"
                        }
            )
        }

        val checkoutCustomer = activeOrderCustomer
        if (showOrderCheckout && checkoutCustomer != null) {
            ProfessionalOrderCheckoutDialog(
                customer = checkoutCustomer,
                selectedTests = selectedTests,
                customerPriceOverrides = customerPriceOverrides,
                onDismiss = { showOrderCheckout = false },
                onConfirm = { discount, discountPercent, paymentStatus, paidAmount, notes, _ ->
                    viewModel.saveCustomerOrderAdvanced(
                        customer = checkoutCustomer,
                        tests = selectedTests,
                        discountAmount = discount,
                        discountPercent = discountPercent,
                        paymentStatus = paymentStatus,
                        paidAmount = paidAmount,
                        notes = notes
                    ) { order, msg ->
                        orderStatusSuccess = order != null
                        orderStatusMessage = msg
                        if (order != null) {
                            // V38: the order is saved first. Document generation/sharing is optional.
                            pendingOutputOrder = order
                            pendingOutputCustomer = checkoutCustomer
                            orderStatusMessage = null
                            showOrderCheckout = false
                            viewModel.clearSelectedTests()
                            activeOrderCustomer = null
                        }
                    }
                }
            )
        }

        val outputOrder = pendingOutputOrder
        val outputCustomer = pendingOutputCustomer
        if (outputOrder != null && outputCustomer != null) {
            OrderPdfShareDialog(
                order = outputOrder,
                customer = outputCustomer,
                onDismiss = {
                    pendingOutputOrder = null
                    pendingOutputCustomer = null
                }
            )
        }

        orderStatusMessage?.let { message ->
            AlertDialog(
                onDismissRequest = { orderStatusMessage = null },
                title = {
                    Text(
                        if (orderStatusSuccess) "تم" else "تعذر التنفيذ",
                        fontWeight = FontWeight.ExtraBold
                    )
                },
                text = { Text(message) },
                confirmButton = {
                    TextButton(onClick = { orderStatusMessage = null }) { Text(appText("حسنا", "OK")) }
                }
            )
        }

        if (showAdminPasswordDialog) {
            AlertDialog(
                onDismissRequest = {
                    if (!adminUnlocking) {
                        showAdminPasswordDialog = false
                        pendingAdminAction = null
                        adminUnlockError = null
                    }
                },
                title = {
                    Text(
                        appText("دخول الإدارة", "Administration access"),
                        fontWeight = FontWeight.ExtraBold
                    )
                },
                text = {
                    Column {
                        Text(
                            appText(
                                "اكتب PIN الإدارة المكون من 6 أرقام لفتح الخدمات الحساسة.",
                                "Enter the 6-digit admin PIN to unlock sensitive services."
                            ),
                            color = Color(0xFF64748B),
                            fontSize = 12.sp
                        )
                        Spacer(Modifier.height(10.dp))
                        OutlinedTextField(
                            value = adminPin,
                            onValueChange = { adminPin = it.filter(Char::isDigit).take(6); adminUnlockError = null },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            label = { Text(appText("PIN الإدارة", "Admin PIN")) },
                            leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null) },
                            visualTransformation = PasswordVisualTransformation(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword, imeAction = ImeAction.Done),
                            keyboardActions = KeyboardActions(onDone = {
                                if (!adminUnlocking) {
                                    adminUnlocking = true
                                    viewModel.unlockAdmin(adminPin) { success, message ->
                                        adminUnlocking = false
                                        if (success) {
                                            showAdminPasswordDialog = false
                                            adminUnlockError = null
                                            val action = pendingAdminAction
                                            pendingAdminAction = null
                                            action?.invoke()
                                        } else {
                                            adminUnlockError = message
                                        }
                                    }
                                }
                            })
                        )
                        adminUnlockError?.let {
                            Spacer(Modifier.height(7.dp))
                            Text(it, color = Color(0xFFB42318), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            if (!adminUnlocking) {
                                adminUnlocking = true
                                viewModel.unlockAdmin(adminPin) { success, message ->
                                    adminUnlocking = false
                                    if (success) {
                                        showAdminPasswordDialog = false
                                        adminUnlockError = null
                                        val action = pendingAdminAction
                                        pendingAdminAction = null
                                        action?.invoke()
                                    } else {
                                        adminUnlockError = message
                                    }
                                }
                            }
                        },
                        enabled = !adminUnlocking && adminPin.length == 6
                    ) {
                        if (adminUnlocking) {
                            CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                        } else {
                            Text(appText("فتح", "Unlock"), fontWeight = FontWeight.Bold)
                        }
                    }
                },
                dismissButton = {
                    TextButton(onClick = {
                        if (!adminUnlocking) {
                            showAdminPasswordDialog = false
                            pendingAdminAction = null
                            adminUnlockError = null
                        }
                    }) { Text(appText("إلغاء", "Cancel")) }
                }
            )
        }

        if (showSettingsDialog) {
            UserSettingsDialog(
                viewModel = viewModel,
                settings = appSettings,
                onDismiss = { showSettingsDialog = false }
            )
        }

        if (showAdminSettingsDialog && isManager) {
            ManagerSettingsDialog(
                viewModel = viewModel,
                settings = appSettings,
                currentUserEmail = currentUserEmail,
                currentUserUid = currentUserUid,
                onDismiss = { showAdminSettingsDialog = false },
                onOpenManagerDashboard = {
                    showAdminSettingsDialog = false
                    showManagerDashboard = true
                },
                onLogout = onLogout
            )
        }

        if (isManager && showManagerDashboard) {
            ManagerDashboardDialog(
                viewModel = viewModel,
                customerPriceOverrides = customerPriceOverrides,
                lab2LabPrices = lab2LabPrices,
                onDismiss = { showManagerDashboard = false },
                onEdit = { test ->
                    showManagerDashboard = false
                    priceEditorTest = test
                }
            )
        }

        if (isManager) {
            priceEditorTest?.let { test ->
                ManagerPriceEditorDialog(
                    test = test,
                    customerPrice = customerPriceOverrides[test.id] ?: test.customerPrice.orEmpty(),
                    lab2LabPrice = lab2LabPrices[test.id].orEmpty(),
                    onDismiss = { priceEditorTest = null },
                    onSave = { customer, lab, done ->
                        viewModel.saveManagerPrices(test, customer, lab) { success, message ->
                            if (success) priceEditorTest = null
                            done(success, message)
                        }
                    }
                )
            }
        }
    }
}

@Composable
private fun SyncStatusBar(
    isOnline: Boolean,
    pendingCount: Int,
    lastSyncMillis: Long
) {
    val bg = when {
        !isOnline -> Color(0xFFFFF3CD)
        pendingCount > 0 -> Color(0xFFE0F2FE)
        else -> Color(0xFFE8F5E9)
    }
    val fg = when {
        !isOnline -> Color(0xFF92400E)
        pendingCount > 0 -> Color(0xFF075985)
        else -> Color(0xFF166534)
    }
    val text = when {
        !isOnline && pendingCount > 0 -> appText(
            "Offline • $pendingCount عملية في انتظار المزامنة",
            "Offline • $pendingCount operation(s) waiting to sync"
        )
        !isOnline -> appText("Offline • سيتم الحفظ والمزامنة عند رجوع الإنترنت", "Offline • changes will sync when internet returns")
        pendingCount > 0 -> appText("جاري مزامنة $pendingCount عملية...", "Syncing $pendingCount operation(s)...")
        else -> appText("Online • تمت المزامنة", "Online • Synced")
    }
    Surface(color = bg, modifier = Modifier.fillMaxWidth()) {
        Text(
            text = text,
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
            color = fg,
            fontSize = 11.sp,
            lineHeight = 15.sp,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
private fun TopHeader(
    onLogout: (() -> Unit)? = null,
    showSettings: Boolean = false,
    onSettings: (() -> Unit)? = null,
    showHome: Boolean = false,
    onHome: (() -> Unit)? = null
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                Brush.horizontalGradient(
                    colors = listOf(
                        Color(0xFF003A5D),
                        Color(0xFF006D86),
                        Color(0xFF008FA0)
                    )
                )
            )
            .padding(horizontal = 16.dp, vertical = 16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                modifier = Modifier.weight(1f),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(18.dp),
                    color = Color.White,
                    shadowElevation = 3.dp,
                    modifier = Modifier.size(58.dp)
                ) {
                    Box(
                        modifier = Modifier.padding(5.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.ic_clinic_logo),
                            contentDescription = tr("شعار عيادات العقاد", "Alakkad Clinics logo"),
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                    Text(
                        text = appText("تحاليل العقاد", "Tahalil Alakkad"),
                        fontSize = 21.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.White,
                        letterSpacing = (-0.4).sp
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = appText("دليل التحاليل والأسعار", "Lab Tests & Prices"),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        color = Color(0xFFD9F4F4)
                    )
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                if (showHome && onHome != null) {
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = Color.White.copy(alpha = 0.12f)
                    ) {
                        IconButton(
                            onClick = onHome,
                            modifier = Modifier.size(44.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Home,
                                contentDescription = appText("الرئيسية", "Home"),
                                tint = Color.White,
                                modifier = Modifier.size(21.dp)
                            )
                        }
                    }
                }

                if (showSettings && onSettings != null) {
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = Color.White.copy(alpha = 0.12f)
                    ) {
                        IconButton(
                            onClick = onSettings,
                            modifier = Modifier
                                .size(44.dp)
                                .testTag("manager_settings_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Settings,
                                contentDescription = appText("إعدادات التطبيق", "App settings"),
                                tint = Color.White,
                                modifier = Modifier.size(21.dp)
                            )
                        }
                    }
                }

                if (onLogout != null) {
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = Color.White.copy(alpha = 0.12f)
                    ) {
                        IconButton(
                            onClick = onLogout,
                            modifier = Modifier
                                .size(44.dp)
                                .testTag("logout_button")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.Logout,
                                contentDescription = appText("تسجيل الخروج", "Logout"),
                                tint = Color.White,
                                modifier = Modifier.size(21.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StaffHomeDashboard(
    modifier: Modifier = Modifier,
    onSearch: () -> Unit,
    onNewOrder: () -> Unit,
    onImportTests: () -> Unit,
    onCustomers: () -> Unit,
    onQr: () -> Unit,
    onAvailableTests: () -> Unit,
    onSettings: () -> Unit
) {
    LazyColumn(
        modifier = modifier.padding(horizontal = 12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 28.dp)
    ) {
        item {
            Text(
                text = appText("كل الخدمات", "All services"),
                fontSize = 20.sp,
                lineHeight = 26.sp,
                fontWeight = FontWeight.ExtraBold,
                color = Color(0xFF17324D)
            )
            Spacer(Modifier.height(2.dp))
            Text(
                text = appText("اختار الخدمة من الأيقونة مباشرة", "Choose a service directly from its icon"),
                fontSize = 11.sp,
                color = Color(0xFF64748B)
            )
        }

        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GlossyServiceCard(Modifier.weight(1f), R.drawable.staff_search_3d, appText("بحث عن تحليل", "Find test"), onClick = onSearch)
                GlossyServiceCard(Modifier.weight(1f), R.drawable.staff_new_order_3d, appText("طلب جديد", "New order"), onClick = onNewOrder)
                GlossyServiceCard(Modifier.weight(1f), R.drawable.staff_pdf_3d, appText("صورة / PDF", "Image / PDF"), onClick = onImportTests)
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GlossyServiceCard(Modifier.weight(1f), R.drawable.staff_qr_3d, appText("QR العميل", "Customer QR"), onClick = onQr)
                GlossyServiceCard(Modifier.weight(1f), R.drawable.staff_customers_3d, appText("سجلات العملاء", "Customers"), onClick = onCustomers)
                GlossyServiceCard(Modifier.weight(1f), R.drawable.staff_tests_3d, appText("التحاليل المتاحة", "Available tests"), onClick = onAvailableTests)
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                GlossyServiceCard(Modifier.fillMaxWidth(0.32f), R.drawable.settings_3d, appText("الإعدادات", "Settings"), onClick = onSettings)
            }
        }
    }
}

@Composable
private fun GlossyServiceCard(
    modifier: Modifier = Modifier,
    iconRes: Int,
    title: String,
    locked: Boolean = false,
    onClick: () -> Unit
) {
    Card(
        onClick = onClick,
        modifier = modifier.heightIn(min = 142.dp),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFFCFEFF)),
        elevation = CardDefaults.cardElevation(defaultElevation = 7.dp),
        border = BorderStroke(1.dp, Color(0xFFE5EEF2))
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 7.dp, vertical = 9.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(94.dp)
                    .clip(RoundedCornerShape(19.dp))
                    .background(
                        Brush.verticalGradient(
                            listOf(Color(0xFFFFFFFF), Color(0xFFF4FBFC))
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    painter = painterResource(iconRes),
                    contentDescription = null,
                    modifier = Modifier.fillMaxSize().padding(3.dp),
                    contentScale = ContentScale.Fit
                )
                if (locked) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(5.dp)
                            .size(27.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF17324D)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Lock, contentDescription = null, tint = Color.White, modifier = Modifier.size(15.dp))
                    }
                }
            }
            Spacer(Modifier.height(7.dp))
            Text(
                text = title,
                fontSize = 11.sp,
                lineHeight = 15.sp,
                fontWeight = FontWeight.ExtraBold,
                color = Color(0xFF11315D),
                textAlign = TextAlign.Center,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun StaffFeatureIllustration(
    mainIcon: ImageVector,
    badgeIcon: ImageVector,
    accent: Color
) {
    Box(
        modifier = Modifier
            .size(76.dp)
            .clip(RoundedCornerShape(24.dp))
            .background(
                Brush.linearGradient(
                    colors = listOf(accent.copy(alpha = 0.08f), accent.copy(alpha = 0.18f))
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .size(52.dp)
                .clip(CircleShape)
                .background(Color.White),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = mainIcon,
                contentDescription = null,
                tint = accent,
                modifier = Modifier.size(31.dp)
            )
        }
        Box(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .size(27.dp)
                .clip(CircleShape)
                .background(accent),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = badgeIcon,
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(15.dp)
            )
        }
    }
}

@Composable
private fun StaffSecondaryActionCard(
    icon: ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(15.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFF8FAFC)),
        border = BorderStroke(1.dp, Color(0xFFE2E8F0))
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier.size(38.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFFEFF4F8)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = Color(0xFF475569), modifier = Modifier.size(20.dp))
            }
            Spacer(Modifier.width(9.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.ExtraBold, fontSize = 12.sp, color = Color(0xFF334155))
                Text(subtitle, fontSize = 9.sp, color = Color(0xFF94A3B8))
            }
        }
    }
}

@Composable
private fun ManagerHomeDashboard(
    modifier: Modifier = Modifier,
    onSearch: () -> Unit,
    onNewOrder: () -> Unit,
    onImportTests: () -> Unit,
    onCustomers: () -> Unit,
    onQr: () -> Unit,
    onAvailableTests: () -> Unit,
    onAdminPage: (String) -> Unit,
    onAdminSettings: () -> Unit,
    onSettings: () -> Unit,
    onLockAdmin: () -> Unit,
    adminAccess: Boolean,
    showLockAdmin: Boolean
) {
    LazyColumn(
        modifier = modifier.padding(horizontal = 12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 28.dp)
    ) {
        item {
            Text(appText("الخدمات اليومية", "Daily services"), fontSize = 19.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF17324D))
            Text(appText("نفس الشاشة ونفس الخدمات لكل المستخدمين", "The same screen and services for every user"), fontSize = 10.sp, color = Color(0xFF64748B))
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GlossyServiceCard(Modifier.weight(1f), R.drawable.staff_search_3d, appText("بحث عن تحليل", "Test search"), onClick = onSearch)
                GlossyServiceCard(Modifier.weight(1f), R.drawable.staff_new_order_3d, appText("طلب جديد", "New order"), onClick = onNewOrder)
                GlossyServiceCard(Modifier.weight(1f), R.drawable.staff_pdf_3d, appText("قراءة صورة / PDF", "Image / PDF"), onClick = onImportTests)
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GlossyServiceCard(Modifier.weight(1f), R.drawable.staff_qr_3d, appText("QR العميل", "Customer QR"), onClick = onQr)
                GlossyServiceCard(Modifier.weight(1f), R.drawable.staff_customers_3d, appText("سجلات العملاء", "Customers"), onClick = onCustomers)
                GlossyServiceCard(Modifier.weight(1f), R.drawable.staff_tests_3d, appText("التحاليل المتاحة", "Available tests"), onClick = onAvailableTests)
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GlossyServiceCard(Modifier.weight(1f), R.drawable.settings_3d, appText("الإعدادات", "Settings"), onClick = onSettings)
                Spacer(Modifier.weight(2f))
            }
        }

        item {
            Spacer(Modifier.height(2.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(appText("خدمات الإدارة", "Administration"), fontSize = 19.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF17324D))
                Spacer(Modifier.width(8.dp))
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = if (adminAccess) Color(0xFFE8F7F1) else Color(0xFFFFF3E8)
                ) {
                    Text(
                        text = if (adminAccess) appText("مفتوحة", "Unlocked") else appText("PIN", "PIN"),
                        modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp),
                        fontSize = 9.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = if (adminAccess) Color(0xFF157347) else Color(0xFF9A4F00)
                    )
                }
                if (showLockAdmin) {
                    Spacer(Modifier.width(6.dp))
                    TextButton(onClick = onLockAdmin, contentPadding = PaddingValues(horizontal = 7.dp, vertical = 2.dp)) {
                        Icon(Icons.Default.Lock, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(Modifier.width(4.dp))
                        Text(appText("قفل", "Lock"), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
            Text(appText("الأيقونات ظاهرة للجميع؛ المدير يدخل مباشرة والاستاف يحتاج PIN", "Visible to everyone; the manager opens them directly and staff needs the PIN"), fontSize = 10.sp, color = Color(0xFF64748B))
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GlossyServiceCard(Modifier.weight(1f), R.drawable.mgr_reports_3d, appText("التقارير", "Reports"), locked = !adminAccess) { onAdminPage("reports") }
                GlossyServiceCard(Modifier.weight(1f), R.drawable.mgr_staff_3d, appText("حسابات الاستاف", "Staff accounts"), locked = !adminAccess) { onAdminPage("users") }
                GlossyServiceCard(Modifier.weight(1f), R.drawable.mgr_devices_3d, appText("الأجهزة", "Devices"), locked = !adminAccess) { onAdminPage("devices") }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GlossyServiceCard(Modifier.weight(1f), R.drawable.mgr_alerts_3d, appText("التنبيهات", "Alerts"), locked = !adminAccess) { onAdminPage("alerts") }
                GlossyServiceCard(Modifier.weight(1f), R.drawable.mgr_integrity_3d, appText("سلامة البيانات", "Data integrity"), locked = !adminAccess) { onAdminPage("integrity") }
                GlossyServiceCard(Modifier.weight(1f), R.drawable.mgr_health_3d, appText("حالة النظام", "System health"), locked = !adminAccess) { onAdminPage("health") }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GlossyServiceCard(Modifier.weight(1f), R.drawable.mgr_audit_3d, appText("سجل العمليات", "Audit log"), locked = !adminAccess) { onAdminPage("audit") }
                GlossyServiceCard(Modifier.weight(1f), R.drawable.settings_3d, appText("إعدادات الإدارة", "Admin settings"), locked = !adminAccess, onClick = onAdminSettings)
                Spacer(Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun FocusedWorkspaceHeader(
    icon: ImageVector,
    title: String,
    subtitle: String,
    accent: Color
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, accent.copy(alpha = 0.18f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 13.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(11.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(accent.copy(alpha = 0.10f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = accent, modifier = Modifier.size(23.dp))
            }
            Column(Modifier.weight(1f)) {
                Text(
                    text = title,
                    fontSize = 19.sp,
                    lineHeight = 25.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color(0xFF17324D)
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    text = subtitle,
                    fontSize = 10.sp,
                    lineHeight = 15.sp,
                    fontWeight = FontWeight.Medium,
                    color = Color(0xFF64748B)
                )
            }
        }
    }
}

@Composable
private fun OrderWorkspaceCustomerBar(
    customer: Customer?,
    onChooseCustomer: () -> Unit,
    onOpenCustomerFiles: () -> Unit,
    onClearCustomer: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, Color(0xFFE3EAF2))
    ) {
        Column(Modifier.fillMaxWidth().padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFE7F5F7)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.People, contentDescription = null, tint = Color(0xFF007E89), modifier = Modifier.size(20.dp))
                }
                Spacer(Modifier.width(9.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        text = appText("بيانات العميل", "Customer"),
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 13.sp,
                        color = Color(0xFF17324D)
                    )
                    Text(
                        text = if (customer == null) {
                            appText("اختار العميل أو افتح سجلات العملاء والـ QR", "Choose a customer or open customer records and QR")
                        } else {
                            appText("العميل مرتبط بالطلب الحالي", "Customer linked to the current order")
                        },
                        fontSize = 10.sp,
                        lineHeight = 14.sp,
                        color = Color(0xFF64748B)
                    )
                }
                if (customer != null) {
                    IconButton(onClick = onClearCustomer, modifier = Modifier.size(36.dp)) {
                        Icon(Icons.Default.Close, contentDescription = appText("إلغاء ربط العميل", "Unlink customer"), tint = Color(0xFF64748B))
                    }
                }
            }

            if (customer != null) {
                Spacer(Modifier.height(8.dp))
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    color = Color(0xFFF4FAFB)
                ) {
                    Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 9.dp)) {
                        Text(customer.name, fontWeight = FontWeight.ExtraBold, color = Color(0xFF17324D))
                        Text(
                            text = listOf(customer.fileNumber, customer.phone).filter { it.isNotBlank() }.joinToString(" • "),
                            fontSize = 10.sp,
                            color = Color(0xFF64748B)
                        )
                    }
                }
            }

            Spacer(Modifier.height(9.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = onChooseCustomer,
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(13.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF007E89))
                ) {
                    Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(
                        text = if (customer == null) appText("اختيار عميل", "Choose customer") else appText("تغيير العميل", "Change customer"),
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp
                    )
                }
                OutlinedButton(
                    onClick = onOpenCustomerFiles,
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(13.dp),
                    border = BorderStroke(1.dp, Color(0xFFB8DDE1))
                ) {
                    Icon(Icons.Default.People, contentDescription = null, tint = Color(0xFF007E89), modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(appText("السجلات و QR", "Records & QR"), color = Color(0xFF007E89), fontWeight = FontWeight.Bold, fontSize = 11.sp)
                }
            }
        }
    }
}

@Composable
private fun WorkspaceMoreSection(
    currentMode: String,
    showManagerActions: Boolean,
    onOrder: () -> Unit,
    onPrice: () -> Unit,
    onCustomers: () -> Unit,
    onCatalog: () -> Unit,
    onSettings: () -> Unit,
    onAdmin: () -> Unit
) {
    var expanded by remember(currentMode) { mutableStateOf(false) }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFF8FAFC)),
        border = BorderStroke(1.dp, Color(0xFFE2E8F0))
    ) {
        Column(Modifier.fillMaxWidth().padding(10.dp)) {
            TextButton(
                onClick = { expanded = !expanded },
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.Tune, contentDescription = null, tint = Color(0xFF475569))
                Spacer(Modifier.width(8.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        text = appText("المزيد", "More"),
                        fontWeight = FontWeight.ExtraBold,
                        color = Color(0xFF334155),
                        textAlign = TextAlign.Start,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text(
                        text = appText("المهام اللي مش بتستخدمها دلوقتي", "Tasks you are not using right now"),
                        fontSize = 9.sp,
                        color = Color(0xFF94A3B8),
                        textAlign = TextAlign.Start,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                Text(
                    text = if (expanded) appText("إخفاء", "Hide") else appText("عرض", "Show"),
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF64748B)
                )
            }

            AnimatedVisibility(visible = expanded) {
                Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    if (currentMode != "order") {
                        WorkspaceMoreButton(Icons.Default.AddCircle, appText("طلب جديد", "New order"), onOrder)
                    }
                    if (currentMode != "price_search") {
                        WorkspaceMoreButton(Icons.Default.Search, appText("استعلام أسعار التحاليل", "Test price inquiry"), onPrice)
                    }
                    WorkspaceMoreButton(Icons.Default.People, appText("سجلات العملاء والـ QR", "Customer records & QR"), onClick = onCustomers)
                    if (currentMode != "catalog") {
                        WorkspaceMoreButton(Icons.Outlined.Biotech, appText("التحاليل المتاحة", "Available tests"), onCatalog)
                    }
                    WorkspaceMoreButton(Icons.Default.Settings, appText("الإعدادات", "Settings"), onClick = onSettings)

                    if (showManagerActions) {
                        WorkspaceMoreButton(Icons.Default.AdminPanelSettings, appText("خدمات الإدارة 🔒", "Administration 🔒"), onAdmin)
                    }
                }
            }
        }
    }
}

@Composable
private fun WorkspaceMoreButton(
    icon: ImageVector,
    title: String,
    onClick: () -> Unit
) {
    OutlinedButton(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(13.dp),
        border = BorderStroke(1.dp, Color(0xFFD8E1EA)),
        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp)
    ) {
        Icon(icon, contentDescription = null, tint = Color(0xFF475569), modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(8.dp))
        Text(
            text = title,
            modifier = Modifier.weight(1f),
            textAlign = TextAlign.Start,
            color = Color(0xFF334155),
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp
        )
    }
}

@Composable
private fun AvailableTestsScreen(
    viewModel: LabTestsViewModel,
    isManager: Boolean,
    customerPriceOverrides: Map<Int, String>,
    lab2LabPrices: Map<Int, String>,
    onEditPrices: (LabTest) -> Unit,
    bottomContent: (@Composable () -> Unit)? = null
) {
    var query by remember { mutableStateOf("") }
    val tests = remember(query) { viewModel.searchManagerTests(query) }

    Column(modifier = Modifier.fillMaxSize()) {
        Text(
            text = appText("التحاليل المتاحة", "Available tests"),
            fontSize = 20.sp,
            lineHeight = 26.sp,
            fontWeight = FontWeight.ExtraBold,
            color = Color(0xFF17324D)
        )
        Text(
            text = appText(
                "ابحث عن التحليل واعرض سعره مباشرة",
                "Search a test and view its price instantly"
            ),
            fontSize = 11.sp,
            lineHeight = 16.sp,
            color = Color(0xFF64748B)
        )

        Spacer(Modifier.height(12.dp))

        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            modifier = Modifier.fillMaxWidth().heightIn(min = 64.dp),
            singleLine = true,
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            placeholder = { Text(appText("ابحث باسم التحليل", "Search test name")) },
            shape = RoundedCornerShape(16.dp)
        )

        Spacer(Modifier.height(10.dp))

        Text(
            text = appText("عدد التحاليل: ${tests.size}", "Tests: ${tests.size}"),
            fontSize = 11.sp,
            lineHeight = 16.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF475569)
        )

        Spacer(Modifier.height(8.dp))

        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(bottom = 18.dp)
        ) {
            items(tests, key = { it.id }) { test ->
                AvailableTestPriceCard(
                    test = test,
                    customerPrice = customerPriceOverrides[test.id] ?: test.customerPrice,
                    lab2LabPrice = lab2LabPrices[test.id],
                    isManager = isManager,
                    onEditPrices = { onEditPrices(test) }
                )
            }

            if (bottomContent != null) {
                item(key = "catalog_workspace_more") {
                    Spacer(Modifier.height(8.dp))
                    bottomContent()
                }
            }
        }
    }
}

@Composable
private fun AvailableTestPriceCard(
    test: LabTest,
    customerPrice: String?,
    lab2LabPrice: String?,
    isManager: Boolean,
    onEditPrices: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(
                elevation = 3.dp,
                shape = RoundedCornerShape(18.dp),
                spotColor = Color(0x12000000)
            ),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, Color(0xFFE7ECF2))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.Top,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFFE7F5F7)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Outlined.Biotech,
                        contentDescription = null,
                        tint = Color(0xFF007E89)
                    )
                }

                Column(Modifier.weight(1f)) {
                    Text(
                        text = test.englishName,
                        fontSize = 14.sp,
                        lineHeight = 19.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color(0xFF17324D),
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (test.arabicName.isNotBlank()) {
                        Spacer(Modifier.height(2.dp))
                        Text(
                            text = test.arabicName,
                            fontSize = 12.sp,
                            lineHeight = 17.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFF475569),
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    if (
                        test.marketName.isNotBlank() &&
                        test.marketName != test.arabicName &&
                        test.marketName != test.englishName
                    ) {
                        Spacer(Modifier.height(3.dp))
                        Text(
                            text = appText(
                                "الاسم الدارج: ${test.marketName}",
                                "Market name: ${test.marketName}"
                            ),
                            fontSize = 10.sp,
                            lineHeight = 15.sp,
                            color = Color(0xFF64748B),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            Spacer(Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                PriceBox(
                    modifier = Modifier.weight(1f),
                    title = appText("سعر العميل", "Customer price"),
                    price = customerPrice,
                    backgroundColor = Color(0xFFEDF7FF),
                    borderColor = Color(0xFFCFE8F7),
                    titleColor = Color(0xFF28607E),
                    priceColor = Color(0xFF114D6B)
                )

                if (isManager) {
                    PriceBox(
                        modifier = Modifier.weight(1f),
                        title = "Lab 2 Lab",
                        price = lab2LabPrice,
                        backgroundColor = Color(0xFFF3F0FF),
                        borderColor = Color(0xFFDED7FF),
                        titleColor = Color(0xFF6550A5),
                        priceColor = Color(0xFF513B93)
                    )
                }
            }

            if (isManager) {
                Spacer(Modifier.height(10.dp))
                Button(
                    onClick = onEditPrices,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp)
                        .testTag("catalog_edit_prices_${test.id}"),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6D28D9))
                ) {
                    Icon(
                        imageVector = Icons.Default.Edit,
                        contentDescription = null,
                        modifier = Modifier.size(17.dp)
                    )
                    Spacer(Modifier.width(7.dp))
                    Text(
                        text = appText("تعديل الأسعار", "Edit prices"),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
private fun ActingAsUserBanner(
    profile: AppUserProfile,
    onReturnToManager: () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        color = Color(0xFFFFF7ED),
        border = BorderStroke(1.dp, Color(0xFFF59E0B).copy(alpha = 0.45f))
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Box(
                modifier = Modifier.size(36.dp).clip(CircleShape).background(Color(0xFFFFEDD5)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.People, contentDescription = null, tint = Color(0xFFC2410C), modifier = Modifier.size(19.dp))
            }
            Column(Modifier.weight(1f)) {
                Text(
                    text = "تعمل الآن بصلاحيات ${profile.displayName.ifBlank { profile.email }}",
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 12.sp,
                    color = Color(0xFF9A3412),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = "الحساب الفعلي: Abdelrahman",
                    fontSize = 9.sp,
                    color = Color(0xFF7C2D12)
                )
            }
            TextButton(onClick = onReturnToManager) {
                Text(appText("رجوع لـ Abdelrahman", "Back to Abdelrahman"), fontSize = 10.sp, fontWeight = FontWeight.ExtraBold)
            }
        }
    }
}

@Composable
private fun UserSwitcherDialog(
    viewModel: LabTestsViewModel,
    onDismiss: () -> Unit,
    onUserSelected: (AppUserProfile) -> Unit
) {
    val users by viewModel.users.collectAsState()
    var query by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(true) }
    var message by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        viewModel.loadUsers { success, result ->
            loading = false
            if (!success) message = result
        }
    }

    val filtered = remember(users, query) {
        val q = query.trim().lowercase()
        users.filter {
            it.enabled &&
                !LabTestsViewModel.isManagerAccount(it.email, it.uid) &&
                (q.isBlank() || it.displayName.lowercase().contains(q) || it.email.lowercase().contains(q))
        }
    }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(
            modifier = Modifier.fillMaxWidth(0.92f).height(560.dp),
            shape = RoundedCornerShape(24.dp),
            color = Color(0xFFF8FAFC),
            shadowElevation = 8.dp
        ) {
            Column(Modifier.fillMaxSize().padding(16.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(appText("تبديل المستخدم", "Switch user"), fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF17324D))
                        Text(appText("اختر مستخدمًا لتجربة واستخدام صلاحياته", "Choose a user to operate with their permissions"), fontSize = 11.sp, color = Color(0xFF64748B))
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = tr("إغلاق", "Close"))
                    }
                }

                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 72.dp),
                    singleLine = true,
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    placeholder = { Text(appText("ابحث بالاسم أو البريد", "Search by name or email")) },
                    shape = RoundedCornerShape(15.dp)
                )
                Spacer(Modifier.height(10.dp))

                when {
                    loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator()
                    }
                    message != null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text(message.orEmpty(), color = Color(0xFFB91C1C), fontWeight = FontWeight.Bold)
                    }
                    filtered.isEmpty() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text(appText("لا يوجد مستخدمون نشطون", "No active users"), color = Color(0xFF64748B))
                    }
                    else -> LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        contentPadding = PaddingValues(bottom = 12.dp)
                    ) {
                        items(filtered, key = { it.uid }) { profile ->
                            Card(
                                onClick = { onUserSelected(profile) },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = Color.White),
                                border = BorderStroke(1.dp, Color(0xFFE5EAF0))
                            ) {
                                Row(
                                    Modifier.fillMaxWidth().padding(13.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Box(
                                        Modifier.size(42.dp).clip(CircleShape).background(Color(0xFFE7F5F7)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(Icons.Default.People, contentDescription = null, tint = Color(0xFF006D86))
                                    }
                                    Column(Modifier.weight(1f)) {
                                        Text(profile.displayName.ifBlank { profile.email }, fontWeight = FontWeight.ExtraBold, color = Color(0xFF17324D))
                                        Text(profile.email, fontSize = 10.sp, color = Color(0xFF64748B), maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    }
                                    Text(appText(tr("دخول", "Sign In"), "Open"), color = Color(0xFF006D86), fontWeight = FontWeight.ExtraBold, fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ManagerStatChip(
    modifier: Modifier = Modifier,
    label: String,
    value: String
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        color = Color.White,
        shadowElevation = 1.dp,
        border = BorderStroke(1.dp, Color(0xFFE5EAF0))
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = value,
                fontWeight = FontWeight.ExtraBold,
                fontSize = 15.sp,
                color = Color(0xFF17324D),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(3.dp))
            Text(
                text = label,
                fontSize = 9.sp,
                lineHeight = 14.sp,
                fontWeight = FontWeight.Medium,
                color = Color(0xFF64748B),
                maxLines = 1
            )
        }
    }
}

@Composable
private fun ManagerHomeActionCard(
    modifier: Modifier = Modifier,
    icon: ImageVector,
    title: String,
    subtitle: String,
    accent: Color,
    onClick: () -> Unit
) {
    Card(
        onClick = onClick,
        modifier = modifier.heightIn(min = 148.dp),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
        border = BorderStroke(1.dp, Color(0xFFE7ECF2))
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 16.dp)
        ) {
            ManagerActionIcon(
                icon = icon,
                accent = accent
            )
            Spacer(Modifier.height(12.dp))
            Text(
                text = title,
                fontSize = 16.sp,
                lineHeight = 22.sp,
                fontWeight = FontWeight.ExtraBold,
                color = Color(0xFF17324D),
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(3.dp))
            Text(
                text = subtitle,
                fontSize = 11.sp,
                lineHeight = 16.sp,
                fontWeight = FontWeight.Medium,
                color = Color(0xFF64748B),
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun ManagerActionIcon(
    icon: ImageVector,
    accent: Color
) {
    Box(
        modifier = Modifier
            .size(46.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(accent.copy(alpha = 0.11f)),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = accent,
            modifier = Modifier.size(25.dp)
        )
    }
}

@Composable
private fun ManagerDashboardCard(onClick: () -> Unit) {
    Card(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .shadow(
                elevation = 3.dp,
                shape = RoundedCornerShape(18.dp),
                spotColor = Color(0x12000000)
            ),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFF5F3FF)),
        border = BorderStroke(1.dp, Color(0xFFDDD6FE))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFFEDE9FE)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Tune,
                    contentDescription = null,
                    tint = Color(0xFF6D28D9),
                    modifier = Modifier.size(21.dp)
                )
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = tr("لوحة تحكم المدير", "Manager Dashboard"),
                    fontSize = 15.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color(0xFF4C1D95)
                )
                Text(
                    text = tr("اضغط لإدارة أسعار جميع التحاليل", "Manage all test prices"),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium,
                    color = Color(0xFF6B5A8E)
                )
            }
            Icon(
                imageVector = Icons.Default.Edit,
                contentDescription = tr("فتح لوحة المدير", "Open Manager Dashboard"),
                tint = Color(0xFF6D28D9),
                modifier = Modifier.size(20.dp)
            )
        }
    }
}

@Composable
private fun ManagerDashboardDialog(
    viewModel: LabTestsViewModel,
    customerPriceOverrides: Map<Int, String>,
    lab2LabPrices: Map<Int, String>,
    onDismiss: () -> Unit,
    onEdit: (LabTest) -> Unit
) {
    var managerQuery by remember { mutableStateOf("") }
    val tests = remember(managerQuery) { viewModel.searchManagerTests(managerQuery) }

    BackHandler(enabled = true) { onDismiss() }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false, dismissOnBackPress = true)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp),
            shape = RoundedCornerShape(24.dp),
            color = Color(0xFFF7F8FC),
            shadowElevation = 8.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = tr("لوحة تحكم المدير", "Manager Dashboard"),
                            fontSize = 21.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFF3B176B)
                        )
                        Text(
                            text = tr("إدارة سعر العميل و Lab 2 Lab", "Manage Customer & Lab2Lab Prices"),
                            fontSize = 12.sp,
                            color = Color(0xFF6B5A8E)
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = tr("إغلاق", "Close"),
                            tint = Color(0xFF4C1D95)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = managerQuery,
                    onValueChange = { managerQuery = it },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 72.dp),
                    singleLine = true,
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = null
                        )
                    },
                    placeholder = { Text(appText("ابحث باسم التحليل عربي أو إنجليزي", "Search test by Arabic or English name")) },
                    shape = RoundedCornerShape(16.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color(0xFF6D28D9),
                        cursorColor = Color(0xFF6D28D9),
                        focusedContainerColor = Color.White,
                        unfocusedContainerColor = Color.White
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = tr("التحاليل: ${tests.size}", "Tests: ${tests.size}"),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF475569)
                    )
                    Text(
                        text = tr("الأسعار المعدلة: ${customerPriceOverrides.size}", "Modified prices: ${customerPriceOverrides.size}"),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF6D28D9)
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(9.dp),
                    contentPadding = PaddingValues(bottom = 12.dp)
                ) {
                    items(tests, key = { it.id }) { test ->
                        val customer = customerPriceOverrides[test.id] ?: test.customerPrice ?: "—"
                        val lab = lab2LabPrices[test.id] ?: "—"

                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            border = BorderStroke(1.dp, Color(0xFFE7E8EF))
                        ) {
                            Column(modifier = Modifier.padding(13.dp)) {
                                Text(
                                    text = test.englishName,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = Color(0xFF17324D),
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                                if (test.arabicName.isNotBlank()) {
                                    Text(
                                        text = test.arabicName,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = Color(0xFF64748B),
                                        maxLines = 2,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }

                                Spacer(modifier = Modifier.height(9.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(
                                            text = "سعر العميل: $customer ج",
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFF007C88)
                                        )
                                        Text(
                                            text = "Lab 2 Lab: $lab ج",
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFF6D28D9)
                                        )
                                    }
                                    Button(
                                        onClick = { onEdit(test) },
                                        shape = RoundedCornerShape(12.dp),
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = Color(0xFF6D28D9)
                                        )
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Edit,
                                            contentDescription = null,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(5.dp))
                                        Text(appText(tr("تعديل", "Edit"), "Edit"))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ManagerPriceEditorDialog(
    test: LabTest,
    customerPrice: String,
    lab2LabPrice: String,
    onDismiss: () -> Unit,
    onSave: (String, String, (Boolean, String) -> Unit) -> Unit
) {
    var customerText by remember(test.id, customerPrice) { mutableStateOf(customerPrice) }
    var labText by remember(test.id, lab2LabPrice) { mutableStateOf(lab2LabPrice) }
    var saving by remember(test.id) { mutableStateOf(false) }
    var message by remember(test.id) { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = { if (!saving) onDismiss() },
        title = {
            Column {
                Text(
                    text = tr("تعديل الأسعار", "Edit Prices"),
                    fontWeight = FontWeight.ExtraBold,
                    color = Color(0xFF102A43)
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = test.englishName,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color(0xFF52667A)
                )
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = customerText,
                    onValueChange = { customerText = it.filter { ch -> ch.isDigit() || ch == '.' } },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 72.dp),
                    label = { Text(appText(tr("سعر العميل", "Customer Price"), "Customer price")) },
                    suffix = { Text(appText(tr("جنيه", "EGP"), "EGP")) },
                    singleLine = true,
                    enabled = !saving,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    shape = RoundedCornerShape(14.dp)
                )
                OutlinedTextField(
                    value = labText,
                    onValueChange = { labText = it.filter { ch -> ch.isDigit() || ch == '.' } },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 72.dp),
                    label = { Text(appText("سعر Lab 2 Lab", "Lab 2 Lab price")) },
                    suffix = { Text(appText(tr("جنيه", "EGP"), "EGP")) },
                    singleLine = true,
                    enabled = !saving,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    shape = RoundedCornerShape(14.dp)
                )
                message?.let {
                    Text(
                        text = it,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFFB42318)
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    saving = true
                    message = null
                    onSave(customerText, labText) { success, resultMessage ->
                        saving = false
                        if (!success) message = resultMessage
                    }
                },
                enabled = !saving && customerText.isNotBlank() && labText.isNotBlank(),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6D28D9))
            ) {
                if (saving) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(18.dp),
                        strokeWidth = 2.dp,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                }
                Text(appText("حفظ الأسعار", "Save prices"), fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss, enabled = !saving) {
                Text(appText(tr("إلغاء", "Cancel"), "Cancel"))
            }
        },
        shape = RoundedCornerShape(22.dp),
        containerColor = Color.White
    )
}

@Composable
private fun SearchBox(
    query: String,
    onQueryChange: (String) -> Unit,
    onClear: () -> Unit,
    onImportDocument: (() -> Unit)? = null,
    importingDocument: Boolean = false
) {
    val keyboardController = LocalSoftwareKeyboardController.current

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(
                elevation = 6.dp,
                shape = RoundedCornerShape(24.dp),
                spotColor = Color(0x16000000)
            ),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, Color(0xFFE4ECF4))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .clip(RoundedCornerShape(11.dp))
                        .background(Color(0xFFE7F5F7)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = null,
                        tint = Color(0xFF007B87),
                        modifier = Modifier.size(20.dp)
                    )
                }
                Spacer(modifier = Modifier.width(9.dp))
                Column {
                    Text(
                        text = appText("ابحث عن التحليل", "Search for a test"),
                        fontSize = 16.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color(0xFF102A43)
                    )
                    Text(
                        text = appText("عربي • English • الاسم الدارج", "Arabic • English • Market name"),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        color = Color(0xFF718096)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
                value = query,
                onValueChange = onQueryChange,
                enabled = true,
                readOnly = false,
                modifier = Modifier
                    .fillMaxWidth().heightIn(min = 72.dp)
                    .testTag("search_text_field"),
                placeholder = {
                    Text(
                        text = appText("مثال: CBC أو صورة دم كاملة", "Example: CBC or Complete Blood Count"),
                        color = Color(0xFF98A6B8),
                        fontSize = 14.sp
                    )
                },
                trailingIcon = {
                    if (query.isNotEmpty()) {
                        IconButton(
                            onClick = onClear,
                            modifier = Modifier.testTag("clear_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = appText("مسح البحث", "Clear search"),
                                tint = Color(0xFF64748B)
                            )
                        }
                    }
                },
                singleLine = false,
                minLines = 1,
                maxLines = 4,
                shape = RoundedCornerShape(16.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = Color(0xFFF7FAFC),
                    unfocusedContainerColor = Color(0xFFF7FAFC),
                    disabledContainerColor = Color(0xFFF7FAFC),
                    focusedBorderColor = Color(0xFF008B95),
                    unfocusedBorderColor = Color(0xFFDCE5EE),
                    focusedTextColor = Color(0xFF102A43),
                    unfocusedTextColor = Color(0xFF102A43)
                ),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Default),
                keyboardActions = KeyboardActions(onSearch = { keyboardController?.hide() })
            )

            if (query.isBlank()) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = tr("يمكنك كتابة أكثر من تحليل؛ كل تحليل في سطر أو افصل بينهم بفاصلة.", "You can enter multiple tests, one per line or separated by commas."),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium,
                    color = Color(0xFF7B8794),
                    lineHeight = 16.sp
                )
            }

            if (onImportDocument != null) {
                Spacer(modifier = Modifier.height(10.dp))
                Card(
                    onClick = onImportDocument,
                    enabled = !importingDocument,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFF2FAFB)),
                    border = BorderStroke(1.dp, Color(0xFFB8DDE1))
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(RoundedCornerShape(15.dp))
                                .background(Color(0xFFDDF3F5)),
                            contentAlignment = Alignment.Center
                        ) {
                            if (importingDocument) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(24.dp),
                                    strokeWidth = 2.dp,
                                    color = Color(0xFF007B87)
                                )
                            } else {
                                Icon(
                                    imageVector = Icons.Default.PictureAsPdf,
                                    contentDescription = null,
                                    tint = Color(0xFF007B87),
                                    modifier = Modifier.size(28.dp)
                                )
                                Box(
                                    modifier = Modifier
                                        .align(Alignment.BottomEnd)
                                        .size(19.dp)
                                        .clip(CircleShape)
                                        .background(Color(0xFF007B87)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Search,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(11.dp)
                                    )
                                }
                            }
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                text = if (importingDocument)
                                    tr("جاري قراءة التحاليل...", "Reading tests...")
                                else
                                    tr("قراءة التحاليل من صورة أو PDF", "Read tests from image or PDF"),
                                fontWeight = FontWeight.ExtraBold,
                                color = Color(0xFF006D77),
                                fontSize = 12.sp
                            )
                            Text(
                                text = tr(
                                    "اختار الملف والتطبيق يستخرج أسماء التحاليل للمراجعة",
                                    "Choose a file and review the detected test names"
                                ),
                                fontSize = 9.sp,
                                color = Color(0xFF64748B),
                                lineHeight = 13.sp
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ResultCountChip(count: Int) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.Start,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .clip(CircleShape)
                .background(Color(0xFFE1F1FF))
                .padding(horizontal = 14.dp, vertical = 6.dp)
        ) {
            Text(
                text = "$count نتائج",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF0061A4)
            )
        }
    }
}

private fun calculatePriceTotal(tests: List<LabTest>, priceSelector: (LabTest) -> String?): Double {
    var total = 0.0
    val regex = Regex("""\d+(\.\d+)?""")
    for (test in tests) {
        val priceStr = priceSelector(test)
        if (!priceStr.isNullOrBlank()) {
            val match = regex.find(priceStr)
            val valDouble = match?.value?.toDoubleOrNull()
            if (valDouble != null) {
                total += valDouble
            }
        }
    }
    return total
}

private fun formatTotalDisplay(total: Double): String {
    return if (total % 1.0 == 0.0) {
        total.toLong().toString()
    } else {
        String.format("%.2f", total)
    }
}

@Composable
private fun MainContent(
    uiState: SearchUiState,
    selectedTests: List<LabTest>,
    isManager: Boolean,
    lab2LabPrices: Map<Int, String>,
    customerPriceOverrides: Map<Int, String>,
    activeOrderCustomer: Customer?,
    onChooseCustomer: () -> Unit,
    onClearCustomer: () -> Unit,
    onSaveCustomerOrder: () -> Unit,
    onSelectTest: (LabTest) -> Unit,
    onRemoveTest: (Int) -> Unit,
    onEditPrices: (LabTest) -> Unit,
    allowOrderSelection: Boolean = true,
    bottomContent: (@Composable () -> Unit)? = null
) {
    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(16.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        // 1. Selected Tests Section (tr("التحاليل المختارة", "Selected Tests"))
        if (allowOrderSelection && selectedTests.isNotEmpty()) {
            item(key = "selected_tests_section") {
                SelectedTestsSection(
                    selectedTests = selectedTests,
                    isManager = isManager,
                    lab2LabPrices = lab2LabPrices,
                    customerPriceOverrides = customerPriceOverrides,
                    activeOrderCustomer = activeOrderCustomer,
                    onChooseCustomer = onChooseCustomer,
                    onClearCustomer = onClearCustomer,
                    onSaveCustomerOrder = onSaveCustomerOrder,
                    onRemoveTest = onRemoveTest
                )
            }
        }

        // 2. Search States
        when (uiState) {
            is SearchUiState.EmptyQuery -> {
                if (!allowOrderSelection || selectedTests.isEmpty()) {
                    item(key = "empty_state") {
                        EmptyStateView()
                    }
                }
            }
            is SearchUiState.NoResults -> {
                item(key = "no_results_section") {
                    NoResultsSection(unmatchedQueries = uiState.unmatchedQueries)
                }
            }
            is SearchUiState.Success -> {
                item(key = "search_header") {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = tr("نتائج البحث", "Search Results"),
                            fontSize = 17.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFF17324D)
                        )
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .background(Color(0xFFE7F5F7))
                                .padding(horizontal = 10.dp, vertical = 5.dp)
                        ) {
                            Text(
                                text = "${uiState.queryGroups.sumOf { it.candidates.size }} نتيجة",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF007B87)
                            )
                        }
                    }
                }

                items(uiState.queryGroups, key = { it.query }) { group ->
                    QueryGroupSection(
                        group = group,
                        isManager = isManager,
                        lab2LabPrices = lab2LabPrices,
                        customerPriceOverrides = customerPriceOverrides,
                        onSelectTest = onSelectTest,
                        onEditPrices = onEditPrices,
                        allowSelection = allowOrderSelection
                    )
                }

                if (uiState.unmatchedQueries.isNotEmpty()) {
                    item(key = "unmatched_queries") {
                        UnmatchedQueriesCard(unmatchedQueries = uiState.unmatchedQueries)
                    }
                }
            }
        }

        if (bottomContent != null) {
            item(key = "workspace_more") {
                bottomContent()
            }
        }

        item(key = "bottom_spacer") {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
private fun SelectedTestsSection(
    selectedTests: List<LabTest>,
    isManager: Boolean,
    lab2LabPrices: Map<Int, String>,
    customerPriceOverrides: Map<Int, String>,
    activeOrderCustomer: Customer?,
    onChooseCustomer: () -> Unit,
    onClearCustomer: () -> Unit,
    onSaveCustomerOrder: () -> Unit,
    onRemoveTest: (Int) -> Unit
) {
    val settings = LocalAppSettings.current
    val totalPrice = calculatePriceTotal(selectedTests) { customerPriceOverrides[it.id] ?: it.customerPrice }
    val totalLab2LabPrice = if (isManager && settings.showLab2LabPrice) {
        calculatePriceTotal(selectedTests) { lab2LabPrices[it.id] }
    } else {
        0.0
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(
                elevation = 4.dp,
                shape = RoundedCornerShape(20.dp),
                spotColor = Color(0x1A000000)
            ),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.5.dp, Color(0xFF0061A4))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // Section Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = Color(0xFF0061A4),
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = tr("التحاليل المختارة", "Selected Tests"),
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF001D35)
                    )
                }
                Box(
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(Color(0xFFE1F1FF))
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "${selectedTests.size}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0061A4)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Selected items list
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                selectedTests.forEach { test ->
                    SelectedTestRow(
                        test = test,
                        customerPrice = customerPriceOverrides[test.id] ?: test.customerPrice,
                        isManager = isManager,
                        lab2LabPrice = lab2LabPrices[test.id],
                        onRemove = { onRemoveTest(test.id) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Total Price Section - controlled from manager settings.
            if (settings.showCustomerPrice || (isManager && settings.showLab2LabPrice)) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color(0xFF0061A4))
                        .padding(14.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (settings.showCustomerPrice) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = if (isManager) tr("إجمالي سعر العميل", "Customer Total") else tr("الإجمالي", "Total"),
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                                Row(verticalAlignment = Alignment.Bottom) {
                                    Text(
                                        text = formatTotalDisplay(totalPrice),
                                        fontSize = 20.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = Color.White
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = tr("جنيه", "EGP"),
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White,
                                        modifier = Modifier.padding(bottom = 2.dp)
                                    )
                                }
                            }
                        }

                        if (isManager && settings.showLab2LabPrice) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = tr("إجمالي Lab 2 Lab", "Lab 2 Lab Total"),
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                                Row(verticalAlignment = Alignment.Bottom) {
                                    Text(
                                        text = formatTotalDisplay(totalLab2LabPrice),
                                        fontSize = 19.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = Color.White
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = tr("جنيه", "EGP"),
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White,
                                        modifier = Modifier.padding(bottom = 2.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))
            }

            // Customer order flow
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                color = if (activeOrderCustomer == null) Color(0xFFF8FAFC) else Color(0xFFE7F5F7),
                border = BorderStroke(1.dp, if (activeOrderCustomer == null) Color(0xFFE2E8F0) else Color(0xFF7DD3FC))
            ) {
                Column(Modifier.padding(12.dp)) {
                    if (activeOrderCustomer == null) {
                        Text(
                            tr("اربط التحاليل بعميل قبل حفظ الطلب", "Link tests to a customer before saving"),
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFF17324D)
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            tr("اختار عميل سابق أو أضف عميل جديد", "Choose an existing customer or add a new one"),
                            fontSize = 12.sp,
                            color = Color(0xFF64748B)
                        )
                        Spacer(Modifier.height(10.dp))
                        Button(
                            onClick = onChooseCustomer,
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF006D86))
                        ) {
                            Text(appText("اختيار العميل", "Choose customer"), fontWeight = FontWeight.Bold)
                        }
                    } else {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(appText("العميل المرتبط بالطلب", "Order customer"), fontSize = 11.sp, color = Color(0xFF64748B))
                                Text(activeOrderCustomer.name, fontWeight = FontWeight.ExtraBold, color = Color(0xFF17324D))
                                Text(
                                    "${activeOrderCustomer.fileNumber} • ${activeOrderCustomer.phone}",
                                    fontSize = 11.sp,
                                    color = Color(0xFF006D86)
                                )
                            }
                            TextButton(onClick = onClearCustomer) { Text(appText("تغيير", "Change")) }
                        }
                        Spacer(Modifier.height(10.dp))
                        Button(
                            onClick = onSaveCustomerOrder,
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF15803D))
                        ) {
                            Text(appText("حفظ الطلب في ملف العميل", "Save order to customer file"), fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // V36: this button no longer creates the legacy single PDF.
            // It enters the saved-order flow, which creates BOTH the customer receipt and lab request.
            Button(
                onClick = {
                    if (activeOrderCustomer == null) onChooseCustomer() else onSaveCustomerOrder()
                },
                enabled = selectedTests.isNotEmpty(),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("generate_pdf_button"),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF15803D))
            ) {
                Icon(
                    imageVector = Icons.Default.PictureAsPdf,
                    contentDescription = "Dual PDF Icon",
                    tint = Color.White,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (activeOrderCustomer == null) {
                        tr("اختيار العميل لإصدار ملفي PDF", "Choose customer for two PDFs")
                    } else {
                        tr("إصدار إيصال العميل + طلب المعمل", "Create customer receipt + lab request")
                    },
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
        }
    }
}

@Composable
fun ProfessionalOrderCheckoutDialog(
    customer: Customer,
    selectedTests: List<LabTest>,
    customerPriceOverrides: Map<Int, String>,
    onDismiss: () -> Unit,
    onConfirm: (discount: Double, discountPercent: Double, paymentStatus: String, paidAmount: Double, notes: String, sharePdf: Boolean) -> Unit
) {
    val subtotal = calculatePriceTotal(selectedTests) { customerPriceOverrides[it.id] ?: it.customerPrice }
    var discountMode by remember(customer.id) {
        mutableStateOf(if (customer.defaultDiscountPercent > 0.0) "percent" else "amount")
    }
    var discountText by remember(customer.id) {
        mutableStateOf(
            customer.defaultDiscountPercent.takeIf { it > 0.0 }?.let {
                if (it % 1.0 == 0.0) it.toLong().toString() else String.format(java.util.Locale.US, "%.1f", it)
            }.orEmpty()
        )
    }
    var paymentStatus by remember { mutableStateOf("unpaid") }
    var paidText by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }

    val rawDiscountInput = discountText.replace(',', '.').toDoubleOrNull() ?: 0.0
    val discountPercent = if (discountMode == "percent") {
        rawDiscountInput.coerceIn(0.0, 100.0)
    } else if (subtotal > 0.0) {
        ((rawDiscountInput.coerceIn(0.0, subtotal) / subtotal) * 100.0).coerceIn(0.0, 100.0)
    } else {
        0.0
    }
    val discount = if (discountMode == "percent") {
        (subtotal * discountPercent / 100.0).coerceIn(0.0, subtotal)
    } else {
        rawDiscountInput.coerceIn(0.0, subtotal)
    }
    val finalTotal = (subtotal - discount).coerceAtLeast(0.0)
    val typedPaid = paidText.replace(',', '.').toDoubleOrNull() ?: 0.0
    val paidAmount = when (paymentStatus) {
        "paid" -> finalTotal
        "partial" -> typedPaid.coerceIn(0.0, finalTotal)
        else -> 0.0
    }
    val remaining = (finalTotal - paidAmount).coerceAtLeast(0.0)

    BackHandler(enabled = true) { onDismiss() }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false, dismissOnBackPress = true)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            shape = RoundedCornerShape(26.dp),
            color = Color(0xFFF8FAFC)
        ) {
            LazyColumn(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                contentPadding = PaddingValues(bottom = 6.dp)
            ) {
                item {
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(20.dp),
                        color = Color.White,
                        border = BorderStroke(1.dp, Color(0xFFE2E8F0))
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                modifier = Modifier.weight(1f),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(42.dp)
                                        .clip(RoundedCornerShape(13.dp))
                                        .background(Color(0xFFE0F2FE)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        Icons.Default.ReceiptLong,
                                        contentDescription = null,
                                        tint = Color(0xFF0369A1),
                                        modifier = Modifier.size(22.dp)
                                    )
                                }
                                Spacer(Modifier.width(10.dp))
                                Column {
                                    Text(
                                        tr("تأكيد طلب التحاليل", "Confirm Lab Order"),
                                        fontWeight = FontWeight.ExtraBold,
                                        fontSize = 19.sp,
                                        color = Color(0xFF17324D)
                                    )
                                    Text(
                                        "${customer.name} • ${customer.fileNumber}",
                                        fontSize = 12.sp,
                                        color = Color(0xFF006D86)
                                    )
                                }
                            }
                            IconButton(onClick = onDismiss) {
                                Icon(Icons.Default.Close, contentDescription = tr("إغلاق", "Close"))
                            }
                        }
                    }
                }

                item {
                    Text(
                        tr("ملخص الحساب", "Order Summary"),
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 16.sp,
                        color = Color(0xFF17324D)
                    )
                    Spacer(Modifier.height(9.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        FinanceDashboardCard(
                            modifier = Modifier.weight(1f),
                            title = tr("قبل الخصم", "Before Discount"),
                            value = "${formatTotalDisplay(subtotal)} ج",
                            subtitle = tr("${selectedTests.size} تحليل", "${selectedTests.size} tests"),
                            icon = Icons.Default.ReceiptLong,
                            accent = Color(0xFF0369A1),
                            background = Color(0xFFEFF6FF)
                        )
                        FinanceDashboardCard(
                            modifier = Modifier.weight(1f),
                            title = tr("بعد الخصم", "After Discount"),
                            value = "${formatTotalDisplay(finalTotal)} ج",
                            subtitle = tr("الإجمالي النهائي", "Final Total"),
                            icon = Icons.Default.CheckCircle,
                            accent = Color(0xFF15803D),
                            background = Color(0xFFECFDF3)
                        )
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        FinanceDashboardCard(
                            modifier = Modifier.weight(1f),
                            title = tr("مبلغ الخصم", "Discount Amount"),
                            value = "${formatTotalDisplay(discount)} ج",
                            subtitle = if (discount > 0.0) tr("تم تطبيق الخصم", "Discount Applied") else tr("بدون خصم", "No Discount"),
                            icon = Icons.Default.LocalOffer,
                            accent = Color(0xFFB45309),
                            background = Color(0xFFFFF7ED)
                        )
                        FinanceDashboardCard(
                            modifier = Modifier.weight(1f),
                            title = tr("نسبة الخصم", "Discount Percentage"),
                            value = "${formatDashboardPercent(discountPercent)}%",
                            subtitle = if (discountMode == "percent") tr("إدخال بالنسبة", "Enter Percentage") else tr("محسوبة تلقائيًا", "Calculated Automatically"),
                            icon = Icons.Default.Percent,
                            accent = Color(0xFF7C3AED),
                            background = Color(0xFFF5F3FF)
                        )
                    }
                }

                item {
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(18.dp),
                        color = Color.White,
                        border = BorderStroke(1.dp, Color(0xFFE2E8F0))
                    ) {
                        Column(Modifier.padding(14.dp)) {
                            Text(
                                tr("طريقة الخصم", "Discount Method"),
                                fontWeight = FontWeight.ExtraBold,
                                color = Color(0xFF17324D)
                            )
                            Spacer(Modifier.height(9.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Button(
                                    onClick = {
                                        if (discountMode != "amount") {
                                            discountMode = "amount"
                                            discountText = if (discount > 0.0) formatTotalDisplay(discount) else ""
                                        }
                                    },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(12.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (discountMode == "amount") Color(0xFF006D86) else Color(0xFFF1F5F9),
                                        contentColor = if (discountMode == "amount") Color.White else Color(0xFF334155)
                                    )
                                ) {
                                    Icon(Icons.Default.LocalOffer, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text(appText(tr("مبلغ", "Amount"), "Amount"), fontWeight = FontWeight.Bold)
                                }
                                Button(
                                    onClick = {
                                        if (discountMode != "percent") {
                                            discountMode = "percent"
                                            discountText = if (discountPercent > 0.0) formatDashboardPercent(discountPercent) else ""
                                        }
                                    },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(12.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (discountMode == "percent") Color(0xFF7C3AED) else Color(0xFFF1F5F9),
                                        contentColor = if (discountMode == "percent") Color.White else Color(0xFF334155)
                                    )
                                ) {
                                    Icon(Icons.Default.Percent, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text(appText(tr("نسبة %", "Percentage %"), "Percent %"), fontWeight = FontWeight.Bold)
                                }
                            }
                            Spacer(Modifier.height(10.dp))
                            OutlinedTextField(
                                value = discountText,
                                onValueChange = { value ->
                                    val clean = value.filter { it.isDigit() || it == '.' || it == ',' }
                                    discountText = clean.take(10)
                                },
                                modifier = Modifier.fillMaxWidth().heightIn(min = 72.dp),
                                label = {
                                    Text(if (discountMode == "percent") tr("اكتب نسبة الخصم", "Enter Discount Percentage") else tr("اكتب مبلغ الخصم", "Enter Discount Amount"))
                                },
                                placeholder = { Text(if (discountMode == "percent") tr("مثال: 10", "e.g. 10") else tr("مثال: 100", "e.g. 100")) },
                                suffix = { Text(if (discountMode == "percent") "%" else tr("جنيه", "EGP")) },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                singleLine = true
                            )
                            if (discount > 0.0) {
                                Spacer(Modifier.height(7.dp))
                                Text(
                                    if (discountMode == "percent") {
                                        "${formatDashboardPercent(discountPercent)}% = ${formatTotalDisplay(discount)} جنيه"
                                    } else {
                                        "${formatTotalDisplay(discount)} جنيه = ${formatDashboardPercent(discountPercent)}%"
                                    },
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF64748B)
                                )
                            }
                        }
                    }
                }

                item {
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(18.dp),
                        color = Color.White,
                        border = BorderStroke(1.dp, Color(0xFFE2E8F0))
                    ) {
                        Column(Modifier.padding(14.dp)) {
                            Text(appText(tr("حالة الدفع", "Payment Status"), "Payment status"), fontWeight = FontWeight.ExtraBold, color = Color(0xFF17324D))
                            Spacer(Modifier.height(9.dp))
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                listOf(
                                    "unpaid" to tr("غير مدفوع", "Unpaid"),
                                    "partial" to "جزئي",
                                    "paid" to "مدفوع"
                                ).forEach { (value, label) ->
                                    Button(
                                        onClick = {
                                            paymentStatus = value
                                            if (value != "partial") paidText = ""
                                        },
                                        modifier = Modifier.weight(1f),
                                        shape = RoundedCornerShape(11.dp),
                                        contentPadding = PaddingValues(horizontal = 4.dp, vertical = 9.dp),
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = if (paymentStatus == value) Color(0xFF006D86) else Color(0xFFF1F5F9),
                                            contentColor = if (paymentStatus == value) Color.White else Color(0xFF334155)
                                        )
                                    ) {
                                        Text(label, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                            if (paymentStatus == "partial") {
                                Spacer(Modifier.height(10.dp))
                                OutlinedTextField(
                                    value = paidText,
                                    onValueChange = { value -> paidText = value.filter { it.isDigit() || it == '.' || it == ',' }.take(10) },
                                    modifier = Modifier.fillMaxWidth().heightIn(min = 72.dp),
                                    label = { Text(appText(tr("المبلغ المدفوع", "Paid Amount"), "Paid amount")) },
                                    suffix = { Text(appText(tr("جنيه", "EGP"), "EGP")) },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                    singleLine = true
                                )
                            }
                        }
                    }
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        FinanceDashboardCard(
                            modifier = Modifier.weight(1f),
                            title = tr("المدفوع", "Paid"),
                            value = "${formatTotalDisplay(paidAmount)} ج",
                            subtitle = paymentStatusArabic(paymentStatus),
                            icon = Icons.Default.Payments,
                            accent = Color(0xFF15803D),
                            background = Color(0xFFECFDF3)
                        )
                        FinanceDashboardCard(
                            modifier = Modifier.weight(1f),
                            title = tr("المتبقي", "Remaining"),
                            value = "${formatTotalDisplay(remaining)} ج",
                            subtitle = if (remaining > 0.0) tr("مبلغ مستحق", "Amount Due") else tr("تم السداد", "Paid in Full"),
                            icon = Icons.Default.AccountBalanceWallet,
                            accent = if (remaining > 0.0) Color(0xFFB91C1C) else Color(0xFF15803D),
                            background = if (remaining > 0.0) Color(0xFFFEF2F2) else Color(0xFFECFDF3)
                        )
                    }
                }

                item {
                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it.take(500) },
                        modifier = Modifier.fillMaxWidth().heightIn(min = 112.dp),
                        label = { Text(appText(tr("ملاحظات الطلب", "Order Notes"), "Order notes")) },
                        placeholder = { Text(appText(tr("اختياري", "Optional"), "Optional")) },
                        minLines = 2,
                        maxLines = 4
                    )
                }

                item {
                    Button(
                        onClick = { onConfirm(discount, discountPercent, paymentStatus, paidAmount, notes, false) },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF15803D))
                    ) {
                        Icon(Icons.Default.Save, contentDescription = null)
                        Spacer(Modifier.width(7.dp))
                        Text(appText(tr("حفظ الطلب", "Save order"), "Save order"), fontWeight = FontWeight.ExtraBold)
                    }
                    TextButton(onClick = onDismiss, modifier = Modifier.fillMaxWidth()) { Text(appText(tr("إلغاء", "Cancel"), "Cancel")) }
                }
            }
        }
    }
}

@Composable
private fun FinanceDashboardCard(
    modifier: Modifier = Modifier,
    title: String,
    value: String,
    subtitle: String,
    icon: ImageVector,
    accent: Color,
    background: Color
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(17.dp),
        color = background,
        border = BorderStroke(1.dp, accent.copy(alpha = 0.14f))
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(7.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(30.dp)
                        .clip(RoundedCornerShape(9.dp))
                        .background(accent.copy(alpha = 0.12f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = accent,
                        modifier = Modifier.size(17.dp)
                    )
                }
                Spacer(Modifier.width(7.dp))
                Text(
                    title,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF64748B),
                    maxLines = 1
                )
            }
            Text(
                value,
                fontSize = 18.sp,
                fontWeight = FontWeight.ExtraBold,
                color = accent,
                maxLines = 1
            )
            Text(
                subtitle,
                fontSize = 10.sp,
                fontWeight = FontWeight.Medium,
                color = Color(0xFF64748B),
                maxLines = 1
            )
        }
    }
}

private fun formatDashboardPercent(value: Double): String {
    return if (value % 1.0 == 0.0) value.toLong().toString() else String.format("%.1f", value)
}

@Composable
private fun SelectedTestRow(
    test: LabTest,
    customerPrice: String?,
    isManager: Boolean,
    lab2LabPrice: String?,
    onRemove: () -> Unit
) {
    val settings = LocalAppSettings.current
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        color = Color(0xFFF8FAFC),
        border = BorderStroke(1.dp, Color(0xFFE2E8F0))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                if (settings.showEnglishName) {
                    Text(
                        text = test.englishName,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF001D35),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                if (settings.showArabicName && test.arabicName.isNotBlank()) {
                    Text(
                        text = test.arabicName,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        color = Color(0xFF64748B),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                if (settings.showMarketName && test.marketName.isNotBlank() && test.marketName != test.englishName) {
                    Text(
                        text = test.marketName,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        color = Color(0xFF64748B),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            if (settings.showCustomerPrice || (isManager && settings.showLab2LabPrice)) {
                Spacer(modifier = Modifier.width(8.dp))
                Column(horizontalAlignment = Alignment.End) {
                    if (settings.showCustomerPrice) {
                        Text(
                            text = "عميل: ${customerPrice ?: "0"} جنيه",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF004A77)
                        )
                    }
                    if (isManager && settings.showLab2LabPrice) {
                        Text(
                            text = "Lab 2 Lab: ${lab2LabPrice ?: "غير مسجل"}${if (lab2LabPrice.isNullOrBlank()) "" else " جنيه"}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF7C3AED)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.width(8.dp))
            IconButton(
                onClick = onRemove,
                modifier = Modifier
                    .size(28.dp)
                    .testTag("remove_test_${test.id}")
            ) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = tr("إزالة", "Remove"),
                    tint = Color(0xFFE11D48),
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

@Composable
private fun UnmatchedQueriesCard(unmatchedQueries: List<String>) {
    if (unmatchedQueries.isEmpty()) return

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(
                elevation = 2.dp,
                shape = RoundedCornerShape(18.dp),
                spotColor = Color(0x10000000)
            ),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF1F2))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = null,
                    tint = Color(0xFFE11D48),
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = tr("تحاليل غير موجودة", "Tests Not Found"),
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF9F1239)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                unmatchedQueries.forEach { query ->
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color.White)
                            .padding(horizontal = 12.dp, vertical = 8.dp)
                    ) {
                        Text(
                            text = "• $query",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color(0xFF881337)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun QueryGroupSection(
    group: QueryGroup,
    isManager: Boolean,
    lab2LabPrices: Map<Int, String>,
    customerPriceOverrides: Map<Int, String>,
    onSelectTest: (LabTest) -> Unit,
    onEditPrices: (LabTest) -> Unit,
    allowSelection: Boolean = true
) {
    Column(
        verticalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        if (group.candidates.size > 1) {
            AmbiguousHeaderCard(query = group.query, count = group.candidates.size)
        }
        group.candidates.forEach { test ->
            SearchCandidateCard(
                test = test,
                customerPrice = customerPriceOverrides[test.id] ?: test.customerPrice,
                isManager = isManager,
                lab2LabPrice = lab2LabPrices[test.id],
                onSelect = { onSelectTest(test) },
                onEditPrices = { onEditPrices(test) },
                allowSelection = allowSelection
            )
        }
    }
}

@Composable
private fun AmbiguousHeaderCard(query: String, count: Int) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        color = Color(0xFFFFF7ED),
        border = BorderStroke(1.dp, Color(0xFFFFD8A8))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.FilterList,
                contentDescription = null,
                tint = Color(0xFFC2410C),
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "نتائج عدة لـ \"$query\" ($count تحاليل):",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF9A3412)
            )
        }
    }
}

@Composable
private fun SearchCandidateCard(
    test: LabTest,
    customerPrice: String?,
    isManager: Boolean,
    lab2LabPrice: String?,
    onSelect: () -> Unit,
    onEditPrices: () -> Unit,
    allowSelection: Boolean = true
) {
    val settings = LocalAppSettings.current
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(
                elevation = 4.dp,
                shape = RoundedCornerShape(22.dp),
                spotColor = Color(0x14000000)
            ),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, Color(0xFFE5ECF2))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    if (settings.showEnglishName) {
                        Text(
                            text = test.englishName,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFF102A43),
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    if (settings.showArabicName && test.arabicName.isNotBlank()) {
                        if (settings.showEnglishName) Spacer(modifier = Modifier.height(5.dp))
                        Text(
                            text = test.arabicName,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFF52667A),
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    if (!settings.showEnglishName && !settings.showArabicName && test.marketName.isNotBlank()) {
                        Text(
                            text = test.marketName,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFF102A43),
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                Spacer(modifier = Modifier.width(10.dp))

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0xFFF0F4F8))
                        .padding(horizontal = 8.dp, vertical = 5.dp)
                ) {
                    Text(
                        text = "#${test.id}",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF718096)
                    )
                }
            }

            if (settings.showMarketName && test.marketName.isNotBlank() && test.marketName != test.englishName) {
                Spacer(modifier = Modifier.height(9.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = tr("الاسم الدارج", "Market Name"),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF7B8794)
                    )
                    Spacer(modifier = Modifier.width(7.dp))
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(9.dp))
                            .background(Color(0xFFF2F7FA))
                            .padding(horizontal = 9.dp, vertical = 5.dp)
                    ) {
                        Text(
                            text = test.marketName,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFF36536B),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            if (settings.showCustomerPrice || (isManager && settings.showLab2LabPrice)) {
                Spacer(modifier = Modifier.height(14.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (settings.showCustomerPrice) {
                        PriceBox(
                            modifier = Modifier.weight(1f),
                            title = tr("سعر العميل", "Customer Price"),
                            price = customerPrice,
                            backgroundColor = Color(0xFFEDF7FF),
                            borderColor = Color(0xFFCFE8F7),
                            titleColor = Color(0xFF28607E),
                            priceColor = Color(0xFF114D6B)
                        )
                    }
                    if (isManager && settings.showLab2LabPrice) {
                        PriceBox(
                            modifier = Modifier.weight(1f),
                            title = "Lab 2 Lab",
                            price = lab2LabPrice,
                            backgroundColor = Color(0xFFF3F0FF),
                            borderColor = Color(0xFFDED7FF),
                            titleColor = Color(0xFF6550A5),
                            priceColor = Color(0xFF513B93)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (isManager) {
                Button(
                    onClick = onEditPrices,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp)
                        .testTag("edit_prices_${test.id}"),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6D28D9))
                ) {
                    Icon(
                        imageVector = Icons.Default.Edit,
                        contentDescription = null,
                        modifier = Modifier.size(17.dp)
                    )
                    Spacer(modifier = Modifier.width(7.dp))
                    Text(
                        text = tr("تعديل الأسعار", "Edit Prices"),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
            }

            if (allowSelection) {
                Button(
                    onClick = onSelect,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(46.dp)
                        .testTag("select_test_${test.id}"),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF007E89))
                ) {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(7.dp))
                    Text(
                        text = tr("إضافة إلى القائمة", "Add to List"),
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
private fun NoResultsSection(unmatchedQueries: List<String>) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(top = 8.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        if (unmatchedQueries.isNotEmpty()) {
            UnmatchedQueriesCard(unmatchedQueries = unmatchedQueries)
        }
        NoResultsView()
    }
}

@Composable
private fun LabTestCard(
    test: LabTest,
    isSelected: Boolean = false
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(
                elevation = if (isSelected) 4.dp else 3.dp,
                shape = RoundedCornerShape(24.dp),
                spotColor = Color(0x12000000)
            ),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) Color(0xFFF8FAFC) else Color.White
        ),
        border = if (isSelected) BorderStroke(2.dp, Color(0xFF0061A4)) else null
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // English Name
            Text(
                text = test.englishName,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF001D35),
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Arabic Name
            Row(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = tr("الاسم العربي: ", "Arabic name: "),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF64748B)
                )
                Text(
                    text = if (test.arabicName.isNotBlank()) test.arabicName else "غير مسجل",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    color = Color(0xFF1E293B)
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Market Name
            Row(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = tr("الاسم الدارج: ", "Market name: "),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF64748B)
                )
                Text(
                    text = if (test.marketName.isNotBlank()) test.marketName else "غير مسجل",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    color = Color(0xFF1E293B)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Price Section
            PriceBox(
                modifier = Modifier.fillMaxWidth(),
                title = tr("سعر العميل", "Customer Price"),
                price = test.customerPrice,
                backgroundColor = Color(0xFFF0F7FF),
                borderColor = Color(0xFFD0E4FF),
                titleColor = Color(0xFF004A77),
                priceColor = Color(0xFF004A77)
            )
        }
    }
}

@Composable
private fun PriceBox(
    modifier: Modifier = Modifier,
    title: String,
    price: String?,
    backgroundColor: Color,
    borderColor: Color,
    titleColor: Color,
    priceColor: Color
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(backgroundColor)
            .border(1.dp, borderColor, RoundedCornerShape(14.dp))
            .padding(horizontal = 12.dp, vertical = 10.dp)
    ) {
        Column {
            Text(
                text = title,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = titleColor
            )

            Spacer(modifier = Modifier.height(6.dp))

            if (!price.isNullOrBlank()) {
                Row(
                    verticalAlignment = Alignment.Bottom,
                    horizontalArrangement = Arrangement.Start
                ) {
                    Text(
                        text = price,
                        fontSize = 19.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = priceColor
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = tr("جنيه", "EGP"),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = priceColor,
                        modifier = Modifier.padding(bottom = 2.dp)
                    )
                }
            } else {
                Text(
                    text = "غير مسجل",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF94A3B8)
                )
            }
        }
    }
}

@Composable
private fun EmptyStateView() {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 6.dp),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, Color(0xFFE6EDF3))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp, vertical = 34.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(72.dp)
                    .clip(RoundedCornerShape(22.dp))
                    .background(Color(0xFFE7F5F7)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Outlined.Biotech,
                    contentDescription = null,
                    tint = Color(0xFF007E89),
                    modifier = Modifier.size(36.dp)
                )
            }

            Spacer(modifier = Modifier.height(18.dp))

            Text(
                text = tr("ابدأ بكتابة اسم التحليل", "Start typing a test name"),
                fontSize = 19.sp,
                fontWeight = FontWeight.ExtraBold,
                color = Color(0xFF17324D),
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(7.dp))

            Text(
                text = tr("البحث يدعم العربي والإنجليزي والاسم المتداول في المعامل", "Search supports Arabic, English and common lab names"),
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium,
                color = Color(0xFF718096),
                textAlign = TextAlign.Center,
                lineHeight = 19.sp
            )
        }
    }
}

@Composable
private fun NoResultsView() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(80.dp)
                .clip(CircleShape)
                .background(Color(0xFFFEE2E2)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Outlined.SearchOff,
                contentDescription = null,
                tint = Color(0xFFDC2626),
                modifier = Modifier.size(40.dp)
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        Text(
            text = tr("لم يتم العثور على التحليل", "Test Not Found"),
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF001D35),
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = tr("جرّب البحث باسم مختلف أو بالاسم الإنجليزي", "Try another name or the English name"),
            fontSize = 14.sp,
            fontWeight = FontWeight.Medium,
            color = Color(0xFF64748B),
            textAlign = TextAlign.Center
        )
    }
}


private fun paymentStatusArabic(status: String): String = when (status) {
    "paid" -> "مدفوع"
    "partial" -> "جزئي"
    else -> tr("غير مدفوع", "Unpaid")
}
