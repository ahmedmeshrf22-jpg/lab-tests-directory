package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.LabTest
import com.example.data.model.normalizeText
import com.example.data.repository.LabTestRepository
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreSettings
import com.google.firebase.firestore.SetOptions
import com.google.firebase.firestore.Source
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import org.json.JSONArray

data class QueryGroup(
    val query: String,
    val candidates: List<LabTest>
)

sealed interface SearchUiState {
    object EmptyQuery : SearchUiState
    data class Success(
        val query: String,
        val queryGroups: List<QueryGroup>,
        val unmatchedQueries: List<String> = emptyList()
    ) : SearchUiState
    data class NoResults(
        val unmatchedQueries: List<String> = emptyList()
    ) : SearchUiState
}

class LabTestsViewModel(application: Application) : AndroidViewModel(application) {

    companion object {
        const val MANAGER_EMAIL = "abdelrahman@tahali.com"
        private const val MANAGER_UID = "Wps5Y19pZSbeGooEzFfW5UFsshq2"
        private const val LAB2LAB_COLLECTION = "lab2lab_prices"
        private const val CUSTOMER_OVERRIDES_COLLECTION = "customer_price_overrides"

        fun isManagerAccount(email: String?, uid: String? = null): Boolean {
            val normalizedEmail = email?.trim()?.lowercase()
            return normalizedEmail == MANAGER_EMAIL ||
                uid == MANAGER_UID
        }
    }

    private val repository = LabTestRepository(application)

    // Keep Firestore disk persistence disabled so manager-only Lab2Lab data is never
    // left behind in a shared disk cache when another account signs in on the device.
    @Suppress("DEPRECATION")
    private val firestore: FirebaseFirestore = FirebaseFirestore.getInstance().apply {
        firestoreSettings = FirebaseFirestoreSettings.Builder()
            .setPersistenceEnabled(false)
            .build()
    }

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _uiState = MutableStateFlow<SearchUiState>(SearchUiState.EmptyQuery)
    val uiState: StateFlow<SearchUiState> = _uiState.asStateFlow()

    private val _selectedTests = MutableStateFlow<List<LabTest>>(emptyList())
    val selectedTests: StateFlow<List<LabTest>> = _selectedTests.asStateFlow()

    private val _isManager = MutableStateFlow(false)
    val isManager: StateFlow<Boolean> = _isManager.asStateFlow()

    private val _lab2LabPrices = MutableStateFlow<Map<Int, String>>(emptyMap())
    val lab2LabPrices: StateFlow<Map<Int, String>> = _lab2LabPrices.asStateFlow()

    // Customer-price overrides are intentionally separate from Lab2Lab prices.
    // All authenticated users may read this collection, while only the manager may write it.
    private val _customerPriceOverrides = MutableStateFlow<Map<Int, String>>(emptyMap())
    val customerPriceOverrides: StateFlow<Map<Int, String>> = _customerPriceOverrides.asStateFlow()

    private var managerPricesLoaded = false
    private var customerOverridesLoaded = false

    init {
        viewModelScope.launch(Dispatchers.IO) {
            repository.getLabTests()
        }
    }

    /** Called whenever Firebase Auth user changes. */
    fun onAuthenticatedUserChanged(email: String?, uid: String? = null) {
        val authenticated = !email.isNullOrBlank() || !uid.isNullOrBlank()
        if (authenticated && !customerOverridesLoaded) {
            loadCustomerPriceOverrides()
        }

        val manager = isManagerAccount(email, uid)
        if (!manager) {
            clearLab2LabState()
            return
        }

        _isManager.value = true

        // Manager-only local fallback guarantees the existing 331 Lab2Lab prices remain
        // visible even if the network is temporarily unavailable.
        if (!managerPricesLoaded || _lab2LabPrices.value.isEmpty()) {
            val localPrices = loadManagerPricesFromAsset()
            _lab2LabPrices.value = localPrices
            managerPricesLoaded = localPrices.isNotEmpty()
        }

        // Firestore is authoritative when online, and any manager edits override local values.
        firestore.collection(LAB2LAB_COLLECTION)
            .get(Source.SERVER)
            .addOnSuccessListener { snapshot ->
                if (!_isManager.value) return@addOnSuccessListener

                val serverPrices = mutableMapOf<Int, String>()
                snapshot.documents.forEach { doc ->
                    val id = documentTestId(doc.id, doc.getLong("id")?.toInt()) ?: return@forEach
                    val value = doc.get("lab_to_lab_price")
                        ?: doc.get("lab2lab_price")
                        ?: doc.get("labToLabPrice")
                        ?: doc.get("price")
                        ?: return@forEach

                    val formatted = formatFirestorePrice(value)
                    if (!formatted.isNullOrBlank()) serverPrices[id] = formatted
                }

                if (serverPrices.isNotEmpty()) {
                    _lab2LabPrices.value = _lab2LabPrices.value + serverPrices
                    managerPricesLoaded = true
                }
            }
            .addOnFailureListener {
                // Keep the manager-only local fallback.
            }
    }

    private fun loadCustomerPriceOverrides() {
        firestore.collection(CUSTOMER_OVERRIDES_COLLECTION)
            .get(Source.SERVER)
            .addOnSuccessListener { snapshot ->
                val prices = mutableMapOf<Int, String>()
                snapshot.documents.forEach { doc ->
                    val id = documentTestId(doc.id, doc.getLong("id")?.toInt()) ?: return@forEach
                    val value = doc.get("customer_price")
                        ?: doc.get("customerPrice")
                        ?: doc.get("price")
                        ?: return@forEach
                    val formatted = formatFirestorePrice(value)
                    if (!formatted.isNullOrBlank()) prices[id] = formatted
                }
                _customerPriceOverrides.value = prices
                customerOverridesLoaded = true
            }
            .addOnFailureListener {
                // Base customer prices in the bundled data remain available.
            }
    }

    /**
     * Manager-only price update. Customer prices and Lab2Lab prices are stored in separate
     * collections so normal staff can never read the confidential Lab2Lab field.
     */
    fun saveManagerPrices(
        test: LabTest,
        customerPrice: String,
        lab2LabPrice: String,
        onResult: (success: Boolean, message: String) -> Unit
    ) {
        if (!_isManager.value) {
            onResult(false, "غير مصرح بتعديل الأسعار")
            return
        }

        val customerNumber = parsePriceInput(customerPrice)
        val labNumber = parsePriceInput(lab2LabPrice)

        if (customerNumber == null || customerNumber < 0) {
            onResult(false, "اكتب سعر عميل صحيح")
            return
        }
        if (labNumber == null || labNumber < 0) {
            onResult(false, "اكتب سعر Lab 2 Lab صحيح")
            return
        }

        val docId = "test_${test.id}"
        val customerRef = firestore.collection(CUSTOMER_OVERRIDES_COLLECTION).document(docId)
        val labRef = firestore.collection(LAB2LAB_COLLECTION).document(docId)

        val customerData = mapOf(
            "id" to test.id,
            "customer_price" to customerNumber,
            "updated_at" to FieldValue.serverTimestamp()
        )
        val labData = mapOf(
            "id" to test.id,
            "lab_to_lab_price" to labNumber,
            "updated_at" to FieldValue.serverTimestamp()
        )

        firestore.runBatch { batch ->
            batch.set(customerRef, customerData, SetOptions.merge())
            batch.set(labRef, labData, SetOptions.merge())
        }.addOnSuccessListener {
            val customerFormatted = formatNumber(customerNumber)
            val labFormatted = formatNumber(labNumber)
            _customerPriceOverrides.value = _customerPriceOverrides.value + (test.id to customerFormatted)
            _lab2LabPrices.value = _lab2LabPrices.value + (test.id to labFormatted)
            customerOverridesLoaded = true
            managerPricesLoaded = true
            onResult(true, "تم حفظ أسعار ${test.englishName}")
        }.addOnFailureListener {
            onResult(false, "تعذر حفظ الأسعار. تأكد من الإنترنت وصلاحيات Firebase")
        }
    }

    /** Search helper used by the manager dashboard. Blank query returns all tests. */
    fun searchManagerTests(query: String): List<LabTest> {
        return if (query.isBlank()) {
            repository.getLabTests()
        } else {
            repository.searchTests(query)
        }
    }

    fun clearLab2LabState() {
        _isManager.value = false
        _lab2LabPrices.value = emptyMap()
        managerPricesLoaded = false
    }

    private fun loadManagerPricesFromAsset(): Map<Int, String> {
        return try {
            val json = getApplication<Application>().assets
                .open("manager_lab2lab_prices.json")
                .bufferedReader(Charsets.UTF_8)
                .use { it.readText() }

            val array = JSONArray(json)
            buildMap {
                for (i in 0 until array.length()) {
                    val item = array.getJSONObject(i)
                    val id = item.optInt("id", -1)
                    if (id <= 0 || item.isNull("lab_to_lab_price")) continue
                    val formatted = formatFirestorePrice(item.get("lab_to_lab_price"))
                    if (!formatted.isNullOrBlank()) put(id, formatted)
                }
            }
        } catch (_: Exception) {
            emptyMap()
        }
    }

    private fun documentTestId(documentId: String, fallbackId: Int?): Int? {
        return documentId.removePrefix("test_").toIntOrNull() ?: fallbackId
    }

    private fun parsePriceInput(value: String): Double? {
        val normalized = value
            .trim()
            .replace(",", "")
            .replace("جنيه", "", ignoreCase = true)
            .trim()
        return normalized.toDoubleOrNull()
    }

    private fun formatNumber(value: Double): String {
        return if (value % 1.0 == 0.0) value.toLong().toString() else value.toString()
    }

    private fun formatFirestorePrice(value: Any?): String? {
        return when (value) {
            null -> null
            is Byte, is Short, is Int, is Long -> value.toString()
            is Float -> formatNumber(value.toDouble())
            is Double -> formatNumber(value)
            is Number -> value.toString()
            else -> value.toString().trim().takeIf { it.isNotEmpty() && !it.equals("null", true) }
        }
    }

    private fun parseQueries(rawInput: String): List<String> {
        if (rawInput.isBlank()) return emptyList()
        val delimiterRegex = Regex("[\\n,،;؛]+")
        val rawTokens = rawInput.split(delimiterRegex)

        val seenNorm = mutableSetOf<String>()
        val result = mutableListOf<String>()

        for (token in rawTokens) {
            val trimmed = token.trim()
            if (trimmed.isEmpty()) continue
            val norm = normalizeText(trimmed)
            if (norm.isNotEmpty() && seenNorm.add(norm)) result.add(trimmed)
        }
        return result
    }

    fun onQueryChanged(newQuery: String) {
        _searchQuery.value = newQuery
        val trimmedInput = newQuery.trim()

        if (trimmedInput.isEmpty()) {
            _uiState.value = SearchUiState.EmptyQuery
            return
        }

        viewModelScope.launch(Dispatchers.Default) {
            val queries = parseQueries(newQuery)
            if (queries.isEmpty()) {
                _uiState.value = SearchUiState.EmptyQuery
                return@launch
            }

            val selectedIds = _selectedTests.value.map { it.id }.toSet()
            val queryGroups = mutableListOf<QueryGroup>()
            val unmatchedQueries = mutableListOf<String>()

            for (q in queries) {
                val matches = repository.searchTests(q).filter { it.id !in selectedIds }
                if (matches.isNotEmpty()) queryGroups.add(QueryGroup(query = q, candidates = matches))
                else unmatchedQueries.add(q)
            }

            if (queryGroups.isEmpty()) {
                _uiState.value = SearchUiState.NoResults(unmatchedQueries = unmatchedQueries)
            } else {
                _uiState.value = SearchUiState.Success(
                    query = newQuery,
                    queryGroups = queryGroups,
                    unmatchedQueries = unmatchedQueries
                )
            }
        }
    }

    fun addSelectedTest(test: LabTest) {
        if (_selectedTests.value.none { it.id == test.id }) {
            _selectedTests.value = _selectedTests.value + test
        }
        clearSearch()
    }

    fun removeSelectedTest(testId: Int) {
        _selectedTests.value = _selectedTests.value.filter { it.id != testId }
        if (_searchQuery.value.isNotEmpty()) onQueryChanged(_searchQuery.value)
    }

    fun clearSearch() {
        _searchQuery.value = ""
        _uiState.value = SearchUiState.EmptyQuery
    }
}
