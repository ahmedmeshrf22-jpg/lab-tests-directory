package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.Customer
import com.example.data.model.CustomerOrder
import com.example.data.model.LabTest
import com.example.data.model.normalizeText
import com.example.settings.LocalAppSettings
import com.example.util.PdfGenerator
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val CustomerPrimary = Color(0xFF006D86)
private val CustomerDark = Color(0xFF003A5D)
private val CustomerGreen = Color(0xFF15803D)
private val CustomerBg = Color(0xFFF4F7FB)

@Composable
fun CustomerSystemCard(onClick: () -> Unit) {
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .background(Color(0xFFE7F5F7), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.People,
                    contentDescription = null,
                    tint = CustomerPrimary,
                    modifier = Modifier.size(25.dp)
                )
            }
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "ملفات العملاء",
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 17.sp,
                    color = Color(0xFF17324D)
                )
                Text(
                    text = "بيانات العميل وسجل طلباته",
                    fontSize = 12.sp,
                    color = Color(0xFF64748B)
                )
            }
            Text(
                text = "فتح",
                fontWeight = FontWeight.Bold,
                color = CustomerPrimary
            )
        }
    }
}

@Composable
fun CustomerSystemDialog(
    viewModel: LabTestsViewModel,
    selectedTests: List<LabTest>,
    onDismiss: () -> Unit,
    onStartOrderForCustomer: (Customer) -> Unit = {}
) {
    val customers by viewModel.customers.collectAsState()
    val loading by viewModel.customersLoading.collectAsState()
    val orders by viewModel.customerOrders.collectAsState()
    val customerPriceOverrides by viewModel.customerPriceOverrides.collectAsState()
    val settings = LocalAppSettings.current
    val context = LocalContext.current

    var query by remember { mutableStateOf("") }
    var selectedCustomer by remember { mutableStateOf<Customer?>(null) }
    var editingCustomer by remember { mutableStateOf<Customer?>(null) }
    var showCustomerEditor by remember { mutableStateOf(false) }
    var selectedOrder by remember { mutableStateOf<CustomerOrder?>(null) }
    var showOrderCheckout by remember { mutableStateOf(false) }
    var statusMessage by remember { mutableStateOf<String?>(null) }
    var statusSuccess by remember { mutableStateOf(true) }

    LaunchedEffect(Unit) {
        viewModel.loadCustomers()
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = CustomerBg
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                CustomerHeader(
                    title = if (selectedCustomer == null) "ملفات العملاء" else "ملف العميل",
                    subtitle = if (selectedCustomer == null) {
                        "بحث وإضافة ومتابعة العملاء"
                    } else {
                        selectedCustomer?.fileNumber.orEmpty()
                    },
                    onBack = if (selectedCustomer != null) {
                        {
                            selectedCustomer = null
                            statusMessage = null
                        }
                    } else null,
                    onClose = onDismiss
                )

                statusMessage?.let { message ->
                    StatusBanner(
                        message = message,
                        success = statusSuccess,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                    )
                }

                if (selectedCustomer == null) {
                    CustomerListScreen(
                        customers = customers,
                        loading = loading,
                        query = query,
                        onQueryChange = { query = it },
                        onRefresh = {
                            viewModel.loadCustomers { ok, msg ->
                                statusSuccess = ok
                                statusMessage = msg
                            }
                        },
                        onAdd = {
                            editingCustomer = null
                            showCustomerEditor = true
                        },
                        onSelect = { customer ->
                            selectedCustomer = customer
                            viewModel.loadCustomerOrders(customer.id)
                            statusMessage = null
                        }
                    )
                } else {
                    val customer = selectedCustomer
                    if (customer != null) CustomerDetailsScreen(
                        customer = customer,
                        orders = orders,
                        selectedTests = selectedTests,
                        onEdit = {
                            editingCustomer = customer
                            showCustomerEditor = true
                        },
                        onSaveOrder = {
                            if (selectedTests.isNotEmpty()) showOrderCheckout = true
                        },
                        onStartNewOrder = { onStartOrderForCustomer(customer) },
                        onRefreshOrders = {
                            viewModel.loadCustomerOrders(customer.id)
                        },
                        onOpenOrder = { order ->
                            selectedOrder = order
                        }
                    )
                }
            }
        }
    }

    val checkoutCustomer = selectedCustomer
    if (showOrderCheckout && checkoutCustomer != null) {
        ProfessionalOrderCheckoutDialog(
            customer = checkoutCustomer,
            selectedTests = selectedTests,
            customerPriceOverrides = customerPriceOverrides,
            onDismiss = { showOrderCheckout = false },
            onConfirm = { discount, discountPercent, paymentStatus, paidAmount, notes, sharePdf ->
                viewModel.saveCustomerOrderAdvanced(
                    customer = checkoutCustomer,
                    tests = selectedTests,
                    discountAmount = discount,
                    discountPercent = discountPercent,
                    paymentStatus = paymentStatus,
                    paidAmount = paidAmount,
                    notes = notes
                ) { order, msg ->
                    statusSuccess = order != null
                    statusMessage = msg
                    if (order != null) {
                        if (sharePdf) {
                            PdfGenerator.generateAndShareSavedOrderPdf(
                                context = context,
                                order = order,
                                customerPhone = checkoutCustomer.phone,
                                labName = settings.pdfLabName,
                                showContactInfo = settings.pdfShowContactInfo,
                                contactInfo = settings.pdfContactInfo
                            )
                        }
                        showOrderCheckout = false
                        viewModel.clearSelectedTests()
                    }
                }
            }
        )
    }

    selectedOrder?.let { order ->
        CustomerOrderDetailsDialog(
            customer = selectedCustomer,
            order = order,
            onDismiss = { selectedOrder = null }
        )
    }

    if (showCustomerEditor) {
        CustomerEditorDialog(
            existing = editingCustomer,
            onDismiss = { showCustomerEditor = false },
            onSave = { name, phone, age, gender, notes, done ->
                viewModel.saveCustomer(
                    existing = editingCustomer,
                    name = name,
                    phone = phone,
                    age = age,
                    gender = gender,
                    notes = notes
                ) { ok, msg ->
                    done()
                    statusSuccess = ok
                    statusMessage = msg
                    if (ok) {
                        showCustomerEditor = false
                        if (editingCustomer != null) {
                            val updated = editingCustomer!!.copy(
                                name = name.trim(),
                                phone = phone.trim(),
                                age = age.trim(),
                                gender = gender,
                                notes = notes.trim(),
                                updatedAtMillis = System.currentTimeMillis()
                            )
                            selectedCustomer = updated
                        }
                    }
                }
            }
        )
    }
}

@Composable
fun CustomerOrderFlowDialog(
    viewModel: LabTestsViewModel,
    selectedTests: List<LabTest>,
    onDismiss: () -> Unit,
    onCustomerSelected: (Customer) -> Unit
) {
    val customers by viewModel.customers.collectAsState()
    val loading by viewModel.customersLoading.collectAsState()
    var mode by remember { mutableStateOf("choose") }
    var query by remember { mutableStateOf("") }
    var showNewCustomer by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) { viewModel.loadCustomers() }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(modifier = Modifier.fillMaxSize(), color = CustomerBg) {
            Column(Modifier.fillMaxSize()) {
                CustomerHeader(
                    title = "ربط الطلب بعميل",
                    subtitle = "${selectedTests.size} تحليل مختار",
                    onBack = if (mode != "choose") ({ mode = "choose" }) else null,
                    onClose = onDismiss
                )

                errorMessage?.let {
                    StatusBanner(
                        message = it,
                        success = false,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                    )
                }

                when (mode) {
                    "choose" -> {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Text(
                                "الطلب ده هيتسجل على مين؟",
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 18.sp,
                                color = Color(0xFF17324D)
                            )
                            Button(
                                onClick = { mode = "existing" },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(16.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = CustomerPrimary)
                            ) {
                                Icon(Icons.Default.People, contentDescription = null)
                                Spacer(Modifier.width(8.dp))
                                Text("عميل سابق", fontWeight = FontWeight.ExtraBold)
                            }
                            Button(
                                onClick = { showNewCustomer = true },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(16.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = CustomerGreen)
                            ) {
                                Icon(Icons.Default.PersonAdd, contentDescription = null)
                                Spacer(Modifier.width(8.dp))
                                Text("عميل جديد", fontWeight = FontWeight.ExtraBold)
                            }
                        }
                    }
                    "existing" -> {
                        val normalizedQuery = remember(query) { normalizeText(query) }
                        val phoneQuery = remember(query) { query.filter { it.isDigit() } }
                        val filtered = remember(customers, normalizedQuery, phoneQuery) {
                            if (query.isBlank()) customers else customers.filter { customer ->
                                normalizeText(customer.name).contains(normalizedQuery) ||
                                    normalizeText(customer.fileNumber).contains(normalizedQuery) ||
                                    (phoneQuery.isNotBlank() && customer.phone.filter { it.isDigit() }.contains(phoneQuery))
                            }
                        }
                        Column(Modifier.fillMaxSize().padding(14.dp)) {
                            OutlinedTextField(
                                value = query,
                                onValueChange = { query = it },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true,
                                label = { Text("ابحث بالاسم أو الموبايل أو رقم الملف") },
                                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                                shape = RoundedCornerShape(16.dp)
                            )
                            Spacer(Modifier.height(10.dp))
                            if (loading) {
                                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                    CircularProgressIndicator(color = CustomerPrimary)
                                }
                            } else {
                                LazyColumn(
                                    modifier = Modifier.fillMaxSize(),
                                    verticalArrangement = Arrangement.spacedBy(8.dp),
                                    contentPadding = PaddingValues(bottom = 24.dp)
                                ) {
                                    items(filtered, key = { it.id }) { customer ->
                                        CustomerRow(customer = customer, onClick = { onCustomerSelected(customer) })
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showNewCustomer) {
        CustomerEditorDialog(
            existing = null,
            onDismiss = { showNewCustomer = false },
            onSave = { name, phone, age, gender, notes, done ->
                viewModel.saveCustomerAndReturn(
                    name = name,
                    phone = phone,
                    age = age,
                    gender = gender,
                    notes = notes
                ) { customer, msg ->
                    done()
                    if (customer != null) {
                        showNewCustomer = false
                        onCustomerSelected(customer)
                    } else {
                        errorMessage = msg
                    }
                }
            }
        )
    }
}

@Composable
private fun CustomerHeader(
    title: String,
    subtitle: String,
    onBack: (() -> Unit)?,
    onClose: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                Brush.horizontalGradient(
                    listOf(CustomerDark, CustomerPrimary, Color(0xFF008FA0))
                )
            )
            .padding(horizontal = 12.dp, vertical = 14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (onBack != null) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "رجوع", tint = Color.White)
                }
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(title, color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp)
                Text(subtitle, color = Color.White.copy(alpha = 0.82f), fontSize = 12.sp)
            }
            IconButton(onClick = onClose) {
                Icon(Icons.Default.Close, contentDescription = "إغلاق", tint = Color.White)
            }
        }
    }
}

@Composable
private fun CustomerListScreen(
    customers: List<Customer>,
    loading: Boolean,
    query: String,
    onQueryChange: (String) -> Unit,
    onRefresh: () -> Unit,
    onAdd: () -> Unit,
    onSelect: (Customer) -> Unit
) {
    val normalizedQuery = remember(query) { normalizeText(query) }
    val phoneQuery = remember(query) { query.filter { it.isDigit() } }
    val filtered = remember(customers, normalizedQuery, phoneQuery) {
        if (query.isBlank()) customers else customers.filter { customer ->
            normalizeText(customer.name).contains(normalizedQuery) ||
                normalizeText(customer.fileNumber).contains(normalizedQuery) ||
                (phoneQuery.isNotBlank() && customer.phone.filter { it.isDigit() }.contains(phoneQuery))
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = query,
                onValueChange = onQueryChange,
                modifier = Modifier.weight(1f),
                singleLine = true,
                label = { Text("ابحث بالاسم أو الموبايل أو رقم الملف") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                shape = RoundedCornerShape(16.dp)
            )
            Spacer(Modifier.width(8.dp))
            IconButton(onClick = onRefresh) {
                Icon(Icons.Default.Refresh, contentDescription = "تحديث", tint = CustomerPrimary)
            }
        }

        Spacer(Modifier.height(10.dp))

        Button(
            onClick = onAdd,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(containerColor = CustomerPrimary)
        ) {
            Icon(Icons.Default.PersonAdd, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text("إضافة عميل جديد", fontWeight = FontWeight.Bold)
        }

        Spacer(Modifier.height(12.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("العملاء", fontWeight = FontWeight.ExtraBold, color = Color(0xFF17324D))
            Text("${filtered.size} ملف", color = CustomerPrimary, fontWeight = FontWeight.Bold)
        }

        Spacer(Modifier.height(8.dp))

        when {
            loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = CustomerPrimary)
            }
            filtered.isEmpty() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.People, contentDescription = null, tint = Color(0xFF94A3B8), modifier = Modifier.size(44.dp))
                    Spacer(Modifier.height(8.dp))
                    Text(if (query.isBlank()) "لسه مفيش عملاء" else "مفيش نتائج للبحث", color = Color(0xFF64748B))
                }
            }
            else -> LazyColumn(
                contentPadding = PaddingValues(bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(filtered, key = { it.id }) { customer ->
                    CustomerRow(customer = customer, onClick = { onSelect(customer) })
                }
            }
        }
    }
}

@Composable
private fun CustomerRow(customer: Customer, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .background(Color(0xFFE7F5F7), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = customer.name.trim().take(1).ifBlank { "؟" },
                    color = CustomerPrimary,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 18.sp
                )
            }
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    customer.name,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF17324D),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.height(3.dp))
                Text(customer.fileNumber, fontSize = 12.sp, color = CustomerPrimary, fontWeight = FontWeight.Bold)
                Text(customer.phone, fontSize = 12.sp, color = Color(0xFF64748B))
            }
            Text("فتح", color = CustomerPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        }
    }
}

@Composable
private fun CustomerDetailsScreen(
    customer: Customer,
    orders: List<CustomerOrder>,
    selectedTests: List<LabTest>,
    onEdit: () -> Unit,
    onSaveOrder: () -> Unit,
    onStartNewOrder: () -> Unit,
    onRefreshOrders: () -> Unit,
    onOpenOrder: (CustomerOrder) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(bottom = 28.dp)
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                Column(Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(52.dp)
                                .background(Color(0xFFE7F5F7), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(customer.name.take(1), color = CustomerPrimary, fontWeight = FontWeight.ExtraBold, fontSize = 22.sp)
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(customer.name, fontWeight = FontWeight.ExtraBold, fontSize = 19.sp, color = Color(0xFF17324D))
                            Text(customer.fileNumber, color = CustomerPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                        IconButton(onClick = onEdit) {
                            Icon(Icons.Default.Edit, contentDescription = "تعديل", tint = CustomerPrimary)
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    InfoLine(Icons.Default.Phone, "الموبايل", customer.phone)
                    InfoLine(Icons.Default.Person, "البيانات", listOfNotNull(
                        customer.gender.takeIf { it.isNotBlank() },
                        customer.age.takeIf { it.isNotBlank() }?.let { "$it سنة" }
                    ).joinToString(" • ").ifBlank { "غير مسجلة" })
                    if (customer.notes.isNotBlank()) {
                        Spacer(Modifier.height(6.dp))
                        Text("ملاحظات", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF64748B))
                        Text(customer.notes, color = Color(0xFF334155), fontSize = 13.sp)
                    }
                }
            }
        }

        item {
            val totalSpent = orders.sumOf { it.totalCustomerPrice }
            val lastVisit = orders.maxOfOrNull { it.createdAtMillis } ?: 0L
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    "ملخص العميل",
                    fontWeight = FontWeight.ExtraBold,
                    color = Color(0xFF17324D)
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    CustomerStatCard(
                        label = "الزيارات",
                        value = orders.size.toString(),
                        modifier = Modifier.weight(1f)
                    )
                    CustomerStatCard(
                        label = "إجمالي التعاملات",
                        value = "${formatMoney(totalSpent)} ج",
                        modifier = Modifier.weight(1f)
                    )
                }
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFF8FAFC)),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("آخر زيارة", color = Color(0xFF64748B), fontSize = 12.sp)
                        Text(
                            if (lastVisit > 0L) formatDate(lastVisit) else "لا توجد زيارات",
                            color = Color(0xFF17324D),
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                Column(Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.ShoppingCart, contentDescription = null, tint = CustomerGreen)
                        Spacer(Modifier.width(8.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text("طلب تحاليل جديد", fontWeight = FontWeight.ExtraBold, color = Color(0xFF17324D))
                            Text(
                                if (selectedTests.isEmpty()) "اختار التحاليل من شاشة البحث الأول" else "${selectedTests.size} تحليل مختار جاهز للحفظ",
                                fontSize = 12.sp,
                                color = Color(0xFF64748B)
                            )
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    OutlinedButton(
                        onClick = onStartNewOrder,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Icon(Icons.Default.Search, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("اختيار تحاليل جديدة لهذا العميل", fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.height(8.dp))
                    Button(
                        onClick = onSaveOrder,
                        enabled = selectedTests.isNotEmpty(),
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = CustomerGreen)
                    ) {
                        Icon(Icons.Default.Save, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("حفظ التحاليل المختارة كطلب", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.History, contentDescription = null, tint = CustomerPrimary)
                    Spacer(Modifier.width(7.dp))
                    Text("سجل الطلبات", fontWeight = FontWeight.ExtraBold, color = Color(0xFF17324D))
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("${orders.size} طلب", color = CustomerPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    IconButton(onClick = onRefreshOrders) {
                        Icon(Icons.Default.Refresh, contentDescription = "تحديث الطلبات", tint = CustomerPrimary)
                    }
                }
            }
        }

        if (orders.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Text(
                        "لا توجد طلبات محفوظة لهذا العميل",
                        modifier = Modifier.padding(18.dp),
                        color = Color(0xFF64748B)
                    )
                }
            }
        } else {
            items(orders, key = { it.id }) { order ->
                CustomerOrderCard(order = order, onClick = { onOpenOrder(order) })
            }
        }
    }
}

@Composable
private fun InfoLine(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = CustomerPrimary, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(8.dp))
        Text("$label: ", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color(0xFF475569))
        Text(value, fontSize = 13.sp, color = Color(0xFF17324D))
    }
}

@Composable
private fun CustomerStatCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(Modifier.padding(14.dp)) {
            Text(label, color = Color(0xFF64748B), fontSize = 11.sp)
            Spacer(Modifier.height(4.dp))
            Text(value, color = CustomerPrimary, fontWeight = FontWeight.ExtraBold, fontSize = 17.sp)
        }
    }
}

@Composable
private fun CustomerOrderDetailsDialog(
    customer: Customer?,
    order: CustomerOrder,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val settings = LocalAppSettings.current
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = CustomerBg
        ) {
            Column(Modifier.fillMaxSize()) {
                CustomerHeader(
                    title = "تفاصيل الطلب",
                    subtitle = order.orderNumber,
                    onBack = onDismiss,
                    onClose = onDismiss
                )
                LazyColumn(
                    modifier = Modifier.fillMaxSize().padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 28.dp)
                ) {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(18.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White)
                        ) {
                            Column(Modifier.padding(16.dp)) {
                                Text(
                                    customer?.name ?: order.customerName,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 18.sp,
                                    color = Color(0xFF17324D)
                                )
                                Spacer(Modifier.height(4.dp))
                                Text(
                                    customer?.fileNumber ?: order.customerFileNumber,
                                    color = CustomerPrimary,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp
                                )
                                Spacer(Modifier.height(8.dp))
                                InfoLine(Icons.Default.History, "التاريخ", formatDate(order.createdAtMillis))
                                InfoLine(Icons.Default.ShoppingCart, "عدد التحاليل", order.items.size.toString())
                            }
                        }
                    }

                    item {
                        Text(
                            "التحاليل",
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFF17324D),
                            fontSize = 16.sp
                        )
                    }

                    items(order.items) { item ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(13.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        item.englishName.ifBlank { item.arabicName },
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF17324D),
                                        maxLines = 2,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    val secondName = when {
                                        item.arabicName.isNotBlank() && item.arabicName != item.englishName -> item.arabicName
                                        item.marketName.isNotBlank() -> item.marketName
                                        else -> ""
                                    }
                                    if (secondName.isNotBlank()) {
                                        Text(secondName, fontSize = 11.sp, color = Color(0xFF64748B))
                                    }
                                }
                                Spacer(Modifier.width(10.dp))
                                Text(
                                    "${formatMoney(item.customerPrice)} ج",
                                    color = CustomerPrimary,
                                    fontWeight = FontWeight.ExtraBold
                                )
                            }
                        }
                    }

                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(18.dp),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFFE8F7ED))
                        ) {
                            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                FinancialRow("الإجمالي قبل الخصم", order.subtotalCustomerPrice)
                                if (order.discountAmount > 0.0) {
                                    FinancialRow("الخصم", -order.discountAmount, Color(0xFFB45309))
                                    Text(
                                        "نسبة الخصم: ${if (order.discountPercent % 1.0 == 0.0) order.discountPercent.toLong() else String.format("%.1f", order.discountPercent)}%",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF7C3AED)
                                    )
                                }
                                HorizontalDivider(color = Color(0xFFBBE5C8))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("الإجمالي النهائي", fontWeight = FontWeight.ExtraBold, color = Color(0xFF166534))
                                    Text(
                                        "${formatMoney(order.totalCustomerPrice)} جنيه",
                                        fontWeight = FontWeight.ExtraBold,
                                        fontSize = 19.sp,
                                        color = CustomerGreen
                                    )
                                }
                                FinancialRow("المدفوع", order.paidAmount)
                                FinancialRow("المتبقي", order.remainingAmount, if (order.remainingAmount > 0.0) Color(0xFFB91C1C) else CustomerGreen)
                                Text(
                                    "حالة الدفع: ${paymentStatusArabic(order.paymentStatus)}",
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF17324D)
                                )
                                if (order.notes.isNotBlank()) {
                                    Text("ملاحظات: ${order.notes}", fontSize = 12.sp, color = Color(0xFF475569))
                                }
                            }
                        }
                    }

                    item {
                        Button(
                            onClick = {
                                PdfGenerator.generateAndShareSavedOrderPdf(
                                    context = context,
                                    order = order,
                                    customerPhone = customer?.phone,
                                    labName = settings.pdfLabName,
                                    showContactInfo = settings.pdfShowContactInfo,
                                    contactInfo = settings.pdfContactInfo
                                )
                            },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = CustomerGreen)
                        ) {
                            Icon(Icons.Default.PictureAsPdf, contentDescription = null)
                            Spacer(Modifier.width(7.dp))
                            Text("مشاركة PDF للطلب", fontWeight = FontWeight.ExtraBold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CustomerOrderCard(order: CustomerOrder, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(order.orderNumber, fontWeight = FontWeight.ExtraBold, color = Color(0xFF17324D))
                    Text(formatDate(order.createdAtMillis), fontSize = 11.sp, color = Color(0xFF64748B))
                    Text(
                        "${paymentStatusArabic(order.paymentStatus)} • المتبقي ${formatMoney(order.remainingAmount)} ج",
                        fontSize = 11.sp,
                        color = if (order.remainingAmount > 0.0) Color(0xFFB91C1C) else CustomerGreen,
                        fontWeight = FontWeight.Bold
                    )
                    Text("${order.items.size} تحليل • اضغط لعرض التفاصيل", fontSize = 11.sp, color = CustomerPrimary)
                }
                Text(
                    "${formatMoney(order.totalCustomerPrice)} جنيه",
                    color = CustomerGreen,
                    fontWeight = FontWeight.ExtraBold
                )
            }
            Spacer(Modifier.height(8.dp))
            HorizontalDivider(color = Color(0xFFE2E8F0))
            Spacer(Modifier.height(8.dp))
            order.items.take(4).forEach { item ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        item.englishName.ifBlank { item.arabicName },
                        modifier = Modifier.weight(1f),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        fontSize = 12.sp,
                        color = Color(0xFF334155)
                    )
                    Spacer(Modifier.width(8.dp))
                    Text("${formatMoney(item.customerPrice)} ج", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = CustomerPrimary)
                }
            }
            if (order.items.size > 4) {
                Text("+ ${order.items.size - 4} تحاليل أخرى", fontSize = 11.sp, color = Color(0xFF64748B))
            }
        }
    }
}

@Composable
private fun CustomerEditorDialog(
    existing: Customer?,
    onDismiss: () -> Unit,
    onSave: (
        name: String,
        phone: String,
        age: String,
        gender: String,
        notes: String,
        done: () -> Unit
    ) -> Unit
) {
    var name by remember(existing) { mutableStateOf(existing?.name.orEmpty()) }
    var phone by remember(existing) { mutableStateOf(existing?.phone.orEmpty()) }
    var age by remember(existing) { mutableStateOf(existing?.age.orEmpty()) }
    var gender by remember(existing) { mutableStateOf(existing?.gender ?: "ذكر") }
    var notes by remember(existing) { mutableStateOf(existing?.notes.orEmpty()) }
    var saving by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = { if (!saving) onDismiss() },
        title = {
            Text(
                if (existing == null) "إضافة عميل جديد" else "تعديل بيانات العميل",
                fontWeight = FontWeight.ExtraBold
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (existing != null) {
                    Text("رقم الملف: ${existing.fileNumber}", color = CustomerPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("اسم العميل") },
                    singleLine = true
                )
                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("رقم الموبايل") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    singleLine = true
                )
                OutlinedTextField(
                    value = age,
                    onValueChange = { age = it.filter(Char::isDigit).take(3) },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("السن") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true
                )
                Text("النوع", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GenderButton("ذكر", gender == "ذكر") { gender = "ذكر" }
                    GenderButton("أنثى", gender == "أنثى") { gender = "أنثى" }
                }
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it.take(500) },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("ملاحظات") },
                    minLines = 2,
                    maxLines = 4
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (!saving) {
                        saving = true
                        onSave(name, phone, age, gender, notes) { saving = false }
                    }
                },
                enabled = !saving,
                colors = ButtonDefaults.buttonColors(containerColor = CustomerPrimary)
            ) {
                if (saving) {
                    CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp, color = Color.White)
                } else {
                    Icon(Icons.Default.Save, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text("حفظ")
                }
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss, enabled = !saving) { Text("إلغاء") }
        }
    )
}

@Composable
private fun GenderButton(text: String, selected: Boolean, onClick: () -> Unit) {
    if (selected) {
        Button(
            onClick = onClick,
            colors = ButtonDefaults.buttonColors(containerColor = CustomerPrimary),
            shape = RoundedCornerShape(12.dp)
        ) { Text(text) }
    } else {
        OutlinedButton(onClick = onClick, shape = RoundedCornerShape(12.dp)) { Text(text) }
    }
}

@Composable
private fun StatusBanner(message: String, success: Boolean, modifier: Modifier = Modifier) {
    val bg = if (success) Color(0xFFE8F7ED) else Color(0xFFFFEEEE)
    val fg = if (success) Color(0xFF166534) else Color(0xFFB91C1C)
    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(bg, RoundedCornerShape(12.dp))
            .padding(horizontal = 12.dp, vertical = 10.dp)
    ) {
        Text(message, color = fg, fontWeight = FontWeight.Bold, fontSize = 12.sp)
    }
}

@Composable
private fun FinancialRow(label: String, value: Double, valueColor: Color = Color(0xFF17324D)) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = Color(0xFF64748B), fontSize = 12.sp)
        val prefix = if (value < 0.0) "- " else ""
        Text("$prefix${formatMoney(kotlin.math.abs(value))} جنيه", fontWeight = FontWeight.Bold, color = valueColor, fontSize = 12.sp)
    }
}

private fun paymentStatusArabic(status: String): String = when (status) {
    "paid" -> "مدفوع بالكامل"
    "partial" -> "مدفوع جزئيا"
    else -> "غير مدفوع"
}

private fun formatDate(value: Long): String {
    if (value <= 0L) return ""
    return SimpleDateFormat("dd/MM/yyyy - hh:mm a", Locale("ar", "EG")).format(Date(value))
}

private fun formatMoney(value: Double): String {
    return if (value % 1.0 == 0.0) value.toLong().toString() else String.format(Locale.US, "%.2f", value)
}
