package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.example.ui.LabTestsApp
import com.example.ui.LabTestsViewModel
import com.example.ui.LoginScreen
import com.example.ui.theme.LabTestsTheme
import com.google.firebase.FirebaseNetworkException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.FirebaseAuthInvalidUserException

class MainActivity : ComponentActivity() {

    private val viewModel: LabTestsViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val auth = FirebaseAuth.getInstance()

        setContent {
            LabTestsTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    var currentUser by remember { mutableStateOf(auth.currentUser) }
                    var isLoading by remember { mutableStateOf(false) }
                    var errorMessage by remember { mutableStateOf<String?>(null) }

                    DisposableEffect(auth) {
                        val listener = FirebaseAuth.AuthStateListener { fAuth ->
                            currentUser = fAuth.currentUser
                        }
                        auth.addAuthStateListener(listener)
                        onDispose {
                            auth.removeAuthStateListener(listener)
                        }
                    }

                    if (currentUser == null) {
                        LoginScreen(
                            onLoginClick = { email, password ->
                                if (email.isBlank() || password.isBlank()) {
                                    errorMessage = "يرجى إدخال البريد الإلكتروني وكلمة المرور"
                                    return@LoginScreen
                                }
                                isLoading = true
                                errorMessage = null
                                auth.signInWithEmailAndPassword(email, password)
                                    .addOnCompleteListener { task ->
                                        isLoading = false
                                        if (!task.isSuccessful) {
                                            val exception = task.exception
                                            errorMessage = when (exception) {
                                                is FirebaseAuthInvalidUserException,
                                                is FirebaseAuthInvalidCredentialsException -> "البريد الإلكتروني أو كلمة المرور غير صحيحة"
                                                is FirebaseNetworkException -> "خطأ في الاتصال بالإنترنت. يرجى التحقق من الشبكة."
                                                else -> exception?.localizedMessage ?: "فشل تسجيل الدخول. يرجى التأكد من البيانات."
                                            }
                                        }
                                    }
                            },
                            isLoading = isLoading,
                            errorMessage = errorMessage
                        )
                    } else {
                        LabTestsApp(
                            viewModel = viewModel,
                            onLogout = { auth.signOut() }
                        )
                    }
                }
            }
        }
    }
}

