package com.example.data.migration

import android.content.Context
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await
import org.json.JSONArray
import java.io.InputStreamReader

data class MigrationResult(
    val isSuccess: Boolean,
    val message: String
)

class Lab2LabMigrationManager(private val context: Context) {

    private val auth: FirebaseAuth by lazy { FirebaseAuth.getInstance() }
    private val firestore: FirebaseFirestore by lazy { FirebaseFirestore.getInstance() }

    suspend fun performMigration(): MigrationResult {
        // 1. Verify authenticated user is abdelrahman@tahalil.com
        val currentUser = auth.currentUser
        val userEmail = currentUser?.email
        if (userEmail == null || !userEmail.equals("abdelrahman@tahalil.com", ignoreCase = true)) {
            return MigrationResult(
                isSuccess = false,
                message = "عذراً، هذا الإجراء متاح فقط للمسؤول (abdelrahman@tahalil.com)"
            )
        }

        // 2. Read local lab_tests_android.json asset
        val jsonString: String
        try {
            val inputStream = context.assets.open("lab_tests_android.json")
            jsonString = InputStreamReader(inputStream, Charsets.UTF_8).use { it.readText() }
        } catch (e: Exception) {
            return MigrationResult(
                isSuccess = false,
                message = "خطأ في قراءة ملف التحاليل المحلي: ${e.localizedMessage}"
            )
        }

        val jsonArray = try {
            JSONArray(jsonString)
        } catch (e: Exception) {
            return MigrationResult(
                isSuccess = false,
                message = "خطأ في تنسيق ملف JSON المحلي"
            )
        }

        // 3. Confirm exactly 331 lab test records exist BEFORE migration
        if (jsonArray.length() != 331) {
            return MigrationResult(
                isSuccess = false,
                message = "خطأ: عدد التحاليل في الملف المحلي هو ${jsonArray.length()} وليس 331"
            )
        }

        val documentsToUpload = mutableListOf<Pair<String, Map<String, Any>>>()
        val seenDocIds = mutableSetOf<String>()

        // 4. Parse all records and check ID & lab_to_lab_price
        for (i in 0 until jsonArray.length()) {
            val obj = jsonArray.getJSONObject(i)

            if (!obj.has("id") || obj.isNull("id")) {
                return MigrationResult(
                    isSuccess = false,
                    message = "خطأ: العنصر رقم ${i + 1} لا يحتوي على معرف فريد (id)"
                )
            }

            val testId = obj.getInt("id")
            val docId = "test_$testId"

            if (seenDocIds.contains(docId)) {
                return MigrationResult(
                    isSuccess = false,
                    message = "خطأ: تم اكتشاف معرف مكرر ($docId) في الملف المحلي"
                )
            }
            seenDocIds.add(docId)

            if (obj.isNull("lab_to_lab_price")) {
                return MigrationResult(
                    isSuccess = false,
                    message = "خطأ: سعر Lab2Lab مفقود للتحليل رقم $testId"
                )
            }

            val lab2labPriceRaw = obj.get("lab_to_lab_price")
            val lab2labPriceStr = lab2labPriceRaw.toString().trim()
            if (lab2labPriceStr.isEmpty() || lab2labPriceStr.equals("null", ignoreCase = true)) {
                return MigrationResult(
                    isSuccess = false,
                    message = "خطأ: سعر Lab2Lab غير صالح للتحليل رقم $testId"
                )
            }

            // Payload contains ONLY lab2labPrice and stable test identifier (testId)
            val docData = mapOf(
                "testId" to testId,
                "lab2labPrice" to lab2labPriceRaw
            )

            documentsToUpload.add(Pair(docId, docData))
        }

        // Confirm exactly 331 valid records are ready
        if (documentsToUpload.size != 331) {
            return MigrationResult(
                isSuccess = false,
                message = "خطأ: تم تجهيز ${documentsToUpload.size} عنصر للرفع بدلاً من 331"
            )
        }

        // 5. Use a single Firestore WriteBatch
        try {
            val batch = firestore.batch()
            val collectionRef = firestore.collection("lab2lab_prices")

            for ((docId, docData) in documentsToUpload) {
                batch.set(collectionRef.document(docId), docData)
            }

            batch.commit().await()
        } catch (e: Exception) {
            return MigrationResult(
                isSuccess = false,
                message = "فشل في رفع البيانات إلى Firebase: ${e.localizedMessage}"
            )
        }

        // 6. After successful batch commit: Read the lab2lab_prices collection and verify the count
        return try {
            val snapshot = firestore.collection("lab2lab_prices").get().await()
            val actualCount = snapshot.size()

            if (actualCount == 331) {
                MigrationResult(
                    isSuccess = true,
                    message = "تم ترحيل 331 من 331 سعر بنجاح"
                )
            } else {
                MigrationResult(
                    isSuccess = false,
                    message = "خطأ في الترحيل: تم العثور على $actualCount وثيقة في Firebase بدلاً من 331"
                )
            }
        } catch (e: Exception) {
            MigrationResult(
                isSuccess = false,
                message = "فشل في التحقق من البيانات بعد الرفع: ${e.localizedMessage}"
            )
        }
    }
}
