package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.LabTest
import com.example.data.repository.LabTestRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed interface SearchUiState {
    object EmptyQuery : SearchUiState
    data class Success(val query: String, val results: List<LabTest>) : SearchUiState
    object NoResults : SearchUiState
}

class LabTestsViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = LabTestRepository(application)

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _uiState = MutableStateFlow<SearchUiState>(SearchUiState.EmptyQuery)
    val uiState: StateFlow<SearchUiState> = _uiState.asStateFlow()

    init {
        // Pre-load database cache in background
        viewModelScope.launch(Dispatchers.IO) {
            repository.getLabTests()
        }
    }

    fun onQueryChanged(newQuery: String) {
        _searchQuery.value = newQuery
        val query = newQuery.trim()

        if (query.isEmpty()) {
            _uiState.value = SearchUiState.EmptyQuery
            return
        }

        viewModelScope.launch(Dispatchers.Default) {
            val results = repository.searchTests(query)
            if (results.isEmpty()) {
                _uiState.value = SearchUiState.NoResults
            } else {
                _uiState.value = SearchUiState.Success(query, results)
            }
        }
    }

    fun clearSearch() {
        onQueryChanged("")
    }
}
