package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.LabTest
import com.example.data.model.normalizeText
import com.example.data.repository.LabTestRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class QueryGroup(
    val query: String,
    val candidates: List<LabTest>,
    val selectedTestId: Int? = if (candidates.size == 1) candidates.first().id else null
)

sealed interface SearchUiState {
    object EmptyQuery : SearchUiState
    data class Success(
        val query: String,
        val queryGroups: List<QueryGroup>,
        val unmatchedQueries: List<String> = emptyList()
    ) : SearchUiState
    data class NoResults(
        val unmatchedQueries: List<String> = emptyList()
    ) : SearchUiState
}

class LabTestsViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = LabTestRepository(application)

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _uiState = MutableStateFlow<SearchUiState>(SearchUiState.EmptyQuery)
    val uiState: StateFlow<SearchUiState> = _uiState.asStateFlow()

    init {
        // Pre-load database cache in background
        viewModelScope.launch(Dispatchers.IO) {
            repository.getLabTests()
        }
    }

    private fun parseQueries(rawInput: String): List<String> {
        if (rawInput.isBlank()) return emptyList()
        val delimiterRegex = Regex("[\n,،;؛]+")
        val rawTokens = rawInput.split(delimiterRegex)

        val seenNorm = mutableSetOf<String>()
        val result = mutableListOf<String>()

        for (token in rawTokens) {
            val trimmed = token.trim()
            if (trimmed.isEmpty()) continue
            val norm = normalizeText(trimmed)
            if (norm.isNotEmpty() && seenNorm.add(norm)) {
                result.add(trimmed)
            }
        }
        return result
    }

    fun onQueryChanged(newQuery: String) {
        _searchQuery.value = newQuery
        val trimmedInput = newQuery.trim()

        if (trimmedInput.isEmpty()) {
            _uiState.value = SearchUiState.EmptyQuery
            return
        }

        viewModelScope.launch(Dispatchers.Default) {
            val queries = parseQueries(newQuery)
            if (queries.isEmpty()) {
                _uiState.value = SearchUiState.EmptyQuery
                return@launch
            }

            val previousSelections = (_uiState.value as? SearchUiState.Success)
                ?.queryGroups
                ?.associate { it.query to it.selectedTestId }
                .orEmpty()

            val queryGroups = mutableListOf<QueryGroup>()
            val unmatchedQueries = mutableListOf<String>()

            for (q in queries) {
                val matches = repository.searchTests(q)
                if (matches.isNotEmpty()) {
                    val prevSelectedId = previousSelections[q]
                    val initialSelectedId = when {
                        matches.size == 1 -> matches.first().id
                        prevSelectedId != null && matches.any { it.id == prevSelectedId } -> prevSelectedId
                        else -> null
                    }
                    queryGroups.add(
                        QueryGroup(
                            query = q,
                            candidates = matches,
                            selectedTestId = initialSelectedId
                        )
                    )
                } else {
                    unmatchedQueries.add(q)
                }
            }

            if (queryGroups.isEmpty()) {
                _uiState.value = SearchUiState.NoResults(unmatchedQueries = unmatchedQueries)
            } else {
                _uiState.value = SearchUiState.Success(
                    query = newQuery,
                    queryGroups = queryGroups,
                    unmatchedQueries = unmatchedQueries
                )
            }
        }
    }

    fun selectTestForQuery(query: String, testId: Int) {
        val currentState = _uiState.value
        if (currentState is SearchUiState.Success) {
            val updatedGroups = currentState.queryGroups.map { group ->
                if (group.query == query) {
                    group.copy(selectedTestId = testId)
                } else {
                    group
                }
            }
            _uiState.value = currentState.copy(queryGroups = updatedGroups)
        }
    }

    fun clearSelectionForQuery(query: String) {
        val currentState = _uiState.value
        if (currentState is SearchUiState.Success) {
            val updatedGroups = currentState.queryGroups.map { group ->
                if (group.query == query && group.candidates.size > 1) {
                    group.copy(selectedTestId = null)
                } else {
                    group
                }
            }
            _uiState.value = currentState.copy(queryGroups = updatedGroups)
        }
    }

    fun clearSearch() {
        onQueryChanged("")
    }
}

