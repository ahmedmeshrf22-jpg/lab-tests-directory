package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.outlined.Biotech
import androidx.compose.material.icons.outlined.SearchOff
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.LabTest

@Composable
fun LabTestsApp(viewModel: LabTestsViewModel) {
    // Force RTL layout for Arabic-first experience
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        val searchQuery by viewModel.searchQuery.collectAsState()
        val uiState by viewModel.uiState.collectAsState()

        Scaffold(
            topBar = { TopHeader() },
            containerColor = Color(0xFFFDFBFF)
        ) { paddingValues ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .padding(horizontal = 16.dp)
            ) {
                Spacer(modifier = Modifier.height(12.dp))

                SearchBox(
                    query = searchQuery,
                    onQueryChange = { viewModel.onQueryChanged(it) },
                    onClear = { viewModel.clearSearch() }
                )

                Spacer(modifier = Modifier.height(16.dp))

                when (val state = uiState) {
                    is SearchUiState.EmptyQuery -> {
                        EmptyStateView()
                    }
                    is SearchUiState.NoResults -> {
                        NoResultsView()
                    }
                    is SearchUiState.Success -> {
                        ResultCountChip(count = state.results.size)
                        Spacer(modifier = Modifier.height(12.dp))
                        SearchResultsList(results = state.results)
                    }
                }
            }
        }
    }
}

@Composable
private fun TopHeader() {
    Surface(
        color = Color.White,
        shadowElevation = 2.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 16.dp)
        ) {
            Text(
                text = "دليل التحاليل والأسعار",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF001D35),
                letterSpacing = (-0.5).sp
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "ابحث عن أي تحليل بالاسم العربي أو الإنجليزي",
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium,
                color = Color(0xFF64748B)
            )
        }
    }
}

@Composable
private fun SearchBox(
    query: String,
    onQueryChange: (String) -> Unit,
    onClear: () -> Unit
) {
    val keyboardController = LocalSoftwareKeyboardController.current

    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        shadowElevation = 4.dp,
        color = Color(0xFFF3F4F9)
    ) {
        OutlinedTextField(
            value = query,
            onValueChange = onQueryChange,
            enabled = true,
            readOnly = false,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("search_text_field"),
            placeholder = {
                Text(
                    text = "ابحث باسم التحليل...",
                    color = Color(0xFF94A3B8),
                    fontSize = 16.sp
                )
            },
            leadingIcon = {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = "بحث",
                    tint = Color(0xFF0061A4)
                )
            },
            trailingIcon = {
                if (query.isNotEmpty()) {
                    IconButton(
                        onClick = onClear,
                        modifier = Modifier.testTag("clear_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "مسح البحث",
                            tint = Color(0xFF64748B)
                        )
                    }
                }
            },
            singleLine = true,
            shape = RoundedCornerShape(20.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = Color.Transparent,
                unfocusedContainerColor = Color.Transparent,
                disabledContainerColor = Color.Transparent,
                focusedBorderColor = Color(0xFF0061A4),
                unfocusedBorderColor = Color.Transparent,
                focusedTextColor = Color(0xFF001D35),
                unfocusedTextColor = Color(0xFF001D35)
            ),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = { keyboardController?.hide() })
        )
    }
}

@Composable
private fun ResultCountChip(count: Int) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.Start,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .clip(CircleShape)
                .background(Color(0xFFE1F1FF))
                .padding(horizontal = 14.dp, vertical = 6.dp)
        ) {
            Text(
                text = "$count نتائج",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF0061A4)
            )
        }
    }
}

@Composable
private fun SearchResultsList(results: List<LabTest>) {
    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        items(results, key = { it.id }) { test ->
            LabTestCard(test = test)
        }
        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
private fun LabTestCard(test: LabTest) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(
                elevation = 3.dp,
                shape = RoundedCornerShape(24.dp),
                spotColor = Color(0x12000000)
            ),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // English Name
            Text(
                text = test.englishName,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF001D35),
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Arabic Name
            Row(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "الاسم العربي: ",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF64748B)
                )
                Text(
                    text = if (test.arabicName.isNotBlank()) test.arabicName else "غير مسجل",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    color = Color(0xFF1E293B)
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Market Name
            Row(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "الاسم الدارج: ",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF64748B)
                )
                Text(
                    text = if (test.marketName.isNotBlank()) test.marketName else "غير مسجل",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    color = Color(0xFF1E293B)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Prices Section (Visually Separated into 2 distinct blocks)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Customer Price Block
                PriceBox(
                    modifier = Modifier.weight(1f),
                    title = "سعر العميل",
                    price = test.customerPrice,
                    backgroundColor = Color(0xFFF0F7FF),
                    borderColor = Color(0xFFD0E4FF),
                    titleColor = Color(0xFF004A77),
                    priceColor = Color(0xFF004A77)
                )

                // Lab to Lab Price Block
                PriceBox(
                    modifier = Modifier.weight(1f),
                    title = "Lab to Lab",
                    price = test.labToLabPrice,
                    backgroundColor = Color(0xFFF1F5F9),
                    borderColor = Color(0xFFE2E8F0),
                    titleColor = Color(0xFF475569),
                    priceColor = Color(0xFF334155)
                )
            }
        }
    }
}

@Composable
private fun PriceBox(
    modifier: Modifier = Modifier,
    title: String,
    price: String?,
    backgroundColor: Color,
    borderColor: Color,
    titleColor: Color,
    priceColor: Color
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(backgroundColor)
            .border(1.dp, borderColor, RoundedCornerShape(16.dp))
            .padding(12.dp)
    ) {
        Column {
            Text(
                text = title,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = titleColor
            )

            Spacer(modifier = Modifier.height(6.dp))

            if (!price.isNullOrBlank()) {
                Row(
                    verticalAlignment = Alignment.Bottom,
                    horizontalArrangement = Arrangement.Start
                ) {
                    Text(
                        text = price,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = priceColor
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "جنيه",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = priceColor,
                        modifier = Modifier.padding(bottom = 2.dp)
                    )
                }
            } else {
                Text(
                    text = "غير مسجل",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF94A3B8)
                )
            }
        }
    }
}

@Composable
private fun EmptyStateView() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(80.dp)
                .clip(CircleShape)
                .background(Color(0xFFE1F1FF)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Outlined.Biotech,
                contentDescription = null,
                tint = Color(0xFF0061A4),
                modifier = Modifier.size(40.dp)
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        Text(
            text = "ابحث عن التحليل",
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF001D35),
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = "يمكنك البحث بالعربي أو الإنجليزي أو الاسم الدارج",
            fontSize = 14.sp,
            fontWeight = FontWeight.Medium,
            color = Color(0xFF64748B),
            textAlign = TextAlign.Center
        )
    }
}

@Composable
private fun NoResultsView() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(80.dp)
                .clip(CircleShape)
                .background(Color(0xFFFEE2E2)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Outlined.SearchOff,
                contentDescription = null,
                tint = Color(0xFFDC2626),
                modifier = Modifier.size(40.dp)
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        Text(
            text = "لم يتم العثور على التحليل",
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF001D35),
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = "جرّب البحث باسم مختلف أو بالاسم الإنجليزي",
            fontSize = 14.sp,
            fontWeight = FontWeight.Medium,
            color = Color(0xFF64748B),
            textAlign = TextAlign.Center
        )
    }
}
