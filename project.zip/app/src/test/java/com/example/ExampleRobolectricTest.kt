package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import org.json.JSONArray
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.InputStreamReader

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("دليل التحاليل والأسعار", appName)
  }

  @Test
  fun `verify lab_tests_android json asset contains exactly 331 valid records`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val inputStream = context.assets.open("lab_tests_android.json")
    val jsonString = InputStreamReader(inputStream, Charsets.UTF_8).use { it.readText() }
    val jsonArray = JSONArray(jsonString)

    // Confirm count is exactly 331
    assertEquals(331, jsonArray.length())

    val ids = mutableSetOf<Int>()
    for (i in 0 until jsonArray.length()) {
      val obj = jsonArray.getJSONObject(i)
      assertTrue("Record $i missing id", obj.has("id"))
      val id = obj.getInt("id")
      assertTrue("Duplicate ID found: $id", ids.add(id))

      assertTrue("Record $id missing lab_to_lab_price field", obj.has("lab_to_lab_price"))
      val lab2labRaw = if (obj.isNull("lab_to_lab_price")) null else obj.get("lab_to_lab_price")
      assertNotNull("lab_to_lab_price is null for test $id", lab2labRaw)
    }

    assertEquals(331, ids.size)
  }
}

