package com.example.ui

import android.app.DatePickerDialog
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.LockReset
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.AppUserProfile
import com.example.data.model.AuditLogEntry
import com.example.data.model.AuthorizedDevice
import com.example.data.model.CustomerOrder
import com.example.data.model.ReportSummary
import com.example.settings.LocalAppSettings
import com.example.settings.appText
import com.example.settings.tr
import com.example.util.PdfGenerator
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private val OpsPrimary = Color(0xFF006D86)
private val OpsDark = Color(0xFF17324D)
private val OpsGreen = Color(0xFF15803D)
private val OpsBg = Color(0xFFF4F7FB)

@Composable
fun OperationsSystemCard(isManager: Boolean, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier.size(46.dp).background(Color(0xFFEFF6FF), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.Assessment, contentDescription = null, tint = Color(0xFF0369A1))
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(appText("التقارير والحسابات", "Reports & Accounts"), fontWeight = FontWeight.ExtraBold, fontSize = 17.sp, color = OpsDark)
                Text(
                    appText("مبيعات • مديونيات • أرباح • مستخدمين • Audit", "Sales • Debts • Profit • Users • Audit"),
                    fontSize = 12.sp,
                    color = Color(0xFF64748B)
                )
            }
            Text(appText(tr("فتح", "Open"), "Open"), fontWeight = FontWeight.Bold, color = OpsPrimary)
        }
    }
}

@Composable
fun OperationsV14Dialog(
    viewModel: LabTestsViewModel,
    isManager: Boolean,
    initialPage: String = "home",
    initialDebtsOnly: Boolean = false,
    initialRange: String = "today",
    onDismiss: () -> Unit
) {
    if (!isManager) return
    var page by remember(initialPage) { mutableStateOf(initialPage) }

    val handleSystemBack: () -> Unit = {
        if (page != "home") page = "home" else onDismiss()
    }

    BackHandler(enabled = true) { handleSystemBack() }

    Dialog(
        onDismissRequest = handleSystemBack,
        properties = DialogProperties(usePlatformDefaultWidth = false, dismissOnBackPress = true)
    ) {
        Surface(modifier = Modifier.fillMaxSize(), color = OpsBg) {
            Column(Modifier.fillMaxSize()) {
                OperationsHeader(
                    title = when (page) {
                        "reports" -> appText("التقارير والحسابات", "Reports & Accounts")
                        "audit" -> appText("سجل المراجعة", "Audit Log")
                        "users" -> appText("المستخدمين والصلاحيات", "Users & Permissions")
                        "devices" -> appText("الأجهزة المصرح بها", "Authorized Devices")
                        "health" -> appText("حالة النظام", "System Health")
                        "alerts" -> appText("مركز التنبيهات", "Alert Center")
                        "integrity" -> appText("سلامة البيانات", "Data Integrity")
                        else -> appText("نظام الإدارة", "Administration")
                    },
                    subtitle = when (page) {
                        "reports" -> appText("مبيعات • مدفوع • مديونيات • إحصائيات", "Sales • Paid • Debts • Statistics")
                        "audit" -> appText("سجل كامل للعمليات والمزامنة", "Full operations and sync history")
                        "users" -> appText("إضافة وإيقاف وتحديد صلاحيات المستخدمين", "Add, disable and manage user permissions")
                        "devices" -> appText("اعتماد أو رفض أجهزة المستخدمين", "Approve or reject user devices")
                        "health" -> appText("الاتصال • Firebase • المزامنة • الأداء", "Connectivity • Firebase • Sync • Performance")
                        "alerts" -> appText("جديد • مهم • مزامنة • أجهزة • نشاط", "New • Important • Sync • Devices • Activity")
                        "integrity" -> appText("تكرار • تعارض • حسابات • إصلاح آمن", "Duplicates • Conflicts • Totals • Safe repair")
                        else -> appText("لوحة تشغيل وإدارة المدير", "Manager administration panel")
                    },
                    onBack = if (page != "home") ({ page = "home" }) else null,
                    onClose = onDismiss
                )

                when (page) {
                    "reports" -> if (isManager) ReportsScreen(
                        viewModel = viewModel,
                        isManager = true,
                        initialDebtsOnly = initialDebtsOnly,
                        initialRange = initialRange
                    ) else AccessDeniedCard()
                    "audit" -> if (isManager) AuditScreen(viewModel) else AccessDeniedCard()
                    "users" -> if (isManager) UsersScreen(viewModel) else AccessDeniedCard()
                    "devices" -> if (isManager) DevicesScreen(viewModel) else AccessDeniedCard()
                    "health" -> if (isManager) SystemHealthScreen(viewModel) else AccessDeniedCard()
                    "alerts" -> if (isManager) SmartAlertsScreen(viewModel) else AccessDeniedCard()
                    "integrity" -> if (isManager) DataIntegrityScreen(viewModel) else AccessDeniedCard()
                    else -> OperationsHome(viewModel = viewModel, isManager = isManager, onOpen = { page = it })
                }
            }
        }
    }
}

@Composable
private fun OperationsHeader(
    title: String,
    subtitle: String,
    onBack: (() -> Unit)?,
    onClose: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth().background(OpsDark).padding(horizontal = 10.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (onBack != null) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = appText(tr("رجوع", "Back"), "Back"), tint = Color.White) }
        }
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp)
            Text(subtitle, color = Color.White.copy(alpha = 0.78f), fontSize = 11.sp)
        }
        IconButton(onClick = onClose) { Icon(Icons.Default.Close, contentDescription = appText(tr("إغلاق", "Close"), "Close"), tint = Color.White) }
    }
}

@Composable
private fun OperationsHome(viewModel: LabTestsViewModel, isManager: Boolean, onOpen: (String) -> Unit) {
    val unreadAlerts by viewModel.unreadAdminAlertCount.collectAsState()
    LaunchedEffect(Unit) { viewModel.refreshAdminAlerts() }
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(bottom = 28.dp)
    ) {
        if (isManager) {
            item {
                OpsMenuCard(
                    icon = Icons.Default.Assessment,
                    title = appText("التقارير والحسابات", "Reports & Accounts"),
                    subtitle = appText("اليومي • الأسبوعي • الشهري • فترة مخصصة • المديونيات", "Daily • Weekly • Monthly • Custom period • Debts"),
                    accent = Color(0xFF0369A1),
                    onClick = { onOpen("reports") }
                )
            }
            item {
                OpsMenuCard(
                    icon = Icons.Default.People,
                    title = appText("المستخدمين والصلاحيات", "Users & Permissions"),
                    subtitle = appText("إضافة مستخدم • إيقاف/تفعيل • Roles • Reset PIN", "Add user • Enable/Disable • Roles • Reset PIN"),
                    accent = Color(0xFF7C3AED),
                    onClick = { onOpen("users") }
                )
            }
            item {
                OpsMenuCard(
                    icon = Icons.Default.AdminPanelSettings,
                    title = appText("الأجهزة المصرح بها", "Authorized Devices"),
                    subtitle = appText("طلبات أجهزة جديدة • اعتماد • رفض • إلغاء اعتماد", "New device requests • Approve • Reject • Revoke"),
                    accent = Color(0xFF0F766E),
                    onClick = { onOpen("devices") }
                )
            }
            item {
                OpsMenuCard(
                    icon = Icons.Default.NotificationsActive,
                    title = if (unreadAlerts > 0) appText("مركز التنبيهات ($unreadAlerts)", "Alert Center ($unreadAlerts)") else appText("مركز التنبيهات", "Alert Center"),
                    subtitle = appText("تنبيهات المزامنة • الأجهزة • النشاط • المديونيات", "Sync • Devices • Activity • Debts"),
                    accent = if (unreadAlerts > 0) Color(0xFFB91C1C) else Color(0xFF7C3AED),
                    onClick = { onOpen("alerts") }
                )
            }
            item {
                OpsMenuCard(
                    icon = Icons.Default.CheckCircle,
                    title = appText("سلامة البيانات", "Data Integrity"),
                    subtitle = appText("كشف التكرار • التعارضات • مراجعة الحسابات • إصلاح آمن", "Duplicates • Conflicts • Financial checks • Safe repair"),
                    accent = Color(0xFF0F766E),
                    onClick = { onOpen("integrity") }
                )
            }
            item {
                OpsMenuCard(
                    icon = Icons.Default.Speed,
                    title = appText("حالة النظام", "System Health"),
                    subtitle = appText("Firebase • سرعة الاستجابة • المزامنة • العمليات المعلقة", "Firebase • Latency • Sync • Pending operations"),
                    accent = Color(0xFF2563EB),
                    onClick = { onOpen("health") }
                )
            }
            item {
                OpsMenuCard(
                    icon = Icons.Default.History,
                    title = "Audit Log",
                    subtitle = appText("تعديلات العملاء والطلبات والخصومات والمدفوعات والأسعار", "Customers, orders, discounts, payments and prices"),
                    accent = Color(0xFFB45309),
                    onClick = { onOpen("audit") }
                )
            }
        }
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFE8F7ED))
            ) {
                Column(Modifier.padding(14.dp)) {
                    Text("V14", fontWeight = FontWeight.ExtraBold, color = Color(0xFF166534))
                    Text(
                        "الطلبات الملغية لا تدخل المبيعات، والتحصيلات تتسجل كسجل دفعات مستقل، وكل عملية حساسة لها Audit.",
                        fontSize = 12.sp,
                        color = Color(0xFF166534)
                    )
                }
            }
        }
    }
}

@Composable
private fun OpsMenuCard(icon: ImageVector, title: String, subtitle: String, accent: Color, onClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Row(Modifier.fillMaxWidth().padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(44.dp).background(accent.copy(alpha = 0.10f), CircleShape), contentAlignment = Alignment.Center) {
                Icon(icon, contentDescription = null, tint = accent)
            }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.ExtraBold, color = OpsDark)
                Text(subtitle, fontSize = 11.sp, color = Color(0xFF64748B))
            }
            Text(tr("فتح", "Open"), color = accent, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        }
    }
}

@Composable
private fun SmartAlertsScreen(viewModel: LabTestsViewModel) {
    val alerts by viewModel.adminAlerts.collectAsState()
    val unreadCount by viewModel.unreadAdminAlertCount.collectAsState()
    var filter by remember { mutableStateOf("new") }

    LaunchedEffect(Unit) { viewModel.refreshAdminAlerts() }

    val filtered = remember(alerts, filter) {
        when (filter) {
            "new" -> alerts.filter { !it.isRead }
            "important" -> alerts.filter { it.severity == "critical" || it.severity == "warning" }
            else -> alerts
        }
    }

    Column(Modifier.fillMaxSize().padding(14.dp)) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            Column(Modifier.padding(14.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(44.dp).background(Color(0xFFFEE2E2), CircleShape), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.NotificationsActive, contentDescription = null, tint = Color(0xFFB91C1C))
                    }
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(appText("مركز تنبيهات الإدارة", "Admin Alert Center"), fontWeight = FontWeight.ExtraBold, color = OpsDark)
                        Text(
                            appText("$unreadCount تنبيه جديد", "$unreadCount new alert(s)"),
                            fontSize = 11.sp,
                            color = if (unreadCount > 0) Color(0xFFB91C1C) else OpsGreen,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    IconButton(onClick = { viewModel.refreshAdminAlerts() }) {
                        Icon(Icons.Default.Refresh, contentDescription = appText("تحديث", "Refresh"), tint = OpsPrimary)
                    }
                }
                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    AlertFilterButton(appText("جديد", "New"), filter == "new", Modifier.weight(1f)) { filter = "new" }
                    AlertFilterButton(appText("مهم", "Important"), filter == "important", Modifier.weight(1f)) { filter = "important" }
                    AlertFilterButton(appText("الكل", "All"), filter == "all", Modifier.weight(1f)) { filter = "all" }
                }
                if (unreadCount > 0) {
                    TextButton(onClick = { viewModel.markAllAdminAlertsRead() }, modifier = Modifier.align(Alignment.End)) {
                        Icon(Icons.Default.DoneAll, contentDescription = null)
                        Spacer(Modifier.width(5.dp))
                        Text(appText("تحديد الكل كمقروء", "Mark all as read"))
                    }
                }
            }
        }

        Spacer(Modifier.height(10.dp))
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(bottom = 28.dp)
        ) {
            if (filtered.isEmpty()) {
                item { OpsMessage(appText("لا توجد تنبيهات في هذا القسم", "No alerts in this section"), true) }
            } else {
                items(filtered, key = { it.id }) { alert ->
                    AdminAlertRow(alert) { viewModel.markAdminAlertRead(alert.id) }
                }
            }
        }
    }
}

@Composable
private fun AlertFilterButton(text: String, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    if (selected) {
        Button(onClick = onClick, modifier = modifier, colors = ButtonDefaults.buttonColors(containerColor = OpsPrimary)) {
            Text(text, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
    } else {
        OutlinedButton(onClick = onClick, modifier = modifier) {
            Text(text, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun AdminAlertRow(alert: AdminAlert, onMarkRead: () -> Unit) {
    val accent = when (alert.severity) {
        "critical" -> Color(0xFFB91C1C)
        "warning" -> Color(0xFFB45309)
        else -> Color(0xFF2563EB)
    }
    val bg = if (alert.isRead) Color.White else accent.copy(alpha = 0.07f)
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = bg)
    ) {
        Column(Modifier.padding(13.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
                Box(Modifier.size(38.dp).background(accent.copy(alpha = 0.12f), CircleShape), contentAlignment = Alignment.Center) {
                    Icon(
                        if (alert.severity == "critical") Icons.Default.Warning else Icons.Default.NotificationsActive,
                        contentDescription = null,
                        tint = accent
                    )
                }
                Spacer(Modifier.width(9.dp))
                Column(Modifier.weight(1f)) {
                    Text(appText(alert.titleAr, alert.titleEn), fontWeight = FontWeight.ExtraBold, color = OpsDark)
                    Text(appText(alert.detailsAr, alert.detailsEn), fontSize = 11.sp, color = Color(0xFF475569), maxLines = 4, overflow = TextOverflow.Ellipsis)
                    if (alert.actorEmail.isNotBlank()) {
                        Text(alert.actorEmail, fontSize = 9.sp, color = OpsPrimary)
                    }
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(opsDate(alert.createdAtMillis), fontSize = 9.sp, color = Color(0xFF64748B))
                    if (!alert.isRead) {
                        TextButton(onClick = onMarkRead, contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp)) {
                            Text(appText("مقروء", "Read"), fontSize = 10.sp, color = accent)
                        }
                    }
                }
            }
            Spacer(Modifier.height(4.dp))
            Text(
                when (alert.severity) {
                    "critical" -> appText("مهم", "Important")
                    "warning" -> appText("تنبيه", "Warning")
                    else -> appText("معلومة", "Info")
                },
                fontSize = 9.sp,
                color = accent,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
private fun DataIntegrityScreen(viewModel: LabTestsViewModel) {
    val state by viewModel.dataIntegrityState.collectAsState()
    val issues by viewModel.dataIntegrityIssues.collectAsState()
    var resultMessage by remember { mutableStateOf("") }

    LaunchedEffect(Unit) { viewModel.refreshDataIntegrity() }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(bottom = 28.dp)
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (state.criticalCount > 0) Color(0xFFFFF1F2) else Color(0xFFECFDF5)
                )
            ) {
                Column(Modifier.padding(15.dp)) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            if (state.criticalCount > 0) Icons.Default.Warning else Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = if (state.criticalCount > 0) Color(0xFFB91C1C) else OpsGreen,
                            modifier = Modifier.size(32.dp)
                        )
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                if (state.checking) appText("جار فحص البيانات...", "Scanning data...")
                                else if (state.issueCount == 0 && state.checkedAtMillis > 0L) appText("البيانات المفحوصة سليمة", "Scanned data looks healthy")
                                else appText("مراجعة سلامة البيانات", "Data integrity review"),
                                fontWeight = FontWeight.ExtraBold,
                                color = OpsDark,
                                fontSize = 17.sp
                            )
                            Text(state.message, fontSize = 11.sp, color = Color(0xFF64748B))
                        }
                        IconButton(onClick = { viewModel.refreshDataIntegrity() }, enabled = !state.checking) {
                            if (state.checking) CircularProgressIndicator(modifier = Modifier.size(22.dp), strokeWidth = 2.dp)
                            else Icon(Icons.Default.Refresh, contentDescription = appText("تحديث", "Refresh"), tint = OpsPrimary)
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        IntegrityStat(appText("العملاء", "Customers"), state.customersScanned.toString(), Modifier.weight(1f))
                        IntegrityStat(appText("الطلبات", "Orders"), state.ordersScanned.toString(), Modifier.weight(1f))
                        IntegrityStat(appText("الملاحظات", "Findings"), state.issueCount.toString(), Modifier.weight(1f))
                    }
                }
            }
        }

        if (resultMessage.isNotBlank()) {
            item { OpsMessage(resultMessage, !resultMessage.contains("تعذر") && !resultMessage.contains("Could not")) }
        }

        if (!state.checking && issues.isEmpty() && state.checkedAtMillis > 0L) {
            item { OpsMessage(appText("لم يتم اكتشاف تكرار أو خلل حسابي أو تعارض واضح في البيانات المفحوصة.", "No duplicate, arithmetic, or obvious conflict issue was found in the scanned data."), true) }
        }

        items(issues, key = { it.id }) { issue ->
            val critical = issue.severity == "critical"
            val accent = if (critical) Color(0xFFB91C1C) else Color(0xFFB45309)
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = accent.copy(alpha = 0.07f))
            ) {
                Column(Modifier.padding(13.dp)) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
                        Icon(if (critical) Icons.Default.Warning else Icons.Default.Assessment, contentDescription = null, tint = accent)
                        Spacer(Modifier.width(9.dp))
                        Column(Modifier.weight(1f)) {
                            Text(appText(issue.titleAr, issue.titleEn), fontWeight = FontWeight.ExtraBold, color = OpsDark)
                            Text(appText(issue.detailsAr, issue.detailsEn), fontSize = 11.sp, color = Color(0xFF475569))
                        }
                    }
                    if (issue.type == "financial_mismatch" || issue.type == "payment_status") {
                        Spacer(Modifier.height(8.dp))
                        OutlinedButton(
                            onClick = {
                                viewModel.repairIntegrityIssue(issue) { _, message -> resultMessage = message }
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.Sync, contentDescription = null)
                            Spacer(Modifier.width(6.dp))
                            Text(appText("إصلاح آمن بدون حذف بيانات", "Safe repair without deleting data"))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun IntegrityStat(title: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier = modifier, colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(Modifier.padding(9.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value, fontWeight = FontWeight.ExtraBold, color = OpsPrimary, fontSize = 16.sp)
            Text(title, fontSize = 9.sp, color = Color(0xFF64748B))
        }
    }
}

@Composable
private fun SystemHealthScreen(viewModel: LabTestsViewModel) {
    val isOnline by viewModel.isOnline.collectAsState()
    val pendingCount by viewModel.pendingSyncCount.collectAsState()
    val lastSync by viewModel.lastSuccessfulSyncMillis.collectAsState()
    val health by viewModel.systemHealth.collectAsState()

    LaunchedEffect(isOnline) { viewModel.refreshSystemHealth() }

    val overallGood = isOnline && health.firebaseReachable == true && pendingCount == 0
    val overallColor = when {
        overallGood -> OpsGreen
        !isOnline || health.firebaseReachable == false -> Color(0xFFB91C1C)
        else -> Color(0xFFB45309)
    }
    val overallText = when {
        overallGood -> appText("النظام يعمل بشكل جيد", "System is healthy")
        !isOnline -> appText("الجهاز غير متصل بالإنترنت", "Device is offline")
        health.checking -> appText("جار فحص النظام...", "Checking system...")
        health.firebaseReachable == false -> appText("يوجد مشكلة في الوصول إلى Firebase", "Firebase is currently unreachable")
        pendingCount > 0 -> appText("توجد عمليات في انتظار المزامنة", "Some operations are waiting to sync")
        else -> appText("حالة النظام غير مكتملة", "System status is incomplete")
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(bottom = 28.dp)
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = overallColor.copy(alpha = 0.10f))
            ) {
                Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (overallGood) Icons.Default.CheckCircle else Icons.Default.Assessment,
                        contentDescription = null,
                        tint = overallColor,
                        modifier = Modifier.size(34.dp)
                    )
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(overallText, fontWeight = FontWeight.ExtraBold, color = overallColor, fontSize = 17.sp)
                        if (health.message.isNotBlank()) {
                            Text(health.message, fontSize = 11.sp, color = Color(0xFF64748B))
                        }
                    }
                    IconButton(onClick = { viewModel.refreshSystemHealth() }, enabled = !health.checking) {
                        if (health.checking) {
                            CircularProgressIndicator(modifier = Modifier.size(22.dp), strokeWidth = 2.dp)
                        } else {
                            Icon(Icons.Default.Refresh, contentDescription = appText("تحديث", "Refresh"), tint = OpsPrimary)
                        }
                    }
                }
            }
        }

        item {
            SystemHealthMetricCard(
                icon = Icons.Default.Wifi,
                title = appText("اتصال الإنترنت", "Internet Connection"),
                value = if (isOnline) appText("متصل", "Online") else appText("غير متصل", "Offline"),
                good = isOnline
            )
        }
        item {
            SystemHealthMetricCard(
                icon = if (health.firebaseReachable == false) Icons.Default.CloudOff else Icons.Default.CloudDone,
                title = "Firebase / Firestore",
                value = when {
                    health.checking -> appText("جار الفحص", "Checking")
                    health.firebaseReachable == true -> appText("متصل", "Reachable")
                    health.firebaseReachable == false -> appText("غير متاح حاليا", "Unreachable")
                    else -> appText("لم يتم الفحص بعد", "Not checked yet")
                },
                good = health.firebaseReachable == true
            )
        }
        item {
            val latency = health.latencyMs
            SystemHealthMetricCard(
                icon = Icons.Default.Speed,
                title = appText("زمن استجابة Firebase", "Firebase Latency"),
                value = if (latency == null) "—" else "$latency ms",
                good = latency != null && latency < 1000L
            )
        }
        item {
            SystemHealthMetricCard(
                icon = Icons.Default.Sync,
                title = appText("عمليات في انتظار المزامنة", "Pending Sync Operations"),
                value = pendingCount.toString(),
                good = pendingCount == 0
            )
        }
        item {
            val lastSyncText = if (lastSync <= 0L) {
                appText("لا يوجد تسجيل بعد", "No sync recorded yet")
            } else {
                SimpleDateFormat("dd/MM/yyyy  HH:mm:ss", Locale.getDefault()).format(Date(lastSync))
            }
            SystemHealthMetricCard(
                icon = Icons.Default.History,
                title = appText("آخر مزامنة مكتملة", "Last Completed Sync"),
                value = lastSyncText,
                good = lastSync > 0L
            )
        }
        item {
            SystemHealthMetricCard(
                icon = Icons.Default.Storage,
                title = appText("الـ Cache المحلي", "Local Cache"),
                value = "200 MB",
                good = true
            )
        }
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                Column(Modifier.padding(14.dp)) {
                    Text(appText("إعدادات الأداء V29", "V29 Performance Policy"), fontWeight = FontWeight.ExtraBold, color = OpsDark)
                    Text(appText("تحميل تقارير على دفعات حتى 750 سجل لكل دفعة، Cache محلي 200 MB، ومزامنة Offline تلقائية.", "Reports load in pages up to 750 records, 200 MB local cache, and automatic offline synchronization."), fontSize = 12.sp, color = Color(0xFF64748B))
                }
            }
        }
        item {
            Text(
                appText("ملاحظة: الفحص يقيس اتصال هذا الجهاز ووصوله إلى Firebase في اللحظة الحالية، وليس لوحة مراقبة عالمية للبنية التحتية لـ Firebase.", "Note: this checks the current device connection and Firebase reachability; it is not a global Firebase infrastructure monitoring console."),
                fontSize = 10.sp,
                color = Color(0xFF64748B)
            )
        }
    }
}

@Composable
private fun SystemHealthMetricCard(
    icon: ImageVector,
    title: String,
    value: String,
    good: Boolean
) {
    val accent = if (good) OpsGreen else Color(0xFFB45309)
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(40.dp).background(accent.copy(alpha = 0.10f), CircleShape), contentAlignment = Alignment.Center) {
                Icon(icon, contentDescription = null, tint = accent)
            }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontSize = 12.sp, color = Color(0xFF64748B))
                Text(value, fontWeight = FontWeight.ExtraBold, color = OpsDark, fontSize = 15.sp)
            }
        }
    }
}

@Composable
private fun ReportsScreen(
    viewModel: LabTestsViewModel,
    isManager: Boolean,
    initialDebtsOnly: Boolean = false,
    initialRange: String = "today"
) {
    val context = LocalContext.current
    val settings by viewModel.appSettings.collectAsState()
    val orders by viewModel.reportOrders.collectAsState()
    val loading by viewModel.reportsLoading.collectAsState()
    var range by remember(initialRange) { mutableStateOf(initialRange) }
    var query by remember { mutableStateOf("") }
    var debtsOnly by remember(initialDebtsOnly) { mutableStateOf(initialDebtsOnly) }
    var fromText by remember { mutableStateOf("") }
    var toText by remember { mutableStateOf("") }
    var selectedFromMillis by remember { mutableStateOf(startOfToday()) }
    var selectedToMillis by remember { mutableStateOf(System.currentTimeMillis()) }
    var message by remember { mutableStateOf<String?>(null) }

    fun setDisplayedPeriod(from: Long, to: Long) {
        selectedFromMillis = from
        selectedToMillis = to
        fromText = if (from > 0L) formatDateField(from) else ""
        toText = if (to > 0L) formatDateField(to) else ""
    }

    fun loadPreset(value: String) {
        range = value
        val now = System.currentTimeMillis()
        val from = when (value) {
            "week" -> startOfDaysAgo(6)
            "month" -> startOfDaysAgo(29)
            "all" -> 0L
            else -> startOfToday()
        }
        setDisplayedPeriod(from, now)
        viewModel.loadReports(from, now) { ok, msg -> if (!ok) message = msg }
    }

    fun showDatePicker(currentText: String, onSelected: (String) -> Unit) {
        val initialMillis = parseDateStart(currentText) ?: System.currentTimeMillis()
        val cal = Calendar.getInstance().apply { timeInMillis = initialMillis }
        DatePickerDialog(
            context,
            { _, year, month, day ->
                val picked = Calendar.getInstance().apply {
                    set(Calendar.YEAR, year)
                    set(Calendar.MONTH, month)
                    set(Calendar.DAY_OF_MONTH, day)
                    set(Calendar.HOUR_OF_DAY, 0)
                    set(Calendar.MINUTE, 0)
                    set(Calendar.SECOND, 0)
                    set(Calendar.MILLISECOND, 0)
                }
                onSelected(formatDateField(picked.timeInMillis))
            },
            cal.get(Calendar.YEAR),
            cal.get(Calendar.MONTH),
            cal.get(Calendar.DAY_OF_MONTH)
        ).show()
    }

    LaunchedEffect(initialRange) { loadPreset(initialRange) }

    val filtered = remember(orders, query, debtsOnly) {
        val normalized = query.trim().lowercase()
        orders.filter { order ->
            val matchesDebt = !debtsOnly || order.remainingAmount > 0.0
            val matchesQuery = normalized.isBlank() ||
                order.customerName.lowercase().contains(normalized) ||
                order.customerFileNumber.lowercase().contains(normalized) ||
                order.orderNumber.lowercase().contains(normalized) ||
                order.createdByEmail.lowercase().contains(normalized) ||
                paymentStatusLabel(order.paymentStatus).contains(query.trim())
            matchesDebt && matchesQuery
        }
    }
    val summary = viewModel.calculateReportSummary(filtered)
    val topTests = remember(filtered) {
        filtered.flatMap { it.items }
            .groupingBy { it.englishName.ifBlank { it.arabicName }.ifBlank { it.marketName } }
            .eachCount()
            .entries.sortedByDescending { it.value }.take(5)
    }

    val periodLabel = when {
        selectedFromMillis <= 0L -> "كل الفترات حتى ${formatDateDisplay(selectedToMillis)}"
        else -> "من ${formatDateDisplay(selectedFromMillis)} إلى ${formatDateDisplay(selectedToMillis)}"
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(bottom = 30.dp)
    ) {
        message?.let { item { OpsMessage(it, false) } }

        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("today" to tr("اليوم", "Today"), "week" to tr("7 أيام", "7 Days"), "month" to tr("30 يوم", "30 Days"), "all" to tr("الكل", "All")).forEach { (value, label) ->
                    Button(
                        onClick = { loadPreset(value) },
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(horizontal = 3.dp, vertical = 8.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (range == value) OpsPrimary else Color(0xFFE2E8F0),
                            contentColor = if (range == value) Color.White else Color(0xFF334155)
                        )
                    ) { Text(label, fontSize = 10.sp, fontWeight = FontWeight.Bold) }
                }
            }
        }

        item {
            Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    Text(tr("فترة مخصصة", "Custom Range"), fontWeight = FontWeight.ExtraBold, color = OpsDark)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        ReportDateField(
                            label = tr("من", "From"),
                            value = fromText,
                            modifier = Modifier.weight(1f),
                            onClick = { showDatePicker(fromText) { fromText = it } }
                        )
                        ReportDateField(
                            label = tr("إلى", "To"),
                            value = toText,
                            modifier = Modifier.weight(1f),
                            onClick = { showDatePicker(toText) { toText = it } }
                        )
                    }
                    OutlinedButton(
                        onClick = {
                            val from = parseDateStart(fromText)
                            val to = parseDateEnd(toText)
                            if (from == null || to == null || from > to) {
                                message = tr("حدد تاريخ البداية والنهاية من التقويم", "Select start and end dates from the calendar")
                            } else {
                                range = "custom"
                                message = null
                                setDisplayedPeriod(from, to)
                                viewModel.loadReports(from, to) { ok, msg -> if (!ok) message = msg }
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text(tr("عرض التقرير للفترة المحددة", "Show Report for Selected Range")) }
                }
            }
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFE7F5F7))
            ) {
                Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Text(appText("فترة التقرير", "Report period"), fontWeight = FontWeight.ExtraBold, color = OpsDark)
                    Text(periodLabel, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = OpsPrimary)
                    Button(
                        onClick = {
                            PdfGenerator.generateAndShareReportPdf(
                                context = context,
                                orders = filtered,
                                summary = summary,
                                fromMillis = selectedFromMillis,
                                toMillis = selectedToMillis,
                                labName = settings.pdfLabName,
                                showContactInfo = settings.pdfShowContactInfo,
                                contactInfo = settings.pdfContactInfo,
                                debtsOnly = debtsOnly,
                                query = query,
                                language = settings.language
                            )
                        },
                        modifier = Modifier.fillMaxWidth(),
                        enabled = !loading
                    ) {
                        Icon(Icons.Default.PictureAsPdf, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text(appText("طباعة / حفظ / مشاركة التقرير PDF", "Print / Save / Share report PDF"))
                    }
                }
            }
        }

        item {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth().heightIn(min = 72.dp),
                label = { Text(tr("بحث: عميل / طلب / مستخدم / حالة دفع", "Search: customer / order / user / payment status")) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                singleLine = true
            )
        }

        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ReportMetricCard(tr("الطلبات", "Orders"), summary.ordersCount.toString(), Icons.Default.Assessment, Color(0xFF0369A1), Modifier.weight(1f))
                ReportMetricCard(tr("العملاء", "Customers"), summary.customersCount.toString(), Icons.Default.People, Color(0xFF7C3AED), Modifier.weight(1f))
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ReportMetricCard(tr("المبيعات", "Sales"), "${opsMoney(summary.sales)} ج", Icons.Default.TrendingUp, OpsGreen, Modifier.weight(1f))
                ReportMetricCard(tr("الخصومات", "Discounts"), "${opsMoney(summary.discounts)} ج", Icons.Default.Assessment, Color(0xFFB45309), Modifier.weight(1f))
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ReportMetricCard(tr("المدفوع", "Paid"), "${opsMoney(summary.paid)} ج", Icons.Default.Payments, OpsGreen, Modifier.weight(1f))
                ReportMetricCard(tr("المتبقي", "Remaining"), "${opsMoney(summary.remaining)} ج", Icons.Default.AccountBalanceWallet, Color(0xFFB91C1C), Modifier.weight(1f))
            }
        }
        if (isManager) {
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ReportMetricCard(tr("تكلفة Lab2Lab*", "Lab2Lab Cost*"), "${opsMoney(summary.estimatedLabCost)} ج", Icons.Default.AdminPanelSettings, Color(0xFF475569), Modifier.weight(1f))
                    ReportMetricCard(tr("ربح تقديري*", "Estimated Profit*"), "${opsMoney(summary.estimatedProfit)} ج", Icons.Default.TrendingUp, Color(0xFF0F766E), Modifier.weight(1f))
                }
                Text(tr("* التقدير يستخدم أسعار Lab2Lab الحالية.", "* Estimate uses current Lab2Lab prices."), fontSize = 10.sp, color = Color(0xFF64748B))
            }
        }

        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(tr("المديونيات", "Debts"), fontWeight = FontWeight.ExtraBold, color = OpsDark)
                OutlinedButton(onClick = { debtsOnly = !debtsOnly }) {
                    Text(if (debtsOnly) tr("عرض الكل", "Show All") else tr("المتبقي فقط", "Outstanding Only"), fontSize = 11.sp)
                }
            }
        }

        if (topTests.isNotEmpty()) {
            item {
                Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                    Column(Modifier.padding(13.dp)) {
                        Text(tr("أكثر التحاليل طلبًا", "Most Requested Tests"), fontWeight = FontWeight.ExtraBold, color = OpsDark)
                        Spacer(Modifier.height(6.dp))
                        topTests.forEachIndexed { index, entry ->
                            Text("${index + 1}. ${entry.key} — ${entry.value}", fontSize = 12.sp, color = Color(0xFF475569))
                        }
                    }
                }
            }
        }

        when {
            loading -> item { Box(Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator() } }
            filtered.isEmpty() -> item { OpsMessage(tr("لا توجد طلبات في الفترة/الفلاتر الحالية", "No orders for the current period/filters"), true) }
            else -> items(filtered, key = { "${it.customerId}_${it.id}" }) { order -> ReportOrderRow(order) }
        }
    }
}

@Composable
private fun ReportDateField(
    label: String,
    value: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    OutlinedButton(
        onClick = onClick,
        modifier = modifier.height(58.dp),
        shape = RoundedCornerShape(12.dp),
        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 5.dp)
    ) {
        Column(Modifier.weight(1f), horizontalAlignment = Alignment.Start) {
            Text(label, fontSize = 10.sp, color = Color(0xFF64748B))
            Text(
                if (value.isBlank()) tr("اختر التاريخ", "Choose Date") else value,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = if (value.isBlank()) Color(0xFF94A3B8) else OpsDark
            )
        }
        Icon(Icons.Default.CalendarMonth, contentDescription = tr("اختيار التاريخ", "Select Date"), tint = OpsPrimary)
    }
}

@Composable
private fun ReportMetricCard(title: String, value: String, icon: ImageVector, accent: Color, modifier: Modifier) {
    Card(modifier = modifier, shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(Modifier.padding(12.dp)) {
            Icon(icon, contentDescription = null, tint = accent, modifier = Modifier.size(20.dp))
            Spacer(Modifier.height(5.dp))
            Text(title, fontSize = 10.sp, color = Color(0xFF64748B))
            Text(value, fontWeight = FontWeight.ExtraBold, color = accent, fontSize = 16.sp)
        }
    }
}

@Composable
private fun ReportOrderRow(order: CustomerOrder) {
    Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(15.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(Modifier.padding(12.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column(Modifier.weight(1f)) {
                    Text(order.customerName.ifBlank { order.customerFileNumber }, fontWeight = FontWeight.ExtraBold, color = OpsDark, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(order.orderNumber, fontSize = 10.sp, color = OpsPrimary)
                    Text(opsDate(order.createdAtMillis), fontSize = 10.sp, color = Color(0xFF64748B))
                    if (order.createdByEmail.isNotBlank()) Text(order.createdByEmail, fontSize = 10.sp, color = Color(0xFF64748B))
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("${opsMoney(order.totalCustomerPrice)} ${tr("ج", "EGP")}", fontWeight = FontWeight.ExtraBold, color = OpsGreen)
                    Text(paymentStatusLabel(order.paymentStatus), fontSize = 10.sp, color = if (order.remainingAmount > 0) Color(0xFFB91C1C) else OpsGreen)
                }
            }
            if (order.remainingAmount > 0.0) {
                Spacer(Modifier.height(5.dp))
                Text(tr("متبقي ${opsMoney(order.remainingAmount)} ج", "Outstanding ${opsMoney(order.remainingAmount)} EGP"), color = Color(0xFFB91C1C), fontWeight = FontWeight.Bold, fontSize = 11.sp)
            }
        }
    }
}

@Composable
private fun AuditScreen(viewModel: LabTestsViewModel) {
    val logs by viewModel.auditLogs.collectAsState()
    var query by remember { mutableStateOf("") }
    var message by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(Unit) { viewModel.loadAuditLogs { ok, msg -> if (!ok) message = msg } }

    val filtered = remember(logs, query) {
        val q = query.trim().lowercase()
        if (q.isBlank()) logs else logs.filter {
            listOf(it.title, it.details, it.actorEmail, it.action, it.entityType).joinToString(" ").lowercase().contains(q)
        }
    }

    Column(Modifier.fillMaxSize().padding(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.weight(1f).heightIn(min = 72.dp),
                label = { Text(appText("بحث في السجل", "Search audit log")) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                singleLine = true
            )
            IconButton(onClick = { viewModel.loadAuditLogs() }) { Icon(Icons.Default.Refresh, contentDescription = appText("تحديث", "Refresh")) }
        }
        message?.let { OpsMessage(it, false) }
        Spacer(Modifier.height(8.dp))
        LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(7.dp), contentPadding = PaddingValues(bottom = 28.dp)) {
            if (filtered.isEmpty()) item { OpsMessage(appText("لا توجد سجلات", "No audit records"), true) }
            else items(filtered, key = { it.id }) { AuditRow(it) }
        }
    }
}

@Composable
private fun AuditRow(entry: AuditLogEntry) {
    Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(Modifier.padding(12.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(entry.title, fontWeight = FontWeight.ExtraBold, color = OpsDark, modifier = Modifier.weight(1f))
                Text(opsDate(entry.createdAtMillis), fontSize = 9.sp, color = Color(0xFF64748B))
            }
            if (entry.details.isNotBlank()) Text(entry.details, fontSize = 11.sp, color = Color(0xFF475569), maxLines = 4, overflow = TextOverflow.Ellipsis)
            if (entry.actorEmail.isNotBlank()) Text(appText("بواسطة: ${entry.actorEmail}", "By: ${entry.actorEmail}"), fontSize = 10.sp, color = OpsPrimary)
            if (entry.wasOffline) {
                Text(
                    appText(
                        "تمت العملية بدون إنترنت ثم وصلت للسيرفر عند رجوع الشبكة",
                        "Performed offline and delivered to the server after reconnect"
                    ),
                    fontSize = 10.sp,
                    color = Color(0xFFB45309),
                    fontWeight = FontWeight.Bold
                )
                if (entry.syncedAtMillis > 0L) {
                    Text(
                        appText("وقت المزامنة: ${opsDate(entry.syncedAtMillis)}", "Synced: ${opsDate(entry.syncedAtMillis)}"),
                        fontSize = 9.sp,
                        color = Color(0xFF64748B)
                    )
                }
            }
            Text("${entry.entityType} • ${entry.action}", fontSize = 9.sp, color = Color(0xFF94A3B8))
        }
    }
}

@Composable
private fun UsersScreen(viewModel: LabTestsViewModel) {
    val users by viewModel.users.collectAsState()
    var showAdd by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<AppUserProfile?>(null) }
    var message by remember { mutableStateOf<String?>(null) }
    var success by remember { mutableStateOf(true) }

    LaunchedEffect(Unit) { viewModel.loadUsers { ok, msg -> success = ok; if (!ok) message = msg } }

    Column(Modifier.fillMaxSize().padding(14.dp)) {
        Button(
            onClick = { showAdd = true },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(containerColor = OpsPrimary)
        ) {
            Icon(Icons.Default.PersonAdd, contentDescription = null)
            Spacer(Modifier.width(6.dp))
            Text(tr("إضافة مستخدم جديد", "Add New User"), fontWeight = FontWeight.ExtraBold)
        }
        message?.let { Spacer(Modifier.height(8.dp)); OpsMessage(it, success) }
        Spacer(Modifier.height(10.dp))
        LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 28.dp)) {
            items(users, key = { it.uid }) { profile ->
                Card(
                    modifier = Modifier.fillMaxWidth().clickable { editing = profile },
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = if (profile.enabled) Color.White else Color(0xFFF1F5F9))
                ) {
                    Row(Modifier.fillMaxWidth().padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier.size(42.dp).background(if (profile.enabled) Color(0xFFE7F5F7) else Color(0xFFE2E8F0), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(if (profile.enabled) Icons.Default.CheckCircle else Icons.Default.Block, contentDescription = null, tint = if (profile.enabled) OpsGreen else Color(0xFF64748B))
                        }
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(profile.displayName.ifBlank { profile.email }, fontWeight = FontWeight.ExtraBold, color = OpsDark)
                            Text(profile.email, fontSize = 11.sp, color = Color(0xFF64748B))
                            Text("${roleArabic(profile.role)} • ${if (profile.enabled) tr("نشط", "Active") else tr("موقوف", "Disabled")}", fontSize = 11.sp, color = if (profile.enabled) OpsGreen else Color(0xFFB91C1C), fontWeight = FontWeight.Bold)
                        }
                        Icon(Icons.Default.Edit, contentDescription = null, tint = OpsPrimary)
                    }
                }
            }
        }
    }

    if (showAdd) {
        AddUserDialog(
            onDismiss = { showAdd = false },
            onCreate = { name, email, password, role, done ->
                viewModel.createUserAccount(name, email, password, role) { ok, msg ->
                    done()
                    success = ok
                    message = msg
                    if (ok) showAdd = false
                }
            }
        )
    }

    editing?.let { profile ->
        UserAccessDialog(
            profile = profile,
            onDismiss = { editing = null },
            onSave = { enabled, role, editCustomers, discount, collect, reports, done ->
                viewModel.updateUserAccess(profile, enabled, role, editCustomers, discount, collect, reports) { ok, msg ->
                    done()
                    success = ok
                    message = msg
                    if (ok) editing = null
                }
            },
            onResetPin = {
                viewModel.requestUserPinReset(profile) { ok, msg ->
                    success = ok
                    message = msg
                }
            }
        )
    }
}

@Composable
private fun DevicesScreen(viewModel: LabTestsViewModel) {
    val devices by viewModel.authorizedDevices.collectAsState()
    var message by remember { mutableStateOf<String?>(null) }
    var success by remember { mutableStateOf(true) }

    LaunchedEffect(Unit) {
        viewModel.loadAuthorizedDevices { ok, msg ->
            success = ok
            if (!ok) message = msg
        }
    }

    Column(Modifier.fillMaxSize().padding(14.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(tr("تصريح الأجهزة", "Device Authorization"), fontWeight = FontWeight.ExtraBold, color = OpsDark, fontSize = 18.sp)
                Text(tr("كل مستخدم له جهاز واحد معتمد في نفس الوقت", "Each user can have one approved device at a time"), fontSize = 11.sp, color = Color(0xFF64748B))
            }
            IconButton(onClick = {
                viewModel.loadAuthorizedDevices { ok, msg ->
                    success = ok
                    message = if (ok) null else msg
                }
            }) {
                Icon(Icons.Default.Refresh, contentDescription = appText("تحديث", "Refresh"), tint = OpsPrimary)
            }
        }

        message?.let {
            Spacer(Modifier.height(8.dp))
            OpsMessage(it, success)
        }
        Spacer(Modifier.height(8.dp))

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(bottom = 28.dp)
        ) {
            if (devices.isEmpty()) {
                item { OpsMessage(tr("لا توجد طلبات أجهزة حتى الآن", "No device requests yet"), true) }
            } else {
                items(devices, key = { "${it.uid}_${it.id}" }) { device ->
                    DeviceAccessCard(
                        device = device,
                        onApprove = {
                            viewModel.approveDevice(device) { ok, msg ->
                                success = ok
                                message = msg
                            }
                        },
                        onReject = {
                            viewModel.setDeviceStatus(device, "rejected") { ok, msg ->
                                success = ok
                                message = msg
                            }
                        },
                        onRevoke = {
                            viewModel.setDeviceStatus(device, "revoked") { ok, msg ->
                                success = ok
                                message = msg
                            }
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun DeviceAccessCard(
    device: AuthorizedDevice,
    onApprove: () -> Unit,
    onReject: () -> Unit,
    onRevoke: () -> Unit
) {
    val statusText = when (device.status) {
        "approved" -> tr("معتمد", "Approved")
        "rejected" -> tr("مرفوض", "Rejected")
        "revoked" -> tr("تم إلغاء الاعتماد", "Authorization Revoked")
        else -> tr("بانتظار الموافقة", "Pending Approval")
    }
    val statusColor = when (device.status) {
        "approved" -> OpsGreen
        "pending" -> Color(0xFFB45309)
        else -> Color(0xFFB91C1C)
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Column(Modifier.fillMaxWidth().padding(13.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(42.dp).background(Color(0xFFE7F5F7), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.AdminPanelSettings, contentDescription = null, tint = OpsPrimary)
                }
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(device.email.ifBlank { device.uid }, fontWeight = FontWeight.ExtraBold, color = OpsDark)
                    Text(
                        "${device.manufacturer} ${device.model}".trim().ifBlank { tr("جهاز Android", "Android Device") },
                        fontSize = 11.sp,
                        color = Color(0xFF64748B)
                    )
                    Text(statusText, fontSize = 11.sp, color = statusColor, fontWeight = FontWeight.Bold)
                }
            }

            when (device.status) {
                "approved" -> {
                    OutlinedButton(onClick = onRevoke, modifier = Modifier.fillMaxWidth()) {
                        Text(tr("إلغاء اعتماد الجهاز", "Revoke Device"))
                    }
                }
                "pending" -> {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = onApprove, modifier = Modifier.weight(1f)) { Text(tr("اعتماد", "Approve")) }
                        OutlinedButton(onClick = onReject, modifier = Modifier.weight(1f)) { Text(tr("رفض", "Reject")) }
                    }
                }
                else -> {
                    Button(onClick = onApprove, modifier = Modifier.fillMaxWidth()) {
                        Text(tr("اعتماد هذا الجهاز", "Approve This Device"))
                    }
                }
            }
        }
    }
}

@Composable
private fun AddUserDialog(
    onDismiss: () -> Unit,
    onCreate: (name: String, email: String, password: String, role: String, done: () -> Unit) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var role by remember { mutableStateOf("staff") }
    var saving by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = { if (!saving) onDismiss() },
        title = { Text(tr("إضافة مستخدم", "Add User"), fontWeight = FontWeight.ExtraBold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    modifier = Modifier.fillMaxWidth().heightIn(min = 72.dp),
                    value = name, onValueChange = { name = it.take(80) }, label = { Text(tr("الاسم", "Name")) }, singleLine = true)
                OutlinedTextField(
                    modifier = Modifier.fillMaxWidth().heightIn(min = 72.dp),
                    value = email, onValueChange = { email = it.trim() }, label = { Text(tr("البريد الإلكتروني", "Email")) }, singleLine = true)
                OutlinedTextField(
                    modifier = Modifier.fillMaxWidth().heightIn(min = 72.dp),
                    
                    value = password,
                    onValueChange = { password = it.take(50) },
                    label = { Text(tr("كلمة المرور - 6 أحرف على الأقل", "Password - at least 6 characters")) },
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    singleLine = true
                )
                Text(tr("الدور", "Role"), fontWeight = FontWeight.Bold)
                RoleButtons(role = role, onRole = { role = it })
            }
        },
        confirmButton = {
            Button(
                onClick = { if (!saving) { saving = true; onCreate(name, email, password, role) { saving = false } } },
                enabled = !saving
            ) { Text(if (saving) tr("جاري الإنشاء...", "Creating...") else tr("إنشاء الحساب", "Create Account")) }
        },
        dismissButton = { TextButton(onClick = onDismiss, enabled = !saving) { Text(tr("إلغاء", "Cancel")) } }
    )
}

@Composable
private fun UserAccessDialog(
    profile: AppUserProfile,
    onDismiss: () -> Unit,
    onSave: (
        enabled: Boolean,
        role: String,
        canEditCustomers: Boolean,
        canDiscount: Boolean,
        canCollectPayments: Boolean,
        canViewReports: Boolean,
        done: () -> Unit
    ) -> Unit,
    onResetPin: () -> Unit
) {
    var enabled by remember(profile.uid) { mutableStateOf(profile.enabled) }
    var role by remember(profile.uid) { mutableStateOf(profile.role) }
    var editCustomers by remember(profile.uid) { mutableStateOf(profile.canEditCustomers) }
    var discount by remember(profile.uid) { mutableStateOf(profile.canDiscount) }
    var collect by remember(profile.uid) { mutableStateOf(profile.canCollectPayments) }
    var saving by remember { mutableStateOf(false) }
    val isSuper = profile.role == "super_admin"

    AlertDialog(
        onDismissRequest = { if (!saving) onDismiss() },
        title = { Text(profile.displayName.ifBlank { profile.email }, fontWeight = FontWeight.ExtraBold) },
        text = {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                item { Text(profile.email, color = Color(0xFF64748B), fontSize = 12.sp) }
                item {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(tr("الحساب نشط", "Account Active"), fontWeight = FontWeight.Bold)
                            Text(tr("إيقافه يمنع استخدام النظام", "Disabling prevents system access"), fontSize = 10.sp, color = Color(0xFF64748B))
                        }
                        Switch(checked = enabled, onCheckedChange = { if (!isSuper) enabled = it }, enabled = !isSuper)
                    }
                }
                item { Text(tr("الدور", "Role"), fontWeight = FontWeight.Bold); RoleButtons(role, { if (!isSuper) role = it }) }
                item { PermissionSwitch(tr("تعديل بيانات العملاء", "Edit Customer Details"), editCustomers) { editCustomers = it } }
                item { PermissionSwitch(tr("إضافة خصومات", "Add Discounts"), discount) { discount = it } }
                item { PermissionSwitch(tr("تحصيل دفعات", "Collect Payments"), collect) { collect = it } }
                item {
                    Text(
                        tr("التقارير والحسابات العامة: للمدير فقط", "Global reports & accounts: manager only"),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFB45309)
                    )
                }
                if (!isSuper) {
                    item {
                        OutlinedButton(onClick = onResetPin, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Default.LockReset, contentDescription = null)
                            Spacer(Modifier.width(5.dp))
                            Text(tr("Reset PIN عند فتح التطبيق", "Reset PIN on next app open"))
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (!saving) {
                        saving = true
                        onSave(enabled, role, editCustomers, discount, collect, false) { saving = false }
                    }
                },
                enabled = !saving && !isSuper
            ) { Text(if (saving) tr("جاري الحفظ...", "Saving...") else tr("حفظ الصلاحيات", "Save Permissions")) }
        },
        dismissButton = { TextButton(onClick = onDismiss, enabled = !saving) { Text(tr("إغلاق", "Close")) } }
    )
}

@Composable
private fun PermissionSwitch(title: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(title, modifier = Modifier.weight(1f), fontSize = 12.sp)
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun RoleButtons(role: String, onRole: (String) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            listOf("staff" to tr("موظف", "Staff"), "reception" to tr("استقبال", "Reception"), "cashier" to tr("كاشير", "Cashier")).forEach { (value, label) ->
                OutlinedButton(onClick = { onRole(value) }, modifier = Modifier.weight(1f), contentPadding = PaddingValues(3.dp)) {
                    Text(if (role == value) "✓ $label" else label, fontSize = 9.sp)
                }
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            listOf("supervisor" to tr("مشرف", "Supervisor"), "manager" to tr("مدير", "Manager")).forEach { (value, label) ->
                OutlinedButton(onClick = { onRole(value) }, modifier = Modifier.weight(1f), contentPadding = PaddingValues(3.dp)) {
                    Text(if (role == value) "✓ $label" else label, fontSize = 9.sp)
                }
            }
        }
    }
}

@Composable
private fun AccessDeniedCard() {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text(tr("القسم متاح للمدير فقط", "Manager Only"), fontWeight = FontWeight.ExtraBold, color = Color(0xFFB91C1C))
    }
}

@Composable
private fun OpsMessage(message: String, success: Boolean) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = if (success) Color(0xFFE8F7ED) else Color(0xFFFFEEEE))
    ) {
        Text(
            message,
            modifier = Modifier.padding(10.dp),
            color = if (success) Color(0xFF166534) else Color(0xFFB91C1C),
            fontWeight = FontWeight.Bold,
            fontSize = 11.sp
        )
    }
}

private fun startOfToday(): Long {
    val cal = Calendar.getInstance()
    cal.set(Calendar.HOUR_OF_DAY, 0)
    cal.set(Calendar.MINUTE, 0)
    cal.set(Calendar.SECOND, 0)
    cal.set(Calendar.MILLISECOND, 0)
    return cal.timeInMillis
}

private fun startOfDaysAgo(days: Int): Long {
    val cal = Calendar.getInstance()
    cal.add(Calendar.DAY_OF_YEAR, -days.coerceAtLeast(0))
    cal.set(Calendar.HOUR_OF_DAY, 0)
    cal.set(Calendar.MINUTE, 0)
    cal.set(Calendar.SECOND, 0)
    cal.set(Calendar.MILLISECOND, 0)
    return cal.timeInMillis
}

private fun formatDateField(value: Long): String =
    if (value <= 0L) "" else SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(value))

private fun formatDateDisplay(value: Long): String =
    if (value <= 0L) "—" else SimpleDateFormat("dd/MM/yyyy", Locale("ar", "EG")).format(Date(value))

private fun parseDateStart(value: String): Long? {
    return try {
        val format = SimpleDateFormat("yyyy-MM-dd", Locale.US).apply { isLenient = false }
        format.parse(value.trim())?.time
    } catch (_: Exception) { null }
}

private fun parseDateEnd(value: String): Long? {
    val start = parseDateStart(value) ?: return null
    val cal = Calendar.getInstance().apply { timeInMillis = start }
    cal.set(Calendar.HOUR_OF_DAY, 23)
    cal.set(Calendar.MINUTE, 59)
    cal.set(Calendar.SECOND, 59)
    cal.set(Calendar.MILLISECOND, 999)
    return cal.timeInMillis
}

private fun opsMoney(value: Double): String =
    if (value % 1.0 == 0.0) value.toLong().toString() else String.format(Locale.US, "%.2f", value)

private fun opsDate(value: Long): String =
    if (value <= 0L) "—" else SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("ar", "EG")).format(Date(value))

private fun paymentStatusLabel(status: String): String = when (status) {
    "paid" -> "مدفوع"
    "partial" -> tr("مدفوع جزئي", "Partially Paid")
    else -> tr("غير مدفوع", "Unpaid")
}

private fun roleArabic(role: String): String = when (role) {
    "super_admin" -> "Super Admin"
    "manager" -> tr("مدير", "Manager")
    "supervisor" -> tr("مشرف", "Supervisor")
    "cashier" -> tr("كاشير", "Cashier")
    "reception" -> tr("استقبال", "Reception")
    else -> tr("موظف", "Staff")
}
