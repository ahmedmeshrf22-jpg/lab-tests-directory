package com.example.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.outlined.Biotech
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.Customer
import com.example.data.model.CustomerOrder
import com.example.settings.appText
import com.example.util.PdfGenerator

/**
 * V38: saving an order is independent from document generation/sharing.
 * This dialog appears only AFTER the order has already been saved successfully.
 * The user can close it immediately (save only), or generate/share any output on demand.
 */
@Composable
fun OrderPdfShareDialog(
    order: CustomerOrder,
    customer: Customer,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    var busyAction by remember { mutableStateOf<String?>(null) }

    fun runAction(key: String, block: () -> Unit) {
        if (busyAction != null) return
        busyAction = key
        try {
            block()
        } finally {
            busyAction = null
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(dismissOnBackPress = true)
    ) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = Color.White,
            border = BorderStroke(1.dp, Color(0xFFE2E8F0))
        ) {
            Column(
                modifier = Modifier.padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF15803D))
                    Text(
                        text = appText("تم حفظ الطلب", "Order saved"),
                        fontSize = 19.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color(0xFF17324D)
                    )
                }

                Text(
                    text = appText(
                        "إرسال أو إنشاء المستندات اختياري. تقدر تقفل الشاشة الآن والطلب يفضل محفوظ، أو تختار PDF أو صورة PNG للعميل أو للمعمل.",
                        "Sending or creating documents is optional. You can close now and keep the saved order, or choose PDF/PNG for the customer or lab."
                    ),
                    fontSize = 13.sp,
                    color = Color(0xFF64748B)
                )

                Text(
                    text = appText("إيصال العميل", "Customer receipt"),
                    fontWeight = FontWeight.ExtraBold,
                    color = Color(0xFF17324D)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = {
                            runAction("customer_pdf") {
                                PdfGenerator.generateCustomerOrderPdf(context, order, customer)?.let { file ->
                                    PdfGenerator.shareGeneratedPdf(
                                        context = context,
                                        file = file,
                                        subject = "تحاليل ${customer.name} - عيادات العقاد التخصصية",
                                        chooserTitle = "مشاركة PDF العميل"
                                    )
                                }
                            }
                        },
                        enabled = busyAction == null,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(13.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF15803D))
                    ) {
                        if (busyAction == "customer_pdf") {
                            CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp, color = Color.White)
                        } else {
                            Icon(Icons.Default.PictureAsPdf, contentDescription = null, modifier = Modifier.size(18.dp))
                        }
                        Spacer(Modifier.width(6.dp))
                        Text("PDF", fontWeight = FontWeight.ExtraBold)
                    }

                    OutlinedButton(
                        onClick = {
                            runAction("customer_image") {
                                PdfGenerator.generateCustomerOrderImage(context, order, customer)?.let { file ->
                                    PdfGenerator.shareGeneratedImage(
                                        context = context,
                                        file = file,
                                        subject = "تحاليل ${customer.name} - عيادات العقاد التخصصية",
                                        chooserTitle = "مشاركة صورة العميل"
                                    )
                                }
                            }
                        },
                        enabled = busyAction == null,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(13.dp)
                    ) {
                        if (busyAction == "customer_image") {
                            CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                        } else {
                            Icon(Icons.Default.Image, contentDescription = null, modifier = Modifier.size(18.dp))
                        }
                        Spacer(Modifier.width(6.dp))
                        Text(appText("صورة", "PNG"), fontWeight = FontWeight.ExtraBold)
                    }
                }

                Text(
                    text = appText("طلب المعمل", "Lab request"),
                    fontWeight = FontWeight.ExtraBold,
                    color = Color(0xFF17324D)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = {
                            runAction("lab_pdf") {
                                PdfGenerator.generateLabRequestPdf(context, order, customer)?.let { file ->
                                    PdfGenerator.shareGeneratedPdf(
                                        context = context,
                                        file = file,
                                        subject = "طلب تحاليل - ${customer.name}",
                                        chooserTitle = "مشاركة طلب المعمل PDF"
                                    )
                                }
                            }
                        },
                        enabled = busyAction == null,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(13.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF006D86))
                    ) {
                        if (busyAction == "lab_pdf") {
                            CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp, color = Color.White)
                        } else {
                            Icon(Icons.Outlined.Biotech, contentDescription = null, modifier = Modifier.size(18.dp))
                        }
                        Spacer(Modifier.width(6.dp))
                        Text("PDF", fontWeight = FontWeight.ExtraBold)
                    }

                    OutlinedButton(
                        onClick = {
                            runAction("lab_image") {
                                PdfGenerator.generateLabRequestImage(context, order, customer)?.let { file ->
                                    PdfGenerator.shareGeneratedImage(
                                        context = context,
                                        file = file,
                                        subject = "طلب تحاليل - ${customer.name}",
                                        chooserTitle = "مشاركة صورة طلب المعمل"
                                    )
                                }
                            }
                        },
                        enabled = busyAction == null,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(13.dp)
                    ) {
                        if (busyAction == "lab_image") {
                            CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                        } else {
                            Icon(Icons.Default.Image, contentDescription = null, modifier = Modifier.size(18.dp))
                        }
                        Spacer(Modifier.width(6.dp))
                        Text(appText("صورة", "PNG"), fontWeight = FontWeight.ExtraBold)
                    }
                }

                OutlinedButton(
                    onClick = onDismiss,
                    enabled = busyAction == null,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(Icons.Default.Close, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text(appText("إغلاق - حفظ فقط", "Close - save only"), fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
