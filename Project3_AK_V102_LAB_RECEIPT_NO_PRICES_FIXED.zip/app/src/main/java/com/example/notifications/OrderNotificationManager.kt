package com.example.notifications

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.messaging.FirebaseMessaging
import java.security.MessageDigest

object OrderNotificationManager {
    const val CHANNEL_ID = "order_updates"

    fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val channel = NotificationChannel(
                CHANNEL_ID,
                "حالة الطلبات",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "إشعارات تغيير حالة طلبات المعمل"
                enableVibration(true)
            }
            manager.createNotificationChannel(channel)
        }
    }

    fun registerCurrentToken() {
        val user = FirebaseAuth.getInstance().currentUser ?: return
        FirebaseMessaging.getInstance().token.addOnSuccessListener { token ->
            if (token.isBlank()) return@addOnSuccessListener
            saveToken(user.uid, user.email.orEmpty(), token)
        }
    }

    fun saveToken(uid: String, email: String, token: String) {
        val tokenId = MessageDigest.getInstance("SHA-256")
            .digest(token.toByteArray())
            .joinToString("") { "%02x".format(it) }
            .take(40)
        FirebaseFirestore.getInstance()
            .collection("users").document(uid)
            .collection("fcm_tokens").document(tokenId)
            .set(
                mapOf(
                    "token" to token,
                    "email" to email.trim().lowercase(),
                    "updated_at" to FieldValue.serverTimestamp(),
                    "updated_at_ms" to System.currentTimeMillis(),
                    "platform" to "android"
                )
            )
    }
}
