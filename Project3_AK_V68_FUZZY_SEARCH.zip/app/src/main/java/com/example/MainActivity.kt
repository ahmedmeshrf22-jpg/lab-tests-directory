package com.example

import android.app.KeyguardManager
import android.content.ContentResolver
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.ui.AccountDisabledScreen
import com.example.ui.AppPinUnlockScreen
import com.example.ui.DeviceAuthorizationScreen
import com.example.ui.DeviceUnlockScreen
import com.example.ui.LabTestsApp
import com.example.ui.LabTestsViewModel
import com.example.ui.LoginScreen
import com.example.ui.SplashScreen
import com.example.ui.theme.LabTestsTheme
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseNetworkException
import com.google.firebase.appcheck.FirebaseAppCheck
import com.google.firebase.appcheck.playintegrity.PlayIntegrityAppCheckProviderFactory
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.FirebaseAuthInvalidUserException
import kotlinx.coroutines.delay

class MainActivity : FragmentActivity() {

    private val viewModel: LabTestsViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Sensitive pricing and account data must never appear in screenshots,
        // screen recordings, casting, or the recent-apps thumbnail.
        window.setFlags(
            WindowManager.LayoutParams.FLAG_SECURE,
            WindowManager.LayoutParams.FLAG_SECURE
        )

        // V45: block third-party overlay windows on Android 12+ to reduce tapjacking risk.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            window.setHideOverlayWindows(true)
        }

        // Install App Check before any other Firebase SDK is used. Enforcement is
        // enabled later from Firebase Console after the signing SHA-256 is registered.
        FirebaseApp.initializeApp(this)
        FirebaseAppCheck.getInstance().installAppCheckProviderFactory(
            PlayIntegrityAppCheckProviderFactory.getInstance()
        )

        // Process an image/PDF shared to the app only after Firebase/ViewModel dependencies are ready.
        handleIncomingQrShare(intent)

        enableEdgeToEdge()

        val auth = FirebaseAuth.getInstance()

        setContent {
            val appSettings by viewModel.appSettings.collectAsState()
            val accountEnabled by viewModel.accountEnabled.collectAsState()
            val deviceAccessStatus by viewModel.deviceAccessStatus.collectAsState()
            LabTestsTheme(darkTheme = appSettings.darkMode) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    var currentUser by remember { mutableStateOf(auth.currentUser) }
                    var isSplashActive by remember { mutableStateOf(true) }
                    var isLocallyUnlocked by remember { mutableStateOf(false) }
                    var isLoading by remember { mutableStateOf(false) }
                    var errorMessage by remember { mutableStateOf<String?>(null) }
                    var unlockError by remember { mutableStateOf<String?>(null) }
                    var backgroundedAt by remember { mutableStateOf(0L) }

                    LaunchedEffect(Unit) {
                        delay(2000L)
                        isSplashActive = false
                    }

                    LaunchedEffect(appSettings.securityEnabled, currentUser) {
                        if (currentUser != null && !appSettings.securityEnabled) {
                            isLocallyUnlocked = true
                            unlockError = null
                        }
                    }

                    val lifecycleOwner = LocalLifecycleOwner.current

                    DisposableEffect(auth) {
                        val listener = FirebaseAuth.AuthStateListener { fAuth ->
                            currentUser = fAuth.currentUser
                            viewModel.onAuthenticatedUserChanged(fAuth.currentUser?.email, fAuth.currentUser?.uid)
                            if (fAuth.currentUser == null) {
                                isLocallyUnlocked = false
                                viewModel.clearLab2LabState()
                            }
                        }
                        auth.addAuthStateListener(listener)
                        onDispose {
                            auth.removeAuthStateListener(listener)
                        }
                    }

                    DisposableEffect(lifecycleOwner, appSettings.securityEnabled, appSettings.autoLockSeconds, appSettings.unlockMode) {
                        val observer = LifecycleEventObserver { _, event ->
                            if (event == Lifecycle.Event.ON_STOP) {
                                if (auth.currentUser != null) {
                                    viewModel.lockAdmin()
                                }
                                if (auth.currentUser != null && appSettings.securityEnabled) {
                                    backgroundedAt = System.currentTimeMillis()
                                    if (appSettings.autoLockSeconds == 0) {
                                        isLocallyUnlocked = false
                                    }
                                }
                            } else if (event == Lifecycle.Event.ON_START) {
                                if (auth.currentUser != null && appSettings.securityEnabled) {
                                    val elapsedSeconds = if (backgroundedAt > 0L) {
                                        (System.currentTimeMillis() - backgroundedAt) / 1000L
                                    } else {
                                        Long.MAX_VALUE
                                    }
                                    val timeoutReached = appSettings.autoLockSeconds == 0 ||
                                        elapsedSeconds >= appSettings.autoLockSeconds
                                    if (!isLocallyUnlocked || timeoutReached) {
                                        isLocallyUnlocked = false
                                        if (appSettings.unlockMode != "pin" && isSecurityConfiguredOnDevice()) {
                                            launchBiometricPrompt(
                                                onSuccess = {
                                                    isLocallyUnlocked = true
                                                    backgroundedAt = 0L
                                                    unlockError = null
                                                },
                                                onError = { unlockError = it }
                                            )
                                        }
                                    }
                                }
                            }
                        }
                        lifecycleOwner.lifecycle.addObserver(observer)
                        onDispose {
                            lifecycleOwner.lifecycle.removeObserver(observer)
                        }
                    }

                    when {
                        isSplashActive -> {
                            SplashScreen()
                        }

                        currentUser == null -> {
                            LoginScreen(
                                onLoginClick = { email, password ->
                                    if (email.isBlank() || password.isBlank()) {
                                        errorMessage = "يرجى إدخال البريد الإلكتروني وكلمة المرور"
                                        return@LoginScreen
                                    }
                                    isLoading = true
                                    errorMessage = null
                                    auth.signInWithEmailAndPassword(email, password)
                                        .addOnCompleteListener { task ->
                                            isLoading = false
                                            if (task.isSuccessful) {
                                                viewModel.onAuthenticatedUserChanged(
                                                    auth.currentUser?.email ?: email,
                                                    auth.currentUser?.uid
                                                )
                                                isLocallyUnlocked = true
                                            } else {
                                                val exception = task.exception
                                                errorMessage = when (exception) {
                                                    is FirebaseAuthInvalidUserException,
                                                    is FirebaseAuthInvalidCredentialsException -> "البريد الإلكتروني أو كلمة المرور غير صحيحة"
                                                    is FirebaseNetworkException -> "خطأ في الاتصال بالإنترنت. يرجى التحقق من الشبكة."
                                                    else -> exception?.localizedMessage ?: "فشل تسجيل الدخول. يرجى التأكد من البيانات."
                                                }
                                            }
                                        }
                                },
                                isLoading = isLoading,
                                errorMessage = errorMessage
                            )
                        }

                        currentUser != null && accountEnabled == false -> {
                            AccountDisabledScreen(
                                onLogout = {
                                    viewModel.clearLab2LabState()
                                    auth.signOut()
                                    isLocallyUnlocked = false
                                }
                            )
                        }

                        currentUser != null && accountEnabled == null -> {
                            SplashScreen()
                        }

                        // V66: preserve the no-approval login flow for new/pending devices,
                        // but a device explicitly rejected or revoked by the manager must
                        // stop accessing the app immediately.
                        currentUser != null && deviceAccessStatus in setOf("rejected", "revoked") -> {
                            DeviceAuthorizationScreen(
                                status = deviceAccessStatus,
                                onRefresh = { viewModel.recheckDeviceAuthorization() },
                                onApproveWithAdminPin = { pin, result ->
                                    viewModel.approveCurrentDeviceWithAdminPin(pin, result)
                                },
                                onLogout = {
                                    viewModel.clearLab2LabState()
                                    auth.signOut()
                                    isLocallyUnlocked = false
                                }
                            )
                        }

                        appSettings.securityEnabled && !isLocallyUnlocked -> {
                            if (appSettings.unlockMode == "pin" && appSettings.appPinConfigured) {
                                AppPinUnlockScreen(
                                    onUnlock = { pin ->
                                        val ok = viewModel.verifyAppPin(pin)
                                        if (ok) {
                                            isLocallyUnlocked = true
                                            backgroundedAt = 0L
                                            unlockError = null
                                        }
                                        ok
                                    },
                                    onLogoutClick = {
                                        viewModel.clearLab2LabState()
                                        auth.signOut()
                                        isLocallyUnlocked = false
                                    }
                                )
                            } else {
                                val isSecured = isSecurityConfiguredOnDevice()

                                LaunchedEffect(currentUser) {
                                    if (isSecured) {
                                        launchBiometricPrompt(
                                            onSuccess = {
                                                isLocallyUnlocked = true
                                                unlockError = null
                                            },
                                            onError = { unlockError = it }
                                        )
                                    }
                                }

                                DeviceUnlockScreen(
                                    onUnlockClick = {
                                        if (isSecured || isSecurityConfiguredOnDevice()) {
                                            launchBiometricPrompt(
                                                onSuccess = {
                                                    isLocallyUnlocked = true
                                                    unlockError = null
                                                },
                                                onError = { unlockError = it }
                                            )
                                        }
                                    },
                                    onLogoutClick = {
                                        viewModel.clearLab2LabState()
                                        auth.signOut()
                                        isLocallyUnlocked = false
                                    },
                                    isSecurityConfigured = isSecured,
                                    errorMessage = unlockError
                                )
                            }
                        }

                        else -> {
                            LabTestsApp(
                                viewModel = viewModel,
                                currentUserEmail = currentUser?.email,
                                currentUserUid = currentUser?.uid,
                                onLogout = {
                                    viewModel.clearLab2LabState()
                                    auth.signOut()
                                    isLocallyUnlocked = false
                                }
                            )
                        }
                    }
                }
            }
        }
    }


    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIncomingQrShare(intent)
    }

    private fun handleIncomingQrShare(incoming: Intent?) {
        if (incoming?.action != Intent.ACTION_SEND) return

        val mime = incoming.type.orEmpty().substringBefore(';').trim().lowercase()
        val allowedMime = mime in setOf(
            "image/jpeg", "image/jpg", "image/png", "image/webp",
            "image/heic", "image/heif", "image/avif", "application/pdf"
        )
        if (!allowedMime) return

        val uri: Uri? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            incoming.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
        } else {
            @Suppress("DEPRECATION")
            incoming.getParcelableExtra(Intent.EXTRA_STREAM)
        }

        if (uri != null && uri.scheme == ContentResolver.SCHEME_CONTENT) {
            viewModel.queueSharedQrUri(uri.toString())
            // Do not queue the same share again if Android recreates the activity.
            incoming.action = null
        }
    }

    private fun isSecurityConfiguredOnDevice(): Boolean {
        val biometricManager = BiometricManager.from(this)

        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val authenticators = BiometricManager.Authenticators.BIOMETRIC_STRONG or
                    BiometricManager.Authenticators.DEVICE_CREDENTIAL
            biometricManager.canAuthenticate(authenticators) == BiometricManager.BIOMETRIC_SUCCESS
        } else {
            // BIOMETRIC_STRONG | DEVICE_CREDENTIAL is not supported on Android 10 and lower.
            // Use the compatible weak-biometric/device-credential combination and also check
            // the device lock directly so PIN/pattern/password users are not blocked.
            val compatibleAuthenticators = BiometricManager.Authenticators.BIOMETRIC_WEAK or
                    BiometricManager.Authenticators.DEVICE_CREDENTIAL
            val keyguardManager = getSystemService(KeyguardManager::class.java)
            keyguardManager?.isDeviceSecure == true ||
                    biometricManager.canAuthenticate(compatibleAuthenticators) == BiometricManager.BIOMETRIC_SUCCESS
        }
    }

    private fun launchBiometricPrompt(
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        val executor = ContextCompat.getMainExecutor(this)
        val callback = object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                super.onAuthenticationSucceeded(result)
                onSuccess()
            }

            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                super.onAuthenticationError(errorCode, errString)
                if (errorCode != BiometricPrompt.ERROR_USER_CANCELED &&
                    errorCode != BiometricPrompt.ERROR_NEGATIVE_BUTTON &&
                    errorCode != BiometricPrompt.ERROR_CANCELED
                ) {
                    onError(errString.toString())
                }
            }
        }

        try {
            val biometricPrompt = BiometricPrompt(this, executor, callback)
            val authenticators = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                BiometricManager.Authenticators.BIOMETRIC_STRONG or
                        BiometricManager.Authenticators.DEVICE_CREDENTIAL
            } else {
                BiometricManager.Authenticators.BIOMETRIC_WEAK or
                        BiometricManager.Authenticators.DEVICE_CREDENTIAL
            }

            val promptInfo = BiometricPrompt.PromptInfo.Builder()
                .setTitle("فتح دليل التحاليل")
                .setSubtitle("استخدم البصمة أو رمز قفل الهاتف للمتابعة")
                .setAllowedAuthenticators(authenticators)
                .build()

            biometricPrompt.authenticate(promptInfo)
        } catch (e: Exception) {
            onError(e.localizedMessage ?: "فشل في فتح قفل الهاتف")
        }
    }
}
