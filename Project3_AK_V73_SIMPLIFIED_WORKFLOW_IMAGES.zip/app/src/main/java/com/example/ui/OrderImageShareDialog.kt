package com.example.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.outlined.Biotech
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.Customer
import com.example.data.model.CustomerOrder
import com.example.settings.appText
import com.example.util.PdfGenerator

/**
 * V73: output is image-only. The order is already saved before this dialog opens.
 * Two direct actions keep the workflow short: customer image or lab-request image.
 */
@Composable
fun OrderImageShareDialog(
    order: CustomerOrder,
    customer: Customer,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    var busyAction by remember { mutableStateOf<String?>(null) }

    fun runAction(key: String, block: () -> Unit) {
        if (busyAction != null) return
        busyAction = key
        try {
            block()
        } finally {
            busyAction = null
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(dismissOnBackPress = true)
    ) {
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(24.dp),
            color = Color.White,
            border = BorderStroke(1.dp, Color(0xFFE2E8F0))
        ) {
            Column(
                modifier = Modifier.padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF15803D))
                    Text(
                        text = appText("تم حفظ الطلب", "Order saved"),
                        fontSize = 19.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color(0xFF17324D)
                    )
                }

                Text(
                    text = appText(
                        "اختار الصورة المطلوبة مباشرة. الطلب محفوظ بالفعل في ملف العميل.",
                        "Choose the required image directly. The order is already saved to the customer file."
                    ),
                    fontSize = 13.sp,
                    color = Color(0xFF64748B)
                )

                Button(
                    onClick = {
                        runAction("customer_image") {
                            PdfGenerator.generateCustomerOrderImage(context, order, customer)?.let { file ->
                                PdfGenerator.shareGeneratedImage(
                                    context = context,
                                    file = file,
                                    subject = "تحاليل ${customer.name} - عيادات العقاد التخصصية",
                                    chooserTitle = "مشاركة صورة العميل"
                                )
                            }
                        }
                    },
                    enabled = busyAction == null,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(15.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF15803D))
                ) {
                    if (busyAction == "customer_image") {
                        CircularProgressIndicator(Modifier.size(19.dp), strokeWidth = 2.dp, color = Color.White)
                    } else {
                        Icon(Icons.Default.Image, contentDescription = null, modifier = Modifier.size(20.dp))
                    }
                    Spacer(Modifier.width(7.dp))
                    Text(appText("صورة العميل", "Customer image"), fontWeight = FontWeight.ExtraBold)
                }

                Button(
                    onClick = {
                        runAction("lab_image") {
                            PdfGenerator.generateLabRequestImage(context, order, customer)?.let { file ->
                                PdfGenerator.shareGeneratedImage(
                                    context = context,
                                    file = file,
                                    subject = "طلب تحاليل - ${customer.name}",
                                    chooserTitle = "مشاركة صورة طلب المعمل"
                                )
                            }
                        }
                    },
                    enabled = busyAction == null,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(15.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF006D86))
                ) {
                    if (busyAction == "lab_image") {
                        CircularProgressIndicator(Modifier.size(19.dp), strokeWidth = 2.dp, color = Color.White)
                    } else {
                        Icon(Icons.Outlined.Biotech, contentDescription = null, modifier = Modifier.size(20.dp))
                    }
                    Spacer(Modifier.width(7.dp))
                    Text(appText("صورة طلب المعمل", "Lab request image"), fontWeight = FontWeight.ExtraBold)
                }

                OutlinedButton(
                    onClick = onDismiss,
                    enabled = busyAction == null,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(Icons.Default.Close, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text(appText("إغلاق", "Close"), fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
