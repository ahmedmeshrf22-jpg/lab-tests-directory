package com.example.ui

import androidx.activity.compose.BackHandler
import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.ManageAccounts
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.BuildConfig
import com.example.settings.AppSettings
import com.example.settings.appText
import com.example.settings.tr
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ManagerSettingsDialog(
    viewModel: LabTestsViewModel,
    settings: AppSettings,
    currentUserEmail: String?,
    currentUserUid: String?,
    onDismiss: () -> Unit,
    onOpenManagerDashboard: () -> Unit,
    onLogout: (() -> Unit)?
) {
    val context = LocalContext.current
    var syncing by remember { mutableStateOf(false) }
    var syncMessage by remember { mutableStateOf<String?>(null) }
    val tr: (String, String) -> String = { ar, en -> appText(settings, ar, en) }

    BackHandler(enabled = true) { onDismiss() }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false, dismissOnBackPress = true)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .padding(10.dp),
            shape = RoundedCornerShape(24.dp),
            color = if (settings.darkMode) Color(0xFF0F172A) else Color(0xFFF5F7FB),
            shadowElevation = 8.dp
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = tr("إعدادات التطبيق", "App Settings"),
                            fontSize = 22.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = if (settings.darkMode) Color.White else Color(0xFF102A43)
                        )
                        Text(
                            text = tr("متاحة لحساب المدير فقط", "Manager account settings"),
                            fontSize = 12.sp,
                            color = if (settings.darkMode) Color(0xFFCBD5E1) else Color(0xFF64748B)
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = tr("إغلاق", "Close"),
                            tint = if (settings.darkMode) Color.White else Color(0xFF334155)
                        )
                    }
                }

                HorizontalDivider(color = if (settings.darkMode) Color(0xFF334155) else Color(0xFFE2E8F0))

                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(14.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item {
                        SettingsSectionCard(title = tr("اللغة", "Language"), icon = Icons.Default.Language) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(
                                    onClick = { viewModel.updateAppSettings(settings.copy(language = "ar")) },
                                    modifier = Modifier.weight(1f)
                                ) { Text(tr("العربية", "Arabic"), fontWeight = if (settings.language == "ar") FontWeight.ExtraBold else FontWeight.Medium) }
                                OutlinedButton(
                                    onClick = { viewModel.updateAppSettings(settings.copy(language = "en")) },
                                    modifier = Modifier.weight(1f)
                                ) { Text("English", fontWeight = if (settings.language == "en") FontWeight.ExtraBold else FontWeight.Medium) }
                            }
                        }
                    }

                    item {
                        SettingsSectionCard(title = tr("الحساب", "Account"), icon = Icons.Default.ManageAccounts) {
                            SettingsInfoRow(tr("البريد الإلكتروني", "Email"), currentUserEmail ?: "—")
                            SettingsInfoRow(tr("نوع الحساب", "Account type"), tr("مدير النظام", "General Manager"))
                            SettingsInfoRow("User UID", currentUserUid ?: "—")
                            if (onLogout != null) {
                                Spacer(Modifier.height(8.dp))
                                OutlinedButton(
                                    onClick = onLogout,
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Icon(Icons.AutoMirrored.Filled.Logout, null, modifier = Modifier.size(18.dp))
                                    Spacer(Modifier.width(7.dp))
                                    Text(tr("تسجيل الخروج", "Log out"))
                                }
                            }
                        }
                    }

                    item {
                        SettingsSectionCard(title = tr("الأمان", "Security"), icon = Icons.Default.Lock) {
                            SettingsSwitchRow(
                                title = tr("قفل التطبيق", "App lock"),
                                subtitle = tr("استخدام البصمة أو رمز قفل الهاتف عند فتح التطبيق", "Use biometrics or device lock when opening the app"),
                                checked = settings.securityEnabled,
                                onCheckedChange = {
                                    viewModel.updateAppSettings(settings.copy(securityEnabled = it))
                                }
                            )

                            if (settings.securityEnabled) {
                                Spacer(Modifier.height(8.dp))
                                Text(
                                    text = tr("القفل التلقائي", "Auto lock"),
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF334155)
                                )
                                Spacer(Modifier.height(8.dp))
                                ChoiceButtons(
                                    choices = listOf(
                                        0 to tr("فورًا", "Immediately"),
                                        60 to tr("دقيقة", "1 min"),
                                        300 to tr("5 دقائق", "5 min"),
                                        900 to tr("15 دقيقة", "15 min")
                                    ),
                                    selected = settings.autoLockSeconds,
                                    onSelected = {
                                        viewModel.updateAppSettings(settings.copy(autoLockSeconds = it))
                                    }
                                )
                                Spacer(Modifier.height(8.dp))
                                TextButton(
                                    onClick = {
                                        runCatching {
                                            context.startActivity(Intent(Settings.ACTION_SECURITY_SETTINGS))
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(tr("فتح إعدادات البصمة / PIN في الهاتف", "Open phone biometrics / PIN settings"))
                                }
                            }
                        }
                    }

                    item {
                        SettingsSectionCard(title = tr("المظهر", "Appearance"), icon = Icons.Default.Palette) {
                            SettingsSwitchRow(
                                title = tr("الوضع الداكن", "Dark mode"),
                                subtitle = tr("تغيير خلفية التطبيق ووضع العرض", "Change app appearance"),
                                checked = settings.darkMode,
                                onCheckedChange = {
                                    viewModel.updateAppSettings(settings.copy(darkMode = it))
                                },
                                icon = Icons.Default.DarkMode
                            )
                            Spacer(Modifier.height(8.dp))
                            Text(
                                text = tr("حجم الخط", "Font size"),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF334155)
                            )
                            Spacer(Modifier.height(8.dp))
                            ChoiceButtons(
                                choices = listOf(0.90f to tr("صغير", "Small"), 1.0f to tr("متوسط", "Medium"), 1.15f to tr("كبير", "Large")),
                                selected = settings.fontScale,
                                onSelected = {
                                    viewModel.updateAppSettings(settings.copy(fontScale = it))
                                }
                            )
                        }
                    }

                    item {
                        SettingsSectionCard(title = tr("إعدادات البحث", "Search Settings"), icon = Icons.Default.Search) {
                            SettingsSwitchRow(
                                tr("إظهار الاسم الإنجليزي", "Show English name"),
                                tr("يظهر الاسم الإنجليزي في نتائج البحث", "Show English name in search results"),
                                settings.showEnglishName,
                                onCheckedChange = { enabled ->
                                    if (enabled || settings.showArabicName || settings.showMarketName) {
                                        viewModel.updateAppSettings(settings.copy(showEnglishName = enabled))
                                    }
                                }
                            )
                            SettingsSwitchRow(
                                tr("إظهار الاسم العربي", "Show Arabic name"),
                                tr("يظهر الاسم العربي في نتائج البحث", "Show Arabic name in search results"),
                                settings.showArabicName,
                                onCheckedChange = { enabled ->
                                    if (enabled || settings.showEnglishName || settings.showMarketName) {
                                        viewModel.updateAppSettings(settings.copy(showArabicName = enabled))
                                    }
                                }
                            )
                            SettingsSwitchRow(
                                tr("إظهار الاسم الدارج", "Show market name"),
                                tr("إظهار الاسم المستخدم في السوق المصري عند توفره", "Show common market name when available"),
                                settings.showMarketName,
                                onCheckedChange = { enabled ->
                                    if (enabled || settings.showEnglishName || settings.showArabicName) {
                                        viewModel.updateAppSettings(settings.copy(showMarketName = enabled))
                                    }
                                }
                            )
                        }
                    }

                    item {
                        SettingsSectionCard(title = tr("عرض الأسعار", "Price Display"), icon = Icons.Default.Settings) {
                            SettingsSwitchRow(
                                tr("سعر العميل", "Customer price"),
                                tr("إظهار سعر العميل في نتائج البحث والسلة", "Show customer price in search results and cart"),
                                settings.showCustomerPrice,
                                onCheckedChange = {
                                    viewModel.updateAppSettings(settings.copy(showCustomerPrice = it))
                                }
                            )
                        }
                    }

                    item {
                        SettingsSectionCard(title = tr("إعدادات الصور", "Image Settings"), icon = Icons.Default.Description) {
                            OutlinedTextField(
                                value = settings.pdfLabName,
                                onValueChange = {
                                    viewModel.updateAppSettings(settings.copy(pdfLabName = it.take(60)))
                                },
                                modifier = Modifier.fillMaxWidth().heightIn(min = 72.dp),
                                singleLine = true,
                                label = { Text(tr("اسم المعمل / العيادة في الصورة", "Lab / Clinic name in image")) },
                                shape = RoundedCornerShape(12.dp)
                            )
                            Spacer(Modifier.height(8.dp))
                            SettingsSwitchRow(
                                tr("سعر العميل في الصورة", "Customer price in image"),
                                tr("إظهار عمود سعر العميل", "Show customer price column"),
                                settings.pdfIncludeCustomerPrice,
                                onCheckedChange = {
                                    viewModel.updateAppSettings(settings.copy(pdfIncludeCustomerPrice = it))
                                }
                            )
                            SettingsSwitchRow(
                                tr("إظهار الإجمالي", "Show totals"),
                                tr("إضافة إجمالي الأسعار في نهاية الصورة", "Add totals at the end of the image"),
                                settings.pdfShowTotals,
                                onCheckedChange = {
                                    viewModel.updateAppSettings(settings.copy(pdfShowTotals = it))
                                }
                            )
                            SettingsSwitchRow(
                                tr("بيانات التواصل", "Contact information"),
                                tr("إضافة بيانات التواصل أسفل التقرير", "Add contact details at the bottom"),
                                settings.pdfShowContactInfo,
                                onCheckedChange = {
                                    viewModel.updateAppSettings(settings.copy(pdfShowContactInfo = it))
                                }
                            )
                            if (settings.pdfShowContactInfo) {
                                OutlinedTextField(
                                    value = settings.pdfContactInfo,
                                    onValueChange = {
                                        viewModel.updateAppSettings(settings.copy(pdfContactInfo = it.take(180)))
                                    },
                                    modifier = Modifier.fillMaxWidth().heightIn(min = 112.dp),
                                    minLines = 2,
                                    maxLines = 4,
                                    label = { Text(tr("بيانات التواصل", "Contact information")) },
                                    shape = RoundedCornerShape(12.dp)
                                )
                            }
                        }
                    }

                    item {
                        SettingsSectionCard(title = tr("المزامنة والبيانات", "Sync & Data"), icon = Icons.Default.Sync) {
                            SettingsInfoRow(tr("آخر تحديث", "Last sync"), formatLastSync(settings.lastSyncMillis, settings.language))
                            if (!syncMessage.isNullOrBlank()) {
                                Spacer(Modifier.height(6.dp))
                                Text(
                                    text = syncMessage.orEmpty(),
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (syncMessage?.startsWith("تم") == true) Color(0xFF15803D) else Color(0xFFB91C1C)
                                )
                            }
                            Spacer(Modifier.height(8.dp))
                            Button(
                                onClick = {
                                    syncing = true
                                    syncMessage = null
                                    viewModel.refreshPrices { _, message ->
                                        syncing = false
                                        syncMessage = message
                                    }
                                },
                                enabled = !syncing,
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF006D86))
                            ) {
                                if (syncing) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(18.dp),
                                        strokeWidth = 2.dp,
                                        color = Color.White
                                    )
                                } else {
                                    Icon(Icons.Default.Refresh, null, modifier = Modifier.size(18.dp))
                                }
                                Spacer(Modifier.width(7.dp))
                                Text(if (syncing) tr("جاري التحديث...", "Refreshing...") else tr("تحديث الأسعار الآن", "Refresh prices now"))
                            }
                        }
                    }

                    item {
                        SettingsSectionCard(title = tr("الإدارة", "Administration"), icon = Icons.Default.AdminPanelSettings) {
                            Button(
                                onClick = onOpenManagerDashboard,
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6D28D9))
                            ) {
                                Icon(Icons.Default.AdminPanelSettings, null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(7.dp))
                                Text(tr("فتح لوحة تحكم المدير", "Open Manager Dashboard"))
                            }
                        }
                    }

                    item {
                        SettingsSectionCard(title = tr("عن التطبيق", "About App"), icon = Icons.Default.Info) {
                            SettingsInfoRow(tr("الإصدار", "Version"), BuildConfig.VERSION_NAME)
                            SettingsInfoRow(tr("رقم البناء", "Build number"), BuildConfig.VERSION_CODE.toString())
                            SettingsInfoRow(tr("التطبيق", "App"), tr("تحاليل العقاد", "Tahalil Alakkad"))
                            Spacer(Modifier.height(8.dp))
                            TextButton(
                                onClick = { viewModel.resetAppSettings() },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(Icons.Default.RestartAlt, null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(6.dp))
                                Text(tr("إرجاع الإعدادات للوضع الافتراضي", "Reset settings to default"))
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsSectionCard(
    title: String,
    icon: ImageVector,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, Color(0xFFE2E8F0))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, null, tint = Color(0xFF006D86), modifier = Modifier.size(21.dp))
                Spacer(Modifier.width(8.dp))
                Text(
                    text = title,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color(0xFF102A43)
                )
            }
            Spacer(Modifier.height(10.dp))
            content()
        }
    }
}

@Composable
private fun SettingsSwitchRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    icon: ImageVector? = null
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (icon != null) {
            Icon(icon, null, tint = Color(0xFF64748B), modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(7.dp))
        }
        Column(modifier = Modifier.weight(1f)) {
            Text(title, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1E293B))
            Text(subtitle, fontSize = 11.sp, color = Color(0xFF64748B), lineHeight = 15.sp)
        }
        Spacer(Modifier.width(8.dp))
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

@Composable
private fun SettingsInfoRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF64748B))
        Spacer(Modifier.width(10.dp))
        Text(
            value,
            modifier = Modifier.weight(1f),
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            color = Color(0xFF1E293B),
            textAlign = androidx.compose.ui.text.style.TextAlign.End
        )
    }
}

@Composable
private fun <T> ChoiceButtons(
    choices: List<Pair<T, String>>,
    selected: T,
    onSelected: (T) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        choices.forEach { (value, label) ->
            val selectedNow = value == selected
            OutlinedButton(
                onClick = { onSelected(value) },
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(horizontal = 4.dp, vertical = 7.dp),
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, if (selectedNow) Color(0xFF006D86) else Color(0xFFCBD5E1)),
                colors = ButtonDefaults.outlinedButtonColors(
                    containerColor = if (selectedNow) Color(0xFFE6F6F8) else Color.White,
                    contentColor = if (selectedNow) Color(0xFF005766) else Color(0xFF475569)
                )
            ) {
                Text(label, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

private fun formatLastSync(timestamp: Long, language: String): String {
    val en = language == "en"
    if (timestamp <= 0L) return if (en) "No manual sync yet" else "لم يتم التحديث يدويًا بعد"
    return runCatching {
        SimpleDateFormat("dd/MM/yyyy - hh:mm a", if (en) Locale.ENGLISH else Locale("ar", "EG")).format(Date(timestamp))
    }.getOrDefault(if (en) "Synced" else "تم التحديث")
}
