package com.example.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.settings.appText

private data class DailyServiceNavItem(
    val id: String,
    val titleAr: String,
    val titleEn: String,
    val imageRes: Int,
    val glow: Color,
    val action: () -> Unit
)

/**
 * V77 — premium illuminated 3D swipe launcher used inside every daily workspace.
 *
 * The old text-button strip is intentionally gone. Each service is now a bright
 * 3D tile in a horizontal carousel, so the user can swipe right/left between
 * daily tasks without leaving the visual language of the home dashboard.
 */
@Composable
fun DailyServicesNavBar(
    active: String? = null,
    onCatalog: () -> Unit,
    onQuickImage: () -> Unit,
    onOrder: () -> Unit,
    onCustomers: () -> Unit,
    onScan: () -> Unit
) {
    val items = listOf(
        DailyServiceNavItem(
            id = "catalog",
            titleAr = "كتالوج التحاليل",
            titleEn = "Test catalog",
            imageRes = R.drawable.staff_tests_3d,
            glow = Color(0xFF00D9FF),
            action = onCatalog
        ),
        DailyServiceNavItem(
            id = "quick_image",
            titleAr = "صورة سريعة",
            titleEn = "Quick image",
            imageRes = R.drawable.staff_quick_image_3d,
            glow = Color(0xFF9B6CFF),
            action = onQuickImage
        ),
        DailyServiceNavItem(
            id = "order",
            titleAr = "طلب جديد",
            titleEn = "New order",
            imageRes = R.drawable.staff_new_order_3d,
            glow = Color(0xFF2DE3A7),
            action = onOrder
        ),
        DailyServiceNavItem(
            id = "customers",
            titleAr = "سجلات العملاء",
            titleEn = "Customer records",
            imageRes = R.drawable.staff_customers_3d,
            glow = Color(0xFF42A5FF),
            action = onCustomers
        ),
        DailyServiceNavItem(
            id = "scan",
            titleAr = "QR / صورة",
            titleEn = "QR / Image",
            imageRes = R.drawable.staff_qr_3d,
            glow = Color(0xFFFFB23E),
            action = onScan
        )
    )

    val listState = rememberLazyListState()

    LaunchedEffect(active) {
        val index = items.indexOfFirst { it.id == active }
        if (index >= 0) {
            listState.animateScrollToItem(index)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                Brush.verticalGradient(
                    listOf(
                        Color(0xFF030A16),
                        Color(0xFF07182E),
                        Color(0xFF030913)
                    )
                )
            )
            .border(
                BorderStroke(1.dp, Color(0xFF2C6D91)),
                RoundedCornerShape(bottomStart = 20.dp, bottomEnd = 20.dp)
            )
            .padding(vertical = 10.dp)
    ) {
        LazyRow(
            state = listState,
            horizontalArrangement = Arrangement.spacedBy(9.dp),
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
        ) {
            itemsIndexed(items, key = { _, item -> item.id }) { _, item ->
                Mini3DSwipeServiceCard(
                    item = item,
                    selected = active == item.id
                )
            }
        }
    }
}

@Composable
private fun Mini3DSwipeServiceCard(
    item: DailyServiceNavItem,
    selected: Boolean
) {
    val scale by animateFloatAsState(
        targetValue = if (selected) 1.07f else 1f,
        animationSpec = spring(dampingRatio = 0.72f, stiffness = 420f),
        label = "daily-service-scale"
    )

    val borderColor = if (selected) item.glow else item.glow.copy(alpha = 0.48f)
    val glowElevation = if (selected) 24.dp else 12.dp

    Box(
        modifier = Modifier
            .width(108.dp)
            .height(128.dp)
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .shadow(
                elevation = glowElevation,
                shape = RoundedCornerShape(20.dp),
                ambientColor = item.glow,
                spotColor = item.glow,
                clip = false
            )
            .clip(RoundedCornerShape(20.dp))
            .background(
                Brush.verticalGradient(
                    listOf(
                        item.glow.copy(alpha = if (selected) 0.42f else 0.24f),
                        Color(0xFF0A1E38),
                        Color(0xFF030B17)
                    )
                )
            )
            .border(
                width = if (selected) 2.dp else 1.2.dp,
                color = borderColor,
                shape = RoundedCornerShape(20.dp)
            )
            .clickable(onClick = item.action)
            .padding(horizontal = 7.dp, vertical = 7.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Surface(
                modifier = Modifier
                    .size(58.dp)
                    .shadow(
                        elevation = if (selected) 10.dp else 5.dp,
                        shape = RoundedCornerShape(16.dp),
                        ambientColor = item.glow,
                        spotColor = item.glow
                    ),
                shape = RoundedCornerShape(16.dp),
                color = Color(0xFF061422).copy(alpha = 0.96f),
                border = BorderStroke(1.4.dp, item.glow.copy(alpha = 0.92f))
            ) {
                Image(
                    painter = painterResource(item.imageRes),
                    contentDescription = null,
                    modifier = Modifier
                        .padding(3.dp)
                        .clip(RoundedCornerShape(12.dp)),
                    contentScale = ContentScale.Fit
                )
            }

            Spacer(Modifier.height(5.dp))

            Text(
                text = appText(item.titleAr, item.titleEn),
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 28.dp),
                color = if (selected) Color.White else Color(0xFFD8EDFF),
                fontSize = 9.sp,
                lineHeight = 13.sp,
                fontWeight = FontWeight.ExtraBold,
                textAlign = TextAlign.Center,
                maxLines = 2,
                softWrap = true,
                overflow = TextOverflow.Clip
            )

            if (selected) {
                Spacer(Modifier.height(3.dp))
                Box(
                    modifier = Modifier
                        .size(5.dp)
                        .shadow(6.dp, CircleShape, ambientColor = item.glow, spotColor = item.glow)
                        .background(item.glow, CircleShape)
                )
            }
        }
    }
}
