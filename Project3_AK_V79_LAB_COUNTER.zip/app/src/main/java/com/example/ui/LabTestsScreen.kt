package com.example.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Percent
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.LocalOffer
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.outlined.Biotech
import androidx.compose.material.icons.outlined.SearchOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.R
import com.example.data.model.AppUserProfile
import com.example.data.model.Customer
import com.example.data.model.CustomerOrder
import com.example.data.model.LabTest
import com.example.settings.LocalAppSettings
import com.example.settings.appText
import com.example.settings.tr
import com.example.util.PdfGenerator
import com.example.util.TestDocumentImport
import androidx.core.content.ContextCompat
import kotlinx.coroutines.launch

@Composable
fun LabTestsApp(
    viewModel: LabTestsViewModel,
    currentUserEmail: String? = null,
    currentUserUid: String? = null,
    onLogout: (() -> Unit)? = null
) {
    val appSettings by viewModel.appSettings.collectAsState()
    val baseDensity = LocalDensity.current
    val layoutDirection = if (appSettings.language == "en") LayoutDirection.Ltr else LayoutDirection.Rtl
    CompositionLocalProvider(
        LocalLayoutDirection provides layoutDirection,
        LocalDensity provides Density(baseDensity.density, appSettings.fontScale),
        LocalAppSettings provides appSettings
    ) {
        val searchQuery by viewModel.searchQuery.collectAsState()
        val uiState by viewModel.uiState.collectAsState()
        val selectedTests by viewModel.selectedTests.collectAsState()
        val recognizedTests by viewModel.recognizedTests.collectAsState()
        val adminUnlocked by viewModel.adminUnlocked.collectAsState()
        val actualManager by viewModel.actualManager.collectAsState()
        val isOnline by viewModel.isOnline.collectAsState()
        val pendingSyncCount by viewModel.pendingSyncCount.collectAsState()
        val lastSuccessfulSyncMillis by viewModel.lastSuccessfulSyncMillis.collectAsState()
        val pendingSharedQrUri by viewModel.pendingSharedQrUri.collectAsState()
        val lab2LabPrices by viewModel.lab2LabPrices.collectAsState()
        val customerPriceOverrides by viewModel.customerPriceOverrides.collectAsState()
        // Same UI for everyone. The real manager has direct administration access;
        // staff receives the same access only after a successful admin PIN unlock.
        val isManager = actualManager || adminUnlocked
        var priceEditorTest by remember { mutableStateOf<LabTest?>(null) }
        var showManagerDashboard by remember { mutableStateOf(false) }
        var showSettingsDialog by remember { mutableStateOf(false) }
        var showAdminSettingsDialog by remember { mutableStateOf(false) }
        var showAdminPasswordDialog by remember { mutableStateOf(false) }
        var adminPin by remember { mutableStateOf("") }
        var adminUnlocking by remember { mutableStateOf(false) }
        var adminUnlockError by remember { mutableStateOf<String?>(null) }
        var pendingAdminAction by remember { mutableStateOf<(() -> Unit)?>(null) }
        var showCustomerSystem by remember { mutableStateOf(false) }
        var customerSystemInitialCustomer by remember { mutableStateOf<Customer?>(null) }
        var customerSystemAutoScan by remember { mutableStateOf(false) }
        var showScanHub by remember { mutableStateOf(false) }
        var showOperationsV14 by remember { mutableStateOf(false) }
        var operationsInitialPage by remember { mutableStateOf("home") }
        var operationsInitialDebtsOnly by remember { mutableStateOf(false) }
        var operationsInitialRange by remember { mutableStateOf("today") }
        // V58: every account lands on the same unified home.
        var managerMainMode by remember(currentUserUid, currentUserEmail) { mutableStateOf("home") } // home | price_search | order | catalog
        var showOrderCustomerPicker by remember { mutableStateOf(false) }
        var showOrderCheckout by remember { mutableStateOf(false) }
        var autoCheckoutAfterCustomerPick by remember { mutableStateOf(false) }
        var activeOrderCustomer by remember { mutableStateOf<Customer?>(null) }
        // V79 counter-first workflow: keep payment + note state on the landing screen
        // so the user can finish most daily work without opening another workspace.
        var counterPaidText by remember { mutableStateOf("0") }
        var counterNotes by remember { mutableStateOf("") }
        var counterSaving by remember { mutableStateOf(false) }
        var counterAutoSaveAfterCustomerPick by remember { mutableStateOf(false) }
        val context = LocalContext.current
        var orderStatusMessage by remember { mutableStateOf<String?>(null) }
        var orderStatusSuccess by remember { mutableStateOf(true) }
        var importingTestsDocument by remember { mutableStateOf(false) }
        val documentImportScope = rememberCoroutineScope()
        val testsDocumentLauncher = rememberLauncherForActivityResult(
            contract = ActivityResultContracts.OpenDocument()
        ) { uri ->
            if (uri != null) {
                importingTestsDocument = true
                documentImportScope.launch {
                    val result = TestDocumentImport.readTests(context, uri)
                    importingTestsDocument = false
                    result.onSuccess { readResult ->
                        val count = viewModel.applyRecognizedTestsToSearch(readResult.text)
                        orderStatusSuccess = count > 0
                        orderStatusMessage = if (count > 0) {
                            when {
                                readResult.mode == TestDocumentImport.ReadMode.SMART_VISION -> tr(
                                    "تم التعرف الذكي على $count تحليل. راجع النتائج واختار المطلوب.",
                                    "$count tests detected with smart vision. Review the results and select the required tests."
                                )
                                readResult.fallbackReason == TestDocumentImport.SmartFallbackReason.OFFLINE -> tr(
                                    "تم التعرف محليا على $count تحليل. شغّل الإنترنت لاستخدام القراءة الذكية للخط اليدوي.",
                                    "$count tests detected locally. Connect to the internet to use smart handwriting vision."
                                )
                                else -> tr(
                                    "تم التعرف محليا على $count تحليل لأن القراءة الذكية غير متاحة حاليا. راجع النتائج.",
                                    "$count tests detected locally because smart vision is currently unavailable. Review the results."
                                )
                            }
                        } else {
                            when {
                                readResult.fallbackReason == TestDocumentImport.SmartFallbackReason.OFFLINE -> tr(
                                    "تمت قراءة الملف محليا لكن لم أجد تحاليل مطابقة. شغّل الإنترنت وجرب القراءة الذكية.",
                                    "The file was read locally but no matching tests were found. Connect to the internet and try smart vision."
                                )
                                else -> tr(
                                    "تمت قراءة الملف لكن لم أجد أسماء تحاليل مطابقة لقائمة التحاليل.",
                                    "The file was read, but no test names matched the catalogue."
                                )
                            }
                        }
                    }.onFailure { error ->
                        orderStatusSuccess = false
                        orderStatusMessage = tr(
                            "تعذر قراءة التحاليل من الملف: ${error.message ?: "الملف غير واضح"}",
                            "Unable to read tests from file: ${error.message ?: "The file is unclear"}"
                        )
                    }
                }
            }
        }
        var pendingOutputOrder by remember { mutableStateOf<CustomerOrder?>(null) }
        var pendingOutputCustomer by remember { mutableStateOf<Customer?>(null) }

        // Android system Back follows the in-app navigation stack instead of
        // dropping the user out of the current workflow/root screen.
        BackHandler(enabled = true) {
            when {
                pendingOutputOrder != null -> { pendingOutputOrder = null; pendingOutputCustomer = null }
                orderStatusMessage != null -> orderStatusMessage = null
                showOrderCheckout -> showOrderCheckout = false
                showOrderCustomerPicker -> showOrderCustomerPicker = false
                showCustomerSystem -> showCustomerSystem = false
                showScanHub -> showScanHub = false
                showOperationsV14 -> showOperationsV14 = false
                showManagerDashboard -> showManagerDashboard = false
                showAdminPasswordDialog -> { showAdminPasswordDialog = false; pendingAdminAction = null; adminUnlockError = null }
                showAdminSettingsDialog -> showAdminSettingsDialog = false
                showSettingsDialog -> showSettingsDialog = false
                managerMainMode != "home" -> {
                    managerMainMode = "home"
                    viewModel.clearSearch()
                }
                else -> Unit
            }
        }

        LaunchedEffect(currentUserEmail, currentUserUid) {
            viewModel.onAuthenticatedUserChanged(currentUserEmail, currentUserUid)
        }

        // Staff privileged surfaces close when the PIN session locks. The real manager
        // remains authorized by the signed-in manager account and never needs the PIN.
        LaunchedEffect(isManager) {
            if (!isManager) {
                showOperationsV14 = false
                showAdminSettingsDialog = false
                showManagerDashboard = false
                priceEditorTest = null
            }
        }

        // V39: when Android shares an image receipt to the app, open Customer Files.
        // The dialog consumes the URI and resolves the QR after login/unlock is complete.
        LaunchedEffect(pendingSharedQrUri) {
            if (!pendingSharedQrUri.isNullOrBlank()) {
                customerSystemAutoScan = false
                showCustomerSystem = true
            }
        }

        // V41 Focused Workspace navigation. The active task owns the screen;
        // every other task lives in the collapsed “More” section at the bottom.
        // V75: price inquiry is absorbed into the catalog. No duplicate price workspace on the home screen.
        val openPriceWorkspace: () -> Unit = {
            viewModel.clearSearch()
            managerMainMode = "catalog"
        }
        val openQuickImageWorkspace: () -> Unit = {
            viewModel.clearSearch()
            managerMainMode = "quick_image"
        }
        val openOrderWorkspace: () -> Unit = {
            viewModel.clearSearch()
            managerMainMode = "order"
        }
        val openCustomersWorkspace: () -> Unit = {
            customerSystemInitialCustomer = null
            customerSystemAutoScan = false
            showCustomerSystem = true
        }
        val openCustomerQrScanner: () -> Unit = {
            customerSystemInitialCustomer = null
            customerSystemAutoScan = true
            showCustomerSystem = true
        }
        val openCatalogWorkspace: () -> Unit = {
            viewModel.clearSearch()
            managerMainMode = "catalog"
        }
        // V67: every administration action uses the same PIN gate, including the
        // signed-in manager account. Daily services stay identical for everyone.
        val requireAdmin: (() -> Unit) -> Unit = { action ->
            if (adminUnlocked) {
                action()
            } else {
                pendingAdminAction = action
                adminPin = ""
                adminUnlockError = null
                showAdminPasswordDialog = true
            }
        }
        val openAdminPage: (String) -> Unit = { page ->
            requireAdmin {
                operationsInitialPage = page
                operationsInitialDebtsOnly = false
                operationsInitialRange = "today"
                showOperationsV14 = true
            }
        }
        val openAdminWorkspace: () -> Unit = { openAdminPage("home") }
        val openSettingsWorkspace: () -> Unit = { showSettingsDialog = true }
        val openAdminSettings: () -> Unit = { requireAdmin { showAdminSettingsDialog = true } }
        // V44: a staff-first visual shortcut. It opens the same order workspace,
        // then starts OCR immediately so the employee does not hunt for the import action.
        val openImportWorkspace: () -> Unit = {
            viewModel.clearSearch()
            managerMainMode = "order"
            testsDocumentLauncher.launch(arrayOf("image/*"))
        }

        // V79: when a batch list is pasted into the counter, exact matches are added
        // automatically. Unmatched lines stay visible in the search result instead of
        // blocking the rest of the request. A single normal search still requires a tap.
        LaunchedEffect(managerMainMode, searchQuery, uiState) {
            val isBatchQuery = searchQuery.contains('\n') || searchQuery.contains(';') || searchQuery.contains(',')
            val state = uiState
            if (managerMainMode == "home" && isBatchQuery && state is SearchUiState.Success) {
                val resolved = state.queryGroups
                    .mapNotNull { it.candidates.singleOrNull() }
                    .distinctBy { it.id }
                if (resolved.isNotEmpty()) viewModel.addTestsToSelection(resolved)
            }
        }

        val counterTotal = calculatePriceTotal(selectedTests) { customerPriceOverrides[it.id] ?: it.customerPrice }
        val counterPaid = counterPaidText.replace(',', '.').toDoubleOrNull() ?: 0.0
        val counterPaidValid = counterPaidText.isNotBlank() && counterPaid >= 0.0 && counterPaid <= counterTotal
        val saveCounterOrderForCustomer: (Customer) -> Unit = { customer ->
            if (!counterSaving && selectedTests.isNotEmpty() && counterPaidValid) {
                counterSaving = true
                val status = when {
                    counterTotal > 0.0 && counterPaid >= counterTotal -> "paid"
                    counterPaid > 0.0 -> "partial"
                    else -> "unpaid"
                }
                viewModel.saveCustomerOrderAdvanced(
                    customer = customer,
                    tests = selectedTests,
                    discountAmount = 0.0,
                    discountPercent = 0.0,
                    paymentStatus = status,
                    paidAmount = counterPaid,
                    notes = counterNotes
                ) { order, msg ->
                    counterSaving = false
                    orderStatusSuccess = order != null
                    orderStatusMessage = msg
                }
            }
        }

        // V79: the landing screen is the lab counter itself. Secondary tools remain
        // available below it, but 80-90% of the day-to-day flow stays on one screen.
        // Once a task is opened, that task owns the whole screen until Back is pressed.
        if (managerMainMode == "home") {
            Scaffold(
                topBar = {
                    Column {
                        TopHeader(
                            onLogout = onLogout,
                            showSettings = false,
                            onSettings = null,
                            showHome = false,
                            onHome = null
                        )
                        SyncStatusBar(
                            isOnline = isOnline,
                            pendingCount = pendingSyncCount,
                            lastSyncMillis = lastSuccessfulSyncMillis
                        )
                    }
                },
                containerColor = if (appSettings.darkMode) Color(0xFF0B1220) else Color(0xFFF4F7FB)
            ) { paddingValues ->
                MainContent(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(paddingValues)
                        .padding(horizontal = 12.dp),
                    topContent = {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            LabCounterHeader(
                                selectedCount = selectedTests.size,
                                total = counterTotal,
                                customer = activeOrderCustomer
                            )
                            SearchBox(
                                query = searchQuery,
                                onQueryChange = { viewModel.onManualQueryChanged(it) },
                                onClear = { viewModel.clearSearch() },
                                onImportDocument = { testsDocumentLauncher.launch(arrayOf("image/*")) },
                                importingDocument = importingTestsDocument
                            )
                        }
                    },
                    uiState = uiState,
                    selectedTests = selectedTests,
                    recognizedTests = recognizedTests,
                    isManager = false,
                    lab2LabPrices = emptyMap(),
                    customerPriceOverrides = customerPriceOverrides,
                    activeOrderCustomer = activeOrderCustomer,
                    onChooseCustomer = {
                        counterAutoSaveAfterCustomerPick = false
                        showOrderCustomerPicker = true
                    },
                    onClearCustomer = { activeOrderCustomer = null },
                    onSaveCustomerOrder = {},
                    onSelectTest = { test -> viewModel.addSelectedTest(test) },
                    onRemoveTest = { testId -> viewModel.removeSelectedTest(testId) },
                    onAddAllRecognized = { viewModel.addAllRecognizedTests() },
                    onEditPrices = {},
                    onAddPriceResultsToOrder = { tests -> viewModel.addTestsToSelection(tests) },
                    allowOrderSelection = true,
                    showResolvedBatchAction = false,
                    selectedTestsContent = { tests ->
                        LabCounterSelectedSection(
                            selectedTests = tests,
                            customerPriceOverrides = customerPriceOverrides,
                            customer = activeOrderCustomer,
                            paidText = counterPaidText,
                            onPaidTextChange = { counterPaidText = it },
                            notes = counterNotes,
                            onNotesChange = { counterNotes = it },
                            savingOrder = counterSaving,
                            onChooseCustomer = {
                                counterAutoSaveAfterCustomerPick = false
                                showOrderCustomerPicker = true
                            },
                            onClearCustomer = { activeOrderCustomer = null },
                            onSaveOrder = {
                                val customer = activeOrderCustomer
                                if (customer == null) {
                                    counterAutoSaveAfterCustomerPick = true
                                    showOrderCustomerPicker = true
                                } else {
                                    saveCounterOrderForCustomer(customer)
                                }
                            },
                            onClearRequest = {
                                viewModel.clearSelectedTests()
                                viewModel.clearSearch()
                                activeOrderCustomer = null
                                counterPaidText = "0"
                                counterNotes = ""
                            },
                            onRemoveTest = { testId -> viewModel.removeSelectedTest(testId) }
                        )
                    },
                    bottomContent = {
                        CounterToolsDock(
                            onCustomers = openCustomersWorkspace,
                            onScan = { showScanHub = true },
                            onCatalog = openCatalogWorkspace,
                            onAdmin = openAdminWorkspace,
                            onPrices = { requireAdmin { showManagerDashboard = true } },
                            onSettings = openSettingsWorkspace,
                            onLockAdmin = { viewModel.lockAdmin() },
                            adminUnlocked = adminUnlocked
                        )
                    }
                )
            }
        } else {
            val temporaryWorkspaceTitle = when (managerMainMode) {
                "catalog" -> appText("كتالوج التحاليل والأسعار", "Test catalog & prices")
                "quick_image" -> appText("صورة سريعة", "Quick image")
                else -> appText("طلب جديد", "New order")
            }
            val temporaryWorkspaceIcon = when (managerMainMode) {
                "catalog" -> Icons.Outlined.Biotech
                "quick_image" -> Icons.Default.Image
                else -> Icons.Default.AddCircle
            }

            Scaffold(
                topBar = {
                    Column {
                        TemporaryWorkspaceTopBar(
                            title = temporaryWorkspaceTitle,
                            icon = temporaryWorkspaceIcon,
                            onBack = {
                                managerMainMode = "home"
                                viewModel.clearSearch()
                            }
                        )
                        DailyServicesNavBar(
                            active = managerMainMode,
                            onCatalog = openCatalogWorkspace,
                            onQuickImage = openQuickImageWorkspace,
                            onOrder = openOrderWorkspace,
                            onCustomers = openCustomersWorkspace,
                            onScan = { showScanHub = true }
                        )
                        // Keep status out of the working area unless attention is required.
                        if (!isOnline || pendingSyncCount > 0) {
                            SyncStatusBar(
                                isOnline = isOnline,
                                pendingCount = pendingSyncCount,
                                lastSyncMillis = lastSuccessfulSyncMillis
                            )
                        }
                    }
                },
                containerColor = if (appSettings.darkMode) Color(0xFF0B1220) else Color(0xFFF4F7FB)
            ) { paddingValues ->
                when (managerMainMode) {
                    "quick_image" -> {
                        MainContent(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(paddingValues)
                                .padding(horizontal = 14.dp),
                            topContent = {
                                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Text(
                                        text = appText(
                                            "اختار التحاليل واعمل صورة فورا — بيانات العميل اختيارية",
                                            "Select tests and create an image instantly — customer data is optional"
                                        ),
                                        fontSize = 11.sp,
                                        color = Color(0xFF64748B)
                                    )
                                    SearchBox(
                                        query = searchQuery,
                                        onQueryChange = { viewModel.onManualQueryChanged(it) },
                                        onClear = { viewModel.clearSearch() },
                                        onImportDocument = {
                                            testsDocumentLauncher.launch(arrayOf("image/*"))
                                        },
                                        importingDocument = importingTestsDocument
                                    )
                                }
                            },
                            uiState = uiState,
                            selectedTests = selectedTests,
                            recognizedTests = recognizedTests,
                            isManager = false,
                            lab2LabPrices = emptyMap(),
                            customerPriceOverrides = customerPriceOverrides,
                            activeOrderCustomer = null,
                            onChooseCustomer = {},
                            onClearCustomer = {},
                            onSaveCustomerOrder = {},
                            onSelectTest = { test -> viewModel.addSelectedTest(test) },
                            onRemoveTest = { testId -> viewModel.removeSelectedTest(testId) },
                            onAddAllRecognized = { viewModel.addAllRecognizedTests() },
                            onEditPrices = {},
                            onAddPriceResultsToOrder = { tests -> viewModel.addTestsToSelection(tests) },
                            allowOrderSelection = true,
                            showResolvedBatchAction = true,
                            selectedTestsContent = { tests ->
                                QuickImageSelectedSection(
                                    selectedTests = tests,
                                    customerPriceOverrides = customerPriceOverrides,
                                    onRemoveTest = { testId -> viewModel.removeSelectedTest(testId) }
                                )
                            },
                            bottomContent = null
                        )
                    }

                    "catalog" -> {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(paddingValues)
                                .padding(horizontal = 14.dp, vertical = 12.dp)
                        ) {
                            AvailableTestsScreen(
                                viewModel = viewModel,
                                isManager = false,
                                customerPriceOverrides = customerPriceOverrides,
                                lab2LabPrices = emptyMap(),
                                onEditPrices = {},
                                bottomContent = null
                            )
                        }
                    }

                    else -> {
                        MainContent(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(paddingValues)
                                .padding(horizontal = 14.dp),
                            topContent = {
                                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    OrderWorkspaceCustomerBar(
                                        customer = activeOrderCustomer,
                                        onChooseCustomer = { showOrderCustomerPicker = true },
                                        onOpenCustomerFiles = openCustomersWorkspace,
                                        onClearCustomer = { activeOrderCustomer = null }
                                    )
                                    SearchBox(
                                        query = searchQuery,
                                        onQueryChange = { viewModel.onManualQueryChanged(it) },
                                        onClear = { viewModel.clearSearch() },
                                        onImportDocument = {
                                            testsDocumentLauncher.launch(arrayOf("image/*"))
                                        },
                                        importingDocument = importingTestsDocument
                                    )
                                }
                            },
                            uiState = uiState,
                            selectedTests = selectedTests,
                            recognizedTests = recognizedTests,
                            isManager = false,
                            lab2LabPrices = emptyMap(),
                            customerPriceOverrides = customerPriceOverrides,
                            activeOrderCustomer = activeOrderCustomer,
                            onChooseCustomer = { showOrderCustomerPicker = true },
                            onClearCustomer = { activeOrderCustomer = null },
                            onSaveCustomerOrder = {
                                if (activeOrderCustomer != null && selectedTests.isNotEmpty()) {
                                    showOrderCheckout = true
                                }
                            },
                            onSelectTest = { test -> viewModel.addSelectedTest(test) },
                            onRemoveTest = { testId -> viewModel.removeSelectedTest(testId) },
                            onAddAllRecognized = {
                                val added = viewModel.addAllRecognizedTests()
                                if (added > 0) {
                                    orderStatusSuccess = true
                                    orderStatusMessage = tr(
                                        "تمت إضافة $added تحليل إلى القائمة.",
                                        "$added tests were added to the list."
                                    )
                                }
                            },
                            onEditPrices = {},
                            allowOrderSelection = true,
                            bottomContent = null
                        )
                    }
                }
            }
        }

        if (showScanHub) {
            HomeScanHubDialog(
                onDismiss = { showScanHub = false },
                onCustomerQr = {
                    showScanHub = false
                    openCustomerQrScanner()
                },
                onTestsDocument = {
                    showScanHub = false
                    openImportWorkspace()
                },
                onNavigateSearch = { showScanHub = false; openCatalogWorkspace() },
                onNavigateQuickImage = { showScanHub = false; openQuickImageWorkspace() },
                onNavigateOrder = { showScanHub = false; openOrderWorkspace() },
                onNavigateCustomers = { showScanHub = false; openCustomersWorkspace() },
                onNavigateCatalog = { showScanHub = false; openCatalogWorkspace() }
            )
        }

        if (showOperationsV14 && isManager) {
            OperationsV14Dialog(
                viewModel = viewModel,
                isManager = isManager,
                initialPage = operationsInitialPage,
                initialDebtsOnly = operationsInitialDebtsOnly,
                initialRange = operationsInitialRange,
                onOpenAdminSettings = {
                    showOperationsV14 = false
                    showAdminSettingsDialog = true
                },
                onDismiss = { showOperationsV14 = false }
            )
        }

        if (showCustomerSystem) {
            CustomerSystemDialog(
                viewModel = viewModel,
                selectedTests = selectedTests,
                onDismiss = {
                    showCustomerSystem = false
                    customerSystemInitialCustomer = null
                    customerSystemAutoScan = false
                },
                onStartOrderForCustomer = { customer ->
                    activeOrderCustomer = customer
                    showCustomerSystem = false
                    managerMainMode = "order"
                            orderStatusMessage = "تم اختيار ${customer.name}. اختار التحاليل واحفظ الطلب."
                    orderStatusSuccess = true
                },
                initialCustomer = customerSystemInitialCustomer,
                initialAutoScan = customerSystemAutoScan,
                initialQrUri = pendingSharedQrUri,
                onInitialQrConsumed = { uri -> viewModel.consumeSharedQrUri(uri) },
                onNavigateSearch = { showCustomerSystem = false; openCatalogWorkspace() },
                onNavigateQuickImage = { showCustomerSystem = false; openQuickImageWorkspace() },
                onNavigateOrder = { showCustomerSystem = false; openOrderWorkspace() },
                onNavigateCustomers = {},
                onNavigateScan = { showCustomerSystem = false; showScanHub = true },
                onNavigateCatalog = { showCustomerSystem = false; openCatalogWorkspace() }
            )
        }

        if (showOrderCustomerPicker) {
            CustomerOrderFlowDialog(
                viewModel = viewModel,
                selectedTests = selectedTests,
                onDismiss = {
                    showOrderCustomerPicker = false
                    autoCheckoutAfterCustomerPick = false
                    counterAutoSaveAfterCustomerPick = false
                },
                onCustomerSelected = { customer ->
                    val shouldOpenCheckout = autoCheckoutAfterCustomerPick
                    val shouldAutoSaveCounter = counterAutoSaveAfterCustomerPick
                    val stayOnCounter = managerMainMode == "home"
                    activeOrderCustomer = customer
                    showOrderCustomerPicker = false
                    autoCheckoutAfterCustomerPick = false
                    counterAutoSaveAfterCustomerPick = false
                    orderStatusSuccess = true
                    orderStatusMessage = when {
                        shouldAutoSaveCounter -> null
                        shouldOpenCheckout -> null
                        else -> "تم ربط الطلب بالعميل ${customer.name}"
                    }
                    if (!stayOnCounter) managerMainMode = "order"
                    when {
                        shouldAutoSaveCounter && selectedTests.isNotEmpty() -> saveCounterOrderForCustomer(customer)
                        shouldOpenCheckout && selectedTests.isNotEmpty() -> showOrderCheckout = true
                    }
                }
            )
        }

        val checkoutCustomer = activeOrderCustomer
        if (showOrderCheckout && checkoutCustomer != null) {
            ProfessionalOrderCheckoutDialog(
                customer = checkoutCustomer,
                selectedTests = selectedTests,
                customerPriceOverrides = customerPriceOverrides,
                onDismiss = { showOrderCheckout = false },
                onConfirm = { discount, discountPercent, paymentStatus, paidAmount, notes, _, done ->
                    viewModel.saveCustomerOrderAdvanced(
                        customer = checkoutCustomer,
                        tests = selectedTests,
                        discountAmount = discount,
                        discountPercent = discountPercent,
                        paymentStatus = paymentStatus,
                        paidAmount = paidAmount,
                        notes = notes
                    ) { order, msg ->
                        done()
                        orderStatusSuccess = order != null
                        orderStatusMessage = msg
                        if (order != null) {
                            // V38: the order is saved first. Document generation/sharing is optional.
                            pendingOutputOrder = order
                            pendingOutputCustomer = checkoutCustomer
                            orderStatusSuccess = true
                            orderStatusMessage = null
                            showOrderCheckout = false
                            viewModel.clearSelectedTests()
                            // V64: keep the customer linked so the user can immediately open the file
                            // or start another action without having to find the customer again.
                        }
                    }
                }
            )
        }

        val outputOrder = pendingOutputOrder
        val outputCustomer = pendingOutputCustomer
        if (outputOrder != null && outputCustomer != null) {
            OrderImageShareDialog(
                order = outputOrder,
                customer = outputCustomer,
                onDismiss = {
                    orderStatusSuccess = true
                    orderStatusMessage = tr(
                        "تم حفظ ${outputOrder.items.size} تحليل في ملف ${outputCustomer.name} • الإجمالي ${formatTotalDisplay(outputOrder.totalCustomerPrice)} جنيه",
                        "Saved ${outputOrder.items.size} tests to ${outputCustomer.name} • total ${formatTotalDisplay(outputOrder.totalCustomerPrice)} EGP"
                    )
                    pendingOutputOrder = null
                    pendingOutputCustomer = null
                }
            )
        }

        orderStatusMessage?.let { message ->
            AlertDialog(
                onDismissRequest = { orderStatusMessage = null },
                title = {
                    Text(
                        if (orderStatusSuccess) "تم" else "تعذر التنفيذ",
                        fontWeight = FontWeight.ExtraBold
                    )
                },
                text = { Text(message) },
                confirmButton = {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (orderStatusSuccess && activeOrderCustomer != null) {
                            TextButton(
                                onClick = {
                                    orderStatusMessage = null
                                    customerSystemInitialCustomer = activeOrderCustomer
                                    showCustomerSystem = true
                                }
                            ) {
                                Text(appText("فتح ملف العميل", "Open customer file"), fontWeight = FontWeight.Bold)
                            }
                        }
                        TextButton(onClick = { orderStatusMessage = null }) { Text(appText("حسنا", "OK")) }
                    }
                }
            )
        }

        if (showAdminPasswordDialog) {
            AlertDialog(
                onDismissRequest = {
                    if (!adminUnlocking) {
                        showAdminPasswordDialog = false
                        pendingAdminAction = null
                        adminUnlockError = null
                    }
                },
                title = {
                    Text(
                        appText("دخول الإدارة", "Administration access"),
                        fontWeight = FontWeight.ExtraBold
                    )
                },
                text = {
                    Column {
                        Text(
                            appText(
                                "اكتب PIN الإدارة المكون من 6 أرقام لفتح الخدمات الحساسة.",
                                "Enter the 6-digit admin PIN to unlock sensitive services."
                            ),
                            color = Color(0xFF64748B),
                            fontSize = 12.sp
                        )
                        Spacer(Modifier.height(10.dp))
                        OutlinedTextField(
                            value = adminPin,
                            onValueChange = { adminPin = it.filter(Char::isDigit).take(6); adminUnlockError = null },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            label = { Text(appText("PIN الإدارة", "Admin PIN")) },
                            leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null) },
                            visualTransformation = PasswordVisualTransformation(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword, imeAction = ImeAction.Done),
                            keyboardActions = KeyboardActions(onDone = {
                                if (!adminUnlocking) {
                                    adminUnlocking = true
                                    viewModel.unlockAdmin(adminPin) { success, message ->
                                        adminUnlocking = false
                                        if (success) {
                                            showAdminPasswordDialog = false
                                            adminUnlockError = null
                                            val action = pendingAdminAction
                                            pendingAdminAction = null
                                            action?.invoke()
                                        } else {
                                            adminUnlockError = message
                                        }
                                    }
                                }
                            })
                        )
                        adminUnlockError?.let {
                            Spacer(Modifier.height(7.dp))
                            Text(it, color = Color(0xFFB42318), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            if (!adminUnlocking) {
                                adminUnlocking = true
                                viewModel.unlockAdmin(adminPin) { success, message ->
                                    adminUnlocking = false
                                    if (success) {
                                        showAdminPasswordDialog = false
                                        adminUnlockError = null
                                        val action = pendingAdminAction
                                        pendingAdminAction = null
                                        action?.invoke()
                                    } else {
                                        adminUnlockError = message
                                    }
                                }
                            }
                        },
                        enabled = !adminUnlocking && adminPin.length == 6
                    ) {
                        if (adminUnlocking) {
                            CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                        } else {
                            Text(appText("فتح", "Unlock"), fontWeight = FontWeight.Bold)
                        }
                    }
                },
                dismissButton = {
                    TextButton(onClick = {
                        if (!adminUnlocking) {
                            showAdminPasswordDialog = false
                            pendingAdminAction = null
                            adminUnlockError = null
                        }
                    }) { Text(appText("إلغاء", "Cancel")) }
                }
            )
        }

        if (showSettingsDialog) {
            UserSettingsDialog(
                viewModel = viewModel,
                settings = appSettings,
                onDismiss = { showSettingsDialog = false }
            )
        }

        if (showAdminSettingsDialog && isManager) {
            ManagerSettingsDialog(
                viewModel = viewModel,
                settings = appSettings,
                currentUserEmail = currentUserEmail,
                currentUserUid = currentUserUid,
                onDismiss = { showAdminSettingsDialog = false },
                onOpenManagerDashboard = {
                    showAdminSettingsDialog = false
                    showManagerDashboard = true
                },
                onLogout = onLogout
            )
        }

        if (isManager && showManagerDashboard) {
            ManagerDashboardDialog(
                viewModel = viewModel,
                customerPriceOverrides = customerPriceOverrides,
                lab2LabPrices = lab2LabPrices,
                onDismiss = { showManagerDashboard = false },
                onEdit = { test ->
                    showManagerDashboard = false
                    priceEditorTest = test
                }
            )
        }

        if (isManager) {
            priceEditorTest?.let { test ->
                ManagerPriceEditorDialog(
                    test = test,
                    customerPrice = customerPriceOverrides[test.id] ?: test.customerPrice.orEmpty(),
                    lab2LabPrice = lab2LabPrices[test.id].orEmpty(),
                    onDismiss = { priceEditorTest = null },
                    onSave = { customer, lab, done ->
                        viewModel.saveManagerPrices(test, customer, lab) { success, message ->
                            if (success) priceEditorTest = null
                            done(success, message)
                        }
                    }
                )
            }
        }
    }
}

@Composable
private fun SyncStatusBar(
    isOnline: Boolean,
    pendingCount: Int,
    lastSyncMillis: Long
) {
    val bg = when {
        !isOnline -> Color(0xFFFFF3CD)
        pendingCount > 0 -> Color(0xFFE0F2FE)
        else -> Color(0xFFE8F5E9)
    }
    val fg = when {
        !isOnline -> Color(0xFF92400E)
        pendingCount > 0 -> Color(0xFF075985)
        else -> Color(0xFF166534)
    }
    val text = when {
        !isOnline && pendingCount > 0 -> appText(
            "Offline • $pendingCount عملية في انتظار المزامنة",
            "Offline • $pendingCount operation(s) waiting to sync"
        )
        !isOnline -> appText("Offline • سيتم الحفظ والمزامنة عند رجوع الإنترنت", "Offline • changes will sync when internet returns")
        pendingCount > 0 -> appText("جاري مزامنة $pendingCount عملية...", "Syncing $pendingCount operation(s)...")
        else -> appText("Online • تمت المزامنة", "Online • Synced")
    }
    Surface(color = bg, modifier = Modifier.fillMaxWidth()) {
        Text(
            text = text,
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
            color = fg,
            fontSize = 11.sp,
            lineHeight = 15.sp,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
private fun TopHeader(
    onLogout: (() -> Unit)? = null,
    showSettings: Boolean = false,
    onSettings: (() -> Unit)? = null,
    showHome: Boolean = false,
    onHome: (() -> Unit)? = null
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                Brush.horizontalGradient(
                    colors = listOf(
                        Color(0xFF003A5D),
                        Color(0xFF006D86),
                        Color(0xFF008FA0)
                    )
                )
            )
            .padding(horizontal = 16.dp, vertical = 16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                modifier = Modifier.weight(1f),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(18.dp),
                    color = Color.White,
                    shadowElevation = 3.dp,
                    modifier = Modifier.size(58.dp)
                ) {
                    Box(
                        modifier = Modifier.padding(5.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.ic_clinic_logo),
                            contentDescription = tr("شعار عيادات العقاد", "Alakkad Clinics logo"),
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                    Text(
                        text = appText("تحاليل العقاد", "Tahalil Alakkad"),
                        fontSize = 21.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.White,
                        letterSpacing = (-0.4).sp
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = appText("دليل التحاليل والأسعار", "Lab Tests & Prices"),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        color = Color(0xFFD9F4F4)
                    )
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                if (showHome && onHome != null) {
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = Color.White.copy(alpha = 0.12f)
                    ) {
                        IconButton(
                            onClick = onHome,
                            modifier = Modifier.size(44.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Home,
                                contentDescription = appText("الرئيسية", "Home"),
                                tint = Color.White,
                                modifier = Modifier.size(21.dp)
                            )
                        }
                    }
                }

                if (showSettings && onSettings != null) {
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = Color.White.copy(alpha = 0.12f)
                    ) {
                        IconButton(
                            onClick = onSettings,
                            modifier = Modifier
                                .size(44.dp)
                                .testTag("manager_settings_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Settings,
                                contentDescription = appText("إعدادات التطبيق", "App settings"),
                                tint = Color.White,
                                modifier = Modifier.size(21.dp)
                            )
                        }
                    }
                }

                if (onLogout != null) {
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = Color.White.copy(alpha = 0.12f)
                    ) {
                        IconButton(
                            onClick = onLogout,
                            modifier = Modifier
                                .size(44.dp)
                                .testTag("logout_button")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.Logout,
                                contentDescription = appText("تسجيل الخروج", "Logout"),
                                tint = Color.White,
                                modifier = Modifier.size(21.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StaffHomeDashboard(
    modifier: Modifier = Modifier,
    onSearch: () -> Unit,
    onNewOrder: () -> Unit,
    onImportTests: () -> Unit,
    onCustomers: () -> Unit,
    onQr: () -> Unit,
    onAvailableTests: () -> Unit,
    onSettings: () -> Unit
) {
    LazyColumn(
        modifier = modifier.padding(horizontal = 12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 28.dp)
    ) {
        item {
            Text(
                text = appText("كل الخدمات", "All services"),
                fontSize = 20.sp,
                lineHeight = 26.sp,
                fontWeight = FontWeight.ExtraBold,
                color = Color(0xFF17324D)
            )
            Spacer(Modifier.height(2.dp))
            Text(
                text = appText("اختار الخدمة من الأيقونة مباشرة", "Choose a service directly from its icon"),
                fontSize = 11.sp,
                color = Color(0xFF64748B)
            )
        }

        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GlossyServiceCard(Modifier.weight(1f), R.drawable.staff_search_3d, appText("بحث عن تحليل", "Find test"), onClick = onSearch)
                GlossyServiceCard(Modifier.weight(1f), R.drawable.staff_new_order_3d, appText("طلب جديد", "New order"), onClick = onNewOrder)
                GlossyServiceCard(Modifier.weight(1f), R.drawable.staff_quick_image_3d, appText("صورة سريعة", "Quick image"), onClick = onImportTests)
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GlossyServiceCard(Modifier.weight(1f), R.drawable.staff_qr_3d, appText("QR العميل", "Customer QR"), onClick = onQr)
                GlossyServiceCard(Modifier.weight(1f), R.drawable.staff_customers_3d, appText("سجلات العملاء", "Customers"), onClick = onCustomers)
                GlossyServiceCard(Modifier.weight(1f), R.drawable.staff_tests_3d, appText("التحاليل المتاحة", "Available tests"), onClick = onAvailableTests)
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                GlossyServiceCard(Modifier.fillMaxWidth(0.32f), R.drawable.settings_3d, appText("الإعدادات", "Settings"), onClick = onSettings)
            }
        }
    }
}

@Composable
private fun GlossyServiceCard(
    modifier: Modifier = Modifier,
    iconRes: Int,
    title: String,
    locked: Boolean = false,
    compact: Boolean = false,
    onClick: () -> Unit
) {
    val accent = when (iconRes) {
        R.drawable.staff_tests_3d -> Color(0xFF00E5FF)
        R.drawable.staff_quick_image_3d -> Color(0xFFAE72FF)
        R.drawable.staff_new_order_3d -> Color(0xFF25F0A7)
        R.drawable.staff_customers_3d -> Color(0xFF4DA3FF)
        R.drawable.staff_qr_3d -> Color(0xFFFFB23E)
        R.drawable.settings_3d -> Color(0xFFC07CFF)
        R.drawable.mgr_reports_3d -> Color(0xFFFFC857)
        R.drawable.mgr_health_3d -> Color(0xFFFF6E9D)
        else -> Color(0xFF36DFF2)
    }
    val shape = RoundedCornerShape(if (compact) 22.dp else 26.dp)

    Card(
        onClick = onClick,
        modifier = modifier
            .height(if (compact) 154.dp else 172.dp)
            .shadow(
                elevation = if (compact) 19.dp else 24.dp,
                shape = shape,
                ambientColor = accent.copy(alpha = 0.72f),
                spotColor = accent.copy(alpha = 0.96f)
            ),
        shape = shape,
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
        border = BorderStroke(1.7.dp, accent.copy(alpha = 0.92f))
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.verticalGradient(
                        listOf(
                            accent.copy(alpha = 0.25f),
                            Color(0xFF0A1D35),
                            Color(0xFF030A15)
                        )
                    )
                )
                .padding(horizontal = 7.dp, vertical = 9.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(if (compact) 80.dp else 98.dp)
                        .clip(RoundedCornerShape(if (compact) 17.dp else 21.dp))
                        .background(
                            Brush.radialGradient(
                                colors = listOf(
                                    accent.copy(alpha = 0.38f),
                                    Color(0xFF0D2842),
                                    Color(0xFF06111F)
                                )
                            )
                        )
                        .border(
                            1.2.dp,
                            accent.copy(alpha = 0.70f),
                            RoundedCornerShape(if (compact) 17.dp else 21.dp)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(if (compact) 66.dp else 84.dp)
                            .shadow(
                                if (compact) 25.dp else 32.dp,
                                CircleShape,
                                ambientColor = accent.copy(alpha = 0.72f),
                                spotColor = accent
                            )
                            .clip(CircleShape)
                            .background(accent.copy(alpha = 0.10f))
                    )
                    Image(
                        painter = painterResource(iconRes),
                        contentDescription = null,
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(if (compact) 4.dp else 2.dp),
                        contentScale = ContentScale.Fit
                    )
                    if (locked) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .padding(6.dp)
                                .size(29.dp)
                                .shadow(11.dp, CircleShape, ambientColor = Color(0xFFFFC857), spotColor = Color(0xFFFFC857))
                                .clip(CircleShape)
                                .background(Color(0xFF101827))
                                .border(1.dp, Color(0xFFFFD879), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Lock, contentDescription = null, tint = Color(0xFFFFD879), modifier = Modifier.size(16.dp))
                        }
                    }
                }

                Spacer(Modifier.height(8.dp))
                Text(
                    text = title,
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = if (compact) 30.dp else 34.dp),
                    fontSize = if (compact) 10.sp else 11.sp,
                    lineHeight = if (compact) 14.sp else 16.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color.White,
                    textAlign = TextAlign.Center,
                    maxLines = 2,
                    softWrap = true,
                    overflow = TextOverflow.Clip
                )
                Spacer(Modifier.height(4.dp))
                Box(
                    modifier = Modifier
                        .width(if (compact) 28.dp else 34.dp)
                        .height(2.dp)
                        .shadow(7.dp, RoundedCornerShape(99.dp), ambientColor = accent, spotColor = accent)
                        .background(accent, RoundedCornerShape(99.dp))
                )
            }
        }
    }
}

@Composable
private fun StaffFeatureIllustration(
    mainIcon: ImageVector,
    badgeIcon: ImageVector,
    accent: Color
) {
    Box(
        modifier = Modifier
            .size(76.dp)
            .clip(RoundedCornerShape(24.dp))
            .background(
                Brush.linearGradient(
                    colors = listOf(accent.copy(alpha = 0.08f), accent.copy(alpha = 0.18f))
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .size(52.dp)
                .clip(CircleShape)
                .background(Color.White),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = mainIcon,
                contentDescription = null,
                tint = accent,
                modifier = Modifier.size(31.dp)
            )
        }
        Box(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .size(27.dp)
                .clip(CircleShape)
                .background(accent),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = badgeIcon,
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(15.dp)
            )
        }
    }
}

@Composable
private fun StaffSecondaryActionCard(
    icon: ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    val accent = Color(0xFF36DFF2)
    Card(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .shadow(13.dp, RoundedCornerShape(18.dp), ambientColor = accent.copy(alpha = 0.40f), spotColor = accent.copy(alpha = 0.65f)),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF071424)),
        border = BorderStroke(1.dp, accent.copy(alpha = 0.72f))
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 11.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .shadow(12.dp, RoundedCornerShape(13.dp), ambientColor = accent, spotColor = accent)
                    .clip(RoundedCornerShape(13.dp))
                    .background(Brush.radialGradient(listOf(accent.copy(alpha = 0.40f), Color(0xFF0A1D35))))
                    .border(1.dp, accent.copy(alpha = 0.82f), RoundedCornerShape(13.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(22.dp))
            }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.ExtraBold, fontSize = 12.sp, color = Color.White)
                Text(subtitle, fontSize = 9.sp, color = Color(0xFFB8CBE0))
            }
        }
    }
}

@Composable
private fun LabCounterHeader(
    selectedCount: Int,
    total: Double,
    customer: Customer?
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(20.dp, RoundedCornerShape(24.dp), ambientColor = Color(0x6600E5FF), spotColor = Color(0x9900E5FF)),
        shape = RoundedCornerShape(24.dp),
        color = Color(0xFF061323),
        border = BorderStroke(1.4.dp, Color(0xFF2CE8F2))
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 15.dp, vertical = 13.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        appText("كاونتر المعمل", "Lab counter"),
                        color = Color.White,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Text(
                        appText(
                            "اكتب أو الصق التحاليل — اختار — احفظ الطلب أو الصورة من نفس الشاشة",
                            "Type or paste tests — select — save the order or image from the same screen"
                        ),
                        color = Color(0xFFB8DCE7),
                        fontSize = 10.sp,
                        lineHeight = 14.sp
                    )
                }
                Box(
                    modifier = Modifier
                        .size(52.dp)
                        .shadow(20.dp, RoundedCornerShape(16.dp), ambientColor = Color(0xFF00E5FF), spotColor = Color(0xFF00E5FF))
                        .clip(RoundedCornerShape(16.dp))
                        .background(Brush.radialGradient(listOf(Color(0x6600E5FF), Color(0xFF0A2638))))
                        .border(1.dp, Color(0xFF5AF4FF), RoundedCornerShape(16.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Outlined.Biotech, contentDescription = null, tint = Color.White, modifier = Modifier.size(28.dp))
                }
            }

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                CounterStatusChip(
                    modifier = Modifier.weight(1f),
                    label = appText("المختار", "Selected"),
                    value = "$selectedCount",
                    accent = Color(0xFF2CE8F2)
                )
                CounterStatusChip(
                    modifier = Modifier.weight(1f),
                    label = appText("الإجمالي", "Total"),
                    value = "${formatTotalDisplay(total)} ${appText("ج", "EGP")}",
                    accent = Color(0xFF25F0A7)
                )
                CounterStatusChip(
                    modifier = Modifier.weight(1f),
                    label = appText("العميل", "Customer"),
                    value = customer?.name?.take(12) ?: appText("اختياري", "Optional"),
                    accent = Color(0xFFAE72FF)
                )
            }
        }
    }
}

@Composable
private fun CounterStatusChip(
    modifier: Modifier = Modifier,
    label: String,
    value: String,
    accent: Color
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        color = accent.copy(alpha = 0.10f),
        border = BorderStroke(1.dp, accent.copy(alpha = 0.55f))
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 7.dp, vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(label, color = Color(0xFF9CB6C8), fontSize = 8.sp, maxLines = 1)
            Text(
                value,
                color = Color.White,
                fontSize = 11.sp,
                lineHeight = 14.sp,
                fontWeight = FontWeight.ExtraBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun LabCounterSelectedSection(
    selectedTests: List<LabTest>,
    customerPriceOverrides: Map<Int, String>,
    customer: Customer?,
    paidText: String,
    onPaidTextChange: (String) -> Unit,
    notes: String,
    onNotesChange: (String) -> Unit,
    savingOrder: Boolean,
    onChooseCustomer: () -> Unit,
    onClearCustomer: () -> Unit,
    onSaveOrder: () -> Unit,
    onClearRequest: () -> Unit,
    onRemoveTest: (Int) -> Unit
) {
    val context = LocalContext.current
    val total = calculatePriceTotal(selectedTests) { customerPriceOverrides[it.id] ?: it.customerPrice }
    val typedPaid = paidText.replace(',', '.').toDoubleOrNull()
    val paidValid = typedPaid != null && typedPaid >= 0.0 && typedPaid <= total
    val paid = (typedPaid ?: 0.0).coerceIn(0.0, total.coerceAtLeast(0.0))
    val remaining = (total - paid).coerceAtLeast(0.0)
    val paymentLabel = when {
        total > 0.0 && paid >= total -> appText("مدفوع", "Paid")
        paid > 0.0 -> appText("جزئي", "Partial")
        else -> appText("غير مدفوع", "Unpaid")
    }
    var busyImageAction by remember { mutableStateOf<String?>(null) }
    var pendingLegacySave by remember { mutableStateOf(false) }

    LaunchedEffect(total) {
        val current = paidText.replace(',', '.').toDoubleOrNull()
        if (current == null || current < 0.0 || current > total) onPaidTextChange("0")
    }

    fun buildImage() = PdfGenerator.generateQuickTestsImage(
        context = context,
        selectedTests = selectedTests,
        customerPriceOverrides = customerPriceOverrides,
        customerName = customer?.name.orEmpty(),
        customerPhone = customer?.phone.orEmpty()
    )

    fun saveImageNow() {
        if (busyImageAction != null) return
        busyImageAction = "save"
        try {
            val file = buildImage()
            if (file != null) {
                PdfGenerator.saveGeneratedImageToGallery(
                    context = context,
                    file = file,
                    displayName = "Tahalil_Alakkad_Counter_${System.currentTimeMillis()}.png"
                )
            }
        } finally {
            busyImageAction = null
        }
    }

    val legacyPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        val shouldSave = pendingLegacySave
        pendingLegacySave = false
        if (granted && shouldSave) saveImageNow()
    }

    fun requestImageSave() {
        val needsPermission = Build.VERSION.SDK_INT <= Build.VERSION_CODES.P &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
        if (needsPermission) {
            pendingLegacySave = true
            legacyPermissionLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        } else {
            saveImageNow()
        }
    }

    fun shareImageNow() {
        if (busyImageAction != null) return
        busyImageAction = "share"
        try {
            val file = buildImage()
            if (file != null) {
                PdfGenerator.shareGeneratedImage(
                    context = context,
                    file = file,
                    subject = "تحاليل العقاد - طلب تحاليل",
                    chooserTitle = "مشاركة صورة التحاليل"
                )
            }
        } finally {
            busyImageAction = null
        }
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(18.dp, RoundedCornerShape(24.dp), ambientColor = Color(0x5530DCE8), spotColor = Color(0x7730DCE8)),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.5.dp, Color(0xFF35DCE7))
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(11.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        appText("الطلب الحالي", "Current request"),
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 17.sp,
                        color = Color(0xFF17324D)
                    )
                    Text(
                        appText("${selectedTests.size} تحليل", "${selectedTests.size} tests"),
                        color = Color(0xFF64748B),
                        fontSize = 10.sp
                    )
                }
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = Color(0xFF062638),
                    border = BorderStroke(1.dp, Color(0xFF31E5EF))
                ) {
                    Column(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(appText("الإجمالي", "Total"), color = Color(0xFFA8D9E2), fontSize = 8.sp)
                        Text(
                            "${formatTotalDisplay(total)} ${appText("ج", "EGP")}",
                            color = Color.White,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }
                }
            }

            selectedTests.forEach { test ->
                SelectedTestRow(
                    test = test,
                    customerPrice = customerPriceOverrides[test.id] ?: test.customerPrice,
                    isManager = false,
                    lab2LabPrice = null,
                    onRemove = { onRemoveTest(test.id) }
                )
            }

            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(17.dp),
                color = Color(0xFFF7FBFC),
                border = BorderStroke(1.dp, Color(0xFFD7EEF0))
            ) {
                Column(Modifier.fillMaxWidth().padding(11.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.People, contentDescription = null, tint = Color(0xFF007E89), modifier = Modifier.size(19.dp))
                        Spacer(Modifier.width(7.dp))
                        Column(Modifier.weight(1f)) {
                            Text(appText("بيانات العميل - اختيارية", "Customer details - optional"), fontWeight = FontWeight.ExtraBold, fontSize = 12.sp, color = Color(0xFF17324D))
                            Text(
                                customer?.let { "${it.name} • ${it.phone}" }
                                    ?: appText("مش مطلوبة لحفظ أو مشاركة الصورة", "Not required to save or share the image"),
                                fontSize = 9.sp,
                                color = Color(0xFF64748B),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        if (customer != null) {
                            IconButton(onClick = onClearCustomer, modifier = Modifier.size(34.dp)) {
                                Icon(Icons.Default.Close, contentDescription = null, tint = Color(0xFF64748B), modifier = Modifier.size(18.dp))
                            }
                        }
                    }
                    OutlinedButton(
                        onClick = onChooseCustomer,
                        modifier = Modifier.fillMaxWidth().height(40.dp),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, Color(0xFF8FD6DC))
                    ) {
                        Text(
                            if (customer == null) appText("+ إضافة / اختيار عميل", "+ Add / choose customer") else appText("تغيير العميل", "Change customer"),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFF007E89)
                        )
                    }
                }
            }

            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(17.dp),
                color = Color(0xFFF8FAFC),
                border = BorderStroke(1.dp, Color(0xFFE2E8F0))
            ) {
                Column(Modifier.fillMaxWidth().padding(11.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = paidText,
                            onValueChange = { raw ->
                                onPaidTextChange(raw.filter { it.isDigit() || it == '.' || it == ',' }.take(10))
                            },
                            modifier = Modifier.weight(1.25f).heightIn(min = 62.dp),
                            label = { Text(appText("المبلغ المسدد", "Paid amount"), fontSize = 9.sp) },
                            suffix = { Text(appText("ج", "EGP"), fontSize = 9.sp) },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            isError = !paidValid,
                            shape = RoundedCornerShape(13.dp)
                        )
                        CounterMoneyChip(
                            modifier = Modifier.weight(0.9f),
                            title = appText("مدفوع", "Paid"),
                            value = formatTotalDisplay(paid),
                            accent = Color(0xFF16A36A)
                        )
                        CounterMoneyChip(
                            modifier = Modifier.weight(0.9f),
                            title = appText("متبقي", "Remaining"),
                            value = formatTotalDisplay(remaining),
                            accent = if (remaining > 0.0) Color(0xFFE05B68) else Color(0xFF16A36A)
                        )
                    }
                    Text(
                        appText("حالة الدفع: $paymentLabel", "Payment: $paymentLabel"),
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (paidValid) Color(0xFF475569) else Color(0xFFB91C1C)
                    )
                    OutlinedTextField(
                        value = notes,
                        onValueChange = { onNotesChange(it.take(500)) },
                        modifier = Modifier.fillMaxWidth().heightIn(min = 70.dp),
                        label = { Text(appText("ملاحظات - اختياري", "Notes - optional"), fontSize = 9.sp) },
                        minLines = 1,
                        maxLines = 3,
                        shape = RoundedCornerShape(13.dp)
                    )
                }
            }

            Button(
                onClick = onSaveOrder,
                enabled = paidValid && !savingOrder,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .shadow(15.dp, RoundedCornerShape(14.dp), ambientColor = Color(0xFF25F0A7), spotColor = Color(0xFF25F0A7)),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF087B66))
            ) {
                Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(7.dp))
                Text(
                    when {
                        savingOrder -> appText("جاري الحفظ...", "Saving...")
                        customer == null -> appText("إضافة عميل وحفظ الطلب", "Add customer & save order")
                        else -> appText("حفظ الطلب", "Save order")
                    },
                    fontWeight = FontWeight.ExtraBold
                )
            }

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = { requestImageSave() },
                    enabled = busyImageAction == null,
                    modifier = Modifier.weight(1f).height(45.dp),
                    shape = RoundedCornerShape(13.dp),
                    border = BorderStroke(1.2.dp, Color(0xFF00AFC1))
                ) {
                    Icon(Icons.Default.Download, contentDescription = null, tint = Color(0xFF007E89), modifier = Modifier.size(17.dp))
                    Spacer(Modifier.width(5.dp))
                    Text(appText("حفظ صورة", "Save image"), color = Color(0xFF007E89), fontSize = 10.sp, fontWeight = FontWeight.ExtraBold)
                }
                OutlinedButton(
                    onClick = { shareImageNow() },
                    enabled = busyImageAction == null,
                    modifier = Modifier.weight(1f).height(45.dp),
                    shape = RoundedCornerShape(13.dp),
                    border = BorderStroke(1.2.dp, Color(0xFF9965E8))
                ) {
                    Icon(Icons.Default.Share, contentDescription = null, tint = Color(0xFF7C45C9), modifier = Modifier.size(17.dp))
                    Spacer(Modifier.width(5.dp))
                    Text(appText("مشاركة", "Share"), color = Color(0xFF7C45C9), fontSize = 10.sp, fontWeight = FontWeight.ExtraBold)
                }
            }
            TextButton(
                onClick = onClearRequest,
                modifier = Modifier.align(Alignment.CenterHorizontally)
            ) {
                Icon(Icons.Default.AddCircle, contentDescription = null, tint = Color(0xFF64748B), modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(5.dp))
                Text(appText("بدء طلب جديد / تفريغ الشاشة", "Start new request / clear screen"), color = Color(0xFF64748B), fontSize = 9.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun CounterMoneyChip(
    modifier: Modifier = Modifier,
    title: String,
    value: String,
    accent: Color
) {
    Surface(
        modifier = modifier.height(58.dp),
        shape = RoundedCornerShape(13.dp),
        color = accent.copy(alpha = 0.08f),
        border = BorderStroke(1.dp, accent.copy(alpha = 0.45f))
    ) {
        Column(
            modifier = Modifier.fillMaxSize().padding(horizontal = 5.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(title, fontSize = 8.sp, color = Color(0xFF64748B), maxLines = 1)
            Text("$value ${appText("ج", "EGP")}", fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, color = accent, maxLines = 1)
        }
    }
}

@Composable
private fun CounterToolsDock(
    onCustomers: () -> Unit,
    onScan: () -> Unit,
    onCatalog: () -> Unit,
    onAdmin: () -> Unit,
    onPrices: () -> Unit,
    onSettings: () -> Unit,
    onLockAdmin: () -> Unit,
    adminUnlocked: Boolean
) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(
            appText("أدوات جانبية", "Side tools"),
            fontSize = 13.sp,
            fontWeight = FontWeight.ExtraBold,
            color = Color(0xFF475569)
        )
        Text(
            appText("الشغل الأساسي فوق — استخدم الأدوات دي عند الحاجة فقط", "Your main workflow is above — use these only when needed"),
            fontSize = 9.sp,
            color = Color(0xFF64748B)
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            GlossyServiceCard(
                Modifier.weight(1f),
                R.drawable.staff_customers_3d,
                appText("سجلات\nالعملاء", "Customer\nrecords"),
                compact = true,
                onClick = onCustomers
            )
            GlossyServiceCard(
                Modifier.weight(1f),
                R.drawable.staff_qr_3d,
                appText("QR /\nصورة", "QR /\nImage"),
                compact = true,
                onClick = onScan
            )
            GlossyServiceCard(
                Modifier.weight(1f),
                R.drawable.staff_tests_3d,
                appText("دليل\nالتحاليل", "Test\nguide"),
                compact = true,
                onClick = onCatalog
            )
        }

        HorizontalDivider(color = Color(0xFFE2E8F0))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            BottomUtilityCard(
                modifier = Modifier.weight(1f),
                imageRes = R.drawable.mgr_health_3d,
                title = appText("الإدارة", "Admin"),
                locked = !adminUnlocked,
                accent = Color(0xFFFF6E9D),
                onClick = onAdmin
            )
            BottomUtilityCard(
                modifier = Modifier.weight(1f),
                imageRes = R.drawable.mgr_reports_3d,
                title = appText("الأسعار\nLab 2 Lab", "Prices\nLab 2 Lab"),
                locked = !adminUnlocked,
                accent = Color(0xFFFFC857),
                onClick = onPrices
            )
            BottomUtilityCard(
                modifier = Modifier.weight(1f),
                imageRes = R.drawable.settings_3d,
                title = appText("الإعدادات", "Settings"),
                locked = false,
                accent = Color(0xFFC07CFF),
                onClick = onSettings
            )
        }
        if (adminUnlocked) {
            TextButton(onClick = onLockAdmin, modifier = Modifier.align(Alignment.End)) {
                Icon(Icons.Default.Lock, contentDescription = null, modifier = Modifier.size(14.dp))
                Spacer(Modifier.width(4.dp))
                Text(appText("قفل الإدارة", "Lock admin"), fontSize = 9.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun ManagerHomeDashboard(
    modifier: Modifier = Modifier,
    onCatalog: () -> Unit,
    onQuickImage: () -> Unit,
    onNewOrder: () -> Unit,
    onCustomers: () -> Unit,
    onScan: () -> Unit,
    onAdmin: () -> Unit,
    onPrices: () -> Unit,
    onSettings: () -> Unit,
    onLockAdmin: () -> Unit,
    adminUnlocked: Boolean
) {
    LazyColumn(
        modifier = modifier.padding(horizontal = 12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 28.dp)
    ) {
        item {
            Text(
                appText("الخدمات اليومية", "Daily services"),
                fontSize = 19.sp,
                fontWeight = FontWeight.ExtraBold,
                color = Color(0xFF17324D)
            )
            Text(
                appText("واجهة Premium ثلاثية الأبعاد — كل خدمة بأيقونة مضيئة واضحة", "Premium 3D interface — every service has a clear illuminated icon"),
                fontSize = 10.sp,
                color = Color(0xFF64748B)
            )
        }
        item {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(26.dp),
                color = Color(0xFF061323),
                border = BorderStroke(1.4.dp, Color(0xFF37EAF4))
            ) {
                Column(Modifier.padding(9.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        appText("ابدأ من واحدة من دول", "Start with one of these"),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color(0xFF8CF7FF),
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        GlossyServiceCard(
                            Modifier.weight(1f),
                            R.drawable.staff_tests_3d,
                            appText("كتالوج\nالتحاليل", "Test\ncatalog"),
                            compact = true,
                            onClick = onCatalog
                        )
                        GlossyServiceCard(
                            Modifier.weight(1f),
                            R.drawable.staff_quick_image_3d,
                            appText("صورة\nسريعة", "Quick\nimage"),
                            compact = true,
                            onClick = onQuickImage
                        )
                        GlossyServiceCard(
                            Modifier.weight(1f),
                            R.drawable.staff_new_order_3d,
                            appText("طلب\nجديد", "New\norder"),
                            compact = true,
                            onClick = onNewOrder
                        )
                    }
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GlossyServiceCard(Modifier.weight(1f), R.drawable.staff_customers_3d, appText("سجلات العملاء", "Customer records"), onClick = onCustomers)
                GlossyServiceCard(Modifier.weight(1f), R.drawable.staff_qr_3d, appText("QR / قراءة صورة", "QR / Read image"), onClick = onScan)
            }
        }

        item {
            Spacer(Modifier.height(4.dp))
            HorizontalDivider(color = Color(0xFFE2E8F0))
            Spacer(Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    appText("إدارة التطبيق", "App controls"),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color(0xFF475569)
                )
                if (adminUnlocked) {
                    TextButton(
                        onClick = onLockAdmin,
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Icon(Icons.Default.Lock, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(Modifier.width(4.dp))
                        Text(appText("قفل PIN", "Lock PIN"), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                BottomUtilityCard(
                    modifier = Modifier.weight(1f),
                    imageRes = R.drawable.mgr_health_3d,
                    title = appText("الإدارة", "Admin"),
                    locked = !adminUnlocked,
                    accent = Color(0xFFFF6E9D),
                    onClick = onAdmin
                )
                BottomUtilityCard(
                    modifier = Modifier.weight(1f),
                    imageRes = R.drawable.mgr_reports_3d,
                    title = appText("الأسعار\nLab 2 Lab", "Prices\nLab 2 Lab"),
                    locked = !adminUnlocked,
                    accent = Color(0xFFFFC857),
                    onClick = onPrices
                )
                BottomUtilityCard(
                    modifier = Modifier.weight(1f),
                    imageRes = R.drawable.settings_3d,
                    title = appText("الإعدادات العامة", "General Settings"),
                    locked = false,
                    accent = Color(0xFFC07CFF),
                    onClick = onSettings
                )
            }
        }
    }
}

@Composable
private fun BottomUtilityCard(
    modifier: Modifier = Modifier,
    imageRes: Int,
    title: String,
    locked: Boolean,
    accent: Color,
    onClick: () -> Unit
) {
    Card(
        onClick = onClick,
        modifier = modifier
            .height(128.dp)
            .shadow(17.dp, RoundedCornerShape(20.dp), ambientColor = accent.copy(alpha = 0.55f), spotColor = accent.copy(alpha = 0.88f)),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        border = BorderStroke(1.3.dp, accent.copy(alpha = 0.82f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(
                            accent.copy(alpha = 0.22f),
                            Color(0xFF0B1B31),
                            Color(0xFF050C17)
                        )
                    )
                )
        ) {
            Column(
                modifier = Modifier.fillMaxSize().padding(horizontal = 6.dp, vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(58.dp)
                        .shadow(18.dp, RoundedCornerShape(17.dp), ambientColor = accent, spotColor = accent)
                        .clip(RoundedCornerShape(17.dp))
                        .background(accent.copy(alpha = 0.13f))
                        .border(1.dp, accent.copy(alpha = 0.72f), RoundedCornerShape(17.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Image(
                        painter = painterResource(imageRes),
                        contentDescription = null,
                        modifier = Modifier.fillMaxSize().padding(2.dp),
                        contentScale = ContentScale.Fit
                    )
                    if (locked) {
                        Surface(
                            modifier = Modifier.align(Alignment.BottomEnd).size(19.dp),
                            shape = CircleShape,
                            color = Color(0xFF111827),
                            border = BorderStroke(1.dp, Color(0xFFFFD879))
                        ) {
                            Icon(Icons.Default.Lock, contentDescription = null, tint = Color(0xFFFFD879), modifier = Modifier.padding(3.dp))
                        }
                    }
                }
                Spacer(Modifier.height(7.dp))
                Text(
                    title,
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 30.dp),
                    textAlign = TextAlign.Center,
                    fontSize = 10.sp,
                    lineHeight = 14.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color.White,
                    maxLines = 2,
                    softWrap = true,
                    overflow = TextOverflow.Clip
                )
            }
        }
    }
}

@Composable
private fun HomeScanHubDialog(
    onDismiss: () -> Unit,
    onCustomerQr: () -> Unit,
    onTestsDocument: () -> Unit,
    onNavigateSearch: () -> Unit,
    onNavigateQuickImage: () -> Unit,
    onNavigateOrder: () -> Unit,
    onNavigateCustomers: () -> Unit,
    onNavigateCatalog: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                appText("QR / صورة", "QR / Image"),
                fontWeight = FontWeight.ExtraBold
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                DailyServicesNavBar(
                    active = "scan",
                    onCatalog = onNavigateCatalog,
                    onQuickImage = onNavigateQuickImage,
                    onOrder = onNavigateOrder,
                    onCustomers = onNavigateCustomers,
                    onScan = {}
                )
                Text(
                    appText("اختار نوع القراءة المطلوبة", "Choose what you want to read"),
                    color = Color(0xFF64748B),
                    fontSize = 12.sp
                )
                Button(
                    onClick = onCustomerQr,
                    modifier = Modifier.fillMaxWidth().height(50.dp),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF007E89))
                ) {
                    Icon(Icons.Default.QrCodeScanner, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text(appText("مسح QR العميل", "Scan customer QR"), fontWeight = FontWeight.Bold)
                }
                OutlinedButton(
                    onClick = onTestsDocument,
                    modifier = Modifier.fillMaxWidth().height(50.dp),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(Icons.Default.QrCodeScanner, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text(appText("قراءة تحاليل من صورة", "Read tests from image"), fontWeight = FontWeight.Bold)
                }
            }
        },
        confirmButton = {},
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(appText("إلغاء", "Cancel")) }
        }
    )
}


@Composable
private fun TemporaryWorkspaceTopBar(
    title: String,
    icon: ImageVector,
    onBack: () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = Color.White,
        shadowElevation = 4.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier
                    .size(44.dp)
                    .testTag("temporary_workspace_back")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = appText("رجوع", "Back"),
                    tint = Color(0xFF17324D),
                    modifier = Modifier.size(24.dp)
                )
            }

            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFFE7F5F7)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = Color(0xFF007E89),
                    modifier = Modifier.size(21.dp)
                )
            }

            Text(
                text = title,
                modifier = Modifier.weight(1f),
                fontSize = 18.sp,
                lineHeight = 23.sp,
                fontWeight = FontWeight.ExtraBold,
                color = Color(0xFF17324D),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

        }
    }
}

@Composable
private fun FocusedWorkspaceHeader(
    icon: ImageVector,
    title: String,
    subtitle: String,
    accent: Color
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, accent.copy(alpha = 0.18f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 13.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(11.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(accent.copy(alpha = 0.10f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = accent, modifier = Modifier.size(23.dp))
            }
            Column(Modifier.weight(1f)) {
                Text(
                    text = title,
                    fontSize = 19.sp,
                    lineHeight = 25.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color(0xFF17324D)
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    text = subtitle,
                    fontSize = 10.sp,
                    lineHeight = 15.sp,
                    fontWeight = FontWeight.Medium,
                    color = Color(0xFF64748B)
                )
            }
        }
    }
}

@Composable
private fun OrderWorkspaceCustomerBar(
    customer: Customer?,
    onChooseCustomer: () -> Unit,
    onOpenCustomerFiles: () -> Unit,
    onClearCustomer: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, Color(0xFFE3EAF2))
    ) {
        Column(Modifier.fillMaxWidth().padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFE7F5F7)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.People, contentDescription = null, tint = Color(0xFF007E89), modifier = Modifier.size(20.dp))
                }
                Spacer(Modifier.width(9.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        text = appText("بيانات العميل", "Customer"),
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 13.sp,
                        color = Color(0xFF17324D)
                    )
                    Text(
                        text = if (customer == null) {
                            appText("اختار العميل أو افتح سجلات العملاء والـ QR", "Choose a customer or open customer records and QR")
                        } else {
                            appText("العميل مرتبط بالطلب الحالي", "Customer linked to the current order")
                        },
                        fontSize = 10.sp,
                        lineHeight = 14.sp,
                        color = Color(0xFF64748B)
                    )
                }
                if (customer != null) {
                    IconButton(onClick = onClearCustomer, modifier = Modifier.size(36.dp)) {
                        Icon(Icons.Default.Close, contentDescription = appText("إلغاء ربط العميل", "Unlink customer"), tint = Color(0xFF64748B))
                    }
                }
            }

            if (customer != null) {
                Spacer(Modifier.height(8.dp))
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    color = Color(0xFFF4FAFB)
                ) {
                    Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 9.dp)) {
                        Text(customer.name, fontWeight = FontWeight.ExtraBold, color = Color(0xFF17324D))
                        Text(
                            text = listOf(customer.fileNumber, customer.phone).filter { it.isNotBlank() }.joinToString(" • "),
                            fontSize = 10.sp,
                            color = Color(0xFF64748B)
                        )
                    }
                }
            }

            Spacer(Modifier.height(9.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = onChooseCustomer,
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(13.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF007E89))
                ) {
                    Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(
                        text = if (customer == null) appText("اختيار عميل", "Choose customer") else appText("تغيير العميل", "Change customer"),
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp
                    )
                }
                OutlinedButton(
                    onClick = onOpenCustomerFiles,
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(13.dp),
                    border = BorderStroke(1.dp, Color(0xFFB8DDE1))
                ) {
                    Icon(Icons.Default.People, contentDescription = null, tint = Color(0xFF007E89), modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(appText("السجلات و QR", "Records & QR"), color = Color(0xFF007E89), fontWeight = FontWeight.Bold, fontSize = 11.sp)
                }
            }
        }
    }
}

@Composable
private fun WorkspaceMoreSection(
    currentMode: String,
    showManagerActions: Boolean,
    onOrder: () -> Unit,
    onPrice: () -> Unit,
    onCustomers: () -> Unit,
    onCatalog: () -> Unit,
    onSettings: () -> Unit,
    onAdmin: () -> Unit
) {
    var expanded by remember(currentMode) { mutableStateOf(false) }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFF8FAFC)),
        border = BorderStroke(1.dp, Color(0xFFE2E8F0))
    ) {
        Column(Modifier.fillMaxWidth().padding(10.dp)) {
            TextButton(
                onClick = { expanded = !expanded },
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.Tune, contentDescription = null, tint = Color(0xFF475569))
                Spacer(Modifier.width(8.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        text = appText("المزيد", "More"),
                        fontWeight = FontWeight.ExtraBold,
                        color = Color(0xFF334155),
                        textAlign = TextAlign.Start,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text(
                        text = appText("المهام اللي مش بتستخدمها دلوقتي", "Tasks you are not using right now"),
                        fontSize = 9.sp,
                        color = Color(0xFF94A3B8),
                        textAlign = TextAlign.Start,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                Text(
                    text = if (expanded) appText("إخفاء", "Hide") else appText("عرض", "Show"),
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF64748B)
                )
            }

            AnimatedVisibility(visible = expanded) {
                Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    if (currentMode != "order") {
                        WorkspaceMoreButton(Icons.Default.AddCircle, appText("طلب جديد", "New order"), onOrder)
                    }
                    if (currentMode != "price_search") {
                        WorkspaceMoreButton(Icons.Default.Search, appText("استعلام أسعار التحاليل", "Test price inquiry"), onPrice)
                    }
                    WorkspaceMoreButton(Icons.Default.People, appText("سجلات العملاء والـ QR", "Customer records & QR"), onClick = onCustomers)
                    if (currentMode != "catalog") {
                        WorkspaceMoreButton(Icons.Outlined.Biotech, appText("التحاليل المتاحة", "Available tests"), onCatalog)
                    }
                    WorkspaceMoreButton(Icons.Default.Settings, appText("الإعدادات", "Settings"), onClick = onSettings)

                    if (showManagerActions) {
                        WorkspaceMoreButton(Icons.Default.AdminPanelSettings, appText("خدمات الإدارة 🔒", "Administration 🔒"), onAdmin)
                    }
                }
            }
        }
    }
}

@Composable
private fun WorkspaceMoreButton(
    icon: ImageVector,
    title: String,
    onClick: () -> Unit
) {
    val accent = when (icon) {
        Icons.Default.AddCircle -> Color(0xFF25F0A7)
        Icons.Default.Search -> Color(0xFF00E5FF)
        Icons.Default.People -> Color(0xFF4DA3FF)
        Icons.Default.Settings -> Color(0xFFC07CFF)
        Icons.Default.AdminPanelSettings -> Color(0xFFFF6E9D)
        else -> Color(0xFFFFB23E)
    }
    Card(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .shadow(11.dp, RoundedCornerShape(16.dp), ambientColor = accent.copy(alpha = 0.36f), spotColor = accent.copy(alpha = 0.62f)),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF071424)),
        border = BorderStroke(1.dp, accent.copy(alpha = 0.62f))
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 11.dp, vertical = 9.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .shadow(10.dp, RoundedCornerShape(12.dp), ambientColor = accent, spotColor = accent)
                    .clip(RoundedCornerShape(12.dp))
                    .background(accent.copy(alpha = 0.18f))
                    .border(1.dp, accent.copy(alpha = 0.72f), RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(20.dp))
            }
            Spacer(Modifier.width(9.dp))
            Text(
                text = title,
                modifier = Modifier.weight(1f),
                textAlign = TextAlign.Start,
                color = Color.White,
                fontWeight = FontWeight.ExtraBold,
                fontSize = 11.sp
            )
        }
    }
}

@Composable
private fun AvailableTestsScreen(
    viewModel: LabTestsViewModel,
    isManager: Boolean,
    customerPriceOverrides: Map<Int, String>,
    lab2LabPrices: Map<Int, String>,
    onEditPrices: (LabTest) -> Unit,
    bottomContent: (@Composable () -> Unit)? = null
) {
    var query by remember { mutableStateOf("") }
    val tests = remember(query) { viewModel.searchManagerTests(query) }

    Column(modifier = Modifier.fillMaxSize()) {
        Text(
            text = appText("كتالوج التحاليل والأسعار", "Test catalog & prices"),
            fontSize = 20.sp,
            lineHeight = 26.sp,
            fontWeight = FontWeight.ExtraBold,
            color = Color(0xFF17324D)
        )
        Text(
            text = appText(
                "ابحث عن التحليل، شوف سعره وافتح دليل التحليل من المزيد",
                "Search a test, view its price and open its guide from More"
            ),
            fontSize = 11.sp,
            lineHeight = 16.sp,
            color = Color(0xFF64748B)
        )

        Spacer(Modifier.height(12.dp))

        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            modifier = Modifier.fillMaxWidth().heightIn(min = 64.dp),
            singleLine = true,
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            placeholder = { Text(appText("ابحث باسم التحليل", "Search test name")) },
            shape = RoundedCornerShape(16.dp)
        )

        Spacer(Modifier.height(10.dp))

        Text(
            text = appText("عدد التحاليل: ${tests.size}", "Tests: ${tests.size}"),
            fontSize = 11.sp,
            lineHeight = 16.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF475569)
        )

        Spacer(Modifier.height(8.dp))

        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(bottom = 18.dp)
        ) {
            items(tests, key = { it.id }) { test ->
                AvailableTestPriceCard(
                    test = test,
                    customerPrice = customerPriceOverrides[test.id] ?: test.customerPrice,
                    lab2LabPrice = lab2LabPrices[test.id],
                    isManager = isManager,
                    onEditPrices = { onEditPrices(test) }
                )
            }

            if (bottomContent != null) {
                item(key = "catalog_workspace_more") {
                    Spacer(Modifier.height(8.dp))
                    bottomContent()
                }
            }
        }
    }
}

@Composable
private fun AvailableTestPriceCard(
    test: LabTest,
    customerPrice: String?,
    lab2LabPrice: String?,
    isManager: Boolean,
    onEditPrices: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(
                elevation = 3.dp,
                shape = RoundedCornerShape(18.dp),
                spotColor = Color(0x12000000)
            ),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, Color(0xFFE7ECF2))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.Top,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFFE7F5F7)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Outlined.Biotech,
                        contentDescription = null,
                        tint = Color(0xFF007E89)
                    )
                }

                Column(Modifier.weight(1f)) {
                    Text(
                        text = test.englishName,
                        fontSize = 14.sp,
                        lineHeight = 19.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color(0xFF17324D),
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (test.arabicName.isNotBlank()) {
                        Spacer(Modifier.height(2.dp))
                        Text(
                            text = test.arabicName,
                            fontSize = 12.sp,
                            lineHeight = 17.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFF475569),
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    if (
                        test.marketName.isNotBlank() &&
                        test.marketName != test.arabicName &&
                        test.marketName != test.englishName
                    ) {
                        Spacer(Modifier.height(3.dp))
                        Text(
                            text = appText(
                                "الاسم الدارج: ${test.marketName}",
                                "Market name: ${test.marketName}"
                            ),
                            fontSize = 10.sp,
                            lineHeight = 15.sp,
                            color = Color(0xFF64748B),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            Spacer(Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                PriceBox(
                    modifier = Modifier.weight(1f),
                    title = appText("سعر العميل", "Customer price"),
                    price = customerPrice,
                    backgroundColor = Color(0xFFEDF7FF),
                    borderColor = Color(0xFFCFE8F7),
                    titleColor = Color(0xFF28607E),
                    priceColor = Color(0xFF114D6B)
                )

            }


            Spacer(Modifier.height(10.dp))
            TestGuideMoreButton(
                test = test,
                modifier = Modifier.testTag("catalog_test_guide_${test.id}")
            )
        }
    }
}

@Composable
private fun ActingAsUserBanner(
    profile: AppUserProfile,
    onReturnToManager: () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        color = Color(0xFFFFF7ED),
        border = BorderStroke(1.dp, Color(0xFFF59E0B).copy(alpha = 0.45f))
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Box(
                modifier = Modifier.size(36.dp).clip(CircleShape).background(Color(0xFFFFEDD5)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.People, contentDescription = null, tint = Color(0xFFC2410C), modifier = Modifier.size(19.dp))
            }
            Column(Modifier.weight(1f)) {
                Text(
                    text = "تعمل الآن بصلاحيات ${profile.displayName.ifBlank { profile.email }}",
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 12.sp,
                    color = Color(0xFF9A3412),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = "الحساب الفعلي: Abdelrahman",
                    fontSize = 9.sp,
                    color = Color(0xFF7C2D12)
                )
            }
            TextButton(onClick = onReturnToManager) {
                Text(appText("رجوع لـ Abdelrahman", "Back to Abdelrahman"), fontSize = 10.sp, fontWeight = FontWeight.ExtraBold)
            }
        }
    }
}

@Composable
private fun UserSwitcherDialog(
    viewModel: LabTestsViewModel,
    onDismiss: () -> Unit,
    onUserSelected: (AppUserProfile) -> Unit
) {
    val users by viewModel.users.collectAsState()
    var query by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(true) }
    var message by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        viewModel.loadUsers { success, result ->
            loading = false
            if (!success) message = result
        }
    }

    val filtered = remember(users, query) {
        val q = query.trim().lowercase()
        users.filter {
            it.enabled &&
                !LabTestsViewModel.isManagerAccount(it.email, it.uid) &&
                (q.isBlank() || it.displayName.lowercase().contains(q) || it.email.lowercase().contains(q))
        }
    }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(
            modifier = Modifier.fillMaxWidth(0.92f).height(560.dp),
            shape = RoundedCornerShape(24.dp),
            color = Color(0xFFF8FAFC),
            shadowElevation = 8.dp
        ) {
            Column(Modifier.fillMaxSize().padding(16.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(appText("تبديل المستخدم", "Switch user"), fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF17324D))
                        Text(appText("اختر مستخدمًا لتجربة واستخدام صلاحياته", "Choose a user to operate with their permissions"), fontSize = 11.sp, color = Color(0xFF64748B))
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = tr("إغلاق", "Close"))
                    }
                }

                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 72.dp),
                    singleLine = true,
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    placeholder = { Text(appText("ابحث بالاسم أو البريد", "Search by name or email")) },
                    shape = RoundedCornerShape(15.dp)
                )
                Spacer(Modifier.height(10.dp))

                when {
                    loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator()
                    }
                    message != null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text(message.orEmpty(), color = Color(0xFFB91C1C), fontWeight = FontWeight.Bold)
                    }
                    filtered.isEmpty() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text(appText("لا يوجد مستخدمون نشطون", "No active users"), color = Color(0xFF64748B))
                    }
                    else -> LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        contentPadding = PaddingValues(bottom = 12.dp)
                    ) {
                        items(filtered, key = { it.uid }) { profile ->
                            Card(
                                onClick = { onUserSelected(profile) },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = Color.White),
                                border = BorderStroke(1.dp, Color(0xFFE5EAF0))
                            ) {
                                Row(
                                    Modifier.fillMaxWidth().padding(13.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Box(
                                        Modifier.size(42.dp).clip(CircleShape).background(Color(0xFFE7F5F7)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(Icons.Default.People, contentDescription = null, tint = Color(0xFF006D86))
                                    }
                                    Column(Modifier.weight(1f)) {
                                        Text(profile.displayName.ifBlank { profile.email }, fontWeight = FontWeight.ExtraBold, color = Color(0xFF17324D))
                                        Text(profile.email, fontSize = 10.sp, color = Color(0xFF64748B), maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    }
                                    Text(appText(tr("دخول", "Sign In"), "Open"), color = Color(0xFF006D86), fontWeight = FontWeight.ExtraBold, fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ManagerStatChip(
    modifier: Modifier = Modifier,
    label: String,
    value: String
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        color = Color.White,
        shadowElevation = 1.dp,
        border = BorderStroke(1.dp, Color(0xFFE5EAF0))
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = value,
                fontWeight = FontWeight.ExtraBold,
                fontSize = 15.sp,
                color = Color(0xFF17324D),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(3.dp))
            Text(
                text = label,
                fontSize = 9.sp,
                lineHeight = 14.sp,
                fontWeight = FontWeight.Medium,
                color = Color(0xFF64748B),
                maxLines = 1
            )
        }
    }
}

@Composable
private fun ManagerHomeActionCard(
    modifier: Modifier = Modifier,
    icon: ImageVector,
    title: String,
    subtitle: String,
    accent: Color,
    onClick: () -> Unit
) {
    Card(
        onClick = onClick,
        modifier = modifier.heightIn(min = 148.dp),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
        border = BorderStroke(1.dp, Color(0xFFE7ECF2))
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 16.dp)
        ) {
            ManagerActionIcon(
                icon = icon,
                accent = accent
            )
            Spacer(Modifier.height(12.dp))
            Text(
                text = title,
                fontSize = 16.sp,
                lineHeight = 22.sp,
                fontWeight = FontWeight.ExtraBold,
                color = Color(0xFF17324D),
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(3.dp))
            Text(
                text = subtitle,
                fontSize = 11.sp,
                lineHeight = 16.sp,
                fontWeight = FontWeight.Medium,
                color = Color(0xFF64748B),
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun ManagerActionIcon(
    icon: ImageVector,
    accent: Color
) {
    Box(
        modifier = Modifier
            .size(46.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(accent.copy(alpha = 0.11f)),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = accent,
            modifier = Modifier.size(25.dp)
        )
    }
}

@Composable
private fun ManagerDashboardCard(onClick: () -> Unit) {
    Card(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .shadow(
                elevation = 3.dp,
                shape = RoundedCornerShape(18.dp),
                spotColor = Color(0x12000000)
            ),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFF5F3FF)),
        border = BorderStroke(1.dp, Color(0xFFDDD6FE))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFFEDE9FE)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Tune,
                    contentDescription = null,
                    tint = Color(0xFF6D28D9),
                    modifier = Modifier.size(21.dp)
                )
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = tr("لوحة تحكم المدير", "Manager Dashboard"),
                    fontSize = 15.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color(0xFF4C1D95)
                )
                Text(
                    text = tr("اضغط لإدارة أسعار جميع التحاليل", "Manage all test prices"),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium,
                    color = Color(0xFF6B5A8E)
                )
            }
            Icon(
                imageVector = Icons.Default.Edit,
                contentDescription = tr("فتح لوحة المدير", "Open Manager Dashboard"),
                tint = Color(0xFF6D28D9),
                modifier = Modifier.size(20.dp)
            )
        }
    }
}

@Composable
private fun ManagerDashboardDialog(
    viewModel: LabTestsViewModel,
    customerPriceOverrides: Map<Int, String>,
    lab2LabPrices: Map<Int, String>,
    onDismiss: () -> Unit,
    onEdit: (LabTest) -> Unit
) {
    var managerQuery by remember { mutableStateOf("") }
    val tests = remember(managerQuery) { viewModel.searchManagerTests(managerQuery) }

    BackHandler(enabled = true) { onDismiss() }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false, dismissOnBackPress = true)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp),
            shape = RoundedCornerShape(24.dp),
            color = Color(0xFFF7F8FC),
            shadowElevation = 8.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = tr("لوحة تحكم المدير", "Manager Dashboard"),
                            fontSize = 21.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFF3B176B)
                        )
                        Text(
                            text = tr("إدارة سعر العميل و Lab 2 Lab", "Manage Customer & Lab2Lab Prices"),
                            fontSize = 12.sp,
                            color = Color(0xFF6B5A8E)
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = tr("إغلاق", "Close"),
                            tint = Color(0xFF4C1D95)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = managerQuery,
                    onValueChange = { managerQuery = it },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 72.dp),
                    singleLine = true,
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = null
                        )
                    },
                    placeholder = { Text(appText("ابحث باسم التحليل عربي أو إنجليزي", "Search test by Arabic or English name")) },
                    shape = RoundedCornerShape(16.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color(0xFF6D28D9),
                        cursorColor = Color(0xFF6D28D9),
                        focusedContainerColor = Color.White,
                        unfocusedContainerColor = Color.White
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = tr("التحاليل: ${tests.size}", "Tests: ${tests.size}"),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF475569)
                    )
                    Text(
                        text = tr("الأسعار المعدلة: ${customerPriceOverrides.size}", "Modified prices: ${customerPriceOverrides.size}"),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF6D28D9)
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(9.dp),
                    contentPadding = PaddingValues(bottom = 12.dp)
                ) {
                    items(tests, key = { it.id }) { test ->
                        val customer = customerPriceOverrides[test.id] ?: test.customerPrice ?: "—"
                        val lab = lab2LabPrices[test.id] ?: "—"

                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            border = BorderStroke(1.dp, Color(0xFFE7E8EF))
                        ) {
                            Column(modifier = Modifier.padding(13.dp)) {
                                Text(
                                    text = test.englishName,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = Color(0xFF17324D),
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                                if (test.arabicName.isNotBlank()) {
                                    Text(
                                        text = test.arabicName,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = Color(0xFF64748B),
                                        maxLines = 2,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }

                                Spacer(modifier = Modifier.height(9.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(
                                            text = "سعر العميل: $customer ج",
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFF007C88)
                                        )
                                        Text(
                                            text = "Lab 2 Lab: $lab ج",
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFF6D28D9)
                                        )
                                    }
                                    Button(
                                        onClick = { onEdit(test) },
                                        shape = RoundedCornerShape(12.dp),
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = Color(0xFF6D28D9)
                                        )
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Edit,
                                            contentDescription = null,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(5.dp))
                                        Text(appText(tr("تعديل", "Edit"), "Edit"))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ManagerPriceEditorDialog(
    test: LabTest,
    customerPrice: String,
    lab2LabPrice: String,
    onDismiss: () -> Unit,
    onSave: (String, String, (Boolean, String) -> Unit) -> Unit
) {
    var customerText by remember(test.id, customerPrice) { mutableStateOf(customerPrice) }
    var labText by remember(test.id, lab2LabPrice) { mutableStateOf(lab2LabPrice) }
    var saving by remember(test.id) { mutableStateOf(false) }
    var message by remember(test.id) { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = { if (!saving) onDismiss() },
        title = {
            Column {
                Text(
                    text = tr("تعديل الأسعار", "Edit Prices"),
                    fontWeight = FontWeight.ExtraBold,
                    color = Color(0xFF102A43)
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = test.englishName,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color(0xFF52667A)
                )
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = customerText,
                    onValueChange = { customerText = it.filter { ch -> ch.isDigit() || ch == '.' } },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 72.dp),
                    label = { Text(appText(tr("سعر العميل", "Customer Price"), "Customer price")) },
                    suffix = { Text(appText(tr("جنيه", "EGP"), "EGP")) },
                    singleLine = true,
                    enabled = !saving,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    shape = RoundedCornerShape(14.dp)
                )
                OutlinedTextField(
                    value = labText,
                    onValueChange = { labText = it.filter { ch -> ch.isDigit() || ch == '.' } },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 72.dp),
                    label = { Text(appText("سعر Lab 2 Lab", "Lab 2 Lab price")) },
                    suffix = { Text(appText(tr("جنيه", "EGP"), "EGP")) },
                    singleLine = true,
                    enabled = !saving,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    shape = RoundedCornerShape(14.dp)
                )
                message?.let {
                    Text(
                        text = it,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFFB42318)
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    saving = true
                    message = null
                    onSave(customerText, labText) { success, resultMessage ->
                        saving = false
                        if (!success) message = resultMessage
                    }
                },
                enabled = !saving && customerText.isNotBlank() && labText.isNotBlank(),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6D28D9))
            ) {
                if (saving) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(18.dp),
                        strokeWidth = 2.dp,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                }
                Text(appText("حفظ الأسعار", "Save prices"), fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss, enabled = !saving) {
                Text(appText(tr("إلغاء", "Cancel"), "Cancel"))
            }
        },
        shape = RoundedCornerShape(22.dp),
        containerColor = Color.White
    )
}

@Composable
private fun SearchBox(
    query: String,
    onQueryChange: (String) -> Unit,
    onClear: () -> Unit,
    onImportDocument: (() -> Unit)? = null,
    importingDocument: Boolean = false
) {
    val keyboardController = LocalSoftwareKeyboardController.current

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(
                elevation = 6.dp,
                shape = RoundedCornerShape(24.dp),
                spotColor = Color(0x16000000)
            ),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, Color(0xFFE4ECF4))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .clip(RoundedCornerShape(11.dp))
                        .background(Color(0xFFE7F5F7)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = null,
                        tint = Color(0xFF007B87),
                        modifier = Modifier.size(20.dp)
                    )
                }
                Spacer(modifier = Modifier.width(9.dp))
                Column {
                    Text(
                        text = appText("ابحث عن التحليل", "Search for a test"),
                        fontSize = 16.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color(0xFF102A43)
                    )
                    Text(
                        text = appText("عربي • English • الاسم الدارج", "Arabic • English • Market name"),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        color = Color(0xFF718096)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
                value = query,
                onValueChange = onQueryChange,
                enabled = true,
                readOnly = false,
                modifier = Modifier
                    .fillMaxWidth().heightIn(min = 72.dp)
                    .testTag("search_text_field"),
                placeholder = {
                    Text(
                        text = appText("مثال: CBC أو صورة دم كاملة", "Example: CBC or Complete Blood Count"),
                        color = Color(0xFF98A6B8),
                        fontSize = 14.sp
                    )
                },
                trailingIcon = {
                    if (query.isNotEmpty()) {
                        IconButton(
                            onClick = onClear,
                            modifier = Modifier.testTag("clear_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = appText("مسح البحث", "Clear search"),
                                tint = Color(0xFF64748B)
                            )
                        }
                    }
                },
                singleLine = false,
                minLines = 1,
                maxLines = 4,
                shape = RoundedCornerShape(16.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = Color(0xFFF7FAFC),
                    unfocusedContainerColor = Color(0xFFF7FAFC),
                    disabledContainerColor = Color(0xFFF7FAFC),
                    focusedBorderColor = Color(0xFF008B95),
                    unfocusedBorderColor = Color(0xFFDCE5EE),
                    focusedTextColor = Color(0xFF102A43),
                    unfocusedTextColor = Color(0xFF102A43)
                ),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Default),
                keyboardActions = KeyboardActions(onSearch = { keyboardController?.hide() })
            )

            if (query.isBlank()) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = tr("يمكنك كتابة أكثر من تحليل؛ كل تحليل في سطر أو افصل بينهم بفاصلة.", "You can enter multiple tests, one per line or separated by commas."),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium,
                    color = Color(0xFF7B8794),
                    lineHeight = 16.sp
                )
            }

            if (onImportDocument != null) {
                Spacer(modifier = Modifier.height(10.dp))
                Card(
                    onClick = onImportDocument,
                    enabled = !importingDocument,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFF2FAFB)),
                    border = BorderStroke(1.dp, Color(0xFFB8DDE1))
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(RoundedCornerShape(15.dp))
                                .background(Color(0xFFDDF3F5)),
                            contentAlignment = Alignment.Center
                        ) {
                            if (importingDocument) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(24.dp),
                                    strokeWidth = 2.dp,
                                    color = Color(0xFF007B87)
                                )
                            } else {
                                Icon(
                                    imageVector = Icons.Default.QrCodeScanner,
                                    contentDescription = null,
                                    tint = Color(0xFF007B87),
                                    modifier = Modifier.size(28.dp)
                                )
                                Box(
                                    modifier = Modifier
                                        .align(Alignment.BottomEnd)
                                        .size(19.dp)
                                        .clip(CircleShape)
                                        .background(Color(0xFF007B87)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Search,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(11.dp)
                                    )
                                }
                            }
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                text = if (importingDocument)
                                    tr("جاري قراءة التحاليل...", "Reading tests...")
                                else
                                    tr("قراءة التحاليل من صورة", "Read tests from image"),
                                fontWeight = FontWeight.ExtraBold,
                                color = Color(0xFF006D77),
                                fontSize = 12.sp
                            )
                            Text(
                                text = tr(
                                    "اختار الملف والتطبيق يستخرج أسماء التحاليل للمراجعة",
                                    "Choose a file and review the detected test names"
                                ),
                                fontSize = 9.sp,
                                color = Color(0xFF64748B),
                                lineHeight = 13.sp
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ResultCountChip(count: Int) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.Start,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .clip(CircleShape)
                .background(Color(0xFFE1F1FF))
                .padding(horizontal = 14.dp, vertical = 6.dp)
        ) {
            Text(
                text = "$count نتائج",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF0061A4)
            )
        }
    }
}

private fun calculatePriceTotal(tests: List<LabTest>, priceSelector: (LabTest) -> String?): Double {
    var total = 0.0
    val regex = Regex("""\d+(\.\d+)?""")
    for (test in tests) {
        val priceStr = priceSelector(test)
        if (!priceStr.isNullOrBlank()) {
            val match = regex.find(priceStr)
            val valDouble = match?.value?.toDoubleOrNull()
            if (valDouble != null) {
                total += valDouble
            }
        }
    }
    return total
}

private fun formatTotalDisplay(total: Double): String {
    return if (total % 1.0 == 0.0) {
        total.toLong().toString()
    } else {
        String.format("%.2f", total)
    }
}


@Composable
private fun PriceInquirySummaryCard(
    tests: List<LabTest>,
    customerPriceOverrides: Map<Int, String>,
    requestedCount: Int,
    unmatchedCount: Int,
    onAddAllToOrder: (List<LabTest>) -> Unit,
    onStartCustomer: (List<LabTest>) -> Unit,
    onStartOutput: (List<LabTest>) -> Unit
) {
    val total = calculatePriceTotal(tests) { test ->
        customerPriceOverrides[test.id] ?: test.customerPrice
    }
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        color = Color(0xFFE9F8F7),
        border = BorderStroke(1.dp, Color(0xFFB9E2DF))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = tr("إجمالي التحاليل", "Tests total"),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF356B68)
                    )
                    Spacer(modifier = Modifier.height(3.dp))
                    Text(
                        text = tr(
                            "${tests.size} من $requestedCount تحليل",
                            "${tests.size} of $requestedCount tests"
                        ),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        color = if (unmatchedCount == 0) Color(0xFF527A77) else Color(0xFF9A3412)
                    )
                }
                Text(
                    text = "${formatTotalDisplay(total)} ${tr("جنيه", "EGP")}",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color(0xFF006B67)
                )
            }

            HorizontalDivider(color = Color(0xFFB9E2DF))

            Button(
                onClick = { onAddAllToOrder(tests) },
                enabled = tests.isNotEmpty(),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(46.dp)
                    .testTag("price_results_add_all"),
                shape = RoundedCornerShape(13.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF007E89))
            ) {
                Icon(Icons.Default.AddCircle, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(7.dp))
                Text(
                    tr("إضافة الكل للقائمة (${tests.size})", "Add all to list (${tests.size})"),
                    fontWeight = FontWeight.ExtraBold
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = { onStartCustomer(tests) },
                    enabled = tests.isNotEmpty(),
                    modifier = Modifier
                        .weight(1f)
                        .height(44.dp)
                        .testTag("price_results_customer"),
                    shape = RoundedCornerShape(13.dp),
                    border = BorderStroke(1.dp, Color(0xFF7AB7B5))
                ) {
                    Icon(Icons.Default.People, contentDescription = null, modifier = Modifier.size(17.dp))
                    Spacer(Modifier.width(5.dp))
                    Text(tr("ربط بعميل", "Customer"), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }

                OutlinedButton(
                    onClick = { onStartOutput(tests) },
                    enabled = tests.isNotEmpty(),
                    modifier = Modifier
                        .weight(1f)
                        .height(44.dp)
                        .testTag("price_results_output"),
                    shape = RoundedCornerShape(13.dp),
                    border = BorderStroke(1.dp, Color(0xFF7AB7B5))
                ) {
                    Icon(Icons.Default.QrCodeScanner, contentDescription = null, modifier = Modifier.size(17.dp))
                    Spacer(Modifier.width(5.dp))
                    Text(tr("استخراج صورة", "Create image"), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }

            Text(
                text = tr(
                    "اختار العميل ثم احفظ الطلب، وبعدها استخرج صورة العميل أو صورة طلب المعمل مباشرة.",
                    "Choose the customer, save the order, then create the customer or lab image directly."
                ),
                fontSize = 10.sp,
                lineHeight = 14.sp,
                color = Color(0xFF5D7472)
            )
        }
    }
}

@Composable
private fun MainContent(
    modifier: Modifier = Modifier,
    topContent: (@Composable () -> Unit)? = null,
    uiState: SearchUiState,
    selectedTests: List<LabTest>,
    recognizedTests: List<LabTest>,
    isManager: Boolean,
    lab2LabPrices: Map<Int, String>,
    customerPriceOverrides: Map<Int, String>,
    activeOrderCustomer: Customer?,
    onChooseCustomer: () -> Unit,
    onClearCustomer: () -> Unit,
    onSaveCustomerOrder: () -> Unit,
    onSelectTest: (LabTest) -> Unit,
    onRemoveTest: (Int) -> Unit,
    onAddAllRecognized: () -> Unit,
    onEditPrices: (LabTest) -> Unit,
    onAddPriceResultsToOrder: (List<LabTest>) -> Unit = {},
    onStartPriceResultsCustomer: (List<LabTest>) -> Unit = {},
    onStartPriceResultsOutput: (List<LabTest>) -> Unit = {},
    allowOrderSelection: Boolean = true,
    showResolvedBatchAction: Boolean = false,
    selectedTestsContent: (@Composable (List<LabTest>) -> Unit)? = null,
    bottomContent: (@Composable () -> Unit)? = null
) {
    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(16.dp),
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 28.dp)
    ) {
        if (topContent != null) {
            item(key = "workspace_top_content") {
                topContent()
            }
        }

        // 1. Selected Tests Section (tr("التحاليل المختارة", "Selected Tests"))
        if (allowOrderSelection && selectedTests.isNotEmpty()) {
            item(key = "selected_tests_section") {
                if (selectedTestsContent != null) {
                    selectedTestsContent(selectedTests)
                } else {
                    SelectedTestsSection(
                        selectedTests = selectedTests,
                        isManager = isManager,
                        lab2LabPrices = lab2LabPrices,
                        customerPriceOverrides = customerPriceOverrides,
                        activeOrderCustomer = activeOrderCustomer,
                        onChooseCustomer = onChooseCustomer,
                        onClearCustomer = onClearCustomer,
                        onSaveCustomerOrder = onSaveCustomerOrder,
                        onRemoveTest = onRemoveTest
                    )
                }
            }
        }

        // 2. Imported image batch actions.
        val selectedIds = selectedTests.map { it.id }.toSet()
        val selectedRecognizedCount = recognizedTests.count { it.id in selectedIds }
        val remainingRecognizedCount = recognizedTests.size - selectedRecognizedCount
        if (allowOrderSelection && remainingRecognizedCount > 0) {
            item(key = "recognized_tests_actions") {
                RecognizedTestsActionsCard(
                    totalDetected = recognizedTests.size,
                    selectedDetected = selectedRecognizedCount,
                    remainingDetected = remainingRecognizedCount,
                    onAddAll = onAddAllRecognized
                )
            }
        }

        // 3. Search States
        when (uiState) {
            is SearchUiState.EmptyQuery -> {
                if (!allowOrderSelection || selectedTests.isEmpty()) {
                    item(key = "empty_state") {
                        EmptyStateView()
                    }
                }
            }
            is SearchUiState.NoResults -> {
                item(key = "no_results_section") {
                    NoResultsSection(unmatchedQueries = uiState.unmatchedQueries)
                }
            }
            is SearchUiState.Success -> {
                item(key = "search_header") {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = tr("نتائج البحث", "Search Results"),
                            fontSize = 17.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFF17324D)
                        )
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .background(Color(0xFFE7F5F7))
                                .padding(horizontal = 10.dp, vertical = 5.dp)
                        ) {
                            Text(
                                text = "${uiState.queryGroups.sumOf { it.candidates.size }} نتيجة",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF007B87)
                            )
                        }
                    }
                }

                if (allowOrderSelection && showResolvedBatchAction) {
                    val resolvedSelectionTests = uiState.queryGroups
                        .mapNotNull { it.candidates.singleOrNull() }
                        .distinctBy { it.id }
                    if (resolvedSelectionTests.size > 1) {
                        item(key = "selection_batch_add_all") {
                            Button(
                                onClick = { onAddPriceResultsToOrder(resolvedSelectionTests) },
                                modifier = Modifier.fillMaxWidth().height(48.dp),
                                shape = RoundedCornerShape(14.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF007E89))
                            ) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(7.dp))
                                Text(
                                    appText("إضافة كل النتائج (${resolvedSelectionTests.size})", "Add all results (${resolvedSelectionTests.size})"),
                                    fontWeight = FontWeight.ExtraBold
                                )
                            }
                        }
                    }
                }

                if (!allowOrderSelection) {
                    val resolvedPriceTests = uiState.queryGroups
                        .mapNotNull { it.candidates.singleOrNull() }
                        .distinctBy { it.id }
                    if (resolvedPriceTests.isNotEmpty()) {
                        item(key = "price_inquiry_summary") {
                            PriceInquirySummaryCard(
                                tests = resolvedPriceTests,
                                customerPriceOverrides = customerPriceOverrides,
                                requestedCount = uiState.queryGroups.size + uiState.unmatchedQueries.size,
                                unmatchedCount = uiState.unmatchedQueries.size,
                                onAddAllToOrder = onAddPriceResultsToOrder,
                                onStartCustomer = onStartPriceResultsCustomer,
                                onStartOutput = onStartPriceResultsOutput
                            )
                        }
                    }
                }

                items(uiState.queryGroups, key = { it.query }) { group ->
                    QueryGroupSection(
                        group = group,
                        isManager = isManager,
                        lab2LabPrices = lab2LabPrices,
                        customerPriceOverrides = customerPriceOverrides,
                        onSelectTest = onSelectTest,
                        onEditPrices = onEditPrices,
                        allowSelection = allowOrderSelection
                    )
                }

                if (uiState.unmatchedQueries.isNotEmpty()) {
                    item(key = "unmatched_queries") {
                        UnmatchedQueriesCard(unmatchedQueries = uiState.unmatchedQueries)
                    }
                }
            }
        }

        if (bottomContent != null) {
            item(key = "workspace_more") {
                bottomContent()
            }
        }

        item(key = "bottom_spacer") {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
private fun QuickImageSelectedSection(
    selectedTests: List<LabTest>,
    customerPriceOverrides: Map<Int, String>,
    onRemoveTest: (Int) -> Unit
) {
    val context = LocalContext.current
    val totalPrice = calculatePriceTotal(selectedTests) { customerPriceOverrides[it.id] ?: it.customerPrice }
    var showOptionalCustomer by remember { mutableStateOf(false) }
    var customerName by remember { mutableStateOf("") }
    var customerPhone by remember { mutableStateOf("") }
    var busyAction by remember { mutableStateOf<String?>(null) }
    var pendingLegacySave by remember { mutableStateOf(false) }

    fun buildImage() = PdfGenerator.generateQuickTestsImage(
        context = context,
        selectedTests = selectedTests,
        customerPriceOverrides = customerPriceOverrides,
        customerName = customerName.trim(),
        customerPhone = customerPhone.trim()
    )

    fun saveNow() {
        if (busyAction != null) return
        busyAction = "save"
        try {
            val file = buildImage()
            if (file != null) {
                PdfGenerator.saveGeneratedImageToGallery(
                    context = context,
                    file = file,
                    displayName = "Tahalil_Alakkad_Quick_${System.currentTimeMillis()}.png"
                )
            }
        } finally {
            busyAction = null
        }
    }

    val legacyPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        val shouldSave = pendingLegacySave
        pendingLegacySave = false
        if (granted && shouldSave) saveNow()
    }

    fun requestSave() {
        val needsPermission = Build.VERSION.SDK_INT <= Build.VERSION_CODES.P &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
        if (needsPermission) {
            pendingLegacySave = true
            legacyPermissionLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        } else {
            saveNow()
        }
    }

    fun shareNow() {
        if (busyAction != null) return
        busyAction = "share"
        try {
            val file = buildImage()
            if (file != null) {
                PdfGenerator.shareGeneratedImage(
                    context = context,
                    file = file,
                    subject = "تحاليل العقاد - قائمة تحاليل وأسعار",
                    chooserTitle = "مشاركة الصورة السريعة"
                )
            }
        } finally {
            busyAction = null
        }
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(12.dp, RoundedCornerShape(24.dp), spotColor = Color(0x6600E7F2)),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.5.dp, Color(0xFF32D7E4))
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(15.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .background(
                        Brush.linearGradient(
                            listOf(Color(0xFF062638), Color(0xFF0A5162), Color(0xFF007F91))
                        )
                    )
                    .padding(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            appText("الصورة السريعة", "Quick image"),
                            color = Color(0xFF8CF7FF),
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 18.sp
                        )
                        Text(
                            appText("${selectedTests.size} تحليل مختار", "${selectedTests.size} selected tests"),
                            color = Color.White.copy(alpha = 0.85f),
                            fontSize = 11.sp
                        )
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(appText("الإجمالي", "Total"), color = Color.White.copy(alpha = 0.75f), fontSize = 10.sp)
                        Text(
                            "${formatTotalDisplay(totalPrice)} ${appText("ج", "EGP")}",
                            color = Color.White,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 21.sp
                        )
                    }
                }
            }

            selectedTests.forEach { test ->
                SelectedTestRow(
                    test = test,
                    customerPrice = customerPriceOverrides[test.id] ?: test.customerPrice,
                    isManager = false,
                    lab2LabPrice = null,
                    onRemove = { onRemoveTest(test.id) }
                )
            }

            OutlinedButton(
                onClick = { showOptionalCustomer = !showOptionalCustomer },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(13.dp),
                border = BorderStroke(1.dp, Color(0xFF9DDDE3))
            ) {
                Icon(Icons.Default.People, contentDescription = null, tint = Color(0xFF007E89))
                Spacer(Modifier.width(7.dp))
                Text(
                    if (showOptionalCustomer) appText("إخفاء بيانات العميل الاختيارية", "Hide optional customer data")
                    else appText("إضافة بيانات العميل - اختياري", "Add customer details - optional"),
                    color = Color(0xFF007E89),
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 11.sp
                )
            }

            AnimatedVisibility(visible = showOptionalCustomer) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = customerName,
                        onValueChange = { customerName = it.take(80) },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text(appText("اسم العميل - اختياري", "Customer name - optional")) },
                        singleLine = true,
                        shape = RoundedCornerShape(13.dp)
                    )
                    OutlinedTextField(
                        value = customerPhone,
                        onValueChange = { customerPhone = it.filter { ch -> ch.isDigit() }.take(15) },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text(appText("واتساب - اختياري", "WhatsApp - optional")) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        singleLine = true,
                        shape = RoundedCornerShape(13.dp)
                    )
                    Text(
                        appText("البيانات دي بتظهر في الصورة فقط ومش بتتسجل في سجلات العملاء.", "These details appear in the image only and are not saved to customer records."),
                        fontSize = 9.sp,
                        color = Color(0xFF64748B)
                    )
                }
            }

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = { requestSave() },
                    enabled = busyAction == null,
                    modifier = Modifier
                        .weight(1f)
                        .shadow(13.dp, RoundedCornerShape(13.dp), ambientColor = Color(0xFF25F0A7), spotColor = Color(0xFF25F0A7)),
                    shape = RoundedCornerShape(13.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0A8B61))
                ) {
                    if (busyAction == "save") CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp, color = Color.White)
                    else Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(5.dp))
                    Text(appText("حفظ الصورة", "Save image"), fontWeight = FontWeight.ExtraBold, fontSize = 11.sp)
                }
                OutlinedButton(
                    onClick = { shareNow() },
                    enabled = busyAction == null,
                    modifier = Modifier
                        .weight(1f)
                        .shadow(11.dp, RoundedCornerShape(13.dp), ambientColor = Color(0xFFAE72FF), spotColor = Color(0xFFAE72FF)),
                    shape = RoundedCornerShape(13.dp),
                    border = BorderStroke(1.2.dp, Color(0xFFAE72FF))
                ) {
                    if (busyAction == "share") CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                    else Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(5.dp))
                    Text(appText("مشاركة", "Share"), fontWeight = FontWeight.ExtraBold, fontSize = 11.sp)
                }
            }
        }
    }
}

@Composable
private fun RecognizedTestsActionsCard(
    totalDetected: Int,
    selectedDetected: Int,
    remainingDetected: Int,
    onAddAll: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFEAF8F7)),
        border = BorderStroke(1.dp, Color(0xFFB7E4E1))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = tr("التحاليل المقروءة من الملف", "Tests detected from file"),
                    fontSize = 15.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color(0xFF075E63)
                )
                Text(
                    text = "$totalDetected",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color(0xFF007E89)
                )
            }

            Text(
                text = tr(
                    "تمت إضافة $selectedDetected • متبقي $remainingDetected",
                    "$selectedDetected added • $remainingDetected remaining"
                ),
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color(0xFF365A5C)
            )

            Button(
                onClick = onAddAll,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(46.dp)
                    .shadow(12.dp, RoundedCornerShape(14.dp), ambientColor = Color(0xFF00D9FF), spotColor = Color(0xFF00D9FF))
                    .testTag("add_all_recognized_tests"),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF007E89))
            ) {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(7.dp))
                Text(
                    text = tr(
                        "إضافة كل التحاليل المقروءة ($remainingDetected)",
                        "Add all detected tests ($remainingDetected)"
                    ),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
private fun SelectedTestsSection(
    selectedTests: List<LabTest>,
    isManager: Boolean,
    lab2LabPrices: Map<Int, String>,
    customerPriceOverrides: Map<Int, String>,
    activeOrderCustomer: Customer?,
    onChooseCustomer: () -> Unit,
    onClearCustomer: () -> Unit,
    onSaveCustomerOrder: () -> Unit,
    onRemoveTest: (Int) -> Unit
) {
    val settings = LocalAppSettings.current
    val totalPrice = calculatePriceTotal(selectedTests) { customerPriceOverrides[it.id] ?: it.customerPrice }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(
                elevation = 4.dp,
                shape = RoundedCornerShape(20.dp),
                spotColor = Color(0x1A000000)
            ),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.5.dp, Color(0xFF0061A4))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // Section Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = Color(0xFF0061A4),
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = tr("التحاليل المختارة", "Selected Tests"),
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF001D35)
                    )
                }
                Box(
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(Color(0xFFE1F1FF))
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "${selectedTests.size}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0061A4)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // V64: keep the order total visible BEFORE the long selected-tests list.
            // The transaction total is always shown while creating an order; catalog price
            // visibility settings still apply elsewhere in the app.
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color(0xFF0061A4))
                    .padding(14.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = tr("إجمالي الطلب الحالي", "Current Order Total"),
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                text = tr("${selectedTests.size} تحليل مختار", "${selectedTests.size} selected tests"),
                                fontSize = 11.sp,
                                color = Color.White.copy(alpha = 0.86f)
                            )
                        }
                        Row(verticalAlignment = Alignment.Bottom) {
                            Text(
                                text = formatTotalDisplay(totalPrice),
                                fontSize = 22.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color.White
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = tr("جنيه", "EGP"),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                modifier = Modifier.padding(bottom = 2.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Selected items list
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                selectedTests.forEach { test ->
                    SelectedTestRow(
                        test = test,
                        customerPrice = customerPriceOverrides[test.id] ?: test.customerPrice,
                        isManager = isManager,
                        lab2LabPrice = lab2LabPrices[test.id],
                        onRemove = { onRemoveTest(test.id) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Customer order flow
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                color = if (activeOrderCustomer == null) Color(0xFFF8FAFC) else Color(0xFFE7F5F7),
                border = BorderStroke(1.dp, if (activeOrderCustomer == null) Color(0xFFE2E8F0) else Color(0xFF7DD3FC))
            ) {
                Column(Modifier.padding(12.dp)) {
                    if (activeOrderCustomer == null) {
                        Text(
                            tr("اربط التحاليل بعميل قبل حفظ الطلب", "Link tests to a customer before saving"),
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFF17324D)
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            tr("اختار عميل سابق أو أضف عميل جديد", "Choose an existing customer or add a new one"),
                            fontSize = 12.sp,
                            color = Color(0xFF64748B)
                        )
                        Spacer(Modifier.height(10.dp))
                        Button(
                            onClick = onChooseCustomer,
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF006D86))
                        ) {
                            Text(appText("اختيار العميل", "Choose customer"), fontWeight = FontWeight.Bold)
                        }
                    } else {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(appText("العميل المرتبط بالطلب", "Order customer"), fontSize = 11.sp, color = Color(0xFF64748B))
                                Text(activeOrderCustomer.name, fontWeight = FontWeight.ExtraBold, color = Color(0xFF17324D))
                                Text(
                                    tr("واتساب: ${activeOrderCustomer.phone}", "WhatsApp: ${activeOrderCustomer.phone}"),
                                    fontSize = 11.sp,
                                    color = Color(0xFF006D86)
                                )
                            }
                            TextButton(onClick = onClearCustomer) { Text(appText("تغيير", "Change")) }
                        }
                        Spacer(Modifier.height(10.dp))
                        Button(
                            onClick = onSaveCustomerOrder,
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF15803D))
                        ) {
                            Text(appText("حفظ الطلب في ملف العميل", "Save order to customer file"), fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // V73: one clear continuation button above is enough; no duplicate document action.
        }
    }
}

@Composable
fun ProfessionalOrderCheckoutDialog(
    customer: Customer,
    selectedTests: List<LabTest>,
    customerPriceOverrides: Map<Int, String>,
    onDismiss: () -> Unit,
    onConfirm: (discount: Double, discountPercent: Double, paymentStatus: String, paidAmount: Double, notes: String, createImage: Boolean, done: () -> Unit) -> Unit
) {
    val total = calculatePriceTotal(selectedTests) { customerPriceOverrides[it.id] ?: it.customerPrice }
    var paymentStatus by remember { mutableStateOf("unpaid") }
    var paidText by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    var savingOrder by remember { mutableStateOf(false) }

    val typedPaid = paidText.replace(',', '.').toDoubleOrNull() ?: 0.0
    val paidEntryRequired = paymentStatus == "partial" || paymentStatus == "unpaid"
    val paidEntryValid = when (paymentStatus) {
        "partial" -> paidText.isNotBlank() && typedPaid > 0.0 && typedPaid < total
        "unpaid" -> paidText.isNotBlank() && typedPaid == 0.0
        else -> true
    }
    val paidAmount = when (paymentStatus) {
        "paid" -> total
        "partial" -> typedPaid.coerceIn(0.0, total)
        else -> 0.0
    }
    val remaining = (total - paidAmount).coerceAtLeast(0.0)

    BackHandler(enabled = true) { onDismiss() }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false, dismissOnBackPress = true)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.86f)
                .padding(12.dp),
            shape = RoundedCornerShape(26.dp),
            color = Color(0xFFF8FAFC)
        ) {
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(bottom = 24.dp)
            ) {
                item {
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(20.dp),
                        color = Color.White,
                        border = BorderStroke(1.dp, Color(0xFFE2E8F0))
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(
                                    tr("تأكيد الطلب", "Confirm order"),
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 19.sp,
                                    color = Color(0xFF17324D)
                                )
                                Text(
                                    "${customer.name} • ${customer.phone}",
                                    fontSize = 12.sp,
                                    color = Color(0xFF006D86)
                                )
                            }
                            IconButton(onClick = onDismiss) {
                                Icon(Icons.Default.Close, contentDescription = tr("إغلاق", "Close"))
                            }
                        }
                    }
                }

                item {
                    FinanceDashboardCard(
                        modifier = Modifier.fillMaxWidth(),
                        title = tr("إجمالي الطلب", "Order total"),
                        value = "${formatTotalDisplay(total)} ج",
                        subtitle = tr("${selectedTests.size} تحليل", "${selectedTests.size} tests"),
                        icon = Icons.Default.ReceiptLong,
                        accent = Color(0xFF0369A1),
                        background = Color(0xFFEFF6FF)
                    )
                }

                item {
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(18.dp),
                        color = Color.White,
                        border = BorderStroke(1.dp, Color(0xFFE2E8F0))
                    ) {
                        Column(Modifier.padding(14.dp)) {
                            Text(tr("حالة الدفع", "Payment status"), fontWeight = FontWeight.ExtraBold, color = Color(0xFF17324D))
                            Spacer(Modifier.height(9.dp))
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                listOf(
                                    "unpaid" to tr("غير مدفوع", "Unpaid"),
                                    "partial" to tr("جزئي", "Partial"),
                                    "paid" to tr("مدفوع", "Paid")
                                ).forEach { (value, label) ->
                                    Button(
                                        onClick = {
                                            paymentStatus = value
                                            paidText = when (value) {
                                                "unpaid" -> "0"
                                                "partial" -> paidText.takeIf { it != "0" }.orEmpty()
                                                else -> ""
                                            }
                                        },
                                        modifier = Modifier.weight(1f),
                                        shape = RoundedCornerShape(11.dp),
                                        contentPadding = PaddingValues(horizontal = 4.dp, vertical = 9.dp),
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = if (paymentStatus == value) Color(0xFF006D86) else Color(0xFFF1F5F9),
                                            contentColor = if (paymentStatus == value) Color.White else Color(0xFF334155)
                                        )
                                    ) {
                                        Text(label, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }

                            if (paidEntryRequired) {
                                Spacer(Modifier.height(10.dp))
                                OutlinedTextField(
                                    value = paidText,
                                    onValueChange = { value -> paidText = value.filter { it.isDigit() || it == '.' || it == ',' }.take(10) },
                                    modifier = Modifier.fillMaxWidth().heightIn(min = 72.dp),
                                    label = { Text(tr("المبلغ المسدد (إجباري)", "Paid amount (required)")) },
                                    suffix = { Text(tr("جنيه", "EGP")) },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                    singleLine = true,
                                    isError = !paidEntryValid
                                )
                                if (!paidEntryValid) {
                                    Spacer(Modifier.height(5.dp))
                                    Text(
                                        if (paymentStatus == "unpaid") {
                                            tr("اكتب 0 لو لم يتم سداد أي مبلغ.", "Enter 0 if nothing was paid.")
                                        } else {
                                            tr("اكتب مبلغ أكبر من 0 وأقل من إجمالي الطلب.", "Enter an amount greater than 0 and less than the order total.")
                                        },
                                        fontSize = 10.sp,
                                        color = Color(0xFFB91C1C)
                                    )
                                }
                            }
                        }
                    }
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        FinanceDashboardCard(
                            modifier = Modifier.weight(1f),
                            title = tr("المدفوع", "Paid"),
                            value = "${formatTotalDisplay(paidAmount)} ج",
                            subtitle = paymentStatusArabic(paymentStatus),
                            icon = Icons.Default.Payments,
                            accent = Color(0xFF15803D),
                            background = Color(0xFFECFDF3)
                        )
                        FinanceDashboardCard(
                            modifier = Modifier.weight(1f),
                            title = tr("المتبقي", "Remaining"),
                            value = "${formatTotalDisplay(remaining)} ج",
                            subtitle = if (remaining > 0.0) tr("مستحق", "Due") else tr("تم السداد", "Paid in full"),
                            icon = Icons.Default.AccountBalanceWallet,
                            accent = if (remaining > 0.0) Color(0xFFB91C1C) else Color(0xFF15803D),
                            background = if (remaining > 0.0) Color(0xFFFEF2F2) else Color(0xFFECFDF3)
                        )
                    }
                }

                item {
                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it.take(500) },
                        modifier = Modifier.fillMaxWidth().heightIn(min = 100.dp),
                        label = { Text(tr("ملاحظات - اختياري", "Notes - Optional")) },
                        minLines = 2,
                        maxLines = 4
                    )
                }

                item {
                    Button(
                        onClick = {
                            if (!savingOrder) {
                                savingOrder = true
                                onConfirm(0.0, 0.0, paymentStatus, paidAmount, notes, true) { savingOrder = false }
                            }
                        },
                        enabled = paidEntryValid && !savingOrder,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF15803D))
                    ) {
                        if (savingOrder) {
                            CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp, color = Color.White)
                        } else {
                            Icon(Icons.Default.Save, contentDescription = null)
                        }
                        Spacer(Modifier.width(7.dp))
                        Text(if (savingOrder) tr("جاري الحفظ...", "Saving...") else tr("حفظ ومتابعة الصور", "Save and continue to images"), fontWeight = FontWeight.ExtraBold)
                    }
                    TextButton(onClick = onDismiss, enabled = !savingOrder, modifier = Modifier.fillMaxWidth()) { Text(tr("إلغاء", "Cancel")) }
                }
            }
        }
    }
}

@Composable
private fun FinanceDashboardCard(
    modifier: Modifier = Modifier,
    title: String,
    value: String,
    subtitle: String,
    icon: ImageVector,
    accent: Color,
    background: Color
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(17.dp),
        color = background,
        border = BorderStroke(1.dp, accent.copy(alpha = 0.14f))
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(7.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(30.dp)
                        .clip(RoundedCornerShape(9.dp))
                        .background(accent.copy(alpha = 0.12f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = accent,
                        modifier = Modifier.size(17.dp)
                    )
                }
                Spacer(Modifier.width(7.dp))
                Text(
                    title,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF64748B),
                    maxLines = 1
                )
            }
            Text(
                value,
                fontSize = 18.sp,
                fontWeight = FontWeight.ExtraBold,
                color = accent,
                maxLines = 1
            )
            Text(
                subtitle,
                fontSize = 10.sp,
                fontWeight = FontWeight.Medium,
                color = Color(0xFF64748B),
                maxLines = 1
            )
        }
    }
}

private fun formatDashboardPercent(value: Double): String {
    return if (value % 1.0 == 0.0) value.toLong().toString() else String.format("%.1f", value)
}

@Composable
private fun SelectedTestRow(
    test: LabTest,
    customerPrice: String?,
    isManager: Boolean,
    lab2LabPrice: String?,
    onRemove: () -> Unit
) {
    val settings = LocalAppSettings.current
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        color = Color(0xFFF8FAFC),
        border = BorderStroke(1.dp, Color(0xFFE2E8F0))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                if (settings.showEnglishName) {
                    Text(
                        text = test.englishName,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF001D35),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                if (settings.showArabicName && test.arabicName.isNotBlank()) {
                    Text(
                        text = test.arabicName,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        color = Color(0xFF64748B),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                if (settings.showMarketName && test.marketName.isNotBlank() && test.marketName != test.englishName) {
                    Text(
                        text = test.marketName,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        color = Color(0xFF64748B),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            if (settings.showCustomerPrice) {
                Spacer(modifier = Modifier.width(8.dp))
                Column(horizontalAlignment = Alignment.End) {
                    if (settings.showCustomerPrice) {
                        Text(
                            text = "عميل: ${customerPrice ?: "0"} جنيه",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF004A77)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.width(8.dp))
            IconButton(
                onClick = onRemove,
                modifier = Modifier
                    .size(28.dp)
                    .testTag("remove_test_${test.id}")
            ) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = tr("إزالة", "Remove"),
                    tint = Color(0xFFE11D48),
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

@Composable
private fun UnmatchedQueriesCard(unmatchedQueries: List<String>) {
    if (unmatchedQueries.isEmpty()) return

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(
                elevation = 2.dp,
                shape = RoundedCornerShape(18.dp),
                spotColor = Color(0x10000000)
            ),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF1F2))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = null,
                    tint = Color(0xFFE11D48),
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = tr("تحاليل غير موجودة", "Tests Not Found"),
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF9F1239)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                unmatchedQueries.forEach { query ->
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color.White)
                            .padding(horizontal = 12.dp, vertical = 8.dp)
                    ) {
                        Text(
                            text = "• $query",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color(0xFF881337)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun QueryGroupSection(
    group: QueryGroup,
    isManager: Boolean,
    lab2LabPrices: Map<Int, String>,
    customerPriceOverrides: Map<Int, String>,
    onSelectTest: (LabTest) -> Unit,
    onEditPrices: (LabTest) -> Unit,
    allowSelection: Boolean = true
) {
    Column(
        verticalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        if (group.candidates.size > 1) {
            AmbiguousHeaderCard(query = group.query, count = group.candidates.size)
        }
        group.candidates.forEach { test ->
            SearchCandidateCard(
                test = test,
                customerPrice = customerPriceOverrides[test.id] ?: test.customerPrice,
                isManager = isManager,
                lab2LabPrice = lab2LabPrices[test.id],
                onSelect = { onSelectTest(test) },
                onEditPrices = { onEditPrices(test) },
                allowSelection = allowSelection
            )
        }
    }
}

@Composable
private fun AmbiguousHeaderCard(query: String, count: Int) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        color = Color(0xFFFFF7ED),
        border = BorderStroke(1.dp, Color(0xFFFFD8A8))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.FilterList,
                contentDescription = null,
                tint = Color(0xFFC2410C),
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "نتائج عدة لـ \"$query\" ($count تحاليل):",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF9A3412)
            )
        }
    }
}

@Composable
private fun SearchCandidateCard(
    test: LabTest,
    customerPrice: String?,
    isManager: Boolean,
    lab2LabPrice: String?,
    onSelect: () -> Unit,
    onEditPrices: () -> Unit,
    allowSelection: Boolean = true
) {
    val settings = LocalAppSettings.current
    // V67: price inquiry must always show the identifying names and customer price,
    // even if the user hid some optional fields in general display settings.
    val forcePriceInquiry = !allowSelection
    val showEnglishName = settings.showEnglishName || forcePriceInquiry
    val showArabicName = settings.showArabicName || forcePriceInquiry
    val showMarketName = settings.showMarketName || forcePriceInquiry
    val showCustomerPrice = settings.showCustomerPrice || forcePriceInquiry
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(
                elevation = 4.dp,
                shape = RoundedCornerShape(22.dp),
                spotColor = Color(0x14000000)
            ),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, Color(0xFFE5ECF2))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    if (showEnglishName) {
                        Text(
                            text = test.englishName,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFF102A43),
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    if (showArabicName && test.arabicName.isNotBlank()) {
                        if (showEnglishName) Spacer(modifier = Modifier.height(5.dp))
                        Text(
                            text = test.arabicName,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFF52667A),
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    if (!showEnglishName && !showArabicName && test.marketName.isNotBlank()) {
                        Text(
                            text = test.marketName,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFF102A43),
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                Spacer(modifier = Modifier.width(10.dp))

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0xFFF0F4F8))
                        .padding(horizontal = 8.dp, vertical = 5.dp)
                ) {
                    Text(
                        text = "#${test.id}",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF718096)
                    )
                }
            }

            if (showMarketName && test.marketName.isNotBlank() && test.marketName != test.englishName) {
                Spacer(modifier = Modifier.height(9.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = tr("الاسم الدارج", "Market Name"),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF7B8794)
                    )
                    Spacer(modifier = Modifier.width(7.dp))
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(9.dp))
                            .background(Color(0xFFF2F7FA))
                            .padding(horizontal = 9.dp, vertical = 5.dp)
                    ) {
                        Text(
                            text = test.marketName,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFF36536B),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            if (showCustomerPrice) {
                Spacer(modifier = Modifier.height(14.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (showCustomerPrice) {
                        PriceBox(
                            modifier = Modifier.weight(1f),
                            title = tr("سعر العميل", "Customer Price"),
                            price = customerPrice,
                            backgroundColor = Color(0xFFEDF7FF),
                            borderColor = Color(0xFFCFE8F7),
                            titleColor = Color(0xFF28607E),
                            priceColor = Color(0xFF114D6B)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (allowSelection) {
                Button(
                    onClick = onSelect,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(46.dp)
                        .testTag("select_test_${test.id}"),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF007E89))
                ) {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(7.dp))
                    Text(
                        text = tr("إضافة إلى القائمة", "Add to List"),
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            TestGuideMoreButton(
                test = test,
                modifier = Modifier.testTag("search_test_guide_${test.id}")
            )
        }
    }
}

@Composable
private fun NoResultsSection(unmatchedQueries: List<String>) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(top = 8.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        if (unmatchedQueries.isNotEmpty()) {
            UnmatchedQueriesCard(unmatchedQueries = unmatchedQueries)
        }
        NoResultsView()
    }
}

@Composable
private fun LabTestCard(
    test: LabTest,
    isSelected: Boolean = false
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(
                elevation = if (isSelected) 4.dp else 3.dp,
                shape = RoundedCornerShape(24.dp),
                spotColor = Color(0x12000000)
            ),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) Color(0xFFF8FAFC) else Color.White
        ),
        border = if (isSelected) BorderStroke(2.dp, Color(0xFF0061A4)) else null
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // English Name
            Text(
                text = test.englishName,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF001D35),
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Arabic Name
            Row(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = tr("الاسم العربي: ", "Arabic name: "),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF64748B)
                )
                Text(
                    text = if (test.arabicName.isNotBlank()) test.arabicName else "غير مسجل",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    color = Color(0xFF1E293B)
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Market Name
            Row(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = tr("الاسم الدارج: ", "Market name: "),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF64748B)
                )
                Text(
                    text = if (test.marketName.isNotBlank()) test.marketName else "غير مسجل",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    color = Color(0xFF1E293B)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Price Section
            PriceBox(
                modifier = Modifier.fillMaxWidth(),
                title = tr("سعر العميل", "Customer Price"),
                price = test.customerPrice,
                backgroundColor = Color(0xFFF0F7FF),
                borderColor = Color(0xFFD0E4FF),
                titleColor = Color(0xFF004A77),
                priceColor = Color(0xFF004A77)
            )

            Spacer(modifier = Modifier.height(10.dp))
            TestGuideMoreButton(
                test = test,
                modifier = Modifier.testTag("basic_test_guide_${test.id}")
            )
        }
    }
}

@Composable
private fun PriceBox(
    modifier: Modifier = Modifier,
    title: String,
    price: String?,
    backgroundColor: Color,
    borderColor: Color,
    titleColor: Color,
    priceColor: Color
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(backgroundColor)
            .border(1.dp, borderColor, RoundedCornerShape(14.dp))
            .padding(horizontal = 12.dp, vertical = 10.dp)
    ) {
        Column {
            Text(
                text = title,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = titleColor
            )

            Spacer(modifier = Modifier.height(6.dp))

            if (!price.isNullOrBlank()) {
                Row(
                    verticalAlignment = Alignment.Bottom,
                    horizontalArrangement = Arrangement.Start
                ) {
                    Text(
                        text = price,
                        fontSize = 19.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = priceColor
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = tr("جنيه", "EGP"),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = priceColor,
                        modifier = Modifier.padding(bottom = 2.dp)
                    )
                }
            } else {
                Text(
                    text = "غير مسجل",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF94A3B8)
                )
            }
        }
    }
}

@Composable
private fun EmptyStateView() {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 6.dp),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, Color(0xFFE6EDF3))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp, vertical = 34.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(72.dp)
                    .clip(RoundedCornerShape(22.dp))
                    .background(Color(0xFFE7F5F7)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Outlined.Biotech,
                    contentDescription = null,
                    tint = Color(0xFF007E89),
                    modifier = Modifier.size(36.dp)
                )
            }

            Spacer(modifier = Modifier.height(18.dp))

            Text(
                text = tr("ابدأ بكتابة اسم التحليل", "Start typing a test name"),
                fontSize = 19.sp,
                fontWeight = FontWeight.ExtraBold,
                color = Color(0xFF17324D),
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(7.dp))

            Text(
                text = tr("البحث يدعم العربي والإنجليزي والاسم المتداول في المعامل", "Search supports Arabic, English and common lab names"),
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium,
                color = Color(0xFF718096),
                textAlign = TextAlign.Center,
                lineHeight = 19.sp
            )
        }
    }
}

@Composable
private fun NoResultsView() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(80.dp)
                .clip(CircleShape)
                .background(Color(0xFFFEE2E2)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Outlined.SearchOff,
                contentDescription = null,
                tint = Color(0xFFDC2626),
                modifier = Modifier.size(40.dp)
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        Text(
            text = tr("لم يتم العثور على التحليل", "Test Not Found"),
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF001D35),
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = tr("جرّب البحث باسم مختلف أو بالاسم الإنجليزي", "Try another name or the English name"),
            fontSize = 14.sp,
            fontWeight = FontWeight.Medium,
            color = Color(0xFF64748B),
            textAlign = TextAlign.Center
        )
    }
}


private fun paymentStatusArabic(status: String): String = when (status) {
    "paid" -> "مدفوع"
    "partial" -> "جزئي"
    else -> tr("غير مدفوع", "Unpaid")
}
