package com.example.util

import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.os.Build
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import android.widget.Toast
import androidx.core.content.FileProvider
import com.example.R
import com.example.data.model.CustomerOrder
import com.example.data.model.LabTest
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object PdfGenerator {

    private const val PAGE_WIDTH = 420
    private const val PAGE_HEIGHT = 595
    private const val MARGIN = 24f

    fun generateAndSharePdf(
        context: Context,
        selectedTests: List<LabTest>,
        includeCustomerPrice: Boolean = true,
        includeLab2Lab: Boolean = false,
        showTotals: Boolean = true,
        labName: String = "تحاليل العقاد",
        showContactInfo: Boolean = false,
        contactInfo: String = "",
        lab2LabPrices: Map<Int, String> = emptyMap(),
        customerPriceOverrides: Map<Int, String> = emptyMap(),
        customerName: String? = null,
        customerFileNumber: String? = null,
        customerPhone: String? = null,
        orderNumber: String? = null,
        orderDateMillis: Long? = null,
        discountAmount: Double = 0.0,
        finalCustomerTotal: Double? = null,
        paymentStatus: String? = null,
        paidAmount: Double = 0.0,
        remainingAmount: Double = 0.0,
        orderNotes: String = ""
    ) {
        if (selectedTests.isEmpty()) {
            Toast.makeText(context, "لم يتم اختيار أي تحاليل", Toast.LENGTH_SHORT).show()
            return
        }

        val pdfDocument = PdfDocument()
        var pageNumber = 1
        var pageInfo = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, pageNumber).create()
        var page = pdfDocument.startPage(pageInfo)
        var canvas = page.canvas

        val primaryColor = Color.parseColor("#0061A4")
        val darkTextColor = Color.parseColor("#001D35")
        val grayTextColor = Color.parseColor("#475569")
        val lightBgColor = Color.parseColor("#F8FAFC")
        val dividerColor = Color.parseColor("#E2E8F0")
        val managerColor = Color.parseColor("#6D28D9")

        val bgPaint = Paint().apply { color = Color.WHITE; style = Paint.Style.FILL }
        val labNamePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = darkTextColor
            textSize = 16f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }
        val titlePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = primaryColor
            textSize = 12f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }
        val headerTextPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = if (includeCustomerPrice && includeLab2Lab) 9f else 10f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val namePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = darkTextColor
            textSize = 9.5f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val arabicNamePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = grayTextColor
            textSize = 8f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        }
        val pricePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = primaryColor
            textSize = 8.5f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.LEFT
        }
        val lab2LabPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = managerColor
            textSize = 8.5f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.LEFT
        }
        val totalPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 10.5f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val contactPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = grayTextColor
            textSize = 8.5f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        }
        val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = dividerColor
            strokeWidth = 0.8f
        }

        var currentY = MARGIN

        fun startCleanPage() {
            canvas.drawRect(0f, 0f, PAGE_WIDTH.toFloat(), PAGE_HEIGHT.toFloat(), bgPaint)
            currentY = MARGIN
        }

        fun drawPageHeader() {
            val logoBitmap = BitmapFactory.decodeResource(context.resources, R.drawable.ic_clinic_logo)
            if (logoBitmap != null) {
                val logoSize = 62f
                val logoX = (PAGE_WIDTH - logoSize) / 2f
                val srcRect = Rect(0, 0, logoBitmap.width, logoBitmap.height)
                val dstRect = RectF(logoX, currentY, logoX + logoSize, currentY + logoSize)
                canvas.drawBitmap(logoBitmap, srcRect, dstRect, null)
                currentY += logoSize + 6f
            }

            canvas.drawText(labName.ifBlank { "تحاليل العقاد" }, PAGE_WIDTH / 2f, currentY + 13f, labNamePaint)
            currentY += 19f
            canvas.drawText("قائمة التحاليل والأسعار", PAGE_WIDTH / 2f, currentY + 10f, titlePaint)
            currentY += 20f

            if (!customerName.isNullOrBlank()) {
                val customerBg = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = Color.parseColor("#E7F5F7")
                    style = Paint.Style.FILL
                }
                val customerPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = darkTextColor
                    textSize = 8.5f
                    typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                    textAlign = Paint.Align.RIGHT
                }
                val infoRect = RectF(MARGIN, currentY, PAGE_WIDTH - MARGIN, currentY + 34f)
                canvas.drawRoundRect(infoRect, 5f, 5f, customerBg)
                canvas.drawText("العميل: $customerName", PAGE_WIDTH - MARGIN - 8f, currentY + 13f, customerPaint)
                val secondLine = listOfNotNull(
                    customerFileNumber?.takeIf { it.isNotBlank() },
                    customerPhone?.takeIf { it.isNotBlank() }
                ).joinToString("  •  ")
                if (secondLine.isNotBlank()) {
                    customerPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
                    customerPaint.textSize = 7.8f
                    canvas.drawText(secondLine, PAGE_WIDTH - MARGIN - 8f, currentY + 26f, customerPaint)
                }
                currentY += 42f
            }

            if (!orderNumber.isNullOrBlank()) {
                val orderBg = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = Color.parseColor("#F1F5F9")
                    style = Paint.Style.FILL
                }
                val orderPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = darkTextColor
                    textSize = 7.8f
                    typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                    textAlign = Paint.Align.RIGHT
                }
                val orderRect = RectF(MARGIN, currentY, PAGE_WIDTH - MARGIN, currentY + 25f)
                canvas.drawRoundRect(orderRect, 5f, 5f, orderBg)
                canvas.drawText("رقم الطلب: $orderNumber", PAGE_WIDTH - MARGIN - 8f, currentY + 11f, orderPaint)
                val orderDate = orderDateMillis?.takeIf { it > 0L }?.let {
                    SimpleDateFormat("yyyy/MM/dd  HH:mm", Locale("ar", "EG")).format(Date(it))
                }.orEmpty()
                if (orderDate.isNotBlank()) {
                    orderPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
                    orderPaint.textSize = 7.2f
                    canvas.drawText("التاريخ: $orderDate", PAGE_WIDTH - MARGIN - 8f, currentY + 21f, orderPaint)
                }
                currentY += 33f
            }

            val headerHeight = 24f
            val headerRect = RectF(MARGIN, currentY, PAGE_WIDTH - MARGIN, currentY + headerHeight)
            val headerBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = primaryColor
                style = Paint.Style.FILL
            }
            canvas.drawRoundRect(headerRect, 4f, 4f, headerBgPaint)

            when {
                includeCustomerPrice && includeLab2Lab -> {
                    headerTextPaint.textAlign = Paint.Align.LEFT
                    canvas.drawText("Lab 2 Lab", MARGIN + 7f, currentY + 16f, headerTextPaint)
                    canvas.drawText("سعر العميل", MARGIN + 82f, currentY + 16f, headerTextPaint)
                    headerTextPaint.textAlign = Paint.Align.RIGHT
                    canvas.drawText("اسم التحليل", PAGE_WIDTH - MARGIN - 8f, currentY + 16f, headerTextPaint)
                }
                includeCustomerPrice -> {
                    headerTextPaint.textAlign = Paint.Align.LEFT
                    canvas.drawText("سعر العميل", MARGIN + 10f, currentY + 16f, headerTextPaint)
                    headerTextPaint.textAlign = Paint.Align.RIGHT
                    canvas.drawText("اسم التحليل", PAGE_WIDTH - MARGIN - 10f, currentY + 16f, headerTextPaint)
                }
                includeLab2Lab -> {
                    headerTextPaint.textAlign = Paint.Align.LEFT
                    canvas.drawText("Lab 2 Lab", MARGIN + 10f, currentY + 16f, headerTextPaint)
                    headerTextPaint.textAlign = Paint.Align.RIGHT
                    canvas.drawText("اسم التحليل", PAGE_WIDTH - MARGIN - 10f, currentY + 16f, headerTextPaint)
                }
                else -> {
                    headerTextPaint.textAlign = Paint.Align.RIGHT
                    canvas.drawText("اسم التحليل", PAGE_WIDTH - MARGIN - 10f, currentY + 16f, headerTextPaint)
                }
            }

            currentY += headerHeight + 10f
        }

        fun nextPage(withHeader: Boolean = true) {
            pdfDocument.finishPage(page)
            pageNumber++
            pageInfo = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, pageNumber).create()
            page = pdfDocument.startPage(pageInfo)
            canvas = page.canvas
            startCleanPage()
            if (withHeader) drawPageHeader()
        }

        startCleanPage()
        drawPageHeader()

        val reservedBottom = if (showTotals || (showContactInfo && contactInfo.isNotBlank())) 80f else 36f
        val maxUsableY = PAGE_HEIGHT - reservedBottom
        val priceColumnsWidth = when {
            includeCustomerPrice && includeLab2Lab -> 155
            includeCustomerPrice || includeLab2Lab -> 90
            else -> 0
        }
        val nameColumnWidth = (PAGE_WIDTH - (MARGIN * 2) - priceColumnsWidth - 18).toInt().coerceAtLeast(170)

        selectedTests.forEachIndexed { index, test ->
            val nameLayout = createStaticLayout(test.englishName, namePaint, nameColumnWidth)
            val arabicLayout = test.arabicName.takeIf { it.isNotBlank() }?.let {
                createStaticLayout(it, arabicNamePaint, nameColumnWidth)
            }
            val textHeight = nameLayout.height + (arabicLayout?.height ?: 0)
            val rowHeight = textHeight.coerceAtLeast(20) + 12f

            if (currentY + rowHeight > maxUsableY) nextPage(withHeader = true)

            if (index % 2 == 1) {
                val rowBgPaint = Paint().apply { color = lightBgColor; style = Paint.Style.FILL }
                canvas.drawRoundRect(
                    RectF(MARGIN, currentY - 2f, PAGE_WIDTH - MARGIN, currentY + rowHeight - 2f),
                    4f,
                    4f,
                    rowBgPaint
                )
            }

            val customerPrice = customerPriceOverrides[test.id] ?: test.customerPrice ?: "0"
            val labPrice = lab2LabPrices[test.id]

            when {
                includeCustomerPrice && includeLab2Lab -> {
                    canvas.drawText(if (labPrice.isNullOrBlank()) "--" else "$labPrice جنيه", MARGIN + 7f, currentY + 14f, lab2LabPaint)
                    canvas.drawText("$customerPrice جنيه", MARGIN + 82f, currentY + 14f, pricePaint)
                }
                includeCustomerPrice -> {
                    canvas.drawText("$customerPrice جنيه", MARGIN + 10f, currentY + 14f, pricePaint)
                }
                includeLab2Lab -> {
                    canvas.drawText(if (labPrice.isNullOrBlank()) "--" else "$labPrice جنيه", MARGIN + 10f, currentY + 14f, lab2LabPaint)
                }
            }

            canvas.save()
            canvas.translate(PAGE_WIDTH - MARGIN - 10f - nameLayout.width, currentY)
            nameLayout.draw(canvas)
            if (arabicLayout != null) {
                canvas.translate(0f, nameLayout.height.toFloat())
                arabicLayout.draw(canvas)
            }
            canvas.restore()

            currentY += rowHeight
            canvas.drawLine(MARGIN, currentY - 2f, PAGE_WIDTH - MARGIN, currentY - 2f, linePaint)
        }

        val totalCustomer = selectedTests.sumOf { extractNumericPrice(customerPriceOverrides[it.id] ?: it.customerPrice) }
        val totalLab = selectedTests.sumOf { extractNumericPrice(lab2LabPrices[it.id]) }

        if (showTotals && (includeCustomerPrice || includeLab2Lab)) {
            val totalRows = (if (includeCustomerPrice) 1 else 0) + (if (includeLab2Lab) 1 else 0)
            val totalBoxHeight = if (totalRows == 2) 50f else 32f
            if (currentY + totalBoxHeight + 12f > PAGE_HEIGHT - 30f) nextPage(withHeader = false)
            else currentY += 8f

            val totalBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = primaryColor; style = Paint.Style.FILL }
            canvas.drawRoundRect(
                RectF(MARGIN, currentY, PAGE_WIDTH - MARGIN, currentY + totalBoxHeight),
                6f,
                6f,
                totalBgPaint
            )

            var rowY = currentY + 20f
            if (includeCustomerPrice) {
                totalPaint.textAlign = Paint.Align.RIGHT
                canvas.drawText("إجمالي سعر العميل:", PAGE_WIDTH - MARGIN - 16f, rowY, totalPaint)
                totalPaint.textAlign = Paint.Align.LEFT
                canvas.drawText("${formatTotal(finalCustomerTotal ?: totalCustomer)} جنيه", MARGIN + 16f, rowY, totalPaint)
                rowY += 21f
            }
            if (includeLab2Lab) {
                totalPaint.textAlign = Paint.Align.RIGHT
                canvas.drawText("إجمالي Lab 2 Lab:", PAGE_WIDTH - MARGIN - 16f, rowY, totalPaint)
                totalPaint.textAlign = Paint.Align.LEFT
                canvas.drawText("${formatTotal(totalLab)} جنيه", MARGIN + 16f, rowY, totalPaint)
            }
            currentY += totalBoxHeight + 10f
        }

        if (!orderNumber.isNullOrBlank()) {
            val statusAr = when (paymentStatus) {
                "paid" -> "مدفوع بالكامل"
                "partial" -> "مدفوع جزئيا"
                else -> "غير مدفوع"
            }
            val boxHeight = if (orderNotes.isBlank()) 47f else 70f
            if (currentY + boxHeight + 8f > PAGE_HEIGHT - MARGIN) nextPage(withHeader = false)
            val orderSummaryBg = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#F8FAFC")
                style = Paint.Style.FILL
            }
            val summaryPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                color = darkTextColor
                textSize = 8.2f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                textAlign = Paint.Align.RIGHT
            }
            canvas.drawRoundRect(RectF(MARGIN, currentY, PAGE_WIDTH - MARGIN, currentY + boxHeight), 6f, 6f, orderSummaryBg)
            canvas.drawText("حالة الدفع: $statusAr", PAGE_WIDTH - MARGIN - 10f, currentY + 13f, summaryPaint)
            summaryPaint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            canvas.drawText("الخصم: ${formatTotal(discountAmount)} جنيه", PAGE_WIDTH - MARGIN - 10f, currentY + 27f, summaryPaint)
            canvas.drawText("المدفوع: ${formatTotal(paidAmount)} جنيه    •    المتبقي: ${formatTotal(remainingAmount)} جنيه", PAGE_WIDTH - MARGIN - 10f, currentY + 41f, summaryPaint)
            if (orderNotes.isNotBlank()) {
                val notesPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = darkTextColor
                    textSize = 7.6f
                    typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
                }
                val notesLayout = createStaticLayout("ملاحظات: $orderNotes", notesPaint, (PAGE_WIDTH - MARGIN * 2 - 20).toInt())
                canvas.save()
                canvas.translate(MARGIN + 10f, currentY + 48f)
                notesLayout.draw(canvas)
                canvas.restore()
            }
            currentY += boxHeight + 8f
        }

        if (showContactInfo && contactInfo.isNotBlank()) {
            val label = "بيانات التواصل: $contactInfo"
            val contactLayout = createStaticLayout(label, contactPaint, (PAGE_WIDTH - MARGIN * 2).toInt())
            if (currentY + contactLayout.height + 12f > PAGE_HEIGHT - MARGIN) nextPage(withHeader = false)
            canvas.save()
            canvas.translate(MARGIN, currentY + 2f)
            contactLayout.draw(canvas)
            canvas.restore()
            currentY += contactLayout.height + 8f
        }

        pdfDocument.finishPage(page)

        val pdfDir = File(context.cacheDir, "pdf").apply { mkdirs() }
        val file = File(pdfDir, "تحاليل_العقاد.pdf")
        try {
            FileOutputStream(file).use { out -> pdfDocument.writeTo(out) }
            pdfDocument.close()

            val uri = FileProvider.getUriForFile(context, "${context.packageName}.provider", file)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "application/pdf"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, "قائمة التحاليل والأسعار - ${labName.ifBlank { "تحاليل العقاد" }}")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            val chooser = Intent.createChooser(intent, "مشاركة قائمة التحاليل PDF")
            chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(chooser)
        } catch (_: Exception) {
            runCatching { pdfDocument.close() }
            Toast.makeText(context, "حدث خطأ أثناء إنشاء ملف PDF", Toast.LENGTH_SHORT).show()
        }
    }

    fun generateAndShareSavedOrderPdf(
        context: Context,
        order: CustomerOrder,
        customerPhone: String? = null,
        labName: String = "تحاليل العقاد",
        showContactInfo: Boolean = false,
        contactInfo: String = ""
    ) {
        val tests = order.items.map { item ->
            LabTest(
                id = item.testId,
                englishName = item.englishName,
                arabicName = item.arabicName,
                marketName = item.marketName,
                customerPrice = item.customerPrice.toString(),
                searchText = ""
            )
        }
        val priceMap = order.items.associate { it.testId to it.customerPrice.toString() }
        generateAndSharePdf(
            context = context,
            selectedTests = tests,
            includeCustomerPrice = true,
            includeLab2Lab = false,
            showTotals = true,
            labName = labName,
            showContactInfo = showContactInfo,
            contactInfo = contactInfo,
            customerPriceOverrides = priceMap,
            customerName = order.customerName,
            customerFileNumber = order.customerFileNumber,
            customerPhone = customerPhone,
            orderNumber = order.orderNumber,
            orderDateMillis = order.createdAtMillis,
            discountAmount = order.discountAmount,
            finalCustomerTotal = order.totalCustomerPrice,
            paymentStatus = order.paymentStatus,
            paidAmount = order.paidAmount,
            remainingAmount = order.remainingAmount,
            orderNotes = order.notes
        )
    }

    private fun extractNumericPrice(price: String?): Double {
        if (price.isNullOrBlank()) return 0.0
        val match = Regex("""\d+(?:\.\d+)?""").find(price.replace(",", ""))
        return match?.value?.toDoubleOrNull() ?: 0.0
    }

    private fun formatTotal(total: Double): String {
        return if (total % 1.0 == 0.0) total.toLong().toString() else String.format("%.2f", total)
    }

    private fun createStaticLayout(text: String, paint: TextPaint, width: Int): StaticLayout {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            StaticLayout.Builder.obtain(text, 0, text.length, paint, width)
                .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                .setTextDirection(TextDirectionHeuristics.RTL)
                .build()
        } else {
            @Suppress("DEPRECATION")
            StaticLayout(text, paint, width, Layout.Alignment.ALIGN_NORMAL, 1.0f, 0.0f, false)
        }
    }
}
