package com.example.data.repository

import android.content.Context
import com.example.data.model.LabTest
import com.example.data.model.normalizeText
import org.json.JSONArray
import java.io.InputStreamReader

class LabTestRepository(private val context: Context) {

    @Volatile
    private var cachedTests: List<LabTest>? = null

    fun getLabTests(): List<LabTest> {
        cachedTests?.let { return it }

        return synchronized(this) {
            cachedTests?.let { return@synchronized it }

            val testsList = mutableListOf<LabTest>()
            try {
                val inputStream = context.assets.open("lab_tests_android.json")
                val jsonString = InputStreamReader(inputStream, Charsets.UTF_8).use { it.readText() }
                val jsonArray = JSONArray(jsonString)

                for (i in 0 until jsonArray.length()) {
                    val obj = jsonArray.getJSONObject(i)
                    val id = obj.optInt("id")
                    val englishName = obj.optString("english_name", "")
                    val arabicName = obj.optString("arabic_name", "")
                    val marketName = obj.optString("market_name", "")
                    val searchText = obj.optString("search_text", "")

                    val customerPriceRaw = if (obj.isNull("customer_price")) null else obj.get("customer_price").toString()
                    val customerPrice = formatPrice(customerPriceRaw)

                    testsList.add(
                        LabTest(
                            id = id,
                            englishName = englishName,
                            arabicName = arabicName,
                            marketName = marketName,
                            customerPrice = customerPrice,
                            searchText = searchText
                        )
                    )
                }
            } catch (_: Exception) {
                // Do not emit dataset details or stack traces in release logs.
            }

            cachedTests = testsList
            testsList
        }
    }

    private fun formatPrice(priceStr: String?): String? {
        if (priceStr.isNullOrBlank() || priceStr.equals("null", ignoreCase = true)) return null
        return priceStr.trim()
    }

    fun searchTests(query: String): List<LabTest> {
        val trimmedQuery = query.trim()
        if (trimmedQuery.isEmpty()) {
            return emptyList()
        }

        val normQuery = normalizeText(trimmedQuery)
        if (normQuery.isEmpty()) {
            return emptyList()
        }

        val allTests = getLabTests()

        data class ScoredTest(val test: LabTest, val rankScore: Int)

        val matchedTests = mutableListOf<ScoredTest>()

        for (test in allTests) {
            val normEnglish = test.normEnglish
            val normArabic = test.normArabic
            val normMarket = test.normMarket
            val normSearch = test.normSearch

            val matches = normEnglish.contains(normQuery) ||
                    normArabic.contains(normQuery) ||
                    normMarket.contains(normQuery) ||
                    normSearch.contains(normQuery)

            if (!matches) continue

            val rankScore: Int = when {
                // 1. Exact English name match
                normEnglish == normQuery -> 1
                // 2. Exact Arabic name match
                normArabic == normQuery -> 2
                // 3. Exact market name match
                normMarket == normQuery -> 3
                // 4. Exact abbreviation/normalized match in words or searchText
                normEnglish.split(" ").any { it == normQuery } ||
                        normArabic.split(" ").any { it == normQuery } ||
                        normMarket.split(" ").any { it == normQuery } -> 4
                // 5. Name starts with query
                normEnglish.startsWith(normQuery) || normArabic.startsWith(normQuery) -> 5
                // 6. Market name starts with query
                normMarket.startsWith(normQuery) -> 6
                // 7. Name contains query
                normEnglish.contains(normQuery) || normArabic.contains(normQuery) -> 7
                // 8. Other partial matches
                else -> 8
            }

            matchedTests.add(ScoredTest(test, rankScore))
        }

        return matchedTests.sortedWith(compareBy<ScoredTest> { it.rankScore }.thenBy { it.test.id }).map { it.test }
    }
}
