package com.example.data.model

data class Customer(
    val id: String,
    val fileNumber: String,
    val name: String,
    val phone: String,
    val age: String,
    val gender: String,
    val notes: String,
    val createdAtMillis: Long,
    val updatedAtMillis: Long,
    val isBlacklisted: Boolean = false,
    val blacklistReason: String = "",
    val blacklistedAtMillis: Long = 0L,
    val isArchived: Boolean = false,
    val archivedAtMillis: Long = 0L
)

data class CustomerOrderItem(
    val testId: Int,
    val englishName: String,
    val arabicName: String,
    val marketName: String,
    val customerPrice: Double
)

data class CustomerOrder(
    val id: String,
    val orderNumber: String,
    val customerId: String,
    val customerFileNumber: String,
    val customerName: String,
    val items: List<CustomerOrderItem>,
    val subtotalCustomerPrice: Double = 0.0,
    val discountAmount: Double = 0.0,
    val discountPercent: Double = 0.0,
    val totalCustomerPrice: Double,
    val paymentStatus: String = "unpaid",
    val paidAmount: Double = 0.0,
    val remainingAmount: Double = 0.0,
    val notes: String = "",
    val createdAtMillis: Long,
    val createdByUid: String
)
