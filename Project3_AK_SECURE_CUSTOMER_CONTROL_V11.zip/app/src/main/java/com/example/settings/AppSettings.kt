package com.example.settings

import android.content.Context
import androidx.compose.runtime.staticCompositionLocalOf
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * App-wide controls owned by the manager. They are stored locally on the device and
 * applied to all users of this installation, while the Settings UI itself is manager-only.
 */
data class AppSettings(
    val securityEnabled: Boolean = true,
    val autoLockSeconds: Int = 0,
    val darkMode: Boolean = false,
    val fontScale: Float = 1.0f,
    val showEnglishName: Boolean = true,
    val showArabicName: Boolean = true,
    val showMarketName: Boolean = true,
    val showCustomerPrice: Boolean = true,
    val showLab2LabPrice: Boolean = true,
    val pdfIncludeCustomerPrice: Boolean = true,
    val pdfIncludeLab2LabPrice: Boolean = true,
    val pdfShowTotals: Boolean = true,
    val pdfLabName: String = "تحاليل العقاد",
    val pdfShowContactInfo: Boolean = false,
    val pdfContactInfo: String = "",
    val lastSyncMillis: Long = 0L
)


val LocalAppSettings = staticCompositionLocalOf { AppSettings() }

class AppSettingsStore(context: Context) {
    private val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    private val _settings = MutableStateFlow(load())
    val settings: StateFlow<AppSettings> = _settings.asStateFlow()

    fun save(settings: AppSettings) {
        val safeSettings = settings.copy(
            fontScale = settings.fontScale.coerceIn(0.85f, 1.25f),
            autoLockSeconds = settings.autoLockSeconds.coerceAtLeast(0)
        )

        prefs.edit()
            .putBoolean(KEY_SECURITY_ENABLED, safeSettings.securityEnabled)
            .putInt(KEY_AUTO_LOCK_SECONDS, safeSettings.autoLockSeconds)
            .putBoolean(KEY_DARK_MODE, safeSettings.darkMode)
            .putFloat(KEY_FONT_SCALE, safeSettings.fontScale)
            .putBoolean(KEY_SHOW_ENGLISH, safeSettings.showEnglishName)
            .putBoolean(KEY_SHOW_ARABIC, safeSettings.showArabicName)
            .putBoolean(KEY_SHOW_MARKET, safeSettings.showMarketName)
            .putBoolean(KEY_SHOW_CUSTOMER_PRICE, safeSettings.showCustomerPrice)
            .putBoolean(KEY_SHOW_LAB_PRICE, safeSettings.showLab2LabPrice)
            .putBoolean(KEY_PDF_CUSTOMER_PRICE, safeSettings.pdfIncludeCustomerPrice)
            .putBoolean(KEY_PDF_LAB_PRICE, safeSettings.pdfIncludeLab2LabPrice)
            .putBoolean(KEY_PDF_TOTALS, safeSettings.pdfShowTotals)
            .putString(KEY_PDF_LAB_NAME, safeSettings.pdfLabName)
            .putBoolean(KEY_PDF_CONTACT_ENABLED, safeSettings.pdfShowContactInfo)
            .putString(KEY_PDF_CONTACT_INFO, safeSettings.pdfContactInfo)
            .putLong(KEY_LAST_SYNC, safeSettings.lastSyncMillis)
            .apply()

        _settings.value = safeSettings
    }

    fun update(transform: (AppSettings) -> AppSettings) {
        save(transform(_settings.value))
    }

    fun markSynced(timeMillis: Long = System.currentTimeMillis()) {
        update { it.copy(lastSyncMillis = timeMillis) }
    }

    fun reset() {
        val preservedSync = _settings.value.lastSyncMillis
        save(AppSettings(lastSyncMillis = preservedSync))
    }

    private fun load(): AppSettings {
        return AppSettings(
            securityEnabled = prefs.getBoolean(KEY_SECURITY_ENABLED, true),
            autoLockSeconds = prefs.getInt(KEY_AUTO_LOCK_SECONDS, 0),
            darkMode = prefs.getBoolean(KEY_DARK_MODE, false),
            fontScale = prefs.getFloat(KEY_FONT_SCALE, 1.0f),
            showEnglishName = prefs.getBoolean(KEY_SHOW_ENGLISH, true),
            showArabicName = prefs.getBoolean(KEY_SHOW_ARABIC, true),
            showMarketName = prefs.getBoolean(KEY_SHOW_MARKET, true),
            showCustomerPrice = prefs.getBoolean(KEY_SHOW_CUSTOMER_PRICE, true),
            showLab2LabPrice = prefs.getBoolean(KEY_SHOW_LAB_PRICE, true),
            pdfIncludeCustomerPrice = prefs.getBoolean(KEY_PDF_CUSTOMER_PRICE, true),
            pdfIncludeLab2LabPrice = prefs.getBoolean(KEY_PDF_LAB_PRICE, true),
            pdfShowTotals = prefs.getBoolean(KEY_PDF_TOTALS, true),
            pdfLabName = prefs.getString(KEY_PDF_LAB_NAME, "تحاليل العقاد").orEmpty().ifBlank { "تحاليل العقاد" },
            pdfShowContactInfo = prefs.getBoolean(KEY_PDF_CONTACT_ENABLED, false),
            pdfContactInfo = prefs.getString(KEY_PDF_CONTACT_INFO, "").orEmpty(),
            lastSyncMillis = prefs.getLong(KEY_LAST_SYNC, 0L)
        )
    }

    private companion object {
        const val PREFS_NAME = "tahalil_manager_settings_v5"
        const val KEY_SECURITY_ENABLED = "security_enabled"
        const val KEY_AUTO_LOCK_SECONDS = "auto_lock_seconds"
        const val KEY_DARK_MODE = "dark_mode"
        const val KEY_FONT_SCALE = "font_scale"
        const val KEY_SHOW_ENGLISH = "show_english"
        const val KEY_SHOW_ARABIC = "show_arabic"
        const val KEY_SHOW_MARKET = "show_market"
        const val KEY_SHOW_CUSTOMER_PRICE = "show_customer_price"
        const val KEY_SHOW_LAB_PRICE = "show_lab_price"
        const val KEY_PDF_CUSTOMER_PRICE = "pdf_customer_price"
        const val KEY_PDF_LAB_PRICE = "pdf_lab_price"
        const val KEY_PDF_TOTALS = "pdf_totals"
        const val KEY_PDF_LAB_NAME = "pdf_lab_name"
        const val KEY_PDF_CONTACT_ENABLED = "pdf_contact_enabled"
        const val KEY_PDF_CONTACT_INFO = "pdf_contact_info"
        const val KEY_LAST_SYNC = "last_sync"
    }
}
