package com.example.notifications

import android.app.job.JobInfo
import android.app.job.JobParameters
import android.app.job.JobScheduler
import android.app.job.JobService
import android.content.ComponentName
import android.content.Context
import com.example.data.model.normalizeUserRole
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.Source

/**
 * Backend-free safety net for lab notifications.
 * Real-time alerts are delivered while the app is alive. This periodic job checks for
 * newly sent lab orders while the app is backgrounded. Android controls the exact run time
 * (minimum periodic interval is 15 minutes), so FCM remains the instant path when available.
 */
class LabOrderBackgroundService : JobService() {
    override fun onStartJob(params: JobParameters): Boolean {
        val user = FirebaseAuth.getInstance().currentUser ?: return false
        val db = FirebaseFirestore.getInstance()
        db.collection("users").document(user.uid).get(Source.SERVER)
            .addOnSuccessListener { profile ->
                val role = normalizeUserRole(profile.getString("role").orEmpty())
                val enabled = profile.getBoolean("enabled") == true
                if (role != "lab_operator" || !enabled) {
                    jobFinished(params, false)
                    return@addOnSuccessListener
                }

                val prefs = getSharedPreferences("lab_order_background_v106", Context.MODE_PRIVATE)
                val lastScan = prefs.getLong("last_scan_ms", 0L)
                val now = System.currentTimeMillis()

                val recentQuery = db.collectionGroup("orders")
                    .orderBy("created_at_ms", Query.Direction.DESCENDING)
                    .limit(150)

                recentQuery.get(Source.SERVER)
                    .addOnSuccessListener { snapshot ->
                        snapshot.documents.forEach { doc ->
                            val status = doc.getString("workflow_status").orEmpty()
                            val created = doc.getLong("created_at_ms") ?: 0L
                            if (status == "sent_to_lab" && created > lastScan) {
                                OrderNotificationManager.notifyNewLabOrderIfNeeded(
                                    applicationContext,
                                    doc.id,
                                    doc.getString("order_number").orEmpty(),
                                    doc.getString("customer_name").orEmpty()
                                )
                            }
                        }
                        prefs.edit().putLong("last_scan_ms", now).apply()
                        jobFinished(params, false)
                    }
                    .addOnFailureListener {
                        // Keep the old checkpoint; the next job can retry without losing orders.
                        jobFinished(params, true)
                    }
            }
            .addOnFailureListener { jobFinished(params, true) }
        return true
    }

    override fun onStopJob(params: JobParameters): Boolean = true
}

object LabOrderBackgroundScheduler {
    private const val JOB_ID = 10601
    private const val INTERVAL_MS = 15L * 60L * 1000L

    fun schedule(context: Context) {
        val scheduler = context.getSystemService(Context.JOB_SCHEDULER_SERVICE) as JobScheduler
        if (scheduler.allPendingJobs.any { it.id == JOB_ID }) return

        // The first background pass should only alert for orders arriving after scheduling.
        val prefs = context.getSharedPreferences("lab_order_background_v106", Context.MODE_PRIVATE)
        if (!prefs.contains("last_scan_ms")) {
            prefs.edit().putLong("last_scan_ms", System.currentTimeMillis()).apply()
        }

        val info = JobInfo.Builder(JOB_ID, ComponentName(context, LabOrderBackgroundService::class.java))
            .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
            .setPeriodic(INTERVAL_MS)
            .setPersisted(true)
            .build()
        scheduler.schedule(info)
    }

    fun cancel(context: Context) {
        val scheduler = context.getSystemService(Context.JOB_SCHEDULER_SERVICE) as JobScheduler
        scheduler.cancel(JOB_ID)
    }
}
