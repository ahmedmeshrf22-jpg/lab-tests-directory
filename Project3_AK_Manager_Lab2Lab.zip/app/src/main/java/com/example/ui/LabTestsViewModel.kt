package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.LabTest
import com.example.data.model.normalizeText
import com.example.data.repository.LabTestRepository
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreSettings
import com.google.firebase.firestore.Source
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class QueryGroup(
    val query: String,
    val candidates: List<LabTest>
)

sealed interface SearchUiState {
    object EmptyQuery : SearchUiState
    data class Success(
        val query: String,
        val queryGroups: List<QueryGroup>,
        val unmatchedQueries: List<String> = emptyList()
    ) : SearchUiState
    data class NoResults(
        val unmatchedQueries: List<String> = emptyList()
    ) : SearchUiState
}

class LabTestsViewModel(application: Application) : AndroidViewModel(application) {

    companion object {
        const val MANAGER_EMAIL = "abdelrahman@tahali.com"
        private const val LAB2LAB_COLLECTION = "lab2lab_prices"
    }

    private val repository = LabTestRepository(application)

    // Lab2Lab prices never live in the local JSON/APK. They are fetched only for the manager.
    // Persistence is disabled so another account on the same device cannot inherit a disk cache.
    @Suppress("DEPRECATION")
    private val firestore: FirebaseFirestore = FirebaseFirestore.getInstance().apply {
        firestoreSettings = FirebaseFirestoreSettings.Builder()
            .setPersistenceEnabled(false)
            .build()
    }

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _uiState = MutableStateFlow<SearchUiState>(SearchUiState.EmptyQuery)
    val uiState: StateFlow<SearchUiState> = _uiState.asStateFlow()

    private val _selectedTests = MutableStateFlow<List<LabTest>>(emptyList())
    val selectedTests: StateFlow<List<LabTest>> = _selectedTests.asStateFlow()

    private val _isManager = MutableStateFlow(false)
    val isManager: StateFlow<Boolean> = _isManager.asStateFlow()

    private val _lab2LabPrices = MutableStateFlow<Map<Int, String>>(emptyMap())
    val lab2LabPrices: StateFlow<Map<Int, String>> = _lab2LabPrices.asStateFlow()

    private var managerPricesLoaded = false

    init {
        viewModelScope.launch(Dispatchers.IO) {
            repository.getLabTests()
        }
    }

    /** Called whenever Firebase Auth user changes. */
    fun onAuthenticatedUserChanged(email: String?) {
        val manager = email?.trim()?.lowercase() == MANAGER_EMAIL

        if (!manager) {
            clearLab2LabState()
            return
        }

        _isManager.value = true
        if (managerPricesLoaded) return

        // Force a server read. If Firestore rules deny this user, no Lab2Lab data is shown.
        firestore.collection(LAB2LAB_COLLECTION)
            .get(Source.SERVER)
            .addOnSuccessListener { snapshot ->
                if (!_isManager.value) return@addOnSuccessListener

                val prices = mutableMapOf<Int, String>()
                snapshot.documents.forEach { doc ->
                    val id = doc.id.removePrefix("test_").toIntOrNull()
                        ?: doc.getLong("id")?.toInt()
                        ?: return@forEach

                    val value = doc.get("lab_to_lab_price") ?: return@forEach
                    val formatted = formatFirestorePrice(value)
                    if (!formatted.isNullOrBlank()) {
                        prices[id] = formatted
                    }
                }

                _lab2LabPrices.value = prices
                managerPricesLoaded = true
            }
            .addOnFailureListener {
                // Fail closed: never expose stale/local Lab2Lab values.
                _lab2LabPrices.value = emptyMap()
                managerPricesLoaded = false
            }
    }

    fun clearLab2LabState() {
        _isManager.value = false
        _lab2LabPrices.value = emptyMap()
        managerPricesLoaded = false
    }

    private fun formatFirestorePrice(value: Any?): String? {
        return when (value) {
            null -> null
            is Byte, is Short, is Int, is Long -> value.toString()
            is Float -> {
                val n = value.toDouble()
                if (n % 1.0 == 0.0) n.toLong().toString() else n.toString()
            }
            is Double -> if (value % 1.0 == 0.0) value.toLong().toString() else value.toString()
            is Number -> value.toString()
            else -> value.toString().trim().takeIf { it.isNotEmpty() && !it.equals("null", true) }
        }
    }

    private fun parseQueries(rawInput: String): List<String> {
        if (rawInput.isBlank()) return emptyList()
        val delimiterRegex = Regex("[\\n,،;؛]+")
        val rawTokens = rawInput.split(delimiterRegex)

        val seenNorm = mutableSetOf<String>()
        val result = mutableListOf<String>()

        for (token in rawTokens) {
            val trimmed = token.trim()
            if (trimmed.isEmpty()) continue
            val norm = normalizeText(trimmed)
            if (norm.isNotEmpty() && seenNorm.add(norm)) {
                result.add(trimmed)
            }
        }
        return result
    }

    fun onQueryChanged(newQuery: String) {
        _searchQuery.value = newQuery
        val trimmedInput = newQuery.trim()

        if (trimmedInput.isEmpty()) {
            _uiState.value = SearchUiState.EmptyQuery
            return
        }

        viewModelScope.launch(Dispatchers.Default) {
            val queries = parseQueries(newQuery)
            if (queries.isEmpty()) {
                _uiState.value = SearchUiState.EmptyQuery
                return@launch
            }

            val selectedIds = _selectedTests.value.map { it.id }.toSet()
            val queryGroups = mutableListOf<QueryGroup>()
            val unmatchedQueries = mutableListOf<String>()

            for (q in queries) {
                val matches = repository.searchTests(q).filter { it.id !in selectedIds }
                if (matches.isNotEmpty()) {
                    queryGroups.add(QueryGroup(query = q, candidates = matches))
                } else {
                    unmatchedQueries.add(q)
                }
            }

            if (queryGroups.isEmpty()) {
                _uiState.value = SearchUiState.NoResults(unmatchedQueries = unmatchedQueries)
            } else {
                _uiState.value = SearchUiState.Success(
                    query = newQuery,
                    queryGroups = queryGroups,
                    unmatchedQueries = unmatchedQueries
                )
            }
        }
    }

    fun addSelectedTest(test: LabTest) {
        if (_selectedTests.value.none { it.id == test.id }) {
            _selectedTests.value = _selectedTests.value + test
        }
        clearSearch()
    }

    fun removeSelectedTest(testId: Int) {
        _selectedTests.value = _selectedTests.value.filter { it.id != testId }
        if (_searchQuery.value.isNotEmpty()) {
            onQueryChanged(_searchQuery.value)
        }
    }

    fun clearSearch() {
        _searchQuery.value = ""
        _uiState.value = SearchUiState.EmptyQuery
    }
}
