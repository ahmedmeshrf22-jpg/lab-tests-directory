const { onDocumentUpdated } = require("firebase-functions/v2/firestore");
const { initializeApp } = require("firebase-admin/app");
const { getFirestore } = require("firebase-admin/firestore");
const { getMessaging } = require("firebase-admin/messaging");

initializeApp();

const statusAr = {
  new: "جديد",
  sent_to_lab: "تم الإرسال للمعمل",
  processing: "جاري التنفيذ",
  ready: "الطلب جاهز",
  delivered: "تم التسليم"
};

exports.notifyOrderStatusChanged = onDocumentUpdated(
  "customers/{customerId}/orders/{orderId}",
  async (event) => {
    const before = event.data.before.data() || {};
    const after = event.data.after.data() || {};
    if (before.workflow_status === after.workflow_status) return;

    const uid = after.created_by_uid;
    if (!uid) return;

    const tokenSnap = await getFirestore()
      .collection("users").doc(uid).collection("fcm_tokens").get();
    const tokens = tokenSnap.docs.map(d => d.get("token")).filter(Boolean);
    if (!tokens.length) return;

    const orderNo = after.order_number || event.params.orderId;
    const customerName = after.customer_name || "العميل";
    const label = statusAr[after.workflow_status] || after.workflow_status || "تم تحديث الطلب";
    const body = `${orderNo} • ${customerName} • ${label}`;

    const result = await getMessaging().sendEachForMulticast({
      tokens,
      notification: { title: "تحديث حالة الطلب", body },
      data: {
        title: "تحديث حالة الطلب",
        body,
        order_id: event.params.orderId,
        customer_id: event.params.customerId,
        workflow_status: String(after.workflow_status || "")
      },
      android: { priority: "high", notification: { channelId: "order_updates" } }
    });

    const bad = [];
    result.responses.forEach((r, i) => {
      if (!r.success && [
        "messaging/registration-token-not-registered",
        "messaging/invalid-registration-token"
      ].includes(r.error?.code)) bad.push(tokens[i]);
    });
    if (bad.length) {
      const batch = getFirestore().batch();
      tokenSnap.docs.forEach(doc => { if (bad.includes(doc.get("token"))) batch.delete(doc.ref); });
      await batch.commit();
    }
  }
);
