package com.example.data.migration

import android.content.Context

@Deprecated("Migration completed. This class is retained only as an unused stub.")
class Lab2LabMigrationManager(private val context: Context) {
    // Unused stub to preserve project file structure
}
