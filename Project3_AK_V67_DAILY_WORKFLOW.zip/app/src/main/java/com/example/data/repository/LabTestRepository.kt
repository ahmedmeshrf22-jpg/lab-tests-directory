package com.example.data.repository

import android.content.Context
import com.example.data.model.LabTest
import com.example.data.model.normalizeText
import org.json.JSONArray
import java.io.InputStreamReader

class LabTestRepository(private val context: Context) {

    @Volatile
    private var cachedTests: List<LabTest>? = null

    fun getLabTests(): List<LabTest> {
        cachedTests?.let { return it }

        return synchronized(this) {
            cachedTests?.let { return@synchronized it }

            val testsList = mutableListOf<LabTest>()
            try {
                val inputStream = context.assets.open("lab_tests_android.json")
                val jsonString = InputStreamReader(inputStream, Charsets.UTF_8).use { it.readText() }
                val jsonArray = JSONArray(jsonString)

                for (i in 0 until jsonArray.length()) {
                    val obj = jsonArray.getJSONObject(i)
                    val id = obj.optInt("id")
                    val englishName = obj.optString("english_name", "")
                    val arabicName = obj.optString("arabic_name", "")
                    val marketName = obj.optString("market_name", "")
                    val searchText = obj.optString("search_text", "")

                    val customerPriceRaw = if (obj.isNull("customer_price")) null else obj.get("customer_price").toString()
                    val customerPrice = formatPrice(customerPriceRaw)

                    testsList.add(
                        LabTest(
                            id = id,
                            englishName = englishName,
                            arabicName = arabicName,
                            marketName = marketName,
                            customerPrice = customerPrice,
                            searchText = searchText
                        )
                    )
                }
            } catch (_: Exception) {
                // Do not emit dataset details or stack traces in release logs.
            }

            cachedTests = testsList
            testsList
        }
    }

    private fun formatPrice(priceStr: String?): String? {
        if (priceStr.isNullOrBlank() || priceStr.equals("null", ignoreCase = true)) return null
        return priceStr.trim()
    }


    /**
     * V66 manual-search vocabulary. These aliases are intentionally conservative and
     * resolve to exact catalogue names, so common clinic abbreviations do not become
     * broad substring searches (for example INR must resolve to PT, not every test
     * containing the letters "inr").
     */
    private fun aliasTargets(normQuery: String): List<String>? {
        val q = removeArabicArticles(normQuery)
        return when (q) {
            "rbs", "random blood sugar", "random sugar", "سكر عشوائي" ->
                listOf("Glucose Random")
            "fbs", "fasting blood sugar", "fasting sugar", "سكر صائم", "سكر صايم" ->
                listOf("Blood Glucose Fasting")
            "hba1c", "hb a1c", "a1c", "سكر تراكمي" ->
                listOf("Glycated Haemoglobin (HbA1c)")
            "sgpt", "alt" -> listOf("ALT (SGPT)")
            "sgot", "ast" -> listOf("AST (SGOT)")
            "inr" -> listOf("Prothrombin Time & Conc")
            "blood group", "blood grouping", "فصيله دم" -> listOf("ABO", "Rh")
            "وظائف كبد", "انزيم كبد", "انزيمات كبد", "lft", "liver function", "liver functions" ->
                listOf("ALT (SGPT)", "AST (SGOT)")
            "وظائف كلي", "وظائف كليه", "kft", "kidney function", "kidney functions", "renal function", "renal functions" ->
                listOf("Creatinine", "Blood Urea")
            "hbv", "hepatitis b" -> listOf("HBs Ag")
            "hcv", "hepatitis c" -> listOf("HCV Ab")
            "hiv", "aids" -> listOf("HIV Ab")
            "vit d", "vitamin d", "فيتامين د" -> listOf("Vit D3 (25 Hydroxycholecalciferol)")
            "b12", "vit b12", "vitamin b12", "فيتامين ب12" -> listOf("VIT B12 (Cyanocobalamine)")
            "مخزون حديد", "ferritin" -> listOf("Ferritin")
            "lipid profile", "lipids profile", "تحليل دهون", "دهون كامله" -> listOf("Lipids Profile")
            "وظائف غده درقيه", "thyroid function", "thyroid functions", "tft" -> listOf("TSH", "Free T4")
            else -> null
        }
    }

    private fun removeArabicArticles(value: String): String {
        if (value.isBlank()) return value
        return value.split(" ")
            .joinToString(" ") { token ->
                if (token.startsWith("ال") && token.length > 3) token.removePrefix("ال") else token
            }
            .trim()
    }

    private fun resolveExactCatalogueNames(names: List<String>, allTests: List<LabTest>): List<LabTest> {
        val wanted = names.map(::normalizeText)
        return wanted.mapNotNull { target ->
            allTests.firstOrNull { test ->
                test.normEnglish == target || test.normMarket == target || test.normArabic == target
            }
        }.distinctBy { it.id }
    }

    fun searchTests(query: String): List<LabTest> {
        val trimmedQuery = query.trim()
        if (trimmedQuery.isEmpty()) return emptyList()

        val normQuery = normalizeText(trimmedQuery)
        if (normQuery.isEmpty()) return emptyList()

        val allTests = getLabTests()

        // V66: explicit clinic aliases win before fuzzy substring matching.
        aliasTargets(normQuery)?.let { targetNames ->
            val resolved = resolveExactCatalogueNames(targetNames, allTests)
            if (resolved.isNotEmpty()) return resolved
        }

        val queryWithoutArticles = removeArabicArticles(normQuery)

        data class ScoredTest(val test: LabTest, val rankScore: Int)
        val matchedTests = mutableListOf<ScoredTest>()

        for (test in allTests) {
            val normEnglish = test.normEnglish
            val normArabic = test.normArabic
            val normMarket = test.normMarket
            val normSearch = test.normSearch

            val articleFreeArabic = removeArabicArticles(normArabic)
            val articleFreeMarket = removeArabicArticles(normMarket)
            val articleFreeSearch = removeArabicArticles(normSearch)

            val directMatch = normEnglish.contains(normQuery) ||
                normArabic.contains(normQuery) ||
                normMarket.contains(normQuery) ||
                normSearch.contains(normQuery)

            val articleTolerantMatch = queryWithoutArticles.isNotBlank() && (
                articleFreeArabic.contains(queryWithoutArticles) ||
                    articleFreeMarket.contains(queryWithoutArticles) ||
                    articleFreeSearch.contains(queryWithoutArticles)
                )

            if (!directMatch && !articleTolerantMatch) continue

            val rankScore: Int = when {
                normEnglish == normQuery -> 1
                normArabic == normQuery -> 2
                normMarket == normQuery -> 3
                articleFreeArabic == queryWithoutArticles || articleFreeMarket == queryWithoutArticles -> 4
                normEnglish.split(" ").any { it == normQuery } ||
                    normArabic.split(" ").any { it == normQuery } ||
                    normMarket.split(" ").any { it == normQuery } -> 5
                normEnglish.startsWith(normQuery) || normArabic.startsWith(normQuery) -> 6
                normMarket.startsWith(normQuery) -> 7
                normEnglish.contains(normQuery) || normArabic.contains(normQuery) -> 8
                articleTolerantMatch -> 9
                else -> 10
            }

            matchedTests.add(ScoredTest(test, rankScore))
        }

        return matchedTests
            .sortedWith(compareBy<ScoredTest> { it.rankScore }.thenBy { it.test.id })
            .map { it.test }
    }
}
