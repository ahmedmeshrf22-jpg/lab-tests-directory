package com.example.ui

import androidx.activity.compose.BackHandler
import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.ManageAccounts
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.BuildConfig
import com.example.settings.AppSettings
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ManagerSettingsDialog(
    viewModel: LabTestsViewModel,
    settings: AppSettings,
    currentUserEmail: String?,
    currentUserUid: String?,
    onDismiss: () -> Unit,
    onOpenManagerDashboard: () -> Unit,
    onLogout: (() -> Unit)?
) {
    val context = LocalContext.current
    var syncing by remember { mutableStateOf(false) }
    var syncMessage by remember { mutableStateOf<String?>(null) }

    BackHandler(enabled = true) { onDismiss() }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false, dismissOnBackPress = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .padding(10.dp),
            shape = RoundedCornerShape(24.dp),
            color = if (settings.darkMode) Color(0xFF0F172A) else Color(0xFFF5F7FB),
            shadowElevation = 8.dp
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "إعدادات التطبيق",
                            fontSize = 22.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = if (settings.darkMode) Color.White else Color(0xFF102A43)
                        )
                        Text(
                            text = "متاحة لحساب المدير فقط",
                            fontSize = 12.sp,
                            color = if (settings.darkMode) Color(0xFFCBD5E1) else Color(0xFF64748B)
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "إغلاق",
                            tint = if (settings.darkMode) Color.White else Color(0xFF334155)
                        )
                    }
                }

                HorizontalDivider(color = if (settings.darkMode) Color(0xFF334155) else Color(0xFFE2E8F0))

                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(14.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item {
                        SettingsSectionCard(title = "الحساب", icon = Icons.Default.ManageAccounts) {
                            SettingsInfoRow("البريد الإلكتروني", currentUserEmail ?: "—")
                            SettingsInfoRow("نوع الحساب", "مدير النظام")
                            SettingsInfoRow("User UID", currentUserUid ?: "—")
                            if (onLogout != null) {
                                Spacer(Modifier.height(8.dp))
                                OutlinedButton(
                                    onClick = onLogout,
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Icon(Icons.AutoMirrored.Filled.Logout, null, modifier = Modifier.size(18.dp))
                                    Spacer(Modifier.width(7.dp))
                                    Text("تسجيل الخروج")
                                }
                            }
                        }
                    }

                    item {
                        SettingsSectionCard(title = "الأمان", icon = Icons.Default.Lock) {
                            SettingsSwitchRow(
                                title = "قفل التطبيق",
                                subtitle = "استخدام البصمة أو رمز قفل الهاتف عند فتح التطبيق",
                                checked = settings.securityEnabled,
                                onCheckedChange = {
                                    viewModel.updateAppSettings(settings.copy(securityEnabled = it))
                                }
                            )

                            if (settings.securityEnabled) {
                                Spacer(Modifier.height(8.dp))
                                Text(
                                    text = "القفل التلقائي",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF334155)
                                )
                                Spacer(Modifier.height(8.dp))
                                ChoiceButtons(
                                    choices = listOf(
                                        0 to "فورًا",
                                        60 to "دقيقة",
                                        300 to "5 دقائق",
                                        900 to "15 دقيقة"
                                    ),
                                    selected = settings.autoLockSeconds,
                                    onSelected = {
                                        viewModel.updateAppSettings(settings.copy(autoLockSeconds = it))
                                    }
                                )
                                Spacer(Modifier.height(8.dp))
                                TextButton(
                                    onClick = {
                                        runCatching {
                                            context.startActivity(Intent(Settings.ACTION_SECURITY_SETTINGS))
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text("فتح إعدادات البصمة / PIN في الهاتف")
                                }
                            }
                        }
                    }

                    item {
                        SettingsSectionCard(title = "المظهر", icon = Icons.Default.Palette) {
                            SettingsSwitchRow(
                                title = "الوضع الداكن",
                                subtitle = "تغيير خلفية التطبيق ووضع العرض",
                                checked = settings.darkMode,
                                onCheckedChange = {
                                    viewModel.updateAppSettings(settings.copy(darkMode = it))
                                },
                                icon = Icons.Default.DarkMode
                            )
                            Spacer(Modifier.height(8.dp))
                            Text(
                                text = "حجم الخط",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF334155)
                            )
                            Spacer(Modifier.height(8.dp))
                            ChoiceButtons(
                                choices = listOf(0.90f to "صغير", 1.0f to "متوسط", 1.15f to "كبير"),
                                selected = settings.fontScale,
                                onSelected = {
                                    viewModel.updateAppSettings(settings.copy(fontScale = it))
                                }
                            )
                        }
                    }

                    item {
                        SettingsSectionCard(title = "إعدادات البحث", icon = Icons.Default.Search) {
                            SettingsSwitchRow(
                                "إظهار الاسم الإنجليزي",
                                "يظهر الاسم الإنجليزي في نتائج البحث",
                                settings.showEnglishName,
                                onCheckedChange = { enabled ->
                                    if (enabled || settings.showArabicName || settings.showMarketName) {
                                        viewModel.updateAppSettings(settings.copy(showEnglishName = enabled))
                                    }
                                }
                            )
                            SettingsSwitchRow(
                                "إظهار الاسم العربي",
                                "يظهر الاسم العربي في نتائج البحث",
                                settings.showArabicName,
                                onCheckedChange = { enabled ->
                                    if (enabled || settings.showEnglishName || settings.showMarketName) {
                                        viewModel.updateAppSettings(settings.copy(showArabicName = enabled))
                                    }
                                }
                            )
                            SettingsSwitchRow(
                                "إظهار الاسم الدارج",
                                "إظهار الاسم المستخدم في السوق المصري عند توفره",
                                settings.showMarketName,
                                onCheckedChange = { enabled ->
                                    if (enabled || settings.showEnglishName || settings.showArabicName) {
                                        viewModel.updateAppSettings(settings.copy(showMarketName = enabled))
                                    }
                                }
                            )
                        }
                    }

                    item {
                        SettingsSectionCard(title = "عرض الأسعار", icon = Icons.Default.Settings) {
                            SettingsSwitchRow(
                                "سعر العميل",
                                "إظهار سعر العميل في نتائج البحث والسلة",
                                settings.showCustomerPrice,
                                onCheckedChange = {
                                    viewModel.updateAppSettings(settings.copy(showCustomerPrice = it))
                                }
                            )
                            SettingsSwitchRow(
                                "Lab 2 Lab",
                                "إظهار سعر Lab 2 Lab للمدير في النتائج والسلة",
                                settings.showLab2LabPrice,
                                onCheckedChange = {
                                    viewModel.updateAppSettings(settings.copy(showLab2LabPrice = it))
                                }
                            )
                        }
                    }

                    item {
                        SettingsSectionCard(title = "إعدادات PDF", icon = Icons.Default.Description) {
                            OutlinedTextField(
                                value = settings.pdfLabName,
                                onValueChange = {
                                    viewModel.updateAppSettings(settings.copy(pdfLabName = it.take(60)))
                                },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true,
                                label = { Text("اسم المعمل / العيادة في PDF") },
                                shape = RoundedCornerShape(12.dp)
                            )
                            Spacer(Modifier.height(8.dp))
                            SettingsSwitchRow(
                                "سعر العميل في PDF",
                                "إظهار عمود سعر العميل",
                                settings.pdfIncludeCustomerPrice,
                                onCheckedChange = {
                                    viewModel.updateAppSettings(settings.copy(pdfIncludeCustomerPrice = it))
                                }
                            )
                            SettingsSwitchRow(
                                "Lab 2 Lab في PDF",
                                "إظهار العمود السري في PDF المدير",
                                settings.pdfIncludeLab2LabPrice,
                                onCheckedChange = {
                                    viewModel.updateAppSettings(settings.copy(pdfIncludeLab2LabPrice = it))
                                }
                            )
                            SettingsSwitchRow(
                                "إظهار الإجمالي",
                                "إضافة إجمالي الأسعار في نهاية PDF",
                                settings.pdfShowTotals,
                                onCheckedChange = {
                                    viewModel.updateAppSettings(settings.copy(pdfShowTotals = it))
                                }
                            )
                            SettingsSwitchRow(
                                "بيانات التواصل",
                                "إضافة بيانات التواصل أسفل التقرير",
                                settings.pdfShowContactInfo,
                                onCheckedChange = {
                                    viewModel.updateAppSettings(settings.copy(pdfShowContactInfo = it))
                                }
                            )
                            if (settings.pdfShowContactInfo) {
                                OutlinedTextField(
                                    value = settings.pdfContactInfo,
                                    onValueChange = {
                                        viewModel.updateAppSettings(settings.copy(pdfContactInfo = it.take(180)))
                                    },
                                    modifier = Modifier.fillMaxWidth(),
                                    minLines = 2,
                                    maxLines = 4,
                                    label = { Text("بيانات التواصل") },
                                    shape = RoundedCornerShape(12.dp)
                                )
                            }
                        }
                    }

                    item {
                        SettingsSectionCard(title = "المزامنة والبيانات", icon = Icons.Default.Sync) {
                            SettingsInfoRow("آخر تحديث", formatLastSync(settings.lastSyncMillis))
                            if (!syncMessage.isNullOrBlank()) {
                                Spacer(Modifier.height(6.dp))
                                Text(
                                    text = syncMessage.orEmpty(),
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (syncMessage?.startsWith("تم") == true) Color(0xFF15803D) else Color(0xFFB91C1C)
                                )
                            }
                            Spacer(Modifier.height(8.dp))
                            Button(
                                onClick = {
                                    syncing = true
                                    syncMessage = null
                                    viewModel.refreshPrices { _, message ->
                                        syncing = false
                                        syncMessage = message
                                    }
                                },
                                enabled = !syncing,
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF006D86))
                            ) {
                                if (syncing) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(18.dp),
                                        strokeWidth = 2.dp,
                                        color = Color.White
                                    )
                                } else {
                                    Icon(Icons.Default.Refresh, null, modifier = Modifier.size(18.dp))
                                }
                                Spacer(Modifier.width(7.dp))
                                Text(if (syncing) "جاري التحديث..." else "تحديث الأسعار الآن")
                            }
                        }
                    }

                    item {
                        SettingsSectionCard(title = "الإدارة", icon = Icons.Default.AdminPanelSettings) {
                            Button(
                                onClick = onOpenManagerDashboard,
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6D28D9))
                            ) {
                                Icon(Icons.Default.AdminPanelSettings, null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(7.dp))
                                Text("فتح لوحة تحكم المدير")
                            }
                        }
                    }

                    item {
                        SettingsSectionCard(title = "عن التطبيق", icon = Icons.Default.Info) {
                            SettingsInfoRow("الإصدار", BuildConfig.VERSION_NAME)
                            SettingsInfoRow("رقم البناء", BuildConfig.VERSION_CODE.toString())
                            SettingsInfoRow("التطبيق", "تحاليل العقاد")
                            Spacer(Modifier.height(8.dp))
                            TextButton(
                                onClick = { viewModel.resetAppSettings() },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(Icons.Default.RestartAlt, null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("إرجاع الإعدادات للوضع الافتراضي")
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsSectionCard(
    title: String,
    icon: ImageVector,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, Color(0xFFE2E8F0))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, null, tint = Color(0xFF006D86), modifier = Modifier.size(21.dp))
                Spacer(Modifier.width(8.dp))
                Text(
                    text = title,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color(0xFF102A43)
                )
            }
            Spacer(Modifier.height(10.dp))
            content()
        }
    }
}

@Composable
private fun SettingsSwitchRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    icon: ImageVector? = null
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (icon != null) {
            Icon(icon, null, tint = Color(0xFF64748B), modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(7.dp))
        }
        Column(modifier = Modifier.weight(1f)) {
            Text(title, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1E293B))
            Text(subtitle, fontSize = 11.sp, color = Color(0xFF64748B), lineHeight = 15.sp)
        }
        Spacer(Modifier.width(8.dp))
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

@Composable
private fun SettingsInfoRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF64748B))
        Spacer(Modifier.width(10.dp))
        Text(
            value,
            modifier = Modifier.weight(1f),
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            color = Color(0xFF1E293B),
            textAlign = androidx.compose.ui.text.style.TextAlign.End
        )
    }
}

@Composable
private fun <T> ChoiceButtons(
    choices: List<Pair<T, String>>,
    selected: T,
    onSelected: (T) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        choices.forEach { (value, label) ->
            val selectedNow = value == selected
            OutlinedButton(
                onClick = { onSelected(value) },
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(horizontal = 4.dp, vertical = 7.dp),
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, if (selectedNow) Color(0xFF006D86) else Color(0xFFCBD5E1)),
                colors = ButtonDefaults.outlinedButtonColors(
                    containerColor = if (selectedNow) Color(0xFFE6F6F8) else Color.White,
                    contentColor = if (selectedNow) Color(0xFF005766) else Color(0xFF475569)
                )
            ) {
                Text(label, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

private fun formatLastSync(timestamp: Long): String {
    if (timestamp <= 0L) return "لم يتم التحديث يدويًا بعد"
    return runCatching {
        SimpleDateFormat("dd/MM/yyyy - hh:mm a", Locale("ar", "EG")).format(Date(timestamp))
    }.getOrDefault("تم التحديث")
}
