package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.outlined.Biotech
import androidx.compose.material.icons.outlined.SearchOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.LabTest
import com.example.util.PdfGenerator

@Composable
fun LabTestsApp(
    viewModel: LabTestsViewModel,
    currentUserEmail: String? = null,
    onLogout: (() -> Unit)? = null
) {
    // Force RTL layout for Arabic-first experience
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        val searchQuery by viewModel.searchQuery.collectAsState()
        val uiState by viewModel.uiState.collectAsState()
        val selectedTests by viewModel.selectedTests.collectAsState()
        val isManager by viewModel.isManager.collectAsState()
        val lab2LabPrices by viewModel.lab2LabPrices.collectAsState()

        LaunchedEffect(currentUserEmail) {
            viewModel.onAuthenticatedUserChanged(currentUserEmail)
        }

        Scaffold(
            topBar = { TopHeader(onLogout = onLogout) },
            containerColor = Color(0xFFFDFBFF)
        ) { paddingValues ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .padding(horizontal = 16.dp)
            ) {
                Spacer(modifier = Modifier.height(12.dp))

                SearchBox(
                    query = searchQuery,
                    onQueryChange = { viewModel.onQueryChanged(it) },
                    onClear = { viewModel.clearSearch() }
                )

                Spacer(modifier = Modifier.height(16.dp))

                MainContent(
                    uiState = uiState,
                    selectedTests = selectedTests,
                    isManager = isManager,
                    lab2LabPrices = lab2LabPrices,
                    onSelectTest = { test -> viewModel.addSelectedTest(test) },
                    onRemoveTest = { testId -> viewModel.removeSelectedTest(testId) }
                )
            }
        }
    }
}

@Composable
private fun TopHeader(onLogout: (() -> Unit)? = null) {
    Surface(
        color = Color.White,
        shadowElevation = 2.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "دليل التحاليل والأسعار",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF001D35),
                    letterSpacing = (-0.5).sp
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "ابحث عن أي تحليل بالاسم العربي أو الإنجليزي",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium,
                    color = Color(0xFF64748B)
                )
            }

            if (onLogout != null) {
                TextButton(
                    onClick = onLogout,
                    modifier = Modifier.testTag("logout_button"),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.Logout,
                        contentDescription = "تسجيل الخروج",
                        tint = Color(0xFFBA1A1A),
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "تسجيل الخروج",
                        color = Color(0xFFBA1A1A),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
private fun SearchBox(
    query: String,
    onQueryChange: (String) -> Unit,
    onClear: () -> Unit
) {
    val keyboardController = LocalSoftwareKeyboardController.current

    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        shadowElevation = 4.dp,
        color = Color(0xFFF3F4F9)
    ) {
        OutlinedTextField(
            value = query,
            onValueChange = onQueryChange,
            enabled = true,
            readOnly = false,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("search_text_field"),
            placeholder = {
                Text(
                    text = "اكتب أو الصق أسماء التحاليل — كل تحليل في سطر أو افصل بينهم بفاصلة",
                    color = Color(0xFF94A3B8),
                    fontSize = 13.sp,
                    lineHeight = 18.sp
                )
            },
            leadingIcon = {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = "بحث",
                    tint = Color(0xFF0061A4)
                )
            },
            trailingIcon = {
                if (query.isNotEmpty()) {
                    IconButton(
                        onClick = onClear,
                        modifier = Modifier.testTag("clear_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "مسح البحث",
                            tint = Color(0xFF64748B)
                        )
                    }
                }
            },
            singleLine = false,
            maxLines = 4,
            shape = RoundedCornerShape(20.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = Color.Transparent,
                unfocusedContainerColor = Color.Transparent,
                disabledContainerColor = Color.Transparent,
                focusedBorderColor = Color(0xFF0061A4),
                unfocusedBorderColor = Color.Transparent,
                focusedTextColor = Color(0xFF001D35),
                unfocusedTextColor = Color(0xFF001D35)
            ),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Default),
            keyboardActions = KeyboardActions(onSearch = { keyboardController?.hide() })
        )
    }
}

@Composable
private fun ResultCountChip(count: Int) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.Start,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .clip(CircleShape)
                .background(Color(0xFFE1F1FF))
                .padding(horizontal = 14.dp, vertical = 6.dp)
        ) {
            Text(
                text = "$count نتائج",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF0061A4)
            )
        }
    }
}

private fun calculatePriceTotal(tests: List<LabTest>, priceSelector: (LabTest) -> String?): Double {
    var total = 0.0
    val regex = Regex("""\d+(\.\d+)?""")
    for (test in tests) {
        val priceStr = priceSelector(test)
        if (!priceStr.isNullOrBlank()) {
            val match = regex.find(priceStr)
            val valDouble = match?.value?.toDoubleOrNull()
            if (valDouble != null) {
                total += valDouble
            }
        }
    }
    return total
}

private fun formatTotalDisplay(total: Double): String {
    return if (total % 1.0 == 0.0) {
        total.toLong().toString()
    } else {
        String.format("%.2f", total)
    }
}

@Composable
private fun MainContent(
    uiState: SearchUiState,
    selectedTests: List<LabTest>,
    isManager: Boolean,
    lab2LabPrices: Map<Int, String>,
    onSelectTest: (LabTest) -> Unit,
    onRemoveTest: (Int) -> Unit
) {
    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(16.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        // 1. Selected Tests Section ("التحاليل المختارة")
        if (selectedTests.isNotEmpty()) {
            item(key = "selected_tests_section") {
                SelectedTestsSection(
                    selectedTests = selectedTests,
                    isManager = isManager,
                    lab2LabPrices = lab2LabPrices,
                    onRemoveTest = onRemoveTest
                )
            }
        }

        // 2. Search States
        when (uiState) {
            is SearchUiState.EmptyQuery -> {
                if (selectedTests.isEmpty()) {
                    item(key = "empty_state") {
                        EmptyStateView()
                    }
                }
            }
            is SearchUiState.NoResults -> {
                item(key = "no_results_section") {
                    NoResultsSection(unmatchedQueries = uiState.unmatchedQueries)
                }
            }
            is SearchUiState.Success -> {
                item(key = "search_header") {
                    Text(
                        text = "نتائج البحث (${uiState.queryGroups.sumOf { it.candidates.size }})",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0061A4),
                        modifier = Modifier.padding(vertical = 4.dp)
                    )
                }

                items(uiState.queryGroups, key = { it.query }) { group ->
                    QueryGroupSection(
                        group = group,
                        isManager = isManager,
                        lab2LabPrices = lab2LabPrices,
                        onSelectTest = onSelectTest
                    )
                }

                if (uiState.unmatchedQueries.isNotEmpty()) {
                    item(key = "unmatched_queries") {
                        UnmatchedQueriesCard(unmatchedQueries = uiState.unmatchedQueries)
                    }
                }
            }
        }

        item(key = "bottom_spacer") {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
private fun SelectedTestsSection(
    selectedTests: List<LabTest>,
    isManager: Boolean,
    lab2LabPrices: Map<Int, String>,
    onRemoveTest: (Int) -> Unit
) {
    val totalPrice = calculatePriceTotal(selectedTests) { it.customerPrice }
    val totalLab2LabPrice = if (isManager) {
        calculatePriceTotal(selectedTests) { lab2LabPrices[it.id] }
    } else {
        0.0
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(
                elevation = 4.dp,
                shape = RoundedCornerShape(20.dp),
                spotColor = Color(0x1A000000)
            ),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.5.dp, Color(0xFF0061A4))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // Section Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = Color(0xFF0061A4),
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "التحاليل المختارة",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF001D35)
                    )
                }
                Box(
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(Color(0xFFE1F1FF))
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "${selectedTests.size}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0061A4)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Selected items list
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                selectedTests.forEach { test ->
                    SelectedTestRow(
                        test = test,
                        isManager = isManager,
                        lab2LabPrice = lab2LabPrices[test.id],
                        onRemove = { onRemoveTest(test.id) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Total Price Section
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color(0xFF0061A4))
                    .padding(14.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (isManager) "إجمالي سعر العميل" else "الإجمالي",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Row(verticalAlignment = Alignment.Bottom) {
                            Text(
                                text = formatTotalDisplay(totalPrice),
                                fontSize = 20.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color.White
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "جنيه",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                modifier = Modifier.padding(bottom = 2.dp)
                            )
                        }
                    }

                    if (isManager) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "إجمالي Lab 2 Lab",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Row(verticalAlignment = Alignment.Bottom) {
                                Text(
                                    text = formatTotalDisplay(totalLab2LabPrice),
                                    fontSize = 19.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = Color.White
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "جنيه",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    modifier = Modifier.padding(bottom = 2.dp)
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // PDF Generation Button
            val context = LocalContext.current
            Button(
                onClick = {
                    PdfGenerator.generateAndSharePdf(
                        context = context,
                        selectedTests = selectedTests,
                        includeLab2Lab = isManager,
                        lab2LabPrices = lab2LabPrices
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("generate_pdf_button"),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF15803D)
                )
            ) {
                Icon(
                    imageVector = Icons.Default.PictureAsPdf,
                    contentDescription = "PDF Icon",
                    tint = Color.White,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "إنشاء PDF",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
        }
    }
}

@Composable
private fun SelectedTestRow(
    test: LabTest,
    isManager: Boolean,
    lab2LabPrice: String?,
    onRemove: () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        color = Color(0xFFF8FAFC),
        border = BorderStroke(1.dp, Color(0xFFE2E8F0))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = test.englishName,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF001D35),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                if (test.arabicName.isNotBlank()) {
                    Text(
                        text = test.arabicName,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        color = Color(0xFF64748B),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            // Price tag(s)
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "عميل: ${test.customerPrice ?: "0"} جنيه",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF004A77)
                )
                if (isManager) {
                    Text(
                        text = "Lab 2 Lab: ${lab2LabPrice ?: "غير مسجل"}${if (lab2LabPrice.isNullOrBlank()) "" else " جنيه"}",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF7C3AED)
                    )
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            // Remove button
            IconButton(
                onClick = onRemove,
                modifier = Modifier
                    .size(28.dp)
                    .testTag("remove_test_${test.id}")
            ) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "إزالة",
                    tint = Color(0xFFE11D48),
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

@Composable
private fun UnmatchedQueriesCard(unmatchedQueries: List<String>) {
    if (unmatchedQueries.isEmpty()) return

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(
                elevation = 2.dp,
                shape = RoundedCornerShape(18.dp),
                spotColor = Color(0x10000000)
            ),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF1F2))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = null,
                    tint = Color(0xFFE11D48),
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "تحاليل غير موجودة",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF9F1239)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                unmatchedQueries.forEach { query ->
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color.White)
                            .padding(horizontal = 12.dp, vertical = 8.dp)
                    ) {
                        Text(
                            text = "• $query",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color(0xFF881337)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun QueryGroupSection(
    group: QueryGroup,
    isManager: Boolean,
    lab2LabPrices: Map<Int, String>,
    onSelectTest: (LabTest) -> Unit
) {
    Column(
        verticalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        if (group.candidates.size > 1) {
            AmbiguousHeaderCard(query = group.query, count = group.candidates.size)
        }
        group.candidates.forEach { test ->
            SearchCandidateCard(
                test = test,
                isManager = isManager,
                lab2LabPrice = lab2LabPrices[test.id],
                onSelect = { onSelectTest(test) }
            )
        }
    }
}

@Composable
private fun AmbiguousHeaderCard(query: String, count: Int) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        color = Color(0xFFFFF7ED),
        border = BorderStroke(1.dp, Color(0xFFFFD8A8))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.FilterList,
                contentDescription = null,
                tint = Color(0xFFC2410C),
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "نتائج عدة لـ \"$query\" ($count تحاليل):",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF9A3412)
            )
        }
    }
}

@Composable
private fun SearchCandidateCard(
    test: LabTest,
    isManager: Boolean,
    lab2LabPrice: String?,
    onSelect: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(
                elevation = 2.dp,
                shape = RoundedCornerShape(20.dp),
                spotColor = Color(0x10000000)
            ),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, Color(0xFFE2E8F0))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            Text(
                text = test.englishName,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF001D35),
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )

            if (test.arabicName.isNotBlank()) {
                Spacer(modifier = Modifier.height(4.dp))
                Row {
                    Text(
                        text = "الاسم العربي: ",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF64748B)
                    )
                    Text(
                        text = test.arabicName,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        color = Color(0xFF475569)
                    )
                }
            }

            if (test.marketName.isNotBlank()) {
                Spacer(modifier = Modifier.height(2.dp))
                Row {
                    Text(
                        text = "الاسم الدارج: ",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF64748B)
                    )
                    Text(
                        text = test.marketName,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        color = Color(0xFF475569)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            PriceBox(
                modifier = Modifier.fillMaxWidth(),
                title = "سعر العميل",
                price = test.customerPrice,
                backgroundColor = Color(0xFFF0F7FF),
                borderColor = Color(0xFFD0E4FF),
                titleColor = Color(0xFF004A77),
                priceColor = Color(0xFF004A77)
            )

            if (isManager) {
                Spacer(modifier = Modifier.height(8.dp))
                PriceBox(
                    modifier = Modifier.fillMaxWidth(),
                    title = "سعر Lab 2 Lab",
                    price = lab2LabPrice,
                    backgroundColor = Color(0xFFF5F3FF),
                    borderColor = Color(0xFFDDD6FE),
                    titleColor = Color(0xFF6D28D9),
                    priceColor = Color(0xFF6D28D9)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Button(
                onClick = onSelect,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("select_test_${test.id}"),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0061A4))
            ) {
                Icon(
                    imageVector = Icons.Default.Check,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "اختيار",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
private fun NoResultsSection(unmatchedQueries: List<String>) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(top = 8.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        if (unmatchedQueries.isNotEmpty()) {
            UnmatchedQueriesCard(unmatchedQueries = unmatchedQueries)
        }
        NoResultsView()
    }
}

@Composable
private fun LabTestCard(
    test: LabTest,
    isSelected: Boolean = false
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(
                elevation = if (isSelected) 4.dp else 3.dp,
                shape = RoundedCornerShape(24.dp),
                spotColor = Color(0x12000000)
            ),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) Color(0xFFF8FAFC) else Color.White
        ),
        border = if (isSelected) BorderStroke(2.dp, Color(0xFF0061A4)) else null
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // English Name
            Text(
                text = test.englishName,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF001D35),
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Arabic Name
            Row(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "الاسم العربي: ",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF64748B)
                )
                Text(
                    text = if (test.arabicName.isNotBlank()) test.arabicName else "غير مسجل",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    color = Color(0xFF1E293B)
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Market Name
            Row(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "الاسم الدارج: ",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF64748B)
                )
                Text(
                    text = if (test.marketName.isNotBlank()) test.marketName else "غير مسجل",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    color = Color(0xFF1E293B)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Price Section
            PriceBox(
                modifier = Modifier.fillMaxWidth(),
                title = "سعر العميل",
                price = test.customerPrice,
                backgroundColor = Color(0xFFF0F7FF),
                borderColor = Color(0xFFD0E4FF),
                titleColor = Color(0xFF004A77),
                priceColor = Color(0xFF004A77)
            )
        }
    }
}

@Composable
private fun PriceBox(
    modifier: Modifier = Modifier,
    title: String,
    price: String?,
    backgroundColor: Color,
    borderColor: Color,
    titleColor: Color,
    priceColor: Color
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(backgroundColor)
            .border(1.dp, borderColor, RoundedCornerShape(16.dp))
            .padding(12.dp)
    ) {
        Column {
            Text(
                text = title,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = titleColor
            )

            Spacer(modifier = Modifier.height(6.dp))

            if (!price.isNullOrBlank()) {
                Row(
                    verticalAlignment = Alignment.Bottom,
                    horizontalArrangement = Arrangement.Start
                ) {
                    Text(
                        text = price,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = priceColor
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "جنيه",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = priceColor,
                        modifier = Modifier.padding(bottom = 2.dp)
                    )
                }
            } else {
                Text(
                    text = "غير مسجل",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF94A3B8)
                )
            }
        }
    }
}

@Composable
private fun EmptyStateView() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(80.dp)
                .clip(CircleShape)
                .background(Color(0xFFE1F1FF)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Outlined.Biotech,
                contentDescription = null,
                tint = Color(0xFF0061A4),
                modifier = Modifier.size(40.dp)
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        Text(
            text = "ابحث عن التحليل",
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF001D35),
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = "يمكنك البحث بالعربي أو الإنجليزي أو الاسم الدارج",
            fontSize = 14.sp,
            fontWeight = FontWeight.Medium,
            color = Color(0xFF64748B),
            textAlign = TextAlign.Center
        )
    }
}

@Composable
private fun NoResultsView() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(80.dp)
                .clip(CircleShape)
                .background(Color(0xFFFEE2E2)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Outlined.SearchOff,
                contentDescription = null,
                tint = Color(0xFFDC2626),
                modifier = Modifier.size(40.dp)
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        Text(
            text = "لم يتم العثور على التحليل",
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF001D35),
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = "جرّب البحث باسم مختلف أو بالاسم الإنجليزي",
            fontSize = 14.sp,
            fontWeight = FontWeight.Medium,
            color = Color(0xFF64748B),
            textAlign = TextAlign.Center
        )
    }
}

