package com.example.util

import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.os.Build
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import android.widget.Toast
import androidx.core.content.FileProvider
import com.example.R
import com.example.data.model.LabTest
import java.io.File
import java.io.FileOutputStream

object PdfGenerator {

    private const val PAGE_WIDTH = 420
    private const val PAGE_HEIGHT = 595
    private const val MARGIN = 24f

    fun generateAndSharePdf(
        context: Context,
        selectedTests: List<LabTest>,
        includeLab2Lab: Boolean = false,
        lab2LabPrices: Map<Int, String> = emptyMap()
    ) {
        if (selectedTests.isEmpty()) {
            Toast.makeText(context, "لم يتم اختيار أي تحاليل", Toast.LENGTH_SHORT).show()
            return
        }

        val pdfDocument = PdfDocument()
        var pageNumber = 1

        var pageInfo = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, pageNumber).create()
        var page = pdfDocument.startPage(pageInfo)
        var canvas = page.canvas

        val bgPaint = Paint().apply {
            color = Color.WHITE
            style = Paint.Style.FILL
        }

        val primaryColor = Color.parseColor("#0061A4")
        val darkTextColor = Color.parseColor("#001D35")
        val grayTextColor = Color.parseColor("#475569")
        val lightBgColor = Color.parseColor("#F8FAFC")
        val dividerColor = Color.parseColor("#E2E8F0")
        val managerColor = Color.parseColor("#6D28D9")

        val titlePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = primaryColor
            textSize = 15f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }

        val headerTextPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = if (includeLab2Lab) 9f else 11f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }

        val namePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = darkTextColor
            textSize = 9.5f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }

        val arabicNamePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = grayTextColor
            textSize = 8f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        }

        val pricePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = primaryColor
            textSize = if (includeLab2Lab) 8.5f else 10f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.LEFT
        }

        val lab2LabPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = managerColor
            textSize = 8.5f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.LEFT
        }

        val totalPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = if (includeLab2Lab) 11f else 13f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }

        val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = dividerColor
            strokeWidth = 0.8f
        }

        canvas.drawRect(0f, 0f, PAGE_WIDTH.toFloat(), PAGE_HEIGHT.toFloat(), bgPaint)

        var currentY = MARGIN

        fun drawPageHeader() {
            val logoBitmap = BitmapFactory.decodeResource(context.resources, R.drawable.ic_clinic_logo)
            if (logoBitmap != null) {
                val logoWidth = 70f
                val logoHeight = 70f
                val logoX = (PAGE_WIDTH - logoWidth) / 2f
                val srcRect = Rect(0, 0, logoBitmap.width, logoBitmap.height)
                val dstRect = RectF(logoX, currentY, logoX + logoWidth, currentY + logoHeight)
                canvas.drawBitmap(logoBitmap, srcRect, dstRect, null)
                currentY += logoHeight + 8f
            }

            canvas.drawText("قائمة التحاليل والأسعار", PAGE_WIDTH / 2f, currentY + 12f, titlePaint)
            currentY += 24f

            val headerHeight = 24f
            val headerRect = RectF(MARGIN, currentY, PAGE_WIDTH - MARGIN, currentY + headerHeight)
            val headerBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = primaryColor
                style = Paint.Style.FILL
            }
            canvas.drawRoundRect(headerRect, 4f, 4f, headerBgPaint)

            if (includeLab2Lab) {
                headerTextPaint.textAlign = Paint.Align.LEFT
                canvas.drawText("Lab 2 Lab", MARGIN + 7f, currentY + 16f, headerTextPaint)
                canvas.drawText("سعر العميل", MARGIN + 82f, currentY + 16f, headerTextPaint)

                headerTextPaint.textAlign = Paint.Align.RIGHT
                canvas.drawText("اسم التحليل", PAGE_WIDTH - MARGIN - 8f, currentY + 16f, headerTextPaint)
            } else {
                headerTextPaint.textAlign = Paint.Align.LEFT
                canvas.drawText("السعر", MARGIN + 10f, currentY + 16f, headerTextPaint)

                headerTextPaint.textAlign = Paint.Align.RIGHT
                canvas.drawText("اسم التحليل", PAGE_WIDTH - MARGIN - 10f, currentY + 16f, headerTextPaint)
            }

            currentY += headerHeight + 10f
        }

        drawPageHeader()

        val maxUsableY = PAGE_HEIGHT - if (includeLab2Lab) 76f else 60f
        val nameColumnWidth = if (includeLab2Lab) 205 else (PAGE_WIDTH - (MARGIN * 2) - 100).toInt()

        selectedTests.forEachIndexed { index, test ->
            val nameText = test.englishName
            val arabicText = test.arabicName.takeIf { it.isNotBlank() } ?: ""

            val nameLayout = createStaticLayout(nameText, namePaint, nameColumnWidth)
            val arabicLayout = if (arabicText.isNotEmpty()) {
                createStaticLayout(arabicText, arabicNamePaint, nameColumnWidth)
            } else {
                null
            }

            val textHeight = nameLayout.height + (arabicLayout?.height ?: 0)
            val rowHeight = textHeight.coerceAtLeast(20) + 12f

            if (currentY + rowHeight > maxUsableY) {
                pdfDocument.finishPage(page)
                pageNumber++
                pageInfo = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, pageNumber).create()
                page = pdfDocument.startPage(pageInfo)
                canvas = page.canvas
                canvas.drawRect(0f, 0f, PAGE_WIDTH.toFloat(), PAGE_HEIGHT.toFloat(), bgPaint)
                currentY = MARGIN
                drawPageHeader()
            }

            if (index % 2 == 1) {
                val rowBgPaint = Paint().apply {
                    color = lightBgColor
                    style = Paint.Style.FILL
                }
                canvas.drawRoundRect(
                    RectF(MARGIN, currentY - 2f, PAGE_WIDTH - MARGIN, currentY + rowHeight - 2f),
                    4f,
                    4f,
                    rowBgPaint
                )
            }

            val customerPriceStr = "${test.customerPrice ?: "0"} جنيه"

            if (includeLab2Lab) {
                val labPrice = lab2LabPrices[test.id]
                val labPriceStr = if (labPrice.isNullOrBlank()) "--" else "$labPrice جنيه"
                canvas.drawText(labPriceStr, MARGIN + 7f, currentY + 14f, lab2LabPaint)
                canvas.drawText(customerPriceStr, MARGIN + 82f, currentY + 14f, pricePaint)
            } else {
                canvas.drawText(customerPriceStr, MARGIN + 10f, currentY + 14f, pricePaint)
            }

            canvas.save()
            canvas.translate(PAGE_WIDTH - MARGIN - 10f - nameLayout.width, currentY)
            nameLayout.draw(canvas)
            if (arabicLayout != null) {
                canvas.translate(0f, nameLayout.height.toFloat())
                arabicLayout.draw(canvas)
            }
            canvas.restore()

            currentY += rowHeight
            canvas.drawLine(MARGIN, currentY - 2f, PAGE_WIDTH - MARGIN, currentY - 2f, linePaint)
        }

        val totalCustomerPrice = selectedTests.sumOf { extractNumericPrice(it.customerPrice) }
        val totalLab2LabPrice = if (includeLab2Lab) {
            selectedTests.sumOf { extractNumericPrice(lab2LabPrices[it.id]) }
        } else {
            0.0
        }

        val totalBoxHeight = if (includeLab2Lab) 50f else 32f
        if (currentY + totalBoxHeight + 10f > PAGE_HEIGHT - 24f) {
            pdfDocument.finishPage(page)
            pageNumber++
            pageInfo = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, pageNumber).create()
            page = pdfDocument.startPage(pageInfo)
            canvas = page.canvas
            canvas.drawRect(0f, 0f, PAGE_WIDTH.toFloat(), PAGE_HEIGHT.toFloat(), bgPaint)
            currentY = MARGIN + 20f
        } else {
            currentY += 8f
        }

        val totalBgRect = RectF(MARGIN, currentY, PAGE_WIDTH - MARGIN, currentY + totalBoxHeight)
        val totalBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = primaryColor
            style = Paint.Style.FILL
        }
        canvas.drawRoundRect(totalBgRect, 6f, 6f, totalBgPaint)

        if (includeLab2Lab) {
            totalPaint.textAlign = Paint.Align.RIGHT
            canvas.drawText("إجمالي سعر العميل:", PAGE_WIDTH - MARGIN - 16f, currentY + 19f, totalPaint)
            canvas.drawText("إجمالي Lab 2 Lab:", PAGE_WIDTH - MARGIN - 16f, currentY + 40f, totalPaint)

            totalPaint.textAlign = Paint.Align.LEFT
            canvas.drawText("${formatTotal(totalCustomerPrice)} جنيه", MARGIN + 16f, currentY + 19f, totalPaint)
            canvas.drawText("${formatTotal(totalLab2LabPrice)} جنيه", MARGIN + 16f, currentY + 40f, totalPaint)
        } else {
            totalPaint.textAlign = Paint.Align.RIGHT
            canvas.drawText("الإجمالي:", PAGE_WIDTH - MARGIN - 16f, currentY + 21f, totalPaint)

            totalPaint.textAlign = Paint.Align.LEFT
            canvas.drawText("${formatTotal(totalCustomerPrice)} جنيه", MARGIN + 16f, currentY + 21f, totalPaint)
        }

        pdfDocument.finishPage(page)

        val pdfDir = File(context.cacheDir, "pdf").apply { mkdirs() }
        val file = File(pdfDir, "تحاليل_العقاد.pdf")
        try {
            FileOutputStream(file).use { out ->
                pdfDocument.writeTo(out)
            }
            pdfDocument.close()

            val uri = FileProvider.getUriForFile(context, "${context.packageName}.provider", file)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "application/pdf"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, "قائمة التحاليل والأسعار - عيادات العقاد التخصصية")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            val chooser = Intent.createChooser(intent, "مشاركة قائمة التحاليل PDF")
            chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(chooser)
        } catch (e: Exception) {
            pdfDocument.close()
            Toast.makeText(context, "حدث خطأ أثناء إنشاء ملف PDF", Toast.LENGTH_SHORT).show()
        }
    }

    private fun extractNumericPrice(price: String?): Double {
        if (price.isNullOrBlank()) return 0.0
        val match = Regex("""\d+(?:\.\d+)?""").find(price.replace(",", ""))
        return match?.value?.toDoubleOrNull() ?: 0.0
    }

    private fun formatTotal(total: Double): String {
        return if (total % 1.0 == 0.0) {
            total.toLong().toString()
        } else {
            String.format("%.2f", total)
        }
    }

    private fun createStaticLayout(text: String, paint: TextPaint, width: Int): StaticLayout {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            StaticLayout.Builder.obtain(text, 0, text.length, paint, width)
                .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                .setTextDirection(TextDirectionHeuristics.RTL)
                .build()
        } else {
            @Suppress("DEPRECATION")
            StaticLayout(text, paint, width, Layout.Alignment.ALIGN_NORMAL, 1.0f, 0.0f, false)
        }
    }
}
