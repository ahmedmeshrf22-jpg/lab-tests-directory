package com.example.data.model

data class Customer(
    val id: String,
    val fileNumber: String,
    val name: String,
    val phone: String,
    val age: String,
    val gender: String,
    val notes: String,
    val createdAtMillis: Long,
    val updatedAtMillis: Long
)

data class CustomerOrderItem(
    val testId: Int,
    val englishName: String,
    val arabicName: String,
    val marketName: String,
    val customerPrice: Double
)

data class CustomerOrder(
    val id: String,
    val orderNumber: String,
    val customerId: String,
    val customerFileNumber: String,
    val customerName: String,
    val items: List<CustomerOrderItem>,
    val totalCustomerPrice: Double,
    val createdAtMillis: Long,
    val createdByUid: String
)
