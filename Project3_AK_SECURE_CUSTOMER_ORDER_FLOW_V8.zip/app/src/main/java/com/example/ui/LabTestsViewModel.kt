package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.Customer
import com.example.data.model.CustomerOrder
import com.example.data.model.CustomerOrderItem
import com.example.data.model.LabTest
import com.example.data.model.normalizeText
import com.example.data.repository.LabTestRepository
import com.example.settings.AppSettings
import com.example.settings.AppSettingsStore
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreSettings
import com.google.firebase.firestore.SetOptions
import com.google.firebase.firestore.Source
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import org.json.JSONArray
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class QueryGroup(
    val query: String,
    val candidates: List<LabTest>
)

sealed interface SearchUiState {
    object EmptyQuery : SearchUiState
    data class Success(
        val query: String,
        val queryGroups: List<QueryGroup>,
        val unmatchedQueries: List<String> = emptyList()
    ) : SearchUiState
    data class NoResults(
        val unmatchedQueries: List<String> = emptyList()
    ) : SearchUiState
}

class LabTestsViewModel(application: Application) : AndroidViewModel(application) {

    companion object {
        const val MANAGER_EMAIL = "abdelrahman@tahali.com"
        private const val MANAGER_UID = "Wps5Y19pZSbeGooEzFfW5UFsshq2"
        private const val LAB2LAB_COLLECTION = "lab2lab_prices"
        private const val CUSTOMER_OVERRIDES_COLLECTION = "customer_price_overrides"
        private const val CUSTOMERS_COLLECTION = "customers"

        fun isManagerAccount(email: String?, uid: String? = null): Boolean {
            val normalizedEmail = email?.trim()?.lowercase()
            return normalizedEmail == MANAGER_EMAIL ||
                uid == MANAGER_UID
        }
    }

    private val repository = LabTestRepository(application)
    private val settingsStore = AppSettingsStore(application)

    val appSettings: StateFlow<AppSettings> = settingsStore.settings

    // Keep Firestore disk persistence disabled so manager-only Lab2Lab data is never
    // left behind in a shared disk cache when another account signs in on the device.
    @Suppress("DEPRECATION")
    private val firestore: FirebaseFirestore = FirebaseFirestore.getInstance().apply {
        firestoreSettings = FirebaseFirestoreSettings.Builder()
            .setPersistenceEnabled(false)
            .build()
    }

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _uiState = MutableStateFlow<SearchUiState>(SearchUiState.EmptyQuery)
    val uiState: StateFlow<SearchUiState> = _uiState.asStateFlow()

    private val _selectedTests = MutableStateFlow<List<LabTest>>(emptyList())
    val selectedTests: StateFlow<List<LabTest>> = _selectedTests.asStateFlow()

    private val _isManager = MutableStateFlow(false)
    val isManager: StateFlow<Boolean> = _isManager.asStateFlow()

    private val _lab2LabPrices = MutableStateFlow<Map<Int, String>>(emptyMap())
    val lab2LabPrices: StateFlow<Map<Int, String>> = _lab2LabPrices.asStateFlow()

    // Customer-price overrides are intentionally separate from Lab2Lab prices.
    // All authenticated users may read this collection, while only the manager may write it.
    private val _customerPriceOverrides = MutableStateFlow<Map<Int, String>>(emptyMap())
    val customerPriceOverrides: StateFlow<Map<Int, String>> = _customerPriceOverrides.asStateFlow()

    private val _customers = MutableStateFlow<List<Customer>>(emptyList())
    val customers: StateFlow<List<Customer>> = _customers.asStateFlow()

    private val _customersLoading = MutableStateFlow(false)
    val customersLoading: StateFlow<Boolean> = _customersLoading.asStateFlow()

    private val _customerOrders = MutableStateFlow<List<CustomerOrder>>(emptyList())
    val customerOrders: StateFlow<List<CustomerOrder>> = _customerOrders.asStateFlow()

    private var managerPricesLoaded = false
    private var customerOverridesLoaded = false

    init {
        viewModelScope.launch(Dispatchers.IO) {
            repository.getLabTests()
        }
    }

    /** Called whenever Firebase Auth user changes. */
    fun onAuthenticatedUserChanged(email: String?, uid: String? = null) {
        val authenticated = !email.isNullOrBlank() || !uid.isNullOrBlank()
        if (authenticated && !customerOverridesLoaded) {
            loadCustomerPriceOverrides()
        }
        if (authenticated && _customers.value.isEmpty()) {
            loadCustomers()
        }

        val manager = isManagerAccount(email, uid)
        if (!manager) {
            clearLab2LabState()
            return
        }

        _isManager.value = true

        // Manager-only local fallback guarantees the existing 331 Lab2Lab prices remain
        // visible even if the network is temporarily unavailable.
        if (!managerPricesLoaded || _lab2LabPrices.value.isEmpty()) {
            val localPrices = loadManagerPricesFromAsset()
            _lab2LabPrices.value = localPrices
            managerPricesLoaded = localPrices.isNotEmpty()
        }

        // Firestore is authoritative when online, and any manager edits override local values.
        firestore.collection(LAB2LAB_COLLECTION)
            .get(Source.SERVER)
            .addOnSuccessListener { snapshot ->
                if (!_isManager.value) return@addOnSuccessListener

                val serverPrices = mutableMapOf<Int, String>()
                snapshot.documents.forEach { doc ->
                    val id = documentTestId(doc.id, doc.getLong("id")?.toInt()) ?: return@forEach
                    val value = doc.get("lab_to_lab_price")
                        ?: doc.get("lab2lab_price")
                        ?: doc.get("labToLabPrice")
                        ?: doc.get("price")
                        ?: return@forEach

                    val formatted = formatFirestorePrice(value)
                    if (!formatted.isNullOrBlank()) serverPrices[id] = formatted
                }

                if (serverPrices.isNotEmpty()) {
                    _lab2LabPrices.value = _lab2LabPrices.value + serverPrices
                    managerPricesLoaded = true
                }
            }
            .addOnFailureListener {
                // Keep the manager-only local fallback.
            }
    }

    private fun loadCustomerPriceOverrides() {
        firestore.collection(CUSTOMER_OVERRIDES_COLLECTION)
            .get(Source.SERVER)
            .addOnSuccessListener { snapshot ->
                val prices = mutableMapOf<Int, String>()
                snapshot.documents.forEach { doc ->
                    val id = documentTestId(doc.id, doc.getLong("id")?.toInt()) ?: return@forEach
                    val value = doc.get("customer_price")
                        ?: doc.get("customerPrice")
                        ?: doc.get("price")
                        ?: return@forEach
                    val formatted = formatFirestorePrice(value)
                    if (!formatted.isNullOrBlank()) prices[id] = formatted
                }
                _customerPriceOverrides.value = prices
                customerOverridesLoaded = true
            }
            .addOnFailureListener {
                // Base customer prices in the bundled data remain available.
            }
    }

    /**
     * Manager-only price update. Customer prices and Lab2Lab prices are stored in separate
     * collections so normal staff can never read the confidential Lab2Lab field.
     */
    fun saveManagerPrices(
        test: LabTest,
        customerPrice: String,
        lab2LabPrice: String,
        onResult: (success: Boolean, message: String) -> Unit
    ) {
        if (!_isManager.value) {
            onResult(false, "غير مصرح بتعديل الأسعار")
            return
        }

        val customerNumber = parsePriceInput(customerPrice)
        val labNumber = parsePriceInput(lab2LabPrice)

        if (customerNumber == null || customerNumber < 0) {
            onResult(false, "اكتب سعر عميل صحيح")
            return
        }
        if (labNumber == null || labNumber < 0) {
            onResult(false, "اكتب سعر Lab 2 Lab صحيح")
            return
        }

        val docId = "test_${test.id}"
        val customerRef = firestore.collection(CUSTOMER_OVERRIDES_COLLECTION).document(docId)
        val labRef = firestore.collection(LAB2LAB_COLLECTION).document(docId)

        val customerData = mapOf(
            "id" to test.id,
            "customer_price" to customerNumber,
            "updated_at" to FieldValue.serverTimestamp()
        )
        val labData = mapOf(
            "id" to test.id,
            "lab_to_lab_price" to labNumber,
            "updated_at" to FieldValue.serverTimestamp()
        )

        firestore.runBatch { batch ->
            batch.set(customerRef, customerData, SetOptions.merge())
            batch.set(labRef, labData, SetOptions.merge())
        }.addOnSuccessListener {
            val customerFormatted = formatNumber(customerNumber)
            val labFormatted = formatNumber(labNumber)
            _customerPriceOverrides.value = _customerPriceOverrides.value + (test.id to customerFormatted)
            _lab2LabPrices.value = _lab2LabPrices.value + (test.id to labFormatted)
            customerOverridesLoaded = true
            managerPricesLoaded = true
            onResult(true, "تم حفظ أسعار ${test.englishName}")
        }.addOnFailureListener {
            onResult(false, "تعذر حفظ الأسعار. تأكد من الإنترنت وصلاحيات Firebase")
        }
    }


    fun updateAppSettings(settings: AppSettings) {
        settingsStore.save(settings)
    }

    fun resetAppSettings() {
        settingsStore.reset()
    }

    /** Refresh customer and manager prices from Firestore on demand from Settings. */
    fun refreshPrices(onResult: (Boolean, String) -> Unit) {
        firestore.collection(CUSTOMER_OVERRIDES_COLLECTION)
            .get(Source.SERVER)
            .addOnSuccessListener { customerSnapshot ->
                val customerPrices = mutableMapOf<Int, String>()
                customerSnapshot.documents.forEach { doc ->
                    val id = documentTestId(doc.id, doc.getLong("id")?.toInt()) ?: return@forEach
                    val value = doc.get("customer_price")
                        ?: doc.get("customerPrice")
                        ?: doc.get("price")
                        ?: return@forEach
                    val formatted = formatFirestorePrice(value)
                    if (!formatted.isNullOrBlank()) customerPrices[id] = formatted
                }
                _customerPriceOverrides.value = customerPrices
                customerOverridesLoaded = true

                if (!_isManager.value) {
                    settingsStore.markSynced()
                    onResult(true, "تم تحديث الأسعار")
                    return@addOnSuccessListener
                }

                firestore.collection(LAB2LAB_COLLECTION)
                    .get(Source.SERVER)
                    .addOnSuccessListener { labSnapshot ->
                        val labPrices = mutableMapOf<Int, String>()
                        labSnapshot.documents.forEach { doc ->
                            val id = documentTestId(doc.id, doc.getLong("id")?.toInt()) ?: return@forEach
                            val value = doc.get("lab_to_lab_price")
                                ?: doc.get("lab2lab_price")
                                ?: doc.get("labToLabPrice")
                                ?: doc.get("price")
                                ?: return@forEach
                            val formatted = formatFirestorePrice(value)
                            if (!formatted.isNullOrBlank()) labPrices[id] = formatted
                        }
                        if (labPrices.isNotEmpty()) {
                            _lab2LabPrices.value = _lab2LabPrices.value + labPrices
                            managerPricesLoaded = true
                        }
                        settingsStore.markSynced()
                        onResult(true, "تم تحديث الأسعار بنجاح")
                    }
                    .addOnFailureListener {
                        onResult(false, "تعذر تحديث أسعار Lab 2 Lab")
                    }
            }
            .addOnFailureListener {
                onResult(false, "تعذر تحديث الأسعار. تأكد من الإنترنت")
            }
    }

    /** Search helper used by the manager dashboard. Blank query returns all tests. */
    fun searchManagerTests(query: String): List<LabTest> {
        return if (query.isBlank()) {
            repository.getLabTests()
        } else {
            repository.searchTests(query)
        }
    }

    fun clearLab2LabState() {
        _isManager.value = false
        _lab2LabPrices.value = emptyMap()
        managerPricesLoaded = false
    }

    private fun loadManagerPricesFromAsset(): Map<Int, String> {
        return try {
            val json = getApplication<Application>().assets
                .open("manager_lab2lab_prices.json")
                .bufferedReader(Charsets.UTF_8)
                .use { it.readText() }

            val array = JSONArray(json)
            buildMap {
                for (i in 0 until array.length()) {
                    val item = array.getJSONObject(i)
                    val id = item.optInt("id", -1)
                    if (id <= 0 || item.isNull("lab_to_lab_price")) continue
                    val formatted = formatFirestorePrice(item.get("lab_to_lab_price"))
                    if (!formatted.isNullOrBlank()) put(id, formatted)
                }
            }
        } catch (_: Exception) {
            emptyMap()
        }
    }

    private fun documentTestId(documentId: String, fallbackId: Int?): Int? {
        return documentId.removePrefix("test_").toIntOrNull() ?: fallbackId
    }

    private fun parsePriceInput(value: String): Double? {
        val normalized = value
            .trim()
            .replace(",", "")
            .replace("جنيه", "", ignoreCase = true)
            .trim()
        return normalized.toDoubleOrNull()
    }

    private fun formatNumber(value: Double): String {
        return if (value % 1.0 == 0.0) value.toLong().toString() else value.toString()
    }

    private fun formatFirestorePrice(value: Any?): String? {
        return when (value) {
            null -> null
            is Byte, is Short, is Int, is Long -> value.toString()
            is Float -> formatNumber(value.toDouble())
            is Double -> formatNumber(value)
            is Number -> value.toString()
            else -> value.toString().trim().takeIf { it.isNotEmpty() && !it.equals("null", true) }
        }
    }

    fun loadCustomers(onResult: ((Boolean, String) -> Unit)? = null) {
        _customersLoading.value = true
        firestore.collection(CUSTOMERS_COLLECTION)
            .get(Source.SERVER)
            .addOnSuccessListener { snapshot ->
                _customers.value = snapshot.documents.mapNotNull { doc ->
                    val name = doc.getString("name")?.trim().orEmpty()
                    if (name.isBlank()) return@mapNotNull null
                    Customer(
                        id = doc.id,
                        fileNumber = doc.getString("file_number").orEmpty(),
                        name = name,
                        phone = doc.getString("phone").orEmpty(),
                        age = doc.getString("age").orEmpty(),
                        gender = doc.getString("gender").orEmpty(),
                        notes = doc.getString("notes").orEmpty(),
                        createdAtMillis = doc.getLong("created_at_ms") ?: 0L,
                        updatedAtMillis = doc.getLong("updated_at_ms") ?: 0L
                    )
                }.sortedByDescending { it.updatedAtMillis.takeIf { value -> value > 0 } ?: it.createdAtMillis }
                _customersLoading.value = false
                onResult?.invoke(true, "تم تحديث بيانات العملاء")
            }
            .addOnFailureListener {
                _customersLoading.value = false
                onResult?.invoke(false, "تعذر تحميل العملاء. تأكد من الإنترنت وصلاحيات Firebase")
            }
    }

    fun saveCustomer(
        existing: Customer?,
        name: String,
        phone: String,
        age: String,
        gender: String,
        notes: String,
        onResult: (Boolean, String) -> Unit
    ) {
        val cleanName = name.trim()
        val cleanPhone = normalizePhone(phone)
        val cleanAge = age.trim()

        if (cleanName.length < 2) {
            onResult(false, "اكتب اسم العميل")
            return
        }
        if (cleanPhone.length < 8) {
            onResult(false, "اكتب رقم موبايل صحيح")
            return
        }
        if (cleanAge.isNotBlank() && (cleanAge.toIntOrNull() == null || cleanAge.toInt() !in 0..120)) {
            onResult(false, "اكتب سن صحيح")
            return
        }
        if (gender !in setOf("ذكر", "أنثى")) {
            onResult(false, "اختر النوع")
            return
        }

        firestore.collection(CUSTOMERS_COLLECTION)
            .whereEqualTo("phone_normalized", cleanPhone)
            .limit(2)
            .get(Source.SERVER)
            .addOnSuccessListener { duplicateSnapshot ->
                val duplicate = duplicateSnapshot.documents.firstOrNull { it.id != existing?.id }
                if (duplicate != null) {
                    onResult(false, "رقم الموبايل مسجل لعميل آخر")
                    return@addOnSuccessListener
                }

                val now = System.currentTimeMillis()
                val customerRef = existing?.let {
                    firestore.collection(CUSTOMERS_COLLECTION).document(it.id)
                } ?: firestore.collection(CUSTOMERS_COLLECTION).document()

                val fileNumber = existing?.fileNumber?.takeIf { it.isNotBlank() } ?: generateFileNumber(now)
                val data = mutableMapOf<String, Any>(
                    "file_number" to fileNumber,
                    "name" to cleanName,
                    "name_search" to normalizeText(cleanName),
                    "phone" to phone.trim(),
                    "phone_normalized" to cleanPhone,
                    "age" to cleanAge,
                    "gender" to gender,
                    "notes" to notes.trim(),
                    "updated_at_ms" to now,
                    "updated_at" to FieldValue.serverTimestamp(),
                    "updated_by_uid" to (FirebaseAuth.getInstance().currentUser?.uid ?: "")
                )
                if (existing == null) {
                    data["created_at_ms"] = now
                    data["created_at"] = FieldValue.serverTimestamp()
                    data["created_by_uid"] = FirebaseAuth.getInstance().currentUser?.uid ?: ""
                }

                customerRef.set(data, SetOptions.merge())
                    .addOnSuccessListener {
                        loadCustomers()
                        onResult(true, if (existing == null) "تم إنشاء ملف العميل $fileNumber" else "تم تحديث بيانات العميل")
                    }
                    .addOnFailureListener {
                        onResult(false, "تعذر حفظ بيانات العميل. تأكد من صلاحيات Firebase")
                    }
            }
            .addOnFailureListener {
                onResult(false, "تعذر التحقق من رقم الموبايل")
            }
    }

    fun saveCustomerAndReturn(
        name: String,
        phone: String,
        age: String,
        gender: String,
        notes: String,
        onResult: (Customer?, String) -> Unit
    ) {
        val cleanName = name.trim()
        val cleanPhone = normalizePhone(phone)
        val cleanAge = age.trim()

        if (cleanName.length < 2) {
            onResult(null, "اكتب اسم العميل")
            return
        }
        if (cleanPhone.length < 8) {
            onResult(null, "اكتب رقم موبايل صحيح")
            return
        }
        if (cleanAge.isNotBlank() && (cleanAge.toIntOrNull() == null || cleanAge.toInt() !in 0..120)) {
            onResult(null, "اكتب سن صحيح")
            return
        }
        if (gender !in setOf("ذكر", "أنثى")) {
            onResult(null, "اختر النوع")
            return
        }

        firestore.collection(CUSTOMERS_COLLECTION)
            .whereEqualTo("phone_normalized", cleanPhone)
            .limit(1)
            .get(Source.SERVER)
            .addOnSuccessListener { duplicateSnapshot ->
                if (!duplicateSnapshot.isEmpty) {
                    onResult(null, "رقم الموبايل مسجل لعميل سابق")
                    return@addOnSuccessListener
                }

                val now = System.currentTimeMillis()
                val customerRef = firestore.collection(CUSTOMERS_COLLECTION).document()
                val fileNumber = generateFileNumber(now)
                val customer = Customer(
                    id = customerRef.id,
                    fileNumber = fileNumber,
                    name = cleanName,
                    phone = phone.trim(),
                    age = cleanAge,
                    gender = gender,
                    notes = notes.trim(),
                    createdAtMillis = now,
                    updatedAtMillis = now
                )
                val data = mapOf(
                    "file_number" to fileNumber,
                    "name" to cleanName,
                    "name_search" to normalizeText(cleanName),
                    "phone" to phone.trim(),
                    "phone_normalized" to cleanPhone,
                    "age" to cleanAge,
                    "gender" to gender,
                    "notes" to notes.trim(),
                    "created_at_ms" to now,
                    "created_at" to FieldValue.serverTimestamp(),
                    "created_by_uid" to (FirebaseAuth.getInstance().currentUser?.uid ?: ""),
                    "updated_at_ms" to now,
                    "updated_at" to FieldValue.serverTimestamp(),
                    "updated_by_uid" to (FirebaseAuth.getInstance().currentUser?.uid ?: "")
                )

                customerRef.set(data)
                    .addOnSuccessListener {
                        _customers.value = listOf(customer) + _customers.value
                        onResult(customer, "تم إنشاء ملف العميل $fileNumber")
                    }
                    .addOnFailureListener {
                        onResult(null, "تعذر حفظ بيانات العميل. تأكد من صلاحيات Firebase")
                    }
            }
            .addOnFailureListener {
                onResult(null, "تعذر التحقق من رقم الموبايل")
            }
    }

    fun loadCustomerOrders(customerId: String) {
        _customerOrders.value = emptyList()
        if (customerId.isBlank()) return

        firestore.collection(CUSTOMERS_COLLECTION)
            .document(customerId)
            .collection("orders")
            .get(Source.SERVER)
            .addOnSuccessListener { snapshot ->
                _customerOrders.value = snapshot.documents.mapNotNull { doc ->
                    val rawItems = doc.get("items") as? List<*> ?: emptyList<Any>()
                    val items = rawItems.mapNotNull { raw ->
                        val map = raw as? Map<*, *> ?: return@mapNotNull null
                        val testId = (map["test_id"] as? Number)?.toInt() ?: return@mapNotNull null
                        CustomerOrderItem(
                            testId = testId,
                            englishName = map["english_name"]?.toString().orEmpty(),
                            arabicName = map["arabic_name"]?.toString().orEmpty(),
                            marketName = map["market_name"]?.toString().orEmpty(),
                            customerPrice = (map["customer_price"] as? Number)?.toDouble() ?: 0.0
                        )
                    }
                    CustomerOrder(
                        id = doc.id,
                        orderNumber = doc.getString("order_number").orEmpty(),
                        customerId = customerId,
                        customerFileNumber = doc.getString("customer_file_number").orEmpty(),
                        customerName = doc.getString("customer_name").orEmpty(),
                        items = items,
                        totalCustomerPrice = doc.getDouble("total_customer_price")
                            ?: doc.getLong("total_customer_price")?.toDouble()
                            ?: 0.0,
                        createdAtMillis = doc.getLong("created_at_ms") ?: 0L,
                        createdByUid = doc.getString("created_by_uid").orEmpty()
                    )
                }.sortedByDescending { it.createdAtMillis }
            }
            .addOnFailureListener {
                _customerOrders.value = emptyList()
            }
    }

    fun saveCustomerOrder(
        customer: Customer,
        tests: List<LabTest>,
        onResult: (Boolean, String) -> Unit
    ) {
        if (tests.isEmpty()) {
            onResult(false, "اختار تحليل واحد على الأقل")
            return
        }

        val now = System.currentTimeMillis()
        val orderRef = firestore.collection(CUSTOMERS_COLLECTION)
            .document(customer.id)
            .collection("orders")
            .document()

        val items = tests.map { test ->
            val price = parsePriceInput(_customerPriceOverrides.value[test.id] ?: test.customerPrice.orEmpty()) ?: 0.0
            mapOf(
                "test_id" to test.id,
                "english_name" to test.englishName,
                "arabic_name" to test.arabicName,
                "market_name" to test.marketName,
                "customer_price" to price
            )
        }
        val total = items.sumOf { (it["customer_price"] as? Number)?.toDouble() ?: 0.0 }
        val orderNumber = generateOrderNumber(now)
        val data = mapOf(
            "order_number" to orderNumber,
            "customer_id" to customer.id,
            "customer_file_number" to customer.fileNumber,
            "customer_name" to customer.name,
            "items" to items,
            "tests_count" to items.size,
            "total_customer_price" to total,
            "created_at_ms" to now,
            "created_at" to FieldValue.serverTimestamp(),
            "created_by_uid" to (FirebaseAuth.getInstance().currentUser?.uid ?: "")
        )

        orderRef.set(data)
            .addOnSuccessListener {
                loadCustomerOrders(customer.id)
                onResult(true, "تم حفظ الطلب $orderNumber")
            }
            .addOnFailureListener {
                onResult(false, "تعذر حفظ الطلب. تأكد من صلاحيات Firebase")
            }
    }

    fun clearSelectedTests() {
        _selectedTests.value = emptyList()
        clearSearch()
    }

    private fun normalizePhone(value: String): String {
        return value.filter { it.isDigit() }
    }

    private fun generateFileNumber(now: Long): String {
        val date = SimpleDateFormat("yyMMdd-HHmmss", Locale.US).format(Date(now))
        val suffix = (now % 1000).toString().padStart(3, '0')
        return "AK-$date-$suffix"
    }

    private fun generateOrderNumber(now: Long): String {
        val date = SimpleDateFormat("yyMMdd-HHmmss", Locale.US).format(Date(now))
        return "ORD-$date"
    }

    private fun parseQueries(rawInput: String): List<String> {
        if (rawInput.isBlank()) return emptyList()
        val delimiterRegex = Regex("[\\n,،;؛]+")
        val rawTokens = rawInput.split(delimiterRegex)

        val seenNorm = mutableSetOf<String>()
        val result = mutableListOf<String>()

        for (token in rawTokens) {
            val trimmed = token.trim()
            if (trimmed.isEmpty()) continue
            val norm = normalizeText(trimmed)
            if (norm.isNotEmpty() && seenNorm.add(norm)) result.add(trimmed)
        }
        return result
    }

    fun onQueryChanged(newQuery: String) {
        _searchQuery.value = newQuery
        val trimmedInput = newQuery.trim()

        if (trimmedInput.isEmpty()) {
            _uiState.value = SearchUiState.EmptyQuery
            return
        }

        viewModelScope.launch(Dispatchers.Default) {
            val queries = parseQueries(newQuery)
            if (queries.isEmpty()) {
                _uiState.value = SearchUiState.EmptyQuery
                return@launch
            }

            val selectedIds = _selectedTests.value.map { it.id }.toSet()
            val queryGroups = mutableListOf<QueryGroup>()
            val unmatchedQueries = mutableListOf<String>()

            for (q in queries) {
                val matches = repository.searchTests(q).filter { it.id !in selectedIds }
                if (matches.isNotEmpty()) queryGroups.add(QueryGroup(query = q, candidates = matches))
                else unmatchedQueries.add(q)
            }

            if (queryGroups.isEmpty()) {
                _uiState.value = SearchUiState.NoResults(unmatchedQueries = unmatchedQueries)
            } else {
                _uiState.value = SearchUiState.Success(
                    query = newQuery,
                    queryGroups = queryGroups,
                    unmatchedQueries = unmatchedQueries
                )
            }
        }
    }

    fun addSelectedTest(test: LabTest) {
        if (_selectedTests.value.none { it.id == test.id }) {
            _selectedTests.value = _selectedTests.value + test
        }
        clearSearch()
    }

    fun removeSelectedTest(testId: Int) {
        _selectedTests.value = _selectedTests.value.filter { it.id != testId }
        if (_searchQuery.value.isNotEmpty()) onQueryChanged(_searchQuery.value)
    }

    fun clearSearch() {
        _searchQuery.value = ""
        _uiState.value = SearchUiState.EmptyQuery
    }
}
