package com.example.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Science
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CustomerOrder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val LabBlue = Color(0xFF075985)
private val LabCyan = Color(0xFF0EA5E9)
private val LabGreen = Color(0xFF16A34A)
private val LabAmber = Color(0xFFD97706)

@Composable
fun LabOperatorScreen(
    viewModel: LabTestsViewModel,
    userEmail: String,
    onLogout: () -> Unit
) {
    val orders by viewModel.labOrders.collectAsState()
    val loading by viewModel.labOrdersLoading.collectAsState()
    var selectedTab by remember { mutableStateOf("sent_to_lab") }
    var message by remember { mutableStateOf<String?>(null) }
    var uploadOrder by remember { mutableStateOf<CustomerOrder?>(null) }
    var uploadProgress by remember { mutableStateOf("") }

    val picker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        val order = uploadOrder
        if (order != null && uris.isNotEmpty()) {
            uploadProgress = "جاري رفع النتائج..."
            viewModel.labUploadAndSendResults(
                order = order,
                uris = uris,
                onProgress = { done, total -> uploadProgress = "رفع $done من $total" },
                onResult = { ok, msg ->
                    message = msg
                    uploadProgress = ""
                    if (ok) {
                        selectedTab = "ready"
                        viewModel.loadLabOrders()
                    }
                }
            )
        }
        uploadOrder = null
    }

    LaunchedEffect(Unit) {
        viewModel.loadLabOrders { _, msg -> message = msg }
    }

    val filtered = remember(orders, selectedTab) {
        orders.filter { it.workflowStatus == selectedTab }
    }

    Surface(modifier = Modifier.fillMaxSize(), color = Color(0xFFF4F8FB)) {
        Column(Modifier.fillMaxSize()) {
            Surface(color = LabBlue, shadowElevation = 6.dp) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 13.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        Modifier.size(42.dp).background(Color.White.copy(alpha = 0.15f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Science, contentDescription = null, tint = Color.White)
                    }
                    Column(Modifier.weight(1f).padding(horizontal = 10.dp)) {
                        Text("طلبات المعمل", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 19.sp)
                        Text(userEmail, color = Color.White.copy(alpha = 0.78f), fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    IconButton(onClick = { viewModel.loadLabOrders { _, msg -> message = msg } }) {
                        Icon(Icons.Default.Refresh, contentDescription = "تحديث", tint = Color.White)
                    }
                    IconButton(onClick = onLogout) {
                        Icon(Icons.Default.Logout, contentDescription = "خروج", tint = Color.White)
                    }
                }
            }

            Column(Modifier.fillMaxSize().padding(12.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    LabTab("sent_to_lab", "طلبات جديدة", orders.count { it.workflowStatus == "sent_to_lab" }, selectedTab) { selectedTab = it }
                    LabTab("processing", "جاري التنفيذ", orders.count { it.workflowStatus == "processing" }, selectedTab) { selectedTab = it }
                    LabTab("ready", "تم إرسالها", orders.count { it.workflowStatus == "ready" }, selectedTab) { selectedTab = it }
                }

                if (!message.isNullOrBlank()) {
                    Text(message.orEmpty(), modifier = Modifier.padding(vertical = 8.dp), color = Color(0xFF475569), fontSize = 11.sp)
                }
                if (uploadProgress.isNotBlank()) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                        Text(uploadProgress, color = LabBlue, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    }
                    Spacer(Modifier.height(8.dp))
                }

                when {
                    loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
                    filtered.isEmpty() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF94A3B8), modifier = Modifier.size(52.dp))
                            Spacer(Modifier.height(8.dp))
                            Text("لا توجد طلبات هنا", color = Color(0xFF64748B), fontWeight = FontWeight.Bold)
                        }
                    }
                    else -> LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                        items(filtered, key = { it.id }) { order ->
                            LabOrderCard(
                                order = order,
                                onAccept = {
                                    viewModel.labAcceptOrder(order) { ok, msg ->
                                        message = msg
                                        if (ok) {
                                            selectedTab = "processing"
                                            viewModel.loadLabOrders()
                                        }
                                    }
                                },
                                onSendResults = {
                                    uploadOrder = order
                                    picker.launch(arrayOf("image/*", "application/pdf"))
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun RowScope.LabTab(key: String, label: String, count: Int, selected: String, onClick: (String) -> Unit) {
    FilterChip(
        selected = selected == key,
        onClick = { onClick(key) },
        label = { Text("$label ($count)", fontSize = 10.sp, maxLines = 1) },
        modifier = Modifier.weight(1f)
    )
}

@Composable
private fun LabOrderCard(order: CustomerOrder, onAccept: () -> Unit, onSendResults: () -> Unit) {
    val accent = when (order.workflowStatus) {
        "sent_to_lab" -> LabCyan
        "processing" -> LabAmber
        else -> LabGreen
    }
    val time = remember(order.updatedAtMillis, order.createdAtMillis) {
        SimpleDateFormat("dd/MM • hh:mm a", Locale("ar", "EG"))
            .format(Date(order.updatedAtMillis.takeIf { it > 0 } ?: order.createdAtMillis))
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, accent.copy(alpha = 0.35f))
    ) {
        Column(Modifier.padding(13.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(38.dp).background(accent.copy(alpha = 0.12f), CircleShape), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Schedule, contentDescription = null, tint = accent, modifier = Modifier.size(20.dp))
                }
                Column(Modifier.weight(1f).padding(horizontal = 9.dp)) {
                    Text(order.customerName.ifBlank { "عميل" }, fontWeight = FontWeight.ExtraBold, color = Color(0xFF0F172A), fontSize = 15.sp)
                    Text("${order.orderNumber} • $time", color = Color(0xFF64748B), fontSize = 9.sp)
                }
            }

            Text(
                order.items.joinToString(" • ") { it.arabicName.ifBlank { it.englishName } },
                color = Color(0xFF334155), fontSize = 11.sp, maxLines = 4, overflow = TextOverflow.Ellipsis
            )

            if (order.notes.isNotBlank()) {
                Surface(shape = RoundedCornerShape(10.dp), color = Color(0xFFFFF7ED)) {
                    Text("ملاحظة: ${order.notes}", modifier = Modifier.padding(8.dp), color = Color(0xFF9A3412), fontSize = 10.sp)
                }
            }

            when (order.workflowStatus) {
                "sent_to_lab" -> Button(
                    onClick = onAccept,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = LabCyan)
                ) { Text("استلام الطلب وبدء التنفيذ", fontWeight = FontWeight.ExtraBold) }

                "processing" -> Button(
                    onClick = onSendResults,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = LabGreen)
                ) {
                    Icon(Icons.Default.CloudUpload, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.size(7.dp))
                    Text("رفع وإرسال النتيجة", fontWeight = FontWeight.ExtraBold)
                }

                "ready" -> {
                    Surface(shape = RoundedCornerShape(12.dp), color = LabGreen.copy(alpha = 0.10f)) {
                        Text(
                            "تم إرسال النتيجة للعيادة${if (order.resultUrls.isNotEmpty()) " • ${order.resultUrls.size} ملف" else ""}",
                            modifier = Modifier.fillMaxWidth().padding(10.dp),
                            color = LabGreen, fontWeight = FontWeight.ExtraBold, fontSize = 11.sp
                        )
                    }
                    OutlinedButton(onClick = onSendResults, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) {
                        Text("تعديل / إعادة إرسال النتيجة", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
