package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import android.app.DatePickerDialog
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Label
import androidx.compose.material.icons.filled.Percent
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.Customer
import com.example.data.model.CustomerOrder
import com.example.data.model.CustomerActivityEntry
import com.example.data.model.PaymentEntry
import com.example.data.model.LabTest
import com.example.data.model.normalizeText
import com.example.settings.LocalAppSettings
import com.example.settings.appText
import com.example.settings.tr
import com.example.util.CustomerQrImport
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.codescanner.GmsBarcodeScannerOptions
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private val CustomerPrimary = Color(0xFF006D86)
private val CustomerDark = Color(0xFF003A5D)
private val CustomerGreen = Color(0xFF15803D)
private val CustomerBg = Color(0xFFF4F7FB)

@Composable
fun CustomerSystemCard(onClick: () -> Unit) {
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .background(Color(0xFFE7F5F7), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.People,
                    contentDescription = null,
                    tint = CustomerPrimary,
                    modifier = Modifier.size(25.dp)
                )
            }
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = appText("ملفات العملاء", "Customer Files"),
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 17.sp,
                    color = Color(0xFF17324D)
                )
                Text(
                    text = appText("بحث بالاسم أو واتساب أو QR • سجل الطلبات", "Search by name, WhatsApp or QR • order history"),
                    fontSize = 12.sp,
                    color = Color(0xFF64748B)
                )
            }
            Text(
                text = appText(tr("فتح", "Open"), "Open"),
                fontWeight = FontWeight.Bold,
                color = CustomerPrimary
            )
        }
    }
}

@Composable
fun CustomerSystemDialog(
    viewModel: LabTestsViewModel,
    selectedTests: List<LabTest>,
    onDismiss: () -> Unit,
    onStartOrderForCustomer: (Customer) -> Unit = {},
    initialCustomer: Customer? = null,
    initialAutoScan: Boolean = false,
    initialQrUri: String? = null,
    onInitialQrConsumed: (String) -> Unit = {},
    onNavigateSearch: () -> Unit = {},
    onNavigateQuickImage: () -> Unit = {},
    onNavigateOrder: () -> Unit = {},
    onNavigateCustomers: () -> Unit = {},
    onNavigateScan: () -> Unit = {},
    onNavigateCatalog: () -> Unit = {}
) {
    val customers by viewModel.customers.collectAsState()
    val loading by viewModel.customersLoading.collectAsState()
    val orders by viewModel.customerOrders.collectAsState()
    val ordersLoading by viewModel.customerOrdersLoading.collectAsState()
    val activity by viewModel.customerActivity.collectAsState()
    val customerPriceOverrides by viewModel.customerPriceOverrides.collectAsState()
    val adminUnlocked by viewModel.adminUnlocked.collectAsState()
    val actualManager by viewModel.actualManager.collectAsState()
    val isManager = actualManager || adminUnlocked
    val settings = LocalAppSettings.current
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var query by remember { mutableStateOf("") }
    var selectedCustomer by remember(initialCustomer?.id) { mutableStateOf(initialCustomer) }
    var editingCustomer by remember { mutableStateOf<Customer?>(null) }
    var showCustomerEditor by remember { mutableStateOf(false) }
    var selectedOrder by remember { mutableStateOf<CustomerOrder?>(null) }
    var showOrderCheckout by remember { mutableStateOf(false) }
    var showBlacklistDialog by remember { mutableStateOf(false) }
    var blacklistReason by remember { mutableStateOf("") }
    var showArchiveConfirm by remember { mutableStateOf(false) }
    var statusMessage by remember { mutableStateOf<String?>(null) }
    var statusSuccess by remember { mutableStateOf(true) }
    var pendingOutputOrder by remember { mutableStateOf<CustomerOrder?>(null) }
    var pendingOutputCustomer by remember { mutableStateOf<Customer?>(null) }
    var qrScanBusy by remember { mutableStateOf(false) }
    var initialAutoScanConsumed by remember(initialAutoScan) { mutableStateOf(false) }

    val customerQrScannerOptions = remember {
        GmsBarcodeScannerOptions.Builder()
            .setBarcodeFormats(Barcode.FORMAT_QR_CODE)
            .enableAutoZoom()
            .build()
    }
    val customerQrScanner = remember(context) {
        GmsBarcodeScanning.getClient(context, customerQrScannerOptions)
    }

    // One resolver is shared by camera scan, local file import, and Android Share.
    val resolveCustomerQrPayload: (String) -> Unit = { rawValue ->
        viewModel.findCustomerByQrPayload(rawValue) { customer, message ->
            qrScanBusy = false
            if (customer != null) {
                if (customer.isArchived && !isManager) {
                    statusSuccess = false
                    statusMessage = tr("ملف العميل مؤرشف. لازم المدير يفتحه", "This customer is archived. A manager must open it")
                } else {
                    statusSuccess = true
                    statusMessage = null
                    selectedCustomer = customer
                    viewModel.loadCustomerOrders(customer.id)
                    viewModel.loadCustomerActivity(customer.id)
                }
            } else {
                statusSuccess = false
                statusMessage = message
            }
        }
    }

    val importCustomerQrFromUri: (Uri) -> Unit = { uri ->
        if (!qrScanBusy) {
            qrScanBusy = true
            statusMessage = tr("جاري قراءة QR من الملف...", "Reading QR from file...")
            statusSuccess = true
            coroutineScope.launch {
                val result = withContext(Dispatchers.IO) {
                    CustomerQrImport.readQrPayload(context, uri)
                }
                result.onSuccess { payload ->
                    resolveCustomerQrPayload(payload)
                }.onFailure { error ->
                    qrScanBusy = false
                    statusSuccess = false
                    statusMessage = tr(
                        "تعذر قراءة QR من الصورة: ${error.message ?: "الملف غير واضح"}",
                        "Unable to read QR from image: ${error.message ?: "The file is unclear"}"
                    )
                }
            }
        }
    }

    val qrFilePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) importCustomerQrFromUri(uri)
    }

    val openScannedCustomer: () -> Unit = {
        if (!qrScanBusy) {
            qrScanBusy = true
            customerQrScanner.startScan()
                .addOnSuccessListener { barcode ->
                    resolveCustomerQrPayload(barcode.rawValue.orEmpty())
                }
                .addOnCanceledListener {
                    qrScanBusy = false
                }
                .addOnFailureListener { error ->
                    qrScanBusy = false
                    statusSuccess = false
                    statusMessage = tr(
                        "تعذر فتح ماسح QR: ${error.message ?: "خطأ غير معروف"}",
                        "Unable to open QR scanner: ${error.message ?: "Unknown error"}"
                    )
                }
        }
    }

    val openQrFromFile: () -> Unit = {
        if (!qrScanBusy) {
            qrFilePicker.launch(arrayOf("image/*"))
        }
    }

    // V66: the QR shortcut on the home screen opens the camera scanner immediately
    // instead of making the user enter Customer Records and press another button.
    LaunchedEffect(initialAutoScan) {
        if (initialAutoScan && !initialAutoScanConsumed) {
            initialAutoScanConsumed = true
            openScannedCustomer()
        }
    }

    // V39: a receipt shared from WhatsApp/gallery/files opens the same customer flow.
    LaunchedEffect(initialQrUri) {
        val shared = initialQrUri?.takeIf { it.isNotBlank() } ?: return@LaunchedEffect
        onInitialQrConsumed(shared)
        importCustomerQrFromUri(Uri.parse(shared))
    }

    LaunchedEffect(initialCustomer?.id) {
        val customer = initialCustomer ?: return@LaunchedEffect
        selectedCustomer = customer
        viewModel.loadCustomerOrders(customer.id)
        viewModel.loadCustomerActivity(customer.id)
    }

    LaunchedEffect(Unit) {
        viewModel.loadCustomers()
    }

    val handleSystemBack: () -> Unit = {
        when {
            pendingOutputOrder != null -> { pendingOutputOrder = null; pendingOutputCustomer = null }
            showBlacklistDialog -> showBlacklistDialog = false
            showArchiveConfirm -> showArchiveConfirm = false
            showOrderCheckout -> showOrderCheckout = false
            selectedOrder != null -> selectedOrder = null
            showCustomerEditor -> showCustomerEditor = false
            selectedCustomer != null -> {
                selectedCustomer = null
                statusMessage = null
            }
            else -> onDismiss()
        }
    }

    BackHandler(enabled = true) { handleSystemBack() }

    Dialog(
        onDismissRequest = handleSystemBack,
        properties = DialogProperties(usePlatformDefaultWidth = false, dismissOnBackPress = true)
    ) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = CustomerBg
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                CustomerHeader(
                    title = if (selectedCustomer == null) appText("ملفات العملاء", "Customer Files") else appText("ملف العميل", "Customer File"),
                    subtitle = if (selectedCustomer == null) {
                        appText("بحث وإضافة ومتابعة العملاء", "Search, add and manage customers")
                    } else {
                        selectedCustomer?.phone.orEmpty()
                    },
                    onBack = if (selectedCustomer != null) {
                        {
                            selectedCustomer = null
                            statusMessage = null
                        }
                    } else null,
                    onClose = onDismiss
                )
                DailyServicesNavBar(
                    active = "customers",
                    onCatalog = onNavigateCatalog,
                    onQuickImage = onNavigateQuickImage,
                    onOrder = onNavigateOrder,
                    onCustomers = onNavigateCustomers,
                    onScan = onNavigateScan
                )

                statusMessage?.let { message ->
                    StatusBanner(
                        message = message,
                        success = statusSuccess,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                    )
                }

                if (selectedCustomer == null) {
                    CustomerListScreen(
                        customers = customers,
                        loading = loading,
                        query = query,
                        onQueryChange = { query = it },
                        onRefresh = {
                            viewModel.loadCustomers { ok, msg ->
                                statusSuccess = ok
                                statusMessage = msg
                            }
                        },
                        onScanQr = openScannedCustomer,
                        onImportQr = openQrFromFile,
                        qrScanBusy = qrScanBusy,
                        onAdd = {
                            editingCustomer = null
                            showCustomerEditor = true
                        },
                        isManager = isManager,
                        onSelect = { customer ->
                            selectedCustomer = customer
                            viewModel.loadCustomerOrders(customer.id)
                            viewModel.loadCustomerActivity(customer.id)
                            statusMessage = null
                        }
                    )
                } else {
                    val customer = selectedCustomer
                    if (customer != null) CustomerDetailsScreen(
                        customer = customer,
                        orders = orders,
                        ordersLoading = ordersLoading,
                        activity = activity,
                        selectedTests = selectedTests,
                        onEdit = {
                            editingCustomer = customer
                            showCustomerEditor = true
                        },
                        onSaveOrder = {
                            if (selectedTests.isNotEmpty()) showOrderCheckout = true
                        },
                        onStartNewOrder = { onStartOrderForCustomer(customer) },
                        onRepeatLastOrder = { previousOrder ->
                            val matched = viewModel.prepareRepeatOrder(previousOrder)
                            if (matched > 0) {
                                onStartOrderForCustomer(customer)
                            } else {
                                statusSuccess = false
                                statusMessage = tr("تحاليل الطلب القديم مش موجودة في الكتالوج الحالي", "The previous order tests are not available in the current catalogue")
                            }
                        },
                        onRefreshOrders = {
                            viewModel.loadCustomerOrders(customer.id)
                            viewModel.loadCustomerActivity(customer.id)
                        },
                        onOpenOrder = { order ->
                            selectedOrder = order
                        },
                        isManager = isManager,
                        onBlacklist = {
                            blacklistReason = customer.blacklistReason
                            showBlacklistDialog = true
                        },
                        onUnblacklist = {
                            viewModel.setCustomerBlacklist(customer, false) { ok, msg ->
                                statusSuccess = ok
                                statusMessage = msg
                                if (ok) selectedCustomer = customer.copy(
                                    isBlacklisted = false,
                                    blacklistReason = "",
                                    blacklistedAtMillis = 0L,
                                    updatedAtMillis = System.currentTimeMillis()
                                )
                            }
                        },
                        onArchive = { showArchiveConfirm = true },
                        onRestore = {
                            viewModel.setCustomerArchived(customer, false) { ok, msg ->
                                statusSuccess = ok
                                statusMessage = msg
                                if (ok) selectedCustomer = customer.copy(
                                    isArchived = false,
                                    archivedAtMillis = 0L,
                                    updatedAtMillis = System.currentTimeMillis()
                                )
                            }
                        }
                    )
                }
            }
        }
    }

    if (showBlacklistDialog && selectedCustomer != null) {
        val customer = selectedCustomer!!
        AlertDialog(
            onDismissRequest = { showBlacklistDialog = false },
            title = { Text(tr("إضافة للبلاك ليست", "Blacklist"), fontWeight = FontWeight.ExtraBold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(tr("العميل: ${customer.name}", "Customer: ${customer.name}"))
                    OutlinedTextField(
                        value = blacklistReason,
                        onValueChange = { blacklistReason = it },
                        modifier = Modifier.fillMaxWidth().heightIn(min = 112.dp),
                        label = { Text(tr("سبب الحظر - اختياري", "Blacklist reason - optional")) },
                        minLines = 2,
                        shape = RoundedCornerShape(14.dp)
                    )
                    Text(
                        tr("العميل المحظور يفضل محفوظ بس مش هيظهر لاختيار طلب جديد.", "The customer remains saved but cannot be selected for a new order."),
                        fontSize = 12.sp,
                        color = Color(0xFF64748B)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.setCustomerBlacklist(customer, true, blacklistReason) { ok, msg ->
                            statusSuccess = ok
                            statusMessage = msg
                            if (ok) selectedCustomer = customer.copy(
                                isBlacklisted = true,
                                blacklistReason = blacklistReason.trim(),
                                blacklistedAtMillis = System.currentTimeMillis(),
                                updatedAtMillis = System.currentTimeMillis()
                            )
                            showBlacklistDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB91C1C))
                ) {
                    Icon(Icons.Default.Block, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text(tr("حظر العميل", "Blacklist Customer"))
                }
            },
            dismissButton = { TextButton(onClick = { showBlacklistDialog = false }) { Text(appText(tr("إلغاء", "Cancel"), "Cancel")) } }
        )
    }

    if (showArchiveConfirm && selectedCustomer != null) {
        val customer = selectedCustomer!!
        AlertDialog(
            onDismissRequest = { showArchiveConfirm = false },
            title = { Text(tr("حذف العميل من القائمة", "Remove Customer from List"), fontWeight = FontWeight.ExtraBold) },
            text = { Text(tr("هنشيل ${customer.name} من قائمة العملاء النشطين، لكن هنحتفظ بملفه وطلباته القديمة عشان التاريخ مايضيعش.", "${customer.name} will be removed from active customers while keeping the profile and history.")) },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.setCustomerArchived(customer, true) { ok, msg ->
                            statusSuccess = ok
                            statusMessage = msg
                            if (ok) {
                                selectedCustomer = null
                                viewModel.loadCustomers()
                            }
                            showArchiveConfirm = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF475569))
                ) {
                    Icon(Icons.Default.Delete, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text(tr("حذف من القائمة", "Remove from List"))
                }
            },
            dismissButton = { TextButton(onClick = { showArchiveConfirm = false }) { Text(appText(tr("إلغاء", "Cancel"), "Cancel")) } }
        )
    }

    val checkoutCustomer = selectedCustomer
    if (showOrderCheckout && checkoutCustomer != null) {
        ProfessionalOrderCheckoutDialog(
            customer = checkoutCustomer,
            selectedTests = selectedTests,
            customerPriceOverrides = customerPriceOverrides,
            onDismiss = { showOrderCheckout = false },
            onConfirm = { discount, discountPercent, paymentStatus, paidAmount, notes, _, done ->
                viewModel.saveCustomerOrderAdvanced(
                    customer = checkoutCustomer,
                    tests = selectedTests,
                    discountAmount = discount,
                    discountPercent = discountPercent,
                    paymentStatus = paymentStatus,
                    paidAmount = paidAmount,
                    notes = notes
                ) { order, msg ->
                    done()
                    statusSuccess = order != null
                    statusMessage = msg
                    if (order != null) {
                        // V38: save first; image output is optional and generated only on request.
                        pendingOutputOrder = order
                        pendingOutputCustomer = checkoutCustomer
                        statusMessage = null
                        showOrderCheckout = false
                        viewModel.clearSelectedTests()
                    }
                }
            }
        )
    }

    val savedOutputOrder = pendingOutputOrder
    val savedOutputCustomer = pendingOutputCustomer
    if (savedOutputOrder != null && savedOutputCustomer != null) {
        OrderImageShareDialog(
            order = savedOutputOrder,
            customer = savedOutputCustomer,
            onDismiss = {
                pendingOutputOrder = null
                pendingOutputCustomer = null
            }
        )
    }

    selectedOrder?.let { order ->
        CustomerOrderDetailsDialog(
            viewModel = viewModel,
            customer = selectedCustomer,
            order = order,
            isManager = isManager,
            onDismiss = { selectedOrder = null }
        )
    }

    if (showCustomerEditor) {
        CustomerEditorDialog(
            existing = editingCustomer,
            onDismiss = { showCustomerEditor = false },
            onSave = { name, phone, alternatePhone, age, birthDate, gender, address, notes, importantAlert, tags, defaultDiscountPercent, done ->
                viewModel.saveCustomer(
                    existing = editingCustomer,
                    name = name,
                    phone = phone,
                    alternatePhone = alternatePhone,
                    age = age,
                    birthDate = birthDate,
                    gender = gender,
                    address = address,
                    notes = notes,
                    importantAlert = importantAlert,
                    tags = tags,
                    defaultDiscountPercent = defaultDiscountPercent
                ) { ok, msg ->
                    done()
                    statusSuccess = ok
                    statusMessage = msg
                    if (ok) {
                        showCustomerEditor = false
                        val updated = editingCustomer?.copy(
                            name = name.trim(),
                            phone = phone.trim(),
                            alternatePhone = alternatePhone.trim(),
                            age = age.trim(),
                            birthDate = birthDate.trim(),
                            gender = gender,
                            address = address.trim(),
                            notes = notes.trim(),
                            importantAlert = importantAlert.trim(),
                            tags = tags,
                            defaultDiscountPercent = defaultDiscountPercent.coerceIn(0.0, 100.0),
                            updatedAtMillis = System.currentTimeMillis()
                        )
                        if (updated != null) {
                            selectedCustomer = updated
                            editingCustomer = updated
                            viewModel.loadCustomerActivity(updated.id)
                        }
                    }
                }
            }
        )
    }
}

@Composable
fun CustomerOrderFlowDialog(
    viewModel: LabTestsViewModel,
    selectedTests: List<LabTest>,
    onDismiss: () -> Unit,
    onCustomerSelected: (Customer) -> Unit
) {
    val customers by viewModel.customers.collectAsState()
    val loading by viewModel.customersLoading.collectAsState()
    var mode by remember { mutableStateOf("choose") }
    var query by remember { mutableStateOf("") }
    var showNewCustomer by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) { viewModel.loadCustomers() }

    val handleSystemBack: () -> Unit = {
        when {
            showNewCustomer -> showNewCustomer = false
            mode != "choose" -> mode = "choose"
            else -> onDismiss()
        }
    }

    BackHandler(enabled = true) { handleSystemBack() }

    Dialog(
        onDismissRequest = handleSystemBack,
        properties = DialogProperties(usePlatformDefaultWidth = false, dismissOnBackPress = true)
    ) {
        Surface(modifier = Modifier.fillMaxSize(), color = CustomerBg) {
            Column(Modifier.fillMaxSize()) {
                CustomerHeader(
                    title = tr("ربط الطلب بعميل", "Link Order to Customer"),
                    subtitle = tr("${selectedTests.size} تحليل مختار", "${selectedTests.size} selected tests"),
                    onBack = if (mode != "choose") ({ mode = "choose" }) else null,
                    onClose = onDismiss
                )

                errorMessage?.let {
                    StatusBanner(
                        message = it,
                        success = false,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                    )
                }

                when (mode) {
                    "choose" -> {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Text(
                                tr("الطلب ده هيتسجل على مين؟", "Who should this order be assigned to?"),
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 18.sp,
                                color = Color(0xFF17324D)
                            )
                            Button(
                                onClick = { mode = "existing" },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(16.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = CustomerPrimary)
                            ) {
                                Icon(Icons.Default.People, contentDescription = null)
                                Spacer(Modifier.width(8.dp))
                                Text(tr("عميل سابق", "Existing Customer"), fontWeight = FontWeight.ExtraBold)
                            }
                            Button(
                                onClick = { showNewCustomer = true },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(16.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = CustomerGreen)
                            ) {
                                Icon(Icons.Default.PersonAdd, contentDescription = null)
                                Spacer(Modifier.width(8.dp))
                                Text(tr("عميل جديد", "New Customer"), fontWeight = FontWeight.ExtraBold)
                            }
                        }
                    }
                    "existing" -> {
                        val normalizedQuery = remember(query) { normalizeText(query) }
                        val phoneQuery = remember(query) { query.filter { it.isDigit() } }
                        val filtered = remember(customers, normalizedQuery, phoneQuery) {
                            val availableCustomers = customers.filter { !it.isArchived }
                            if (query.isBlank()) availableCustomers else availableCustomers.filter { customer ->
                                val blob = normalizeText(
                                    listOf(
                                        customer.name, customer.fileNumber, customer.age, customer.birthDate, customer.gender,
                                        customer.address, customer.notes, customer.importantAlert, customer.tags.joinToString(" ")
                                    ).joinToString(" ")
                                )
                                blob.contains(normalizedQuery) ||
                                    (phoneQuery.isNotBlank() && (
                                        customer.phone.filter { it.isDigit() }.contains(phoneQuery) ||
                                            customer.alternatePhone.filter { it.isDigit() }.contains(phoneQuery)
                                        ))
                            }
                        }
                        Column(Modifier.fillMaxSize().padding(14.dp)) {
                            OutlinedTextField(
                                value = query,
                                onValueChange = { query = it },
                                modifier = Modifier.fillMaxWidth().heightIn(min = 72.dp),
                                singleLine = true,
                                label = { Text(tr("ابحث بالاسم أو رقم واتساب", "Search by name or WhatsApp")) },
                                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                                shape = RoundedCornerShape(16.dp)
                            )
                            Spacer(Modifier.height(10.dp))
                            if (loading) {
                                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                    CircularProgressIndicator(color = CustomerPrimary)
                                }
                            } else {
                                LazyColumn(
                                    modifier = Modifier.fillMaxSize(),
                                    verticalArrangement = Arrangement.spacedBy(8.dp),
                                    contentPadding = PaddingValues(bottom = 24.dp)
                                ) {
                                    items(filtered, key = { it.id }) { customer ->
                                        CustomerRow(
                                            customer = customer,
                                            onClick = {
                                                if (customer.isBlacklisted) {
                                                    errorMessage = "العميل ${customer.name} على البلاك ليست. لازم المدير يفك الحظر قبل طلب جديد."
                                                } else {
                                                    onCustomerSelected(customer)
                                                }
                                            }
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showNewCustomer) {
        CustomerEditorDialog(
            existing = null,
            onDismiss = { showNewCustomer = false },
            onSave = { name, phone, alternatePhone, age, birthDate, gender, address, notes, importantAlert, tags, defaultDiscountPercent, done ->
                viewModel.saveCustomerAndReturn(
                    name = name,
                    phone = phone,
                    alternatePhone = alternatePhone,
                    age = age,
                    birthDate = birthDate,
                    gender = gender,
                    address = address,
                    notes = notes,
                    importantAlert = importantAlert,
                    tags = tags,
                    defaultDiscountPercent = defaultDiscountPercent
                ) { customer, msg ->
                    done()
                    if (customer != null) {
                        showNewCustomer = false
                        onCustomerSelected(customer)
                    } else {
                        errorMessage = msg
                    }
                }
            }
        )
    }
}

@Composable
private fun CustomerHeader(
    title: String,
    subtitle: String,
    onBack: (() -> Unit)?,
    onClose: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                Brush.horizontalGradient(
                    listOf(CustomerDark, CustomerPrimary, Color(0xFF008FA0))
                )
            )
            .padding(horizontal = 12.dp, vertical = 14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (onBack != null) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Default.ArrowBack, contentDescription = appText(tr("رجوع", "Back"), "Back"), tint = Color.White)
                }
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(title, color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp)
                Text(subtitle, color = Color.White.copy(alpha = 0.82f), fontSize = 12.sp)
            }
            IconButton(onClick = onClose) {
                Icon(Icons.Default.Close, contentDescription = appText(tr("إغلاق", "Close"), "Close"), tint = Color.White)
            }
        }
    }
}

@Composable
private fun CustomerListScreen(
    customers: List<Customer>,
    loading: Boolean,
    query: String,
    onQueryChange: (String) -> Unit,
    onRefresh: () -> Unit,
    onScanQr: () -> Unit,
    onImportQr: () -> Unit,
    qrScanBusy: Boolean,
    onAdd: () -> Unit,
    isManager: Boolean,
    onSelect: (Customer) -> Unit
) {
    var statusFilter by remember { mutableStateOf("active") }
    val normalizedQuery = remember(query) { normalizeText(query) }
    val phoneQuery = remember(query) { query.filter { it.isDigit() } }
    val filtered = remember(customers, query, normalizedQuery, phoneQuery, statusFilter, isManager) {
        customers.filter { customer ->
            // Manager searches across ALL customer states so an existing phone can always be found.
            // Without a query, the selected status tab still controls the list.
            val matchesStatus = if (!isManager) {
                // Staff can search/open every non-archived customer, including blacklist records.
                !customer.isArchived
            } else if (query.isNotBlank()) {
                // Manager search spans active + blacklist + archived.
                true
            } else {
                when (statusFilter) {
                    "blacklist" -> customer.isBlacklisted && !customer.isArchived
                    "archived" -> customer.isArchived
                    else -> !customer.isBlacklisted && !customer.isArchived
                }
            }
            val normalizedCustomerBlob = normalizeText(
                listOf(
                    customer.name,
                    customer.fileNumber,
                    customer.age,
                    customer.birthDate,
                    customer.gender,
                    customer.address,
                    customer.notes,
                    customer.importantAlert,
                    customer.tags.joinToString(" ")
                ).joinToString(" ")
            )
            val matchesPhone = phoneQuery.isNotBlank() && (
                customer.phone.filter { it.isDigit() }.contains(phoneQuery) ||
                    customer.alternatePhone.filter { it.isDigit() }.contains(phoneQuery)
                )
            val matchesQuery = query.isBlank() ||
                normalizedCustomerBlob.contains(normalizedQuery) ||
                matchesPhone
            matchesStatus && matchesQuery
        }
    }

    val activeCount = customers.count { !it.isBlacklisted && !it.isArchived }
    val blacklistCount = customers.count { it.isBlacklisted && !it.isArchived }
    val archivedCount = customers.count { it.isArchived }
    val recentCustomers = remember(customers) {
        customers
            .filterNot { it.isArchived }
            .sortedByDescending { it.updatedAtMillis.takeIf { value -> value > 0L } ?: it.createdAtMillis }
            .take(5)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = query,
                onValueChange = onQueryChange,
                modifier = Modifier.weight(1f).heightIn(min = 72.dp),
                singleLine = true,
                label = { Text(tr("ابحث بالاسم أو رقم واتساب", "Search by name or WhatsApp")) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                shape = RoundedCornerShape(16.dp)
            )
            Spacer(Modifier.width(8.dp))
            IconButton(onClick = onRefresh) {
                Icon(Icons.Default.Refresh, contentDescription = tr("تحديث", "Refresh"), tint = CustomerPrimary)
            }
        }

        Spacer(Modifier.height(10.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            CustomerVisualToolCard(
                modifier = Modifier.weight(1f),
                icon = Icons.Default.QrCodeScanner,
                title = tr("QR بالكاميرا", "Camera QR"),
                subtitle = tr("للورقة أو شاشة جهاز تاني", "Paper or another screen"),
                enabled = !qrScanBusy,
                busy = qrScanBusy,
                onClick = onScanQr
            )
            CustomerVisualToolCard(
                modifier = Modifier.weight(1f),
                icon = Icons.Default.QrCodeScanner,
                title = tr("QR من ملف", "QR from file"),
                subtitle = tr("صورة على الموبايل", "Image on phone"),
                enabled = !qrScanBusy,
                busy = false,
                onClick = onImportQr
            )
        }

        Spacer(Modifier.height(10.dp))

        Button(
            onClick = onAdd,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(containerColor = CustomerPrimary)
        ) {
            Icon(Icons.Default.PersonAdd, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text(appText("إضافة عميل جديد", "Add New Customer"), fontWeight = FontWeight.Bold)
        }

        Spacer(Modifier.height(12.dp))

        if (query.isBlank() && recentCustomers.isNotEmpty()) {
            Text(
                tr("آخر العملاء", "Recent Customers"),
                fontWeight = FontWeight.ExtraBold,
                color = Color(0xFF17324D)
            )
            Spacer(Modifier.height(7.dp))
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(end = 6.dp)
            ) {
                items(recentCustomers, key = { "recent_${it.id}" }) { customer ->
                    RecentCustomerCard(customer = customer, onClick = { onSelect(customer) })
                }
            }
            Spacer(Modifier.height(12.dp))
        }

        if (isManager) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                CustomerStatusCard(
                    title = tr("النشطين", "Active"),
                    count = activeCount,
                    selected = statusFilter == "active",
                    icon = Icons.Default.People,
                    modifier = Modifier.weight(1f),
                    onClick = { statusFilter = "active" }
                )
                CustomerStatusCard(
                    title = tr("بلاك ليست", "Blacklist"),
                    count = blacklistCount,
                    selected = statusFilter == "blacklist",
                    icon = Icons.Default.Block,
                    modifier = Modifier.weight(1f),
                    onClick = { statusFilter = "blacklist" }
                )
                CustomerStatusCard(
                    title = tr("المحذوفين", "Archived"),
                    count = archivedCount,
                    selected = statusFilter == "archived",
                    icon = Icons.Default.Delete,
                    modifier = Modifier.weight(1f),
                    onClick = { statusFilter = "archived" }
                )
            }
            Spacer(Modifier.height(12.dp))
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                if (!isManager) {
                    if (query.isNotBlank()) tr("نتائج البحث في العملاء", "Customer Search Results") else tr("كل العملاء المتاحين", "All Available Customers")
                } else if (query.isNotBlank()) {
                    tr("نتائج البحث في كل العملاء", "Search Results")
                } else when (statusFilter) {
                    "blacklist" -> tr("العملاء المحظورين", "Blacklisted Customers")
                    "archived" -> tr("العملاء المحذوفين", "Archived Customers")
                    else -> tr("العملاء النشطين", "Active Customers")
                },
                fontWeight = FontWeight.ExtraBold,
                color = Color(0xFF17324D)
            )
            Text(tr("${filtered.size} ملف", "${filtered.size} customers"), color = CustomerPrimary, fontWeight = FontWeight.Bold)
        }

        Spacer(Modifier.height(8.dp))

        when {
            loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = CustomerPrimary)
            }
            filtered.isEmpty() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        when (statusFilter) {
                            "blacklist" -> Icons.Default.Block
                            "archived" -> Icons.Default.Delete
                            else -> Icons.Default.People
                        },
                        contentDescription = null,
                        tint = Color(0xFF94A3B8),
                        modifier = Modifier.size(44.dp)
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(if (query.isBlank()) tr("مفيش عملاء في القسم ده", "No customers in this section") else tr("مفيش نتائج للبحث", "No search results"), color = Color(0xFF64748B))
                }
            }
            else -> LazyColumn(
                contentPadding = PaddingValues(bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(filtered, key = { it.id }) { customer ->
                    CustomerRow(customer = customer, onClick = { onSelect(customer) })
                }
            }
        }
    }
}

@Composable
private fun CustomerVisualToolCard(
    modifier: Modifier = Modifier,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    enabled: Boolean,
    busy: Boolean,
    onClick: () -> Unit
) {
    Card(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier.heightIn(min = 118.dp),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFD8E8EC))
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .background(Color(0xFFE6F4F7), RoundedCornerShape(15.dp)),
                contentAlignment = Alignment.Center
            ) {
                if (busy) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(23.dp),
                        strokeWidth = 2.dp,
                        color = CustomerPrimary
                    )
                } else {
                    Icon(icon, contentDescription = null, tint = CustomerPrimary, modifier = Modifier.size(27.dp))
                }
            }
            Spacer(Modifier.height(7.dp))
            Text(
                text = title,
                fontWeight = FontWeight.ExtraBold,
                color = CustomerDark,
                fontSize = 11.sp,
                maxLines = 1
            )
            Text(
                text = subtitle,
                color = Color(0xFF64748B),
                fontSize = 8.sp,
                lineHeight = 11.sp,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun RecentCustomerCard(customer: Customer, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .width(190.dp)
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(15.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(
                customer.name,
                fontWeight = FontWeight.ExtraBold,
                color = Color(0xFF17324D),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            if (customer.phone.isNotBlank()) {
                Text(
                    text = tr("واتساب: ${customer.phone}", "WhatsApp: ${customer.phone}"),
                    fontSize = 11.sp,
                    color = CustomerPrimary,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
private fun CustomerStatusCard(
    title: String,
    count: Int,
    selected: Boolean,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier,
    onClick: () -> Unit
) {
    val bg = if (selected) CustomerPrimary else Color.White
    val fg = if (selected) Color.White else Color(0xFF334155)
    Card(
        modifier = modifier.clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = bg),
        elevation = CardDefaults.cardElevation(defaultElevation = if (selected) 4.dp else 1.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(vertical = 10.dp, horizontal = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(icon, contentDescription = null, tint = fg, modifier = Modifier.size(20.dp))
            Spacer(Modifier.height(4.dp))
            Text(count.toString(), color = fg, fontWeight = FontWeight.ExtraBold, fontSize = 17.sp)
            Text(title, color = fg.copy(alpha = 0.9f), fontWeight = FontWeight.Bold, fontSize = 11.sp, maxLines = 1)
        }
    }
}

@Composable
private fun CustomerRow(customer: Customer, onClick: () -> Unit) {
    val cardColor = when {
        customer.isArchived -> Color(0xFFF1F5F9)
        customer.isBlacklisted -> Color(0xFFFFF1F2)
        else -> Color.White
    }
    val avatarColor = when {
        customer.isArchived -> Color(0xFFE2E8F0)
        customer.isBlacklisted -> Color(0xFFFEE2E2)
        else -> Color(0xFFE7F5F7)
    }
    val accent = when {
        customer.isArchived -> Color(0xFF64748B)
        customer.isBlacklisted -> Color(0xFFB91C1C)
        else -> CustomerPrimary
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = cardColor),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .background(avatarColor, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = customer.name.trim().take(1).ifBlank { "؟" },
                    color = accent,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 18.sp
                )
            }
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        customer.name,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF17324D),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    if (customer.isBlacklisted || customer.isArchived) {
                        Text(
                            if (customer.isArchived) tr("محذوف", "Archived") else tr("محظور", "Blacklisted"),
                            color = accent,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 10.sp
                        )
                    }
                }
                Spacer(Modifier.height(3.dp))
                Text(tr("واتساب: ${customer.phone}", "WhatsApp: ${customer.phone}"), fontSize = 12.sp, color = Color(0xFF64748B))
            }
            Text(tr("فتح", "Open"), color = accent, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        }
    }
}

@Composable
private fun CustomerDetailsScreen(
    customer: Customer,
    orders: List<CustomerOrder>,
    ordersLoading: Boolean,
    activity: List<CustomerActivityEntry>,
    selectedTests: List<LabTest>,
    onEdit: () -> Unit,
    onSaveOrder: () -> Unit,
    onStartNewOrder: () -> Unit,
    onRepeatLastOrder: (CustomerOrder) -> Unit,
    onRefreshOrders: () -> Unit,
    onOpenOrder: (CustomerOrder) -> Unit,
    isManager: Boolean,
    onBlacklist: () -> Unit,
    onUnblacklist: () -> Unit,
    onArchive: () -> Unit,
    onRestore: () -> Unit
) {
    val context = LocalContext.current
    val validOrders = orders.filterNot { it.isVoided }
    val totalSpent = validOrders.sumOf { it.totalCustomerPrice }
    val totalDebt = validOrders.sumOf { it.remainingAmount }
    val lastVisit = validOrders.maxOfOrNull { it.createdAtMillis } ?: 0L

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(bottom = 28.dp)
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                Column(Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier.size(52.dp).background(Color(0xFFE7F5F7), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(customer.name.take(1), color = CustomerPrimary, fontWeight = FontWeight.ExtraBold, fontSize = 22.sp)
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(customer.name, fontWeight = FontWeight.ExtraBold, fontSize = 19.sp, color = Color(0xFF17324D))
                            Text(tr("ملف العميل", "Customer file"), color = CustomerPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                        IconButton(onClick = onEdit) {
                            Icon(Icons.Default.Edit, contentDescription = tr("تعديل", "Edit"), tint = CustomerPrimary)
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    InfoLine(Icons.Default.Chat, tr("رقم واتساب", "WhatsApp"), customer.phone)
                    if (customer.age.isNotBlank()) InfoLine(Icons.Default.Person, tr("السن", "Age"), if (com.example.settings.AppLanguageRuntime.code == "en") "${customer.age} years" else "${customer.age} سنة")
                    if (customer.birthDate.isNotBlank()) InfoLine(Icons.Default.CalendarMonth, tr("التاريخ", "Date"), customer.birthDate)
                    if (customer.notes.isNotBlank()) {
                        Spacer(Modifier.height(8.dp))
                        Text(tr("ملاحظات", "Notes"), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF64748B))
                        Text(customer.notes, color = Color(0xFF334155), fontSize = 13.sp)
                    }

                    Spacer(Modifier.height(12.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = {
                                runCatching {
                                    context.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${customer.phone}")))
                                }
                            },
                            modifier = Modifier.weight(1f),
                            enabled = customer.phone.isNotBlank()
                        ) {
                            Icon(Icons.Default.Call, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(5.dp))
                            Text(tr("اتصال", "Call"))
                        }
                        OutlinedButton(
                            onClick = {
                                val wa = normalizeWhatsAppNumber(customer.phone)
                                runCatching {
                                    context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$wa")))
                                }
                            },
                            modifier = Modifier.weight(1f),
                            enabled = customer.phone.isNotBlank()
                        ) {
                            Icon(Icons.Default.Chat, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(5.dp))
                            Text(tr("واتساب", "WhatsApp"))
                        }
                    }
                }
            }
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFE7F5F7))
            ) {
                Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.ReceiptLong, contentDescription = null, tint = CustomerPrimary)
                    Spacer(Modifier.width(8.dp))
                    Text(
                        tr(
                            "كل طلب محفوظ يظهر هنا. اضغط على أي طلب لعرض التحاليل والإجمالي واستخراج صورة العميل أو صورة طلب المعمل.",
                            "Every saved order appears here. Open any order to view tests, totals, and create the customer or lab image."
                        ),
                        modifier = Modifier.weight(1f),
                        fontSize = 12.sp,
                        color = Color(0xFF365A5C),
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.History, contentDescription = null, tint = CustomerPrimary)
                    Spacer(Modifier.width(7.dp))
                    Text(appText(tr("سجل الطلبات", "Order History"), "Order history"), fontWeight = FontWeight.ExtraBold, color = Color(0xFF17324D))
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(tr("${orders.size} طلب محفوظ", "${orders.size} saved orders"), color = CustomerPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    IconButton(onClick = onRefreshOrders) {
                        Icon(Icons.Default.Refresh, contentDescription = tr("تحديث الطلبات", "Refresh Orders"), tint = CustomerPrimary)
                    }
                }
            }
        }

        if (ordersLoading && orders.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(18.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp, color = CustomerPrimary)
                        Spacer(Modifier.width(9.dp))
                        Text(tr("جاري تحميل الطلبات المحفوظة...", "Loading saved orders..."), color = Color(0xFF64748B), fontWeight = FontWeight.Bold)
                    }
                }
            }
        } else if (orders.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Text(tr("لا توجد طلبات محفوظة لهذا العميل", "No saved orders for this customer"), modifier = Modifier.padding(18.dp), color = Color(0xFF64748B))
                }
            }
        } else {
            items(orders, key = { it.id }) { order ->
                CustomerOrderCard(order = order, onClick = { onOpenOrder(order) })
            }
        }

        if (customer.isBlacklisted || customer.isArchived) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (customer.isArchived) Color(0xFFF1F5F9) else Color(0xFFFFE4E6)
                    )
                ) {
                    Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            if (customer.isArchived) Icons.Default.Delete else Icons.Default.Block,
                            contentDescription = null,
                            tint = if (customer.isArchived) Color(0xFF475569) else Color(0xFFB91C1C)
                        )
                        Spacer(Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                if (customer.isArchived) tr("العميل محذوف/مؤرشف", "Customer is Archived") else tr("العميل على البلاك ليست", "Customer is Blacklisted"),
                                fontWeight = FontWeight.ExtraBold,
                                color = if (customer.isArchived) Color(0xFF334155) else Color(0xFF991B1B)
                            )
                            if (customer.isBlacklisted && customer.blacklistReason.isNotBlank()) {
                                Text(tr("السبب: ${customer.blacklistReason}", "Reason: ${customer.blacklistReason}"), fontSize = 12.sp, color = Color(0xFF7F1D1D))
                            }
                            if (customer.isBlacklisted) {
                                Text(tr("يظهر في البحث للجميع لكن ممنوع إنشاء طلب جديد له.", "Visible in search, but new orders are blocked."), fontSize = 11.sp, color = Color(0xFF7F1D1D))
                            }
                        }
                    }
                }
            }
        }

        if (isManager) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(tr("إدارة حالة العميل", "Customer Status"), fontWeight = FontWeight.ExtraBold, color = Color(0xFF17324D))
                        when {
                            customer.isArchived -> {
                                Button(
                                    onClick = onRestore,
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(14.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = CustomerGreen)
                                ) {
                                    Icon(Icons.Default.Restore, contentDescription = null)
                                    Spacer(Modifier.width(7.dp))
                                    Text(tr("استرجاع العميل", "Restore Customer"), fontWeight = FontWeight.Bold)
                                }
                            }
                            customer.isBlacklisted -> {
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Button(
                                        onClick = onUnblacklist,
                                        modifier = Modifier.weight(1f),
                                        shape = RoundedCornerShape(14.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = CustomerGreen)
                                    ) {
                                        Icon(Icons.Default.Restore, contentDescription = null)
                                        Spacer(Modifier.width(5.dp))
                                        Text(tr("فك الحظر", "Remove Blacklist"), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    }
                                    OutlinedButton(
                                        onClick = onArchive,
                                        modifier = Modifier.weight(1f),
                                        shape = RoundedCornerShape(14.dp)
                                    ) {
                                        Icon(Icons.Default.Delete, contentDescription = null)
                                        Spacer(Modifier.width(5.dp))
                                        Text(tr("حذف آمن", "Safe Archive"), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    }
                                }
                            }
                            else -> {
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedButton(
                                        onClick = onBlacklist,
                                        modifier = Modifier.weight(1f),
                                        shape = RoundedCornerShape(14.dp),
                                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFB91C1C))
                                    ) {
                                        Icon(Icons.Default.Block, contentDescription = null)
                                        Spacer(Modifier.width(5.dp))
                                        Text(tr("بلاك ليست", "Blacklist"), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    }
                                    OutlinedButton(
                                        onClick = onArchive,
                                        modifier = Modifier.weight(1f),
                                        shape = RoundedCornerShape(14.dp)
                                    ) {
                                        Icon(Icons.Default.Delete, contentDescription = null)
                                        Spacer(Modifier.width(5.dp))
                                        Text(tr("حذف آمن", "Safe Archive"), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(tr("ملخص العميل", "Customer Summary"), fontWeight = FontWeight.ExtraBold, color = Color(0xFF17324D))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    CustomerStatCard(tr("الزيارات", "Visits"), validOrders.size.toString(), Modifier.weight(1f))
                    CustomerStatCard(tr("إجمالي التعاملات", "Total Business"), "${formatMoney(totalSpent)} ج", Modifier.weight(1f))
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    CustomerStatCard(tr("المديونية", "Debt"), "${formatMoney(totalDebt)} ج", Modifier.weight(1f))
                    CustomerStatCard(tr("آخر زيارة", "Last Visit"), if (lastVisit > 0L) formatShortDate(lastVisit) else "—", Modifier.weight(1f))
                }
            }
        }

        if (totalDebt > 0.0) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF2F2))
                ) {
                    Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Payments, contentDescription = null, tint = Color(0xFFB91C1C))
                        Spacer(Modifier.width(8.dp))
                        Column {
                            Text(tr("على العميل مديونية", "Outstanding Debt"), fontWeight = FontWeight.ExtraBold, color = Color(0xFF991B1B))
                            Text(tr("${formatMoney(totalDebt)} جنيه متبقي", "${formatMoney(totalDebt)} EGP outstanding"), color = Color(0xFFB91C1C), fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                Column(Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.ShoppingCart, contentDescription = null, tint = CustomerGreen)
                        Spacer(Modifier.width(8.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(tr("طلب تحاليل جديد", "New Lab Order"), fontWeight = FontWeight.ExtraBold, color = Color(0xFF17324D))
                            Text(
                                when {
                                    customer.isArchived -> tr("العميل محذوف من القائمة", "Customer is Archived")
                                    customer.isBlacklisted -> "العميل محظور - فك الحظر قبل إنشاء طلب جديد"
                                    selectedTests.isEmpty() -> tr("اختار التحاليل من شاشة البحث الأول", "Select tests from the search screen first")
                                    else -> "${selectedTests.size} تحليل مختار جاهز للحفظ"
                                },
                                fontSize = 12.sp,
                                color = Color(0xFF64748B)
                            )
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    val lastRepeatableOrder = validOrders.maxByOrNull { it.createdAtMillis }
                    if (lastRepeatableOrder != null) {
                        Button(
                            onClick = { onRepeatLastOrder(lastRepeatableOrder) },
                            enabled = !customer.isBlacklisted && !customer.isArchived,
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0F766E))
                        ) {
                            Icon(Icons.Default.History, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text(
                                tr("إعادة آخر طلب (${lastRepeatableOrder.items.size} تحليل)", "Repeat Last Order (${lastRepeatableOrder.items.size} tests)"),
                                fontWeight = FontWeight.ExtraBold
                            )
                        }
                        Spacer(Modifier.height(8.dp))
                    }
                    OutlinedButton(
                        onClick = onStartNewOrder,
                        enabled = !customer.isBlacklisted && !customer.isArchived,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Icon(Icons.Default.Search, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text(tr("اختيار تحاليل جديدة لهذا العميل", "Select New Tests for This Customer"), fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.height(8.dp))
                    Button(
                        onClick = onSaveOrder,
                        enabled = selectedTests.isNotEmpty() && !customer.isBlacklisted && !customer.isArchived,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = CustomerGreen)
                    ) {
                        Icon(Icons.Default.Save, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text(tr("حفظ التحاليل المختارة كطلب", "Save Selected Tests as Order"), fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        item {
            Text("Timeline", fontWeight = FontWeight.ExtraBold, color = Color(0xFF17324D), fontSize = 16.sp)
        }
        if (activity.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Text(tr("لا توجد عمليات مسجلة حتى الآن", "No activity recorded yet"), modifier = Modifier.padding(14.dp), fontSize = 12.sp, color = Color(0xFF64748B))
                }
            }
        } else {
            items(activity.take(20), key = { it.id }) { entry ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Column(Modifier.padding(12.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(entry.title, fontWeight = FontWeight.Bold, color = Color(0xFF17324D), modifier = Modifier.weight(1f))
                            Text(formatShortDate(entry.createdAtMillis), fontSize = 10.sp, color = Color(0xFF64748B))
                        }
                        if (entry.details.isNotBlank()) Text(entry.details, fontSize = 11.sp, color = Color(0xFF475569))
                        if (entry.actorEmail.isNotBlank()) Text(entry.actorEmail, fontSize = 10.sp, color = CustomerPrimary)
                    }
                }
            }
        }
    }
}

@Composable
private fun InfoLine(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = null, tint = CustomerPrimary, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(8.dp))
        Text("$label: ", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color(0xFF475569))
        Text(value, fontSize = 13.sp, color = Color(0xFF17324D))
    }
}

@Composable
private fun CustomerStatCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(Modifier.padding(14.dp)) {
            Text(label, color = Color(0xFF64748B), fontSize = 11.sp)
            Spacer(Modifier.height(4.dp))
            Text(value, color = CustomerPrimary, fontWeight = FontWeight.ExtraBold, fontSize = 17.sp)
        }
    }
}

@Composable
private fun CustomerOrderDetailsDialog(
    viewModel: LabTestsViewModel,
    customer: Customer?,
    order: CustomerOrder,
    isManager: Boolean,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val settings = LocalAppSettings.current
    val payments by viewModel.paymentHistory.collectAsState()
    var currentOrder by remember(order) { mutableStateOf(order) }
    var showPaymentDialog by remember { mutableStateOf(false) }
    var showEditDialog by remember { mutableStateOf(false) }
    var showVoidDialog by remember { mutableStateOf(false) }
    var voidReason by remember { mutableStateOf("") }
    var statusMessage by remember { mutableStateOf<String?>(null) }
    var statusSuccess by remember { mutableStateOf(true) }
    var pendingOutputOrder by remember { mutableStateOf<CustomerOrder?>(null) }
    var pendingOutputCustomer by remember { mutableStateOf<Customer?>(null) }

    LaunchedEffect(currentOrder.id, customer?.id) {
        val customerId = customer?.id ?: currentOrder.customerId
        viewModel.loadPaymentHistory(customerId, currentOrder.id)
    }

    val handleSystemBack: () -> Unit = {
        when {
            pendingOutputOrder != null -> { pendingOutputOrder = null; pendingOutputCustomer = null }
            showPaymentDialog -> showPaymentDialog = false
            showEditDialog -> showEditDialog = false
            showVoidDialog -> showVoidDialog = false
            else -> onDismiss()
        }
    }

    BackHandler(enabled = true) { handleSystemBack() }

    Dialog(
        onDismissRequest = handleSystemBack,
        properties = DialogProperties(usePlatformDefaultWidth = false, dismissOnBackPress = true)
    ) {
        Surface(modifier = Modifier.fillMaxSize(), color = CustomerBg) {
            Column(Modifier.fillMaxSize()) {
                CustomerHeader(
                    title = tr("تفاصيل الطلب", "Order Details"),
                    subtitle = currentOrder.orderNumber,
                    onBack = onDismiss,
                    onClose = onDismiss
                )
                LazyColumn(
                    modifier = Modifier.fillMaxSize().padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 28.dp)
                ) {
                    statusMessage?.let { message ->
                        item { StatusBanner(message, statusSuccess, Modifier.fillMaxWidth()) }
                    }

                    if (currentOrder.isVoided) {
                        item {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = Color(0xFFFFE4E6))
                            ) {
                                Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Block, contentDescription = null, tint = Color(0xFFB91C1C))
                                    Spacer(Modifier.width(8.dp))
                                    Column {
                                        Text(tr("طلب ملغي", "Voided Order"), fontWeight = FontWeight.ExtraBold, color = Color(0xFF991B1B))
                                        if (currentOrder.voidReason.isNotBlank()) Text(tr("السبب: ${currentOrder.voidReason}", "Reason: ${currentOrder.voidReason}"), fontSize = 12.sp, color = Color(0xFF7F1D1D))
                                    }
                                }
                            }
                        }
                    }

                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(18.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White)
                        ) {
                            Column(Modifier.padding(16.dp)) {
                                Text(
                                    customer?.name ?: currentOrder.customerName,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 18.sp,
                                    color = Color(0xFF17324D)
                                )
                                Spacer(Modifier.height(4.dp))
                                Text(
                                    customer?.fileNumber ?: currentOrder.customerFileNumber,
                                    color = CustomerPrimary,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp
                                )
                                Spacer(Modifier.height(8.dp))
                                InfoLine(Icons.Default.History, tr("التاريخ", "Date"), formatDate(currentOrder.createdAtMillis))
                                InfoLine(Icons.Default.ShoppingCart, tr("عدد التحاليل", "Tests Count"), currentOrder.items.size.toString())
                                val creator = currentOrder.createdByEmail.ifBlank { currentOrder.createdByUid }
                                if (creator.isNotBlank()) InfoLine(Icons.Default.Person, tr("أنشأ الطلب", "Created By"), creator)
                                if (currentOrder.editCount > 0) InfoLine(Icons.Default.Edit, tr("عدد التعديلات", "Edit Count"), currentOrder.editCount.toString())
                            }
                        }
                    }

                    item {
                        Text(tr("التحاليل", "Tests"), fontWeight = FontWeight.ExtraBold, color = Color(0xFF17324D), fontSize = 16.sp)
                    }

                    items(currentOrder.items) { item ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(13.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        item.englishName.ifBlank { item.arabicName },
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF17324D),
                                        maxLines = 2,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    val secondName = when {
                                        item.arabicName.isNotBlank() && item.arabicName != item.englishName -> item.arabicName
                                        item.marketName.isNotBlank() -> item.marketName
                                        else -> ""
                                    }
                                    if (secondName.isNotBlank()) Text(secondName, fontSize = 11.sp, color = Color(0xFF64748B))
                                }
                                Spacer(Modifier.width(10.dp))
                                Text("${formatMoney(item.customerPrice)} ${tr("ج", "EGP")}", color = CustomerPrimary, fontWeight = FontWeight.ExtraBold)
                            }
                        }
                    }

                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(18.dp),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFFE8F7ED))
                        ) {
                            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text(tr("الإجمالي", "Total"), fontWeight = FontWeight.ExtraBold, color = Color(0xFF166534))
                                    Text("${formatMoney(currentOrder.totalCustomerPrice)} ${tr("جنيه", "EGP")}", fontWeight = FontWeight.ExtraBold, fontSize = 19.sp, color = CustomerGreen)
                                }
                                FinancialRow(tr("المدفوع", "Paid"), currentOrder.paidAmount)
                                FinancialRow(tr("المتبقي", "Remaining"), currentOrder.remainingAmount, if (currentOrder.remainingAmount > 0.0) Color(0xFFB91C1C) else CustomerGreen)
                                Text(tr("حالة الدفع: ${paymentStatusArabic(currentOrder.paymentStatus)}", "Payment status: ${paymentStatusEnglish(currentOrder.paymentStatus)}"), fontWeight = FontWeight.Bold, color = Color(0xFF17324D))
                                if (currentOrder.notes.isNotBlank()) Text(tr("ملاحظات: ${currentOrder.notes}", "Notes: ${currentOrder.notes}"), fontSize = 12.sp, color = Color(0xFF475569))
                            }
                        }
                    }

                    if (!currentOrder.isVoided) {
                        item {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = Color.White)
                            ) {
                                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Text(
                                        tr("حالة تشغيل الطلب", "Order Workflow Status"),
                                        fontWeight = FontWeight.ExtraBold,
                                        color = Color(0xFF17324D)
                                    )
                                    Text(
                                        tr(workflowStatusArabic(currentOrder.workflowStatus), workflowStatusEnglish(currentOrder.workflowStatus)),
                                        color = CustomerPrimary,
                                        fontWeight = FontWeight.ExtraBold
                                    )
                                    OrderWorkflowStatusBar(
                                        currentStatus = currentOrder.workflowStatus,
                                        onStatusSelected = { newStatus ->
                                            val active = customer
                                            if (active != null) {
                                                viewModel.updateOrderWorkflowStatus(active, currentOrder, newStatus) { updated, message ->
                                                    statusSuccess = updated != null
                                                    statusMessage = message
                                                    if (updated != null) currentOrder = updated
                                                }
                                            } else {
                                                statusSuccess = false
                                                statusMessage = tr("تعذر تحديد العميل لهذا الطلب", "Unable to resolve the customer for this order")
                                            }
                                        }
                                    )
                                }
                            }
                        }
                        item {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(
                                    onClick = { showPaymentDialog = true },
                                    enabled = currentOrder.remainingAmount > 0.0,
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(14.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = CustomerGreen)
                                ) {
                                    Icon(Icons.Default.Payments, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(Modifier.width(5.dp))
                                    Text(tr("تحصيل دفعة", "Collect payment"), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                                OutlinedButton(
                                    onClick = { showEditDialog = true },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(14.dp)
                                ) {
                                    Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(Modifier.width(5.dp))
                                    Text(tr("تعديل الدفع", "Edit Payment"), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    if (payments.isNotEmpty()) {
                        item { Text(tr("سجل الدفعات", "Payment History"), fontWeight = FontWeight.ExtraBold, color = Color(0xFF17324D)) }
                        items(payments, key = { it.id }) { payment ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(14.dp),
                                colors = CardDefaults.cardColors(containerColor = Color.White)
                            ) {
                                Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Column(Modifier.weight(1f)) {
                                        Text("${formatMoney(payment.amount)} ${tr("جنيه", "EGP")}", fontWeight = FontWeight.ExtraBold, color = CustomerGreen)
                                        Text(formatDate(payment.createdAtMillis), fontSize = 10.sp, color = Color(0xFF64748B))
                                        if (payment.createdByEmail.isNotBlank()) Text(payment.createdByEmail, fontSize = 10.sp, color = CustomerPrimary)
                                        if (payment.note.isNotBlank()) Text(payment.note, fontSize = 11.sp, color = Color(0xFF475569))
                                    }
                                    Icon(Icons.Default.Payments, contentDescription = null, tint = CustomerGreen)
                                }
                            }
                        }
                    }

                    item {
                        Button(
                            onClick = {
                                customer?.let { receiptCustomer ->
                                    pendingOutputOrder = currentOrder
                                    pendingOutputCustomer = receiptCustomer
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = CustomerPrimary)
                        ) {
                            Icon(Icons.Default.QrCodeScanner, contentDescription = null)
                            Spacer(Modifier.width(7.dp))
                            Text(appText(tr("استخراج صورة للطلب", "Create order image"), "Create order image"), fontWeight = FontWeight.ExtraBold)
                        }
                    }

                    if (isManager && !currentOrder.isVoided) {
                        item {
                            OutlinedButton(
                                onClick = { showVoidDialog = true },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(14.dp),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFB91C1C))
                            ) {
                                Icon(Icons.Default.Delete, contentDescription = null)
                                Spacer(Modifier.width(7.dp))
                                Text(tr("إلغاء الطلب - مدير فقط", "Void Order - Manager Only"), fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }

    val detailsOutputOrder = pendingOutputOrder
    val detailsOutputCustomer = pendingOutputCustomer
    if (detailsOutputOrder != null && detailsOutputCustomer != null) {
        OrderImageShareDialog(
            order = detailsOutputOrder,
            customer = detailsOutputCustomer,
            onDismiss = {
                pendingOutputOrder = null
                pendingOutputCustomer = null
            }
        )
    }

    val activeCustomer = customer
    if (showPaymentDialog && activeCustomer != null) {
        PaymentCollectionDialog(
            remaining = currentOrder.remainingAmount,
            onDismiss = { showPaymentDialog = false },
            onSave = { amount, note, done ->
                viewModel.collectOrderPayment(activeCustomer, currentOrder, amount, note) { updated, message ->
                    done()
                    statusSuccess = updated != null
                    statusMessage = message
                    if (updated != null) {
                        currentOrder = updated
                        showPaymentDialog = false
                    }
                }
            }
        )
    }

    if (showEditDialog && activeCustomer != null) {
        OrderFinancialEditDialog(
            order = currentOrder,
            onDismiss = { showEditDialog = false },
            onSave = { discountAmount, discountPercent, paymentStatus, paidAmount, notes, done ->
                viewModel.updateOrderFinancials(
                    customer = activeCustomer,
                    order = currentOrder,
                    discountAmount = discountAmount,
                    discountPercent = discountPercent,
                    paymentStatus = paymentStatus,
                    paidAmount = paidAmount,
                    notes = notes
                ) { updated, message ->
                    done()
                    statusSuccess = updated != null
                    statusMessage = message
                    if (updated != null) {
                        currentOrder = updated
                        showEditDialog = false
                    }
                }
            }
        )
    }

    if (showVoidDialog && activeCustomer != null) {
        AlertDialog(
            onDismissRequest = { showVoidDialog = false },
            title = { Text(tr("إلغاء الطلب", "Void Order"), fontWeight = FontWeight.ExtraBold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(tr("الطلب هيفضل محفوظ في سجل المراجعة لكنه مش هيتحسب في المبيعات.", "The order will remain in the audit log but will not count toward sales."))
                    OutlinedTextField(
                        value = voidReason,
                        onValueChange = { voidReason = it.take(300) },
                        modifier = Modifier.fillMaxWidth().heightIn(min = 112.dp),
                        label = { Text(tr("سبب الإلغاء", "Void Reason")) },
                        minLines = 2
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.voidOrder(activeCustomer, currentOrder, voidReason) { ok, message ->
                            statusSuccess = ok
                            statusMessage = message
                            if (ok) {
                                currentOrder = currentOrder.copy(isVoided = true, voidReason = voidReason.trim())
                                showVoidDialog = false
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB91C1C))
                ) { Text(tr("تأكيد الإلغاء", "Confirm Void")) }
            },
            dismissButton = { TextButton(onClick = { showVoidDialog = false }) { Text(tr("رجوع", "Back")) } }
        )
    }
}

private fun workflowStatusArabic(status: String): String = when (status) {
    "sent_to_lab" -> "تم الإرسال للمعمل"
    "processing" -> "جاري التنفيذ"
    "ready" -> "النتائج جاهزة"
    "delivered" -> "تم التسليم"
    else -> "جديد"
}

private fun workflowStatusEnglish(status: String): String = when (status) {
    "sent_to_lab" -> "Sent to Lab"
    "processing" -> "Processing"
    "ready" -> "Results Ready"
    "delivered" -> "Delivered"
    else -> "New"
}

@Composable
private fun OrderWorkflowStatusBar(
    currentStatus: String,
    onStatusSelected: (String) -> Unit
) {
    val statuses = listOf(
        "new" to tr("جديد", "New"),
        "sent_to_lab" to tr("تم الإرسال", "Sent"),
        "processing" to tr("جاري التنفيذ", "Processing"),
        "ready" to tr("جاهز", "Ready"),
        "delivered" to tr("تم التسليم", "Delivered")
    )
    LazyRow(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
        items(statuses, key = { it.first }) { (value, label) ->
            if (value == currentStatus) {
                Button(
                    onClick = {},
                    enabled = false,
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        disabledContainerColor = CustomerPrimary,
                        disabledContentColor = Color.White
                    )
                ) { Text(label, fontSize = 11.sp, fontWeight = FontWeight.Bold) }
            } else {
                OutlinedButton(
                    onClick = { onStatusSelected(value) },
                    shape = RoundedCornerShape(12.dp)
                ) { Text(label, fontSize = 11.sp, fontWeight = FontWeight.Bold) }
            }
        }
    }
}

@Composable
private fun PaymentCollectionDialog(
    remaining: Double,
    onDismiss: () -> Unit,
    onSave: (amount: Double, note: String, done: () -> Unit) -> Unit
) {
    var amountText by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var saving by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = { if (!saving) onDismiss() },
        title = { Text(tr("تحصيل دفعة", "Collect Payment"), fontWeight = FontWeight.ExtraBold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(tr("المتبقي: ${formatMoney(remaining)} جنيه", "Outstanding: ${formatMoney(remaining)} EGP"), fontWeight = FontWeight.Bold, color = Color(0xFFB91C1C))
                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it.filter { ch -> ch.isDigit() || ch == '.' || ch == ',' }.take(12) },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 72.dp),
                    label = { Text(tr("المبلغ المحصل", "Collected Amount")) },
                    suffix = { Text(tr("ج", "EGP")) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true
                )
                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it.take(300) },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 112.dp),
                    label = { Text(tr("ملاحظة - اختياري", "Note - Optional")) },
                    minLines = 2
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amount = amountText.replace(',', '.').toDoubleOrNull() ?: 0.0
                    if (!saving) {
                        saving = true
                        onSave(amount, note) { saving = false }
                    }
                },
                enabled = !saving
            ) { Text(if (saving) tr("جاري الحفظ...", "Saving...") else tr("تسجيل الدفعة", "Record Payment")) }
        },
        dismissButton = { TextButton(onClick = onDismiss, enabled = !saving) { Text(appText(tr("إلغاء", "Cancel"), "Cancel")) } }
    )
}

@Composable
private fun OrderFinancialEditDialog(
    order: CustomerOrder,
    onDismiss: () -> Unit,
    onSave: (
        discountAmount: Double,
        discountPercent: Double,
        paymentStatus: String,
        paidAmount: Double,
        notes: String,
        done: () -> Unit
    ) -> Unit
) {
    var paymentStatus by remember { mutableStateOf(order.paymentStatus) }
    var paidText by remember { mutableStateOf(formatMoney(order.paidAmount).takeIf { order.paidAmount > 0.0 }.orEmpty()) }
    var notes by remember { mutableStateOf(order.notes) }
    var saving by remember { mutableStateOf(false) }

    val total = order.totalCustomerPrice
    val typedPaid = paidText.replace(',', '.').toDoubleOrNull() ?: 0.0
    val paidEntryRequired = paymentStatus == "partial" || paymentStatus == "unpaid"
    val paidEntryValid = when (paymentStatus) {
        "partial" -> paidText.isNotBlank() && typedPaid > 0.0 && typedPaid < total
        "unpaid" -> paidText.isNotBlank() && typedPaid == 0.0
        else -> true
    }
    val paidAmount = when (paymentStatus) {
        "paid" -> total
        "partial" -> typedPaid.coerceIn(0.0, total)
        else -> 0.0
    }
    val remaining = (total - paidAmount).coerceAtLeast(0.0)

    AlertDialog(
        onDismissRequest = { if (!saving) onDismiss() },
        title = { Text(tr("تعديل الدفع", "Edit Payment"), fontWeight = FontWeight.ExtraBold) },
        text = {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                item {
                    Text(tr("الإجمالي: ${formatMoney(total)} ج", "Total: ${formatMoney(total)} EGP"), fontWeight = FontWeight.ExtraBold, color = CustomerGreen)
                }
                item {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        listOf(
                            "unpaid" to tr("غير مدفوع", "Unpaid"),
                            "partial" to tr("جزئي", "Partial"),
                            "paid" to tr("مدفوع", "Paid")
                        ).forEach { (value, label) ->
                            OutlinedButton(
                                onClick = {
                                    paymentStatus = value
                                    paidText = when (value) {
                                        "unpaid" -> "0"
                                        "partial" -> paidText.takeIf { it != "0" }.orEmpty()
                                        else -> ""
                                    }
                                },
                                modifier = Modifier.weight(1f),
                                contentPadding = PaddingValues(4.dp)
                            ) {
                                Text(label, fontSize = 10.sp)
                            }
                        }
                    }
                }
                if (paidEntryRequired) {
                    item {
                        OutlinedTextField(
                            value = paidText,
                            onValueChange = { paidText = it.filter { ch -> ch.isDigit() || ch == '.' || ch == ',' }.take(12) },
                            modifier = Modifier.fillMaxWidth().heightIn(min = 72.dp),
                            label = { Text(tr("المبلغ المسدد (إجباري)", "Paid amount (required)")) },
                            suffix = { Text(tr("ج", "EGP")) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true,
                            isError = !paidEntryValid
                        )
                    }
                }
                item {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(tr("المدفوع: ${formatMoney(paidAmount)} ج", "Paid: ${formatMoney(paidAmount)} EGP"), fontWeight = FontWeight.Bold, color = CustomerGreen)
                        Text(tr("المتبقي: ${formatMoney(remaining)} ج", "Remaining: ${formatMoney(remaining)} EGP"), fontWeight = FontWeight.Bold, color = if (remaining > 0.0) Color(0xFFB91C1C) else CustomerGreen)
                    }
                }
                item {
                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it.take(500) },
                        modifier = Modifier.fillMaxWidth().heightIn(min = 100.dp),
                        label = { Text(tr("ملاحظات - اختياري", "Notes - Optional")) },
                        minLines = 2
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (!saving) {
                        saving = true
                        onSave(order.discountAmount, order.discountPercent, paymentStatus, paidAmount, notes) { saving = false }
                    }
                },
                enabled = !saving && paidEntryValid
            ) { Text(if (saving) tr("جاري الحفظ...", "Saving...") else tr("حفظ", "Save")) }
        },
        dismissButton = { TextButton(onClick = onDismiss, enabled = !saving) { Text(tr("إلغاء", "Cancel")) } }
    )
}

@Composable
private fun CustomerOrderCard(order: CustomerOrder, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(order.orderNumber, fontWeight = FontWeight.ExtraBold, color = Color(0xFF17324D))
                    Text(formatDate(order.createdAtMillis), fontSize = 11.sp, color = Color(0xFF64748B))
                    Text(
                        tr("حالة الطلب: ${workflowStatusArabic(order.workflowStatus)}", "Order status: ${workflowStatusEnglish(order.workflowStatus)}"),
                        fontSize = 11.sp,
                        color = CustomerPrimary,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Text(
                        "${paymentStatusArabic(order.paymentStatus)} • المتبقي ${formatMoney(order.remainingAmount)} ج",
                        fontSize = 11.sp,
                        color = if (order.remainingAmount > 0.0) Color(0xFFB91C1C) else CustomerGreen,
                        fontWeight = FontWeight.Bold
                    )
                    Text(tr("${order.items.size} تحليل • فتح / صورة", "${order.items.size} tests • open / image"), fontSize = 11.sp, color = CustomerPrimary)
                }
                Text(
                    "${formatMoney(order.totalCustomerPrice)} جنيه",
                    color = CustomerGreen,
                    fontWeight = FontWeight.ExtraBold
                )
            }
            Spacer(Modifier.height(8.dp))
            HorizontalDivider(color = Color(0xFFE2E8F0))
            Spacer(Modifier.height(8.dp))
            order.items.take(4).forEach { item ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        item.englishName.ifBlank { item.arabicName },
                        modifier = Modifier.weight(1f),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        fontSize = 12.sp,
                        color = Color(0xFF334155)
                    )
                    Spacer(Modifier.width(8.dp))
                    Text("${formatMoney(item.customerPrice)} ${tr("ج", "EGP")}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = CustomerPrimary)
                }
            }
            if (order.items.size > 4) {
                Text(tr("+ ${order.items.size - 4} تحاليل أخرى", "+ ${order.items.size - 4} more tests"), fontSize = 11.sp, color = Color(0xFF64748B))
            }
        }
    }
}

@Composable
private fun CustomerEditorDialog(
    existing: Customer?,
    onDismiss: () -> Unit,
    onSave: (
        name: String,
        phone: String,
        alternatePhone: String,
        age: String,
        birthDate: String,
        gender: String,
        address: String,
        notes: String,
        importantAlert: String,
        tags: List<String>,
        defaultDiscountPercent: Double,
        done: () -> Unit
    ) -> Unit
) {
    val context = LocalContext.current
    val today = remember { SimpleDateFormat("dd/MM/yyyy", Locale.US).format(Date()) }
    var name by remember(existing) { mutableStateOf(existing?.name.orEmpty()) }
    var phone by remember(existing) { mutableStateOf(existing?.phone.orEmpty()) }
    var age by remember(existing) { mutableStateOf(existing?.age.orEmpty()) }
    var selectedDate by remember(existing) { mutableStateOf(existing?.birthDate?.ifBlank { today } ?: today) }
    var notes by remember(existing) { mutableStateOf(existing?.notes.orEmpty()) }
    var saving by remember { mutableStateOf(false) }

    fun openDatePicker() {
        val calendar = Calendar.getInstance()
        runCatching {
            val parsed = SimpleDateFormat("dd/MM/yyyy", Locale.US).parse(selectedDate)
            if (parsed != null) calendar.time = parsed
        }
        DatePickerDialog(
            context,
            { _, year, month, day ->
                selectedDate = String.format(Locale.US, "%02d/%02d/%04d", day, month + 1, year)
            },
            calendar.get(Calendar.YEAR),
            calendar.get(Calendar.MONTH),
            calendar.get(Calendar.DAY_OF_MONTH)
        ).show()
    }

    BackHandler(enabled = true) {
        if (!saving) onDismiss()
    }

    Dialog(
        onDismissRequest = { if (!saving) onDismiss() },
        properties = DialogProperties(usePlatformDefaultWidth = false, dismissOnBackPress = true)
    ) {
        Surface(
            modifier = Modifier.fillMaxSize().padding(10.dp),
            shape = RoundedCornerShape(24.dp),
            color = CustomerBg
        ) {
            Column(Modifier.fillMaxSize()) {
                CustomerHeader(
                    title = if (existing == null) tr("إضافة عميل", "Add Customer") else tr("تعديل بيانات العميل", "Edit Customer"),
                    subtitle = tr("بيانات أساسية فقط", "Essential data only"),
                    onBack = onDismiss,
                    onClose = onDismiss
                )

                LazyColumn(
                    modifier = Modifier.fillMaxSize().padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 30.dp)
                ) {
                    item {
                        OutlinedTextField(
                            value = name,
                            onValueChange = { name = it.take(120) },
                            modifier = Modifier.fillMaxWidth().heightIn(min = 72.dp),
                            label = { Text(tr("اسم العميل", "Customer Name")) },
                            singleLine = true
                        )
                    }
                    item {
                        OutlinedTextField(
                            value = phone,
                            onValueChange = { phone = it.filter { ch -> ch.isDigit() || ch == '+' }.take(20) },
                            modifier = Modifier.fillMaxWidth().heightIn(min = 72.dp),
                            label = { Text(tr("رقم واتساب", "WhatsApp Number")) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                            singleLine = true
                        )
                    }
                    item {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = age,
                                onValueChange = { age = it.filter(Char::isDigit).take(3) },
                                modifier = Modifier.weight(0.8f).heightIn(min = 72.dp),
                                label = { Text(tr("السن", "Age")) },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true
                            )
                            OutlinedButton(
                                onClick = { openDatePicker() },
                                modifier = Modifier.weight(1.2f).heightIn(min = 72.dp),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(Icons.Default.CalendarMonth, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(6.dp))
                                Column(horizontalAlignment = Alignment.Start) {
                                    Text(tr("التاريخ", "Date"), fontSize = 10.sp, color = Color(0xFF64748B))
                                    Text(selectedDate, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                }
                            }
                        }
                    }
                    item {
                        OutlinedTextField(
                            value = notes,
                            onValueChange = { notes = it.take(500) },
                            modifier = Modifier.fillMaxWidth().heightIn(min = 112.dp),
                            label = { Text(tr("ملاحظات - اختياري", "Notes - Optional")) },
                            minLines = 2,
                            maxLines = 4
                        )
                    }
                    item {
                        Text(
                            tr("المدفوع والمتبقي يتسجلوا داخل كل طلب، مش في بيانات العميل الأساسية.", "Paid and remaining amounts are recorded per order, not in the basic customer profile."),
                            fontSize = 11.sp,
                            color = Color(0xFF64748B)
                        )
                    }
                    item {
                        Button(
                            onClick = {
                                if (!saving && name.isNotBlank() && phone.isNotBlank()) {
                                    saving = true
                                    onSave(
                                        name.trim(),
                                        phone.trim(),
                                        existing?.alternatePhone.orEmpty(),
                                        age.trim(),
                                        selectedDate,
                                        existing?.gender.orEmpty(),
                                        existing?.address.orEmpty(),
                                        notes.trim(),
                                        existing?.importantAlert.orEmpty(),
                                        existing?.tags.orEmpty(),
                                        existing?.defaultDiscountPercent ?: 0.0
                                    ) { saving = false }
                                }
                            },
                            enabled = !saving && name.isNotBlank() && phone.isNotBlank(),
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = CustomerPrimary),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            if (saving) {
                                CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp, color = Color.White)
                            } else {
                                Icon(Icons.Default.Save, contentDescription = null)
                                Spacer(Modifier.width(6.dp))
                                Text(tr("حفظ", "Save"), fontWeight = FontWeight.ExtraBold)
                            }
                        }
                        TextButton(onClick = onDismiss, enabled = !saving, modifier = Modifier.fillMaxWidth()) {
                            Text(tr("إلغاء", "Cancel"))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StatusBanner(message: String, success: Boolean, modifier: Modifier = Modifier) {
    val bg = if (success) Color(0xFFE8F7ED) else Color(0xFFFFEEEE)
    val fg = if (success) Color(0xFF166534) else Color(0xFFB91C1C)
    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(bg, RoundedCornerShape(12.dp))
            .padding(horizontal = 12.dp, vertical = 10.dp)
    ) {
        Text(message, color = fg, fontWeight = FontWeight.Bold, fontSize = 12.sp)
    }
}

@Composable
private fun FinancialRow(label: String, value: Double, valueColor: Color = Color(0xFF17324D)) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = Color(0xFF64748B), fontSize = 12.sp)
        val prefix = if (value < 0.0) "- " else ""
        Text("$prefix${formatMoney(kotlin.math.abs(value))} ${tr("جنيه", "EGP")}", fontWeight = FontWeight.Bold, color = valueColor, fontSize = 12.sp)
    }
}

private fun paymentStatusArabic(status: String): String = when (status) {
    "paid" -> tr("مدفوع بالكامل", "Fully Paid")
    "partial" -> tr("مدفوع جزئيا", "Partially Paid")
    else -> tr("غير مدفوع", "Unpaid")
}

private fun paymentStatusEnglish(status: String): String = when (status) {
    "paid" -> "Paid"
    "partial" -> "Partially paid"
    else -> "Unpaid"
}


private fun formatDate(value: Long): String {
    if (value <= 0L) return ""
    return SimpleDateFormat("dd/MM/yyyy - hh:mm a", Locale("ar", "EG")).format(Date(value))
}

private fun formatMoney(value: Double): String {
    return if (value % 1.0 == 0.0) value.toLong().toString() else String.format(Locale.US, "%.2f", value)
}

private fun formatPercent(value: Double): String {
    return if (value % 1.0 == 0.0) value.toLong().toString() else String.format(Locale.US, "%.1f", value)
}

private fun formatShortDate(value: Long): String {
    if (value <= 0L) return "—"
    return SimpleDateFormat("dd/MM/yy", Locale("ar", "EG")).format(Date(value))
}

private fun normalizeWhatsAppNumber(value: String): String {
    val digits = value.filter { it.isDigit() }
    return when {
        digits.startsWith("20") -> digits
        digits.startsWith("0") && digits.length >= 10 -> "20${digits.drop(1)}"
        else -> digits
    }
}
