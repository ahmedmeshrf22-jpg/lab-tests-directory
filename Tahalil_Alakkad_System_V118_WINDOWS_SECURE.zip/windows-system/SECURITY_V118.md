# Windows V118 Security

- Electron sandbox + contextIsolation + no Node in renderer.
- CSP blocks remote scripts/frames/plugins and allows only Firebase network endpoints.
- External links are restricted to HTTP/HTTPS and navigation away from the local app is blocked.
- Result files are magic-signature checked, limited to 6 MB, opened from a short-lived temp folder, and stale plaintext temp files are cleaned.
- New result files carry SHA-256 integrity metadata; Android and Windows verify it before opening.
- Firebase Auth persistence is browser-session only on Windows, reducing long-lived authentication tokens on disk.
- Local PIN upgrades to PBKDF2-HMAC-SHA256 310k iterations after the next successful unlock.
- Portable EXE; no installer required.
