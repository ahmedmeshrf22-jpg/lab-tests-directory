import { auth, db } from './firebase.js';
import { doc, getDoc, setDoc } from 'firebase/firestore';

// Keep schema byte-for-byte compatible with Android V117 FirestoreResultFileStore.
const RAW_CHUNK_BYTES = 420 * 1024;
const MAX_FILE_BYTES = 6 * 1024 * 1024;
const MAX_CHUNKS = 64;
const META_PREFIX = 'resultmeta_';
const CHUNK_PREFIX = 'resultchunk_';

function sanitizeName(name = '', mime = '') {
  const fallback = mime === 'application/pdf' ? 'result.pdf' : mime.includes('png') ? 'result.png' : mime.includes('webp') ? 'result.webp' : 'result.jpg';
  const clean = String(name || fallback).replace(/[\\/:*?"<>|\x00-\x1f]+/g, '_').replace(/\s+/g, ' ').trim();
  return (clean || fallback).slice(0, 120);
}

function bytesToBase64(bytes) {
  let binary = '';
  const step = 32 * 1024;
  for (let i = 0; i < bytes.length; i += step) {
    const part = bytes.subarray(i, Math.min(i + step, bytes.length));
    binary += String.fromCharCode(...part);
  }
  return btoa(binary);
}

function base64ToBytes(text) {
  const binary = atob(String(text || ''));
  const out = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) out[i] = binary.charCodeAt(i);
  return out;
}

async function sha256Hex(bytes) {
  const digest = await crypto.subtle.digest('SHA-256', bytes);
  return [...new Uint8Array(digest)].map(x => x.toString(16).padStart(2, '0')).join('');
}

function parseRef(storedRef = '') {
  const text = String(storedRef || '').trim();
  if (!text.startsWith('fsr:')) return null;
  const match = text.match(/^fsr:\/+(?:\/)?([^/]+)\/([^/?#]+)/i);
  if (!match) return null;
  return { customerId: decodeURIComponent(match[1]), fileId: decodeURIComponent(match[2]) };
}

export function isFirestoreResultRef(storedRef = '') {
  return !!parseRef(storedRef);
}

export async function uploadResultFile(file, customerId, orderId, displayName = '') {
  const user = auth.currentUser;
  if (!user) throw new Error('سجل الدخول أولاً');
  if (!customerId || !orderId) throw new Error('بيانات الطلب غير مكتملة');
  if (!file) throw new Error('اختر صورة أو PDF للنتيجة');

  const mime = String(file.type || '').toLowerCase();
  if (!(mime === 'application/pdf' || mime.startsWith('image/'))) throw new Error('الملفات المسموحة صور أو PDF فقط');
  const size = Number(file.size || 0);
  if (size <= 0) throw new Error('الملف فارغ');
  if (size > MAX_FILE_BYTES) throw new Error('حجم الملف أكبر من 6 MB');

  const bytes = new Uint8Array(await file.arrayBuffer());
  if (!bytes.length) throw new Error('الملف فارغ');
  if (bytes.length > MAX_FILE_BYTES) throw new Error('حجم الملف أكبر من 6 MB');

  const fileId = crypto.randomUUID().replaceAll('-', '');
  const safeName = sanitizeName(displayName || file.name, mime);
  const activityPath = ['customers', String(customerId), 'activity'];
  const chunkCount = Math.ceil(bytes.length / RAW_CHUNK_BYTES);
  if (chunkCount <= 0 || chunkCount > MAX_CHUNKS) throw new Error('حجم ملف النتيجة غير مدعوم');

  // Sequential writes intentionally mirror Android V117 and avoid request-size spikes.
  for (let index = 0; index < chunkCount; index++) {
    const start = index * RAW_CHUNK_BYTES;
    const end = Math.min(start + RAW_CHUNK_BYTES, bytes.length);
    const encoded = bytesToBase64(bytes.subarray(start, end));
    const chunkId = `${CHUNK_PREFIX}${fileId}_${String(index).padStart(3, '0')}`;
    await setDoc(doc(db, ...activityPath, chunkId), {
      type: 'result_file_chunk',
      file_id: fileId,
      order_id: String(orderId),
      chunk_index: index,
      chunk_count: chunkCount,
      data_b64: encoded,
      actor_uid: user.uid,
      actor_email: user.email || ''
    });
  }

  const sha256 = await sha256Hex(bytes);
  await setDoc(doc(db, ...activityPath, `${META_PREFIX}${fileId}`), {
    type: 'result_file_meta',
    file_id: fileId,
    order_id: String(orderId),
    file_name: safeName,
    mime_type: mime,
    size_bytes: bytes.length,
    chunk_count: chunkCount,
    sha256,
    actor_uid: user.uid,
    actor_email: user.email || '',
    file_created_ms: Date.now()
  });

  return {
    ref: `fsr:/${encodeURIComponent(String(customerId))}/${encodeURIComponent(fileId)}`,
    name: safeName,
    mime,
    size: bytes.length,
    chunks: chunkCount
  };
}

export async function readResultFile(storedRef) {
  const parsed = parseRef(storedRef);
  if (!parsed) throw new Error('مرجع ملف النتيجة غير صالح');
  const { customerId, fileId } = parsed;
  const activityPath = ['customers', customerId, 'activity'];

  const metaSnap = await getDoc(doc(db, ...activityPath, `${META_PREFIX}${fileId}`));
  if (!metaSnap.exists()) throw new Error('ملف النتيجة غير موجود');
  const meta = metaSnap.data() || {};
  const name = sanitizeName(meta.file_name || 'result.pdf', meta.mime_type || 'application/pdf');
  const mime = String(meta.mime_type || 'application/pdf');
  const chunkCount = Number(meta.chunk_count || 0);
  const expectedSize = Number(meta.size_bytes || 0);
  const expectedSha256 = String(meta.sha256 || '').trim().toLowerCase();
  if (!Number.isInteger(chunkCount) || chunkCount <= 0 || chunkCount > MAX_CHUNKS) throw new Error('بيانات ملف النتيجة غير مكتملة');
  if (expectedSize <= 0 || expectedSize > MAX_FILE_BYTES) throw new Error('حجم ملف النتيجة غير صالح');

  const parts = [];
  let total = 0;
  for (let index = 0; index < chunkCount; index++) {
    const chunkId = `${CHUNK_PREFIX}${fileId}_${String(index).padStart(3, '0')}`;
    const snap = await getDoc(doc(db, ...activityPath, chunkId));
    if (!snap.exists()) throw new Error('جزء من ملف النتيجة غير موجود');
    const encoded = String(snap.data()?.data_b64 || '');
    if (!encoded) throw new Error('جزء من ملف النتيجة غير موجود');
    let part;
    try { part = base64ToBytes(encoded); } catch { throw new Error('تعذر قراءة ملف النتيجة'); }
    parts.push(part);
    total += part.length;
    if (total > MAX_FILE_BYTES) throw new Error('حجم ملف النتيجة غير صالح');
  }
  if (total !== expectedSize) throw new Error('ملف النتيجة غير مكتمل، حاول مرة أخرى');

  const bytes = new Uint8Array(total);
  let offset = 0;
  for (const part of parts) { bytes.set(part, offset); offset += part.length; }
  if (expectedSha256 && (await sha256Hex(bytes)) !== expectedSha256) throw new Error('فشل فحص سلامة ملف النتيجة');
  return { bytes, name, mime, customerId, fileId };
}
