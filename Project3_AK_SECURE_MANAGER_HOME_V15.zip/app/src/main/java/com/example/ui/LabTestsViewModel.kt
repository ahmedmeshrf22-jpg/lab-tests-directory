package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.AppUserProfile
import com.example.data.model.AuditLogEntry
import com.example.data.model.Customer
import com.example.data.model.CustomerActivityEntry
import com.example.data.model.CustomerOrder
import com.example.data.model.CustomerOrderItem
import com.example.data.model.LabTest
import com.example.data.model.PaymentEntry
import com.example.data.model.ReportSummary
import com.example.data.model.normalizeText
import com.example.data.repository.LabTestRepository
import com.example.settings.AppSettings
import com.example.settings.AppSettingsStore
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.SetOptions
import com.google.firebase.firestore.Source
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import org.json.JSONArray
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale


data class QueryGroup(
    val query: String,
    val candidates: List<LabTest>
)

sealed interface SearchUiState {
    object EmptyQuery : SearchUiState
    data class Success(
        val query: String,
        val queryGroups: List<QueryGroup>,
        val unmatchedQueries: List<String> = emptyList()
    ) : SearchUiState
    data class NoResults(
        val unmatchedQueries: List<String> = emptyList()
    ) : SearchUiState
}

class LabTestsViewModel(application: Application) : AndroidViewModel(application) {

    companion object {
        const val MANAGER_EMAIL = "abdelrahman@tahali.com"
        private const val MANAGER_UID = "Wps5Y19pZSbeGooEzFfW5UFsshq2"
        private const val LAB2LAB_COLLECTION = "lab2lab_prices"
        private const val CUSTOMER_OVERRIDES_COLLECTION = "customer_price_overrides"
        private const val CUSTOMERS_COLLECTION = "customers"
        private const val USERS_COLLECTION = "users"
        private const val AUDIT_COLLECTION = "audit_logs"
        private const val PHONE_REGISTRY_COLLECTION = "phone_registry"
        private const val SECONDARY_AUTH_APP = "TahalilUserAdmin"

        fun isManagerAccount(email: String?, uid: String? = null): Boolean {
            val normalizedEmail = email?.trim()?.lowercase()
            return normalizedEmail == MANAGER_EMAIL || uid == MANAGER_UID
        }
    }

    private val repository = LabTestRepository(application)
    private val settingsStore = AppSettingsStore(application)

    val appSettings: StateFlow<AppSettings> = settingsStore.settings

    // Firestore Android persistence stays enabled (the SDK default) so operational customer/order
    // writes can survive temporary network loss and sync when connectivity returns. Lab2Lab is still
    // protected by server rules and is never loaded into staff UI/state.
    private val firestore: FirebaseFirestore = FirebaseFirestore.getInstance()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _uiState = MutableStateFlow<SearchUiState>(SearchUiState.EmptyQuery)
    val uiState: StateFlow<SearchUiState> = _uiState.asStateFlow()

    private val _selectedTests = MutableStateFlow<List<LabTest>>(emptyList())
    val selectedTests: StateFlow<List<LabTest>> = _selectedTests.asStateFlow()

    private val _isManager = MutableStateFlow(false)
    val isManager: StateFlow<Boolean> = _isManager.asStateFlow()

    /** null = checking, true = enabled, false = disabled by manager. */
    private val _accountEnabled = MutableStateFlow<Boolean?>(null)
    val accountEnabled: StateFlow<Boolean?> = _accountEnabled.asStateFlow()

    private val _currentUserProfile = MutableStateFlow<AppUserProfile?>(null)
    val currentUserProfile: StateFlow<AppUserProfile?> = _currentUserProfile.asStateFlow()

    private val _lab2LabPrices = MutableStateFlow<Map<Int, String>>(emptyMap())
    val lab2LabPrices: StateFlow<Map<Int, String>> = _lab2LabPrices.asStateFlow()

    private val _customerPriceOverrides = MutableStateFlow<Map<Int, String>>(emptyMap())
    val customerPriceOverrides: StateFlow<Map<Int, String>> = _customerPriceOverrides.asStateFlow()

    private val _customers = MutableStateFlow<List<Customer>>(emptyList())
    val customers: StateFlow<List<Customer>> = _customers.asStateFlow()

    private val _customersLoading = MutableStateFlow(false)
    val customersLoading: StateFlow<Boolean> = _customersLoading.asStateFlow()

    private val _customerOrders = MutableStateFlow<List<CustomerOrder>>(emptyList())
    val customerOrders: StateFlow<List<CustomerOrder>> = _customerOrders.asStateFlow()

    private val _customerActivity = MutableStateFlow<List<CustomerActivityEntry>>(emptyList())
    val customerActivity: StateFlow<List<CustomerActivityEntry>> = _customerActivity.asStateFlow()

    private val _paymentHistory = MutableStateFlow<List<PaymentEntry>>(emptyList())
    val paymentHistory: StateFlow<List<PaymentEntry>> = _paymentHistory.asStateFlow()

    private val _reportOrders = MutableStateFlow<List<CustomerOrder>>(emptyList())
    val reportOrders: StateFlow<List<CustomerOrder>> = _reportOrders.asStateFlow()

    private val _reportsLoading = MutableStateFlow(false)
    val reportsLoading: StateFlow<Boolean> = _reportsLoading.asStateFlow()

    private val _managerHomeSummary = MutableStateFlow(ReportSummary())
    val managerHomeSummary: StateFlow<ReportSummary> = _managerHomeSummary.asStateFlow()

    private val _managerHomeLoading = MutableStateFlow(false)
    val managerHomeLoading: StateFlow<Boolean> = _managerHomeLoading.asStateFlow()

    private val _auditLogs = MutableStateFlow<List<AuditLogEntry>>(emptyList())
    val auditLogs: StateFlow<List<AuditLogEntry>> = _auditLogs.asStateFlow()

    private val _users = MutableStateFlow<List<AppUserProfile>>(emptyList())
    val users: StateFlow<List<AppUserProfile>> = _users.asStateFlow()

    private val _systemMessage = MutableStateFlow<String?>(null)
    val systemMessage: StateFlow<String?> = _systemMessage.asStateFlow()

    private var managerPricesLoaded = false
    private var customerOverridesLoaded = false
    private var profileListener: ListenerRegistration? = null
    private var lastAuthUid: String? = null

    init {
        viewModelScope.launch(Dispatchers.IO) { repository.getLabTests() }
    }

    override fun onCleared() {
        profileListener?.remove()
        super.onCleared()
    }

    /** Called whenever Firebase Auth user changes. */
    fun onAuthenticatedUserChanged(email: String?, uid: String? = null) {
        settingsStore.setActiveProfile(uid ?: email?.trim()?.lowercase())

        if (email.isNullOrBlank() && uid.isNullOrBlank()) {
            lastAuthUid = null
            profileListener?.remove()
            profileListener = null
            _accountEnabled.value = null
            _currentUserProfile.value = null
            _customers.value = emptyList()
            _customerOrders.value = emptyList()
            clearLab2LabState()
            return
        }

        val manager = isManagerAccount(email, uid)
        _isManager.value = manager

        if (manager) {
            _accountEnabled.value = true
            _currentUserProfile.value = AppUserProfile(
                uid = uid.orEmpty(),
                email = email.orEmpty(),
                displayName = "عبدالرحمن",
                role = "super_admin",
                enabled = true
            )
            ensureManagerProfile(email, uid)
            loadAfterAccessGranted()
            loadManagerPriceState()
            return
        }

        clearLab2LabState()
        if (uid.isNullOrBlank()) {
            _accountEnabled.value = true
            loadAfterAccessGranted()
            return
        }

        if (lastAuthUid != uid) {
            _accountEnabled.value = null
            lastAuthUid = uid
            attachUserProfileListener(email.orEmpty(), uid)
        }
    }

    private fun loadAfterAccessGranted() {
        if (!customerOverridesLoaded) loadCustomerPriceOverrides()
        if (_customers.value.isEmpty()) loadCustomers()
    }

    private fun ensureManagerProfile(email: String?, uid: String?) {
        if (uid.isNullOrBlank()) return
        val now = System.currentTimeMillis()
        val data = mapOf(
            "email" to email.orEmpty().trim().lowercase(),
            "display_name" to "عبدالرحمن",
            "role" to "super_admin",
            "enabled" to true,
            "can_edit_customers" to true,
            "can_discount" to true,
            "can_collect_payments" to true,
            "can_view_sales_reports" to true,
            "updated_at_ms" to now,
            "updated_at" to FieldValue.serverTimestamp()
        )
        firestore.collection(USERS_COLLECTION).document(uid).set(data, SetOptions.merge())
    }

    private fun attachUserProfileListener(email: String, uid: String) {
        profileListener?.remove()
        val ref = firestore.collection(USERS_COLLECTION).document(uid)

        // Create a safe default staff profile if this is a legacy user. If V14 rules have not
        // been published yet the write may fail; the listener fallback still keeps legacy access.
        ref.get(Source.SERVER)
            .addOnSuccessListener { snapshot ->
                if (!snapshot.exists()) {
                    val now = System.currentTimeMillis()
                    val defaultData = mapOf(
                        "email" to email.trim().lowercase(),
                        "display_name" to email.substringBefore('@').ifBlank { "مستخدم" },
                        "role" to "staff",
                        "enabled" to true,
                        "can_edit_customers" to true,
                        "can_discount" to true,
                        "can_collect_payments" to true,
                        "can_view_sales_reports" to false,
                        "created_at_ms" to now,
                        "created_at" to FieldValue.serverTimestamp(),
                        "updated_at_ms" to now,
                        "updated_at" to FieldValue.serverTimestamp()
                    )
                    ref.set(defaultData, SetOptions.merge())
                }
            }
            .addOnFailureListener {
                // Backward compatibility while rules are being upgraded.
                _accountEnabled.value = true
                _currentUserProfile.value = defaultStaffProfile(uid, email)
                loadAfterAccessGranted()
            }

        profileListener = ref.addSnapshotListener { snapshot, error ->
            if (error != null) {
                if (_accountEnabled.value == null) {
                    _accountEnabled.value = true
                    _currentUserProfile.value = defaultStaffProfile(uid, email)
                    loadAfterAccessGranted()
                }
                return@addSnapshotListener
            }

            val profile = if (snapshot != null && snapshot.exists()) {
                parseUserProfile(snapshot)
            } else {
                defaultStaffProfile(uid, email)
            }
            _currentUserProfile.value = profile
            _accountEnabled.value = profile.enabled
            settingsStore.applyRemotePinReset(profile.pinResetRequestedAtMillis)
            if (profile.enabled) loadAfterAccessGranted()
            else {
                _customers.value = emptyList()
                _customerOrders.value = emptyList()
            }
        }
    }

    private fun defaultStaffProfile(uid: String, email: String): AppUserProfile = AppUserProfile(
        uid = uid,
        email = email,
        displayName = email.substringBefore('@').ifBlank { "مستخدم" },
        role = "staff",
        enabled = true
    )

    private fun parseUserProfile(doc: DocumentSnapshot): AppUserProfile = AppUserProfile(
        uid = doc.id,
        email = doc.getString("email").orEmpty(),
        displayName = doc.getString("display_name").orEmpty().ifBlank { doc.getString("email").orEmpty().substringBefore('@') },
        role = doc.getString("role") ?: "staff",
        enabled = doc.getBoolean("enabled") ?: true,
        canEditCustomers = doc.getBoolean("can_edit_customers") ?: true,
        canDiscount = doc.getBoolean("can_discount") ?: true,
        canCollectPayments = doc.getBoolean("can_collect_payments") ?: true,
        canViewSalesReports = doc.getBoolean("can_view_sales_reports") ?: false,
        createdAtMillis = doc.getLong("created_at_ms") ?: 0L,
        updatedAtMillis = doc.getLong("updated_at_ms") ?: 0L,
        pinResetRequestedAtMillis = doc.getLong("pin_reset_requested_at_ms") ?: 0L
    )

    private fun loadManagerPriceState() {
        if (!managerPricesLoaded || _lab2LabPrices.value.isEmpty()) {
            val localPrices = loadManagerPricesFromAsset()
            _lab2LabPrices.value = localPrices
            managerPricesLoaded = localPrices.isNotEmpty()
        }

        firestore.collection(LAB2LAB_COLLECTION)
            .get(Source.SERVER)
            .addOnSuccessListener { snapshot ->
                if (!_isManager.value) return@addOnSuccessListener
                val serverPrices = mutableMapOf<Int, String>()
                snapshot.documents.forEach { doc ->
                    val id = documentTestId(doc.id, doc.getLong("id")?.toInt()) ?: return@forEach
                    val value = doc.get("lab_to_lab_price")
                        ?: doc.get("lab2lab_price")
                        ?: doc.get("labToLabPrice")
                        ?: doc.get("price")
                        ?: return@forEach
                    formatFirestorePrice(value)?.takeIf { it.isNotBlank() }?.let { serverPrices[id] = it }
                }
                if (serverPrices.isNotEmpty()) {
                    _lab2LabPrices.value = _lab2LabPrices.value + serverPrices
                    managerPricesLoaded = true
                }
            }
    }

    private fun loadCustomerPriceOverrides() {
        firestore.collection(CUSTOMER_OVERRIDES_COLLECTION)
            .get(Source.SERVER)
            .addOnSuccessListener { snapshot ->
                val prices = mutableMapOf<Int, String>()
                snapshot.documents.forEach { doc ->
                    val id = documentTestId(doc.id, doc.getLong("id")?.toInt()) ?: return@forEach
                    val value = doc.get("customer_price")
                        ?: doc.get("customerPrice")
                        ?: doc.get("price")
                        ?: return@forEach
                    formatFirestorePrice(value)?.takeIf { it.isNotBlank() }?.let { prices[id] = it }
                }
                _customerPriceOverrides.value = prices
                customerOverridesLoaded = true
            }
    }

    fun saveManagerPrices(
        test: LabTest,
        customerPrice: String,
        lab2LabPrice: String,
        onResult: (success: Boolean, message: String) -> Unit
    ) {
        if (!_isManager.value) {
            onResult(false, "غير مصرح بتعديل الأسعار")
            return
        }

        val customerNumber = parsePriceInput(customerPrice)
        val labNumber = parsePriceInput(lab2LabPrice)
        if (customerNumber == null || customerNumber < 0) {
            onResult(false, "اكتب سعر عميل صحيح")
            return
        }
        if (labNumber == null || labNumber < 0) {
            onResult(false, "اكتب سعر Lab 2 Lab صحيح")
            return
        }

        val docId = "test_${test.id}"
        val customerRef = firestore.collection(CUSTOMER_OVERRIDES_COLLECTION).document(docId)
        val labRef = firestore.collection(LAB2LAB_COLLECTION).document(docId)
        val customerData = mapOf(
            "id" to test.id,
            "customer_price" to customerNumber,
            "updated_at" to FieldValue.serverTimestamp()
        )
        val labData = mapOf(
            "id" to test.id,
            "lab_to_lab_price" to labNumber,
            "updated_at" to FieldValue.serverTimestamp()
        )

        firestore.runBatch { batch ->
            batch.set(customerRef, customerData, SetOptions.merge())
            batch.set(labRef, labData, SetOptions.merge())
        }.addOnSuccessListener {
            _customerPriceOverrides.value = _customerPriceOverrides.value + (test.id to formatNumber(customerNumber))
            _lab2LabPrices.value = _lab2LabPrices.value + (test.id to formatNumber(labNumber))
            customerOverridesLoaded = true
            managerPricesLoaded = true
            logAudit(
                action = "price_update",
                entityType = "lab_test",
                entityId = test.id.toString(),
                title = "تعديل سعر تحليل",
                details = "${test.englishName}: عميل ${formatNumber(customerNumber)} / Lab2Lab ${formatNumber(labNumber)}"
            )
            onResult(true, "تم حفظ أسعار ${test.englishName}")
        }.addOnFailureListener {
            onResult(false, "تعذر حفظ الأسعار. تأكد من الإنترنت وصلاحيات Firebase")
        }
    }

    fun updateAppSettings(settings: AppSettings) = settingsStore.save(settings)
    fun setAppPin(pin: String): Boolean = settingsStore.setAppPin(pin)
    fun verifyAppPin(pin: String): Boolean = settingsStore.verifyAppPin(pin)
    fun clearAppPin() = settingsStore.clearAppPin()
    fun resetAppSettings() = settingsStore.reset()
    fun toggleFavoriteTest(testId: Int) = settingsStore.toggleFavoriteTest(testId)
    fun useRecentSearch(query: String) = onQueryChanged(query)

    fun refreshPrices(onResult: (Boolean, String) -> Unit) {
        firestore.collection(CUSTOMER_OVERRIDES_COLLECTION)
            .get(Source.SERVER)
            .addOnSuccessListener { customerSnapshot ->
                val customerPrices = mutableMapOf<Int, String>()
                customerSnapshot.documents.forEach { doc ->
                    val id = documentTestId(doc.id, doc.getLong("id")?.toInt()) ?: return@forEach
                    val value = doc.get("customer_price") ?: doc.get("customerPrice") ?: doc.get("price") ?: return@forEach
                    formatFirestorePrice(value)?.takeIf { it.isNotBlank() }?.let { customerPrices[id] = it }
                }
                _customerPriceOverrides.value = customerPrices
                customerOverridesLoaded = true

                if (!_isManager.value) {
                    settingsStore.markSynced()
                    onResult(true, "تم تحديث الأسعار")
                    return@addOnSuccessListener
                }

                firestore.collection(LAB2LAB_COLLECTION).get(Source.SERVER)
                    .addOnSuccessListener { labSnapshot ->
                        val labPrices = mutableMapOf<Int, String>()
                        labSnapshot.documents.forEach { doc ->
                            val id = documentTestId(doc.id, doc.getLong("id")?.toInt()) ?: return@forEach
                            val value = doc.get("lab_to_lab_price")
                                ?: doc.get("lab2lab_price")
                                ?: doc.get("labToLabPrice")
                                ?: doc.get("price")
                                ?: return@forEach
                            formatFirestorePrice(value)?.takeIf { it.isNotBlank() }?.let { labPrices[id] = it }
                        }
                        if (labPrices.isNotEmpty()) {
                            _lab2LabPrices.value = _lab2LabPrices.value + labPrices
                            managerPricesLoaded = true
                        }
                        settingsStore.markSynced()
                        onResult(true, "تم تحديث الأسعار بنجاح")
                    }
                    .addOnFailureListener { onResult(false, "تعذر تحديث أسعار Lab 2 Lab") }
            }
            .addOnFailureListener { onResult(false, "تعذر تحديث الأسعار. تأكد من الإنترنت") }
    }

    fun searchManagerTests(query: String): List<LabTest> =
        if (query.isBlank()) repository.getLabTests() else repository.searchTests(query)

    fun clearLab2LabState() {
        _isManager.value = false
        _lab2LabPrices.value = emptyMap()
        managerPricesLoaded = false
    }

    // ------------------------- USERS / ROLES -------------------------

    fun loadUsers(onResult: ((Boolean, String) -> Unit)? = null) {
        if (!_isManager.value) {
            onResult?.invoke(false, "الإجراء متاح للمدير فقط")
            return
        }
        firestore.collection(USERS_COLLECTION).get(Source.SERVER)
            .addOnSuccessListener { snapshot ->
                val parsed = snapshot.documents.map { parseUserProfile(it) }.toMutableList()
                if (parsed.none { it.uid == MANAGER_UID }) {
                    parsed += AppUserProfile(
                        uid = MANAGER_UID,
                        email = MANAGER_EMAIL,
                        displayName = "عبدالرحمن",
                        role = "super_admin",
                        enabled = true
                    )
                }
                _users.value = parsed.sortedWith(compareByDescending<AppUserProfile> { it.uid == MANAGER_UID }.thenBy { it.displayName.lowercase() })
                onResult?.invoke(true, "تم تحديث المستخدمين")
            }
            .addOnFailureListener { onResult?.invoke(false, "تعذر تحميل المستخدمين") }
    }

    fun createUserAccount(
        displayName: String,
        email: String,
        password: String,
        role: String,
        onResult: (Boolean, String) -> Unit
    ) {
        if (!_isManager.value) {
            onResult(false, "الإجراء متاح للمدير فقط")
            return
        }
        val cleanEmail = email.trim().lowercase()
        val cleanName = displayName.trim()
        if (cleanName.length < 2) {
            onResult(false, "اكتب اسم المستخدم")
            return
        }
        if (!cleanEmail.contains('@')) {
            onResult(false, "اكتب بريد إلكتروني صحيح")
            return
        }
        if (password.length < 6) {
            onResult(false, "كلمة المرور لازم تكون 6 أحرف على الأقل")
            return
        }

        val secondaryApp = try {
            FirebaseApp.getInstance(SECONDARY_AUTH_APP)
        } catch (_: IllegalStateException) {
            FirebaseApp.initializeApp(
                getApplication<Application>(),
                FirebaseApp.getInstance().options,
                SECONDARY_AUTH_APP
            ) ?: run {
                onResult(false, "تعذر تجهيز إنشاء المستخدم")
                return
            }
        }
        val secondaryAuth = FirebaseAuth.getInstance(secondaryApp)
        secondaryAuth.createUserWithEmailAndPassword(cleanEmail, password)
            .addOnSuccessListener { authResult ->
                val newUid = authResult.user?.uid
                if (newUid.isNullOrBlank()) {
                    secondaryAuth.signOut()
                    onResult(false, "تعذر الحصول على UID للمستخدم")
                    return@addOnSuccessListener
                }
                val now = System.currentTimeMillis()
                val normalizedRole = normalizeRole(role)
                val data = mapOf(
                    "email" to cleanEmail,
                    "display_name" to cleanName,
                    "role" to normalizedRole,
                    "enabled" to true,
                    "can_edit_customers" to true,
                    "can_discount" to true,
                    "can_collect_payments" to true,
                    "can_view_sales_reports" to false,
                    "created_at_ms" to now,
                    "created_at" to FieldValue.serverTimestamp(),
                    "updated_at_ms" to now,
                    "updated_at" to FieldValue.serverTimestamp(),
                    "created_by_uid" to currentUid()
                )
                firestore.collection(USERS_COLLECTION).document(newUid).set(data)
                    .addOnSuccessListener {
                        secondaryAuth.signOut()
                        logAudit(
                            action = "user_create",
                            entityType = "user",
                            entityId = newUid,
                            title = "إضافة مستخدم",
                            details = "$cleanName • $cleanEmail • $normalizedRole"
                        )
                        loadUsers()
                        onResult(true, "تم إنشاء حساب $cleanName")
                    }
                    .addOnFailureListener {
                        secondaryAuth.signOut()
                        onResult(false, "تم إنشاء حساب الدخول لكن تعذر حفظ صلاحياته. راجع Firebase")
                    }
            }
            .addOnFailureListener { error ->
                secondaryAuth.signOut()
                onResult(false, error.localizedMessage ?: "تعذر إنشاء المستخدم")
            }
    }

    fun updateUserAccess(
        profile: AppUserProfile,
        enabled: Boolean,
        role: String,
        canEditCustomers: Boolean,
        canDiscount: Boolean,
        canCollectPayments: Boolean,
        canViewSalesReports: Boolean,
        onResult: (Boolean, String) -> Unit
    ) {
        if (!_isManager.value) {
            onResult(false, "الإجراء متاح للمدير فقط")
            return
        }
        if (profile.uid == MANAGER_UID) {
            onResult(false, "لا يمكن إيقاف أو خفض صلاحيات حساب المدير الأساسي")
            return
        }
        val now = System.currentTimeMillis()
        val data = mapOf(
            "enabled" to enabled,
            "role" to normalizeRole(role),
            "can_edit_customers" to canEditCustomers,
            "can_discount" to canDiscount,
            "can_collect_payments" to canCollectPayments,
            "can_view_sales_reports" to false,
            "updated_at_ms" to now,
            "updated_at" to FieldValue.serverTimestamp(),
            "updated_by_uid" to currentUid()
        )
        firestore.collection(USERS_COLLECTION).document(profile.uid).set(data, SetOptions.merge())
            .addOnSuccessListener {
                logAudit(
                    action = "user_access_update",
                    entityType = "user",
                    entityId = profile.uid,
                    title = "تعديل صلاحيات مستخدم",
                    details = "${profile.displayName}: enabled=$enabled role=${normalizeRole(role)}"
                )
                loadUsers()
                onResult(true, "تم تحديث صلاحيات ${profile.displayName}")
            }
            .addOnFailureListener { onResult(false, "تعذر تحديث صلاحيات المستخدم") }
    }

    fun requestUserPinReset(profile: AppUserProfile, onResult: (Boolean, String) -> Unit) {
        if (!_isManager.value) {
            onResult(false, "الإجراء متاح للمدير فقط")
            return
        }
        val now = System.currentTimeMillis()
        firestore.collection(USERS_COLLECTION).document(profile.uid)
            .set(
                mapOf(
                    "pin_reset_requested_at_ms" to now,
                    "updated_at_ms" to now,
                    "updated_at" to FieldValue.serverTimestamp(),
                    "updated_by_uid" to currentUid()
                ),
                SetOptions.merge()
            )
            .addOnSuccessListener {
                logAudit(
                    action = "pin_reset_request",
                    entityType = "user",
                    entityId = profile.uid,
                    title = "طلب Reset PIN",
                    details = profile.displayName
                )
                onResult(true, "هيتم إلغاء PIN الخاص بالمستخدم عند فتح التطبيق على جهازه")
            }
            .addOnFailureListener { onResult(false, "تعذر إرسال طلب Reset PIN") }
    }

    private fun normalizeRole(role: String): String = when (role.trim().lowercase()) {
        "reception", "استقبال" -> "reception"
        "cashier", "كاشير" -> "cashier"
        "supervisor", "مشرف" -> "supervisor"
        "manager", "مدير" -> "manager"
        else -> "staff"
    }

    // ------------------------- CUSTOMERS -------------------------

    fun loadCustomers(onResult: ((Boolean, String) -> Unit)? = null) {
        if (_accountEnabled.value == false) {
            onResult?.invoke(false, "الحساب موقوف")
            return
        }
        _customersLoading.value = true
        firestore.collection(CUSTOMERS_COLLECTION)
            .get(Source.SERVER)
            .addOnSuccessListener { snapshot ->
                _customers.value = snapshot.documents.mapNotNull { parseCustomer(it) }
                    .sortedByDescending { it.updatedAtMillis.takeIf { value -> value > 0 } ?: it.createdAtMillis }
                _customersLoading.value = false
                onResult?.invoke(true, "تم تحديث بيانات العملاء")
            }
            .addOnFailureListener {
                _customersLoading.value = false
                onResult?.invoke(false, "تعذر تحميل العملاء. تأكد من الإنترنت وصلاحيات Firebase")
            }
    }

    private fun parseCustomer(doc: DocumentSnapshot): Customer? {
        val name = doc.getString("name")?.trim().orEmpty()
        if (name.isBlank()) return null
        val rawTags = doc.get("tags") as? List<*>
        return Customer(
            id = doc.id,
            fileNumber = doc.getString("file_number").orEmpty(),
            name = name,
            phone = doc.getString("phone").orEmpty(),
            alternatePhone = doc.getString("alternate_phone").orEmpty(),
            age = doc.getString("age").orEmpty(),
            birthDate = doc.getString("birth_date").orEmpty(),
            gender = doc.getString("gender").orEmpty(),
            address = doc.getString("address").orEmpty(),
            notes = doc.getString("notes").orEmpty(),
            importantAlert = doc.getString("important_alert").orEmpty(),
            tags = rawTags?.mapNotNull { it?.toString()?.trim()?.takeIf(String::isNotBlank) } ?: emptyList(),
            defaultDiscountPercent = numberAsDouble(doc.get("default_discount_percent")).coerceIn(0.0, 100.0),
            createdAtMillis = doc.getLong("created_at_ms") ?: 0L,
            updatedAtMillis = doc.getLong("updated_at_ms") ?: 0L,
            createdByUid = doc.getString("created_by_uid").orEmpty(),
            updatedByUid = doc.getString("updated_by_uid").orEmpty(),
            isBlacklisted = doc.getBoolean("is_blacklisted") ?: false,
            blacklistReason = doc.getString("blacklist_reason").orEmpty(),
            blacklistedAtMillis = doc.getLong("blacklisted_at_ms") ?: 0L,
            isArchived = doc.getBoolean("is_archived") ?: false,
            archivedAtMillis = doc.getLong("archived_at_ms") ?: 0L
        )
    }

    fun saveCustomer(
        existing: Customer?,
        name: String,
        phone: String,
        alternatePhone: String = "",
        age: String,
        birthDate: String = "",
        gender: String,
        address: String = "",
        notes: String,
        importantAlert: String = "",
        tags: List<String> = emptyList(),
        defaultDiscountPercent: Double = 0.0,
        onResult: (Boolean, String) -> Unit
    ) {
        saveCustomerInternal(
            existing, name, phone, alternatePhone, age, birthDate, gender, address,
            notes, importantAlert, tags, defaultDiscountPercent
        ) { customer, message -> onResult(customer != null, message) }
    }

    fun saveCustomerAndReturn(
        name: String,
        phone: String,
        alternatePhone: String = "",
        age: String,
        birthDate: String = "",
        gender: String,
        address: String = "",
        notes: String,
        importantAlert: String = "",
        tags: List<String> = emptyList(),
        defaultDiscountPercent: Double = 0.0,
        onResult: (Customer?, String) -> Unit
    ) {
        saveCustomerInternal(
            null, name, phone, alternatePhone, age, birthDate, gender, address,
            notes, importantAlert, tags, defaultDiscountPercent, onResult
        )
    }

    private fun saveCustomerInternal(
        existing: Customer?,
        name: String,
        phone: String,
        alternatePhone: String,
        age: String,
        birthDate: String,
        gender: String,
        address: String,
        notes: String,
        importantAlert: String,
        tags: List<String>,
        defaultDiscountPercent: Double,
        onResult: (Customer?, String) -> Unit
    ) {
        val profile = _currentUserProfile.value
        if (!_isManager.value && profile?.canEditCustomers == false) {
            onResult(null, "حسابك غير مصرح له بتعديل بيانات العملاء")
            return
        }

        val cleanName = name.trim()
        val cleanPhone = normalizePhone(phone)
        val cleanAltPhone = normalizePhone(alternatePhone)
        val cleanAge = age.trim()
        val cleanBirthDate = birthDate.trim().take(20)
        val cleanTags = tags.map { it.trim() }.filter { it.isNotBlank() }.distinct().take(10)
        val safeDefaultDiscount = defaultDiscountPercent.coerceIn(0.0, 100.0)

        if (cleanName.length < 2) {
            onResult(null, "اكتب اسم العميل")
            return
        }
        if (cleanPhone.length < 8) {
            onResult(null, "اكتب رقم موبايل صحيح")
            return
        }
        if (cleanAltPhone.isNotBlank() && cleanAltPhone.length < 8) {
            onResult(null, "رقم الموبايل البديل غير صحيح")
            return
        }
        if (cleanPhone == cleanAltPhone && cleanAltPhone.isNotBlank()) {
            onResult(null, "رقم الموبايل البديل مطابق للرقم الأساسي")
            return
        }
        if (cleanAge.isNotBlank() && (cleanAge.toIntOrNull() == null || cleanAge.toInt() !in 0..120)) {
            onResult(null, "اكتب سن صحيح")
            return
        }
        if (gender !in setOf("ذكر", "أنثى")) {
            onResult(null, "اختر النوع")
            return
        }

        val numbersToCheck = listOf(cleanPhone, cleanAltPhone).filter { it.isNotBlank() }.distinct()
        findDuplicatePhone(numbersToCheck, existing?.id) { duplicate ->
            if (duplicate != null) {
                onResult(null, duplicatePhoneMessage(duplicate))
                return@findDuplicatePhone
            }

            val now = System.currentTimeMillis()
            val customerRef = existing?.let { firestore.collection(CUSTOMERS_COLLECTION).document(it.id) }
                ?: firestore.collection(CUSTOMERS_COLLECTION).document()
            val fileNumber = existing?.fileNumber?.takeIf { it.isNotBlank() } ?: generateFileNumber(now)
            val currentUid = currentUid()
            val currentEmail = currentEmail()

            val customer = Customer(
                id = customerRef.id,
                fileNumber = fileNumber,
                name = cleanName,
                phone = phone.trim(),
                alternatePhone = alternatePhone.trim(),
                age = cleanAge,
                birthDate = cleanBirthDate,
                gender = gender,
                address = address.trim(),
                notes = notes.trim(),
                importantAlert = importantAlert.trim(),
                tags = cleanTags,
                defaultDiscountPercent = safeDefaultDiscount,
                createdAtMillis = existing?.createdAtMillis ?: now,
                updatedAtMillis = now,
                createdByUid = existing?.createdByUid ?: currentUid,
                updatedByUid = currentUid,
                isBlacklisted = existing?.isBlacklisted ?: false,
                blacklistReason = existing?.blacklistReason.orEmpty(),
                blacklistedAtMillis = existing?.blacklistedAtMillis ?: 0L,
                isArchived = existing?.isArchived ?: false,
                archivedAtMillis = existing?.archivedAtMillis ?: 0L
            )

            val data = mutableMapOf<String, Any>(
                "file_number" to fileNumber,
                "name" to cleanName,
                "name_search" to normalizeText(cleanName),
                "phone" to phone.trim(),
                "phone_normalized" to cleanPhone,
                "alternate_phone" to alternatePhone.trim(),
                "alternate_phone_normalized" to cleanAltPhone,
                "age" to cleanAge,
                "birth_date" to cleanBirthDate,
                "gender" to gender,
                "address" to address.trim(),
                "address_search" to normalizeText(address),
                "notes" to notes.trim(),
                "important_alert" to importantAlert.trim(),
                "tags" to cleanTags,
                "tags_search" to normalizeText(cleanTags.joinToString(" ")),
                "default_discount_percent" to safeDefaultDiscount,
                "updated_at_ms" to now,
                "updated_at" to FieldValue.serverTimestamp(),
                "updated_by_uid" to currentUid,
                "updated_by_email" to currentEmail
            )
            if (existing == null) {
                data["created_at_ms"] = now
                data["created_at"] = FieldValue.serverTimestamp()
                data["created_by_uid"] = currentUid
                data["created_by_email"] = currentEmail
                data["is_blacklisted"] = false
                data["blacklist_reason"] = ""
                data["blacklisted_at_ms"] = 0L
                data["is_archived"] = false
                data["archived_at_ms"] = 0L
            }

            val newNumbers = numbersToCheck.toSet()
            val oldNumbers = existing?.let {
                setOf(normalizePhone(it.phone), normalizePhone(it.alternatePhone)).filter { n -> n.isNotBlank() }.toSet()
            } ?: emptySet()

            firestore.runTransaction { tx ->
                // Registry makes simultaneous writes deterministic. The historical query above keeps
                // this compatible with customers created before V14 registry documents existed.
                newNumbers.forEach { number ->
                    val registryRef = firestore.collection(PHONE_REGISTRY_COLLECTION).document(number)
                    val registry = tx.get(registryRef)
                    val owner = registry.getString("customer_id")
                    if (registry.exists() && !owner.isNullOrBlank() && owner != customerRef.id) {
                        throw IllegalStateException("DUPLICATE_PHONE")
                    }
                }

                tx.set(customerRef, data, SetOptions.merge())
                newNumbers.forEach { number ->
                    val registryRef = firestore.collection(PHONE_REGISTRY_COLLECTION).document(number)
                    tx.set(
                        registryRef,
                        mapOf(
                            "customer_id" to customerRef.id,
                            "phone" to number,
                            "updated_at_ms" to now,
                            "updated_by_uid" to currentUid
                        ),
                        SetOptions.merge()
                    )
                }
                (oldNumbers - newNumbers).forEach { number ->
                    tx.delete(firestore.collection(PHONE_REGISTRY_COLLECTION).document(number))
                }
            }.addOnSuccessListener {
                _customers.value = listOf(customer) + _customers.value.filterNot { it.id == customer.id }
                val changes = describeCustomerChanges(existing, customer)
                val action = if (existing == null) "customer_create" else "customer_update"
                val title = if (existing == null) "إنشاء عميل" else "تعديل بيانات العميل"
                val detail = if (changes.isBlank()) "$cleanName • $fileNumber" else changes
                logAudit(action, "customer", customer.id, title, detail, customerId = customer.id)
                addCustomerActivity(customer.id, action, title, detail)
                onResult(customer, if (existing == null) "تم إنشاء ملف العميل $fileNumber" else "تم تحديث بيانات العميل")
            }.addOnFailureListener { error ->
                if (error.message?.contains("DUPLICATE_PHONE") == true) {
                    onResult(null, "رقم الموبايل مستخدم لعميل آخر")
                } else {
                    onResult(null, "تعذر حفظ بيانات العميل. تأكد من صلاحيات Firebase والإنترنت")
                }
            }
        }
    }

    private fun findDuplicatePhone(numbers: List<String>, existingId: String?, callback: (Customer?) -> Unit) {
        // First inspect already-loaded customers. This catches legacy V6-V13 records that do not
        // yet have phone_normalized / phone_registry fields and prevents the old "number exists but
        // search cannot find it" case from returning.
        val localDuplicate = _customers.value.firstOrNull { customer ->
            customer.id != existingId && numbers.any { number ->
                normalizePhone(customer.phone) == number || normalizePhone(customer.alternatePhone) == number
            }
        }
        if (localDuplicate != null) {
            callback(localDuplicate)
            return
        }

        fun check(index: Int, fieldIndex: Int) {
            if (index >= numbers.size) {
                callback(null)
                return
            }
            val number = numbers[index]
            val field = if (fieldIndex == 0) "phone_normalized" else "alternate_phone_normalized"
            firestore.collection(CUSTOMERS_COLLECTION)
                .whereEqualTo(field, number)
                .limit(3)
                .get(Source.SERVER)
                .addOnSuccessListener { snapshot ->
                    val duplicateDoc = snapshot.documents.firstOrNull { it.id != existingId }
                    if (duplicateDoc != null) {
                        callback(parseCustomer(duplicateDoc))
                    } else if (fieldIndex == 0) {
                        check(index, 1)
                    } else {
                        check(index + 1, 0)
                    }
                }
                .addOnFailureListener {
                    // Registry transaction is the final uniqueness guard. Continue if a legacy query
                    // temporarily fails instead of blocking all customer updates.
                    if (fieldIndex == 0) check(index, 1) else check(index + 1, 0)
                }
        }
        check(0, 0)
    }

    private fun duplicatePhoneMessage(customer: Customer): String {
        val status = when {
            customer.isArchived -> "محذوف/مؤرشف - راجع المدير"
            customer.isBlacklisted -> "بلاك ليست"
            else -> "نشط"
        }
        val file = customer.fileNumber.takeIf { it.isNotBlank() }?.let { " • ملف $it" }.orEmpty()
        return "رقم الموبايل مسجل للعميل ${customer.name}$file • الحالة: $status"
    }

    private fun describeCustomerChanges(old: Customer?, new: Customer): String {
        if (old == null) return "${new.name} • ملف ${new.fileNumber}"
        val changes = mutableListOf<String>()
        fun changed(label: String, before: String, after: String) {
            if (before.trim() != after.trim()) changes += "$label: ${before.ifBlank { "—" }} ← ${after.ifBlank { "—" }}"
        }
        changed("الاسم", old.name, new.name)
        changed("الموبايل", old.phone, new.phone)
        changed("الموبايل البديل", old.alternatePhone, new.alternatePhone)
        changed("السن", old.age, new.age)
        changed("تاريخ الميلاد", old.birthDate, new.birthDate)
        changed("النوع", old.gender, new.gender)
        changed("العنوان", old.address, new.address)
        changed("الملاحظات", old.notes, new.notes)
        changed("التنبيه", old.importantAlert, new.importantAlert)
        changed("Tags", old.tags.joinToString(", "), new.tags.joinToString(", "))
        if (kotlin.math.abs(old.defaultDiscountPercent - new.defaultDiscountPercent) > 0.001) {
            changes += "خصم افتراضي: ${formatNumber(old.defaultDiscountPercent)}% ← ${formatNumber(new.defaultDiscountPercent)}%"
        }
        return changes.joinToString(" | ").ifBlank { "تم حفظ الملف بدون تغييرات جوهرية" }
    }

    fun setCustomerBlacklist(
        customer: Customer,
        blacklisted: Boolean,
        reason: String = "",
        onResult: (Boolean, String) -> Unit
    ) {
        if (!_isManager.value) {
            onResult(false, "الإجراء متاح للمدير فقط")
            return
        }
        val now = System.currentTimeMillis()
        val data = mapOf(
            "is_blacklisted" to blacklisted,
            "blacklist_reason" to if (blacklisted) reason.trim() else "",
            "blacklisted_at_ms" to if (blacklisted) now else 0L,
            "blacklisted_by_uid" to if (blacklisted) currentUid() else "",
            "updated_at_ms" to now,
            "updated_at" to FieldValue.serverTimestamp(),
            "updated_by_uid" to currentUid()
        )
        firestore.collection(CUSTOMERS_COLLECTION).document(customer.id)
            .set(data, SetOptions.merge())
            .addOnSuccessListener {
                loadCustomers()
                val title = if (blacklisted) "إضافة للبلاك ليست" else "فك الحظر"
                val detail = if (blacklisted) reason.trim().ifBlank { "بدون سبب مسجل" } else "تمت إعادة العميل للحالة النشطة"
                logAudit("customer_blacklist", "customer", customer.id, title, detail, customerId = customer.id)
                addCustomerActivity(customer.id, "blacklist", title, detail)
                onResult(true, if (blacklisted) "تمت إضافة العميل للبلاك ليست" else "تمت إزالة العميل من البلاك ليست")
            }
            .addOnFailureListener { onResult(false, "تعذر تحديث حالة العميل") }
    }

    fun setCustomerArchived(
        customer: Customer,
        archived: Boolean,
        onResult: (Boolean, String) -> Unit
    ) {
        if (!_isManager.value) {
            onResult(false, "الإجراء متاح للمدير فقط")
            return
        }
        val now = System.currentTimeMillis()
        val data = mutableMapOf<String, Any>(
            "is_archived" to archived,
            "archived_at_ms" to if (archived) now else 0L,
            "archived_by_uid" to if (archived) currentUid() else "",
            "updated_at_ms" to now,
            "updated_at" to FieldValue.serverTimestamp(),
            "updated_by_uid" to currentUid()
        )
        if (archived) {
            data["is_blacklisted"] = false
            data["blacklist_reason"] = ""
            data["blacklisted_at_ms"] = 0L
        }
        firestore.collection(CUSTOMERS_COLLECTION).document(customer.id)
            .set(data, SetOptions.merge())
            .addOnSuccessListener {
                loadCustomers()
                val title = if (archived) "أرشفة العميل" else "استرجاع العميل"
                val detail = if (archived) "حذف آمن مع الاحتفاظ بالسجل" else "إعادة العميل للقائمة النشطة"
                logAudit("customer_archive", "customer", customer.id, title, detail, customerId = customer.id)
                addCustomerActivity(customer.id, "archive", title, detail)
                onResult(true, if (archived) "تم حذف العميل من القائمة مع الاحتفاظ بسجله" else "تم استرجاع العميل")
            }
            .addOnFailureListener { onResult(false, "تعذر تحديث حالة العميل") }
    }

    fun loadCustomerActivity(customerId: String) {
        _customerActivity.value = emptyList()
        if (customerId.isBlank()) return
        firestore.collection(CUSTOMERS_COLLECTION).document(customerId).collection("activity")
            .get(Source.SERVER)
            .addOnSuccessListener { snapshot ->
                _customerActivity.value = snapshot.documents.map { doc ->
                    CustomerActivityEntry(
                        id = doc.id,
                        type = doc.getString("type").orEmpty(),
                        title = doc.getString("title").orEmpty(),
                        details = doc.getString("details").orEmpty(),
                        actorUid = doc.getString("actor_uid").orEmpty(),
                        actorEmail = doc.getString("actor_email").orEmpty(),
                        createdAtMillis = doc.getLong("created_at_ms") ?: 0L
                    )
                }.sortedByDescending { it.createdAtMillis }.take(100)
            }
    }

    private fun addCustomerActivity(customerId: String, type: String, title: String, details: String) {
        if (customerId.isBlank()) return
        val ref = firestore.collection(CUSTOMERS_COLLECTION).document(customerId).collection("activity").document()
        val now = System.currentTimeMillis()
        ref.set(
            mapOf(
                "type" to type,
                "title" to title,
                "details" to details.take(1500),
                "actor_uid" to currentUid(),
                "actor_email" to currentEmail(),
                "created_at_ms" to now,
                "created_at" to FieldValue.serverTimestamp()
            )
        )
    }

    // ------------------------- ORDERS / PAYMENTS -------------------------

    fun loadCustomerOrders(customerId: String) {
        _customerOrders.value = emptyList()
        if (customerId.isBlank()) return
        firestore.collection(CUSTOMERS_COLLECTION)
            .document(customerId)
            .collection("orders")
            .get(Source.SERVER)
            .addOnSuccessListener { snapshot ->
                _customerOrders.value = snapshot.documents.mapNotNull { parseOrder(it, customerId) }
                    .sortedByDescending { it.createdAtMillis }
            }
            .addOnFailureListener { _customerOrders.value = emptyList() }
    }

    private fun parseOrder(doc: DocumentSnapshot, fallbackCustomerId: String = ""): CustomerOrder? {
        val rawItems = doc.get("items") as? List<*> ?: emptyList<Any>()
        val items = rawItems.mapNotNull { raw ->
            val map = raw as? Map<*, *> ?: return@mapNotNull null
            val testId = (map["test_id"] as? Number)?.toInt() ?: return@mapNotNull null
            CustomerOrderItem(
                testId = testId,
                englishName = map["english_name"]?.toString().orEmpty(),
                arabicName = map["arabic_name"]?.toString().orEmpty(),
                marketName = map["market_name"]?.toString().orEmpty(),
                customerPrice = numberAsDouble(map["customer_price"])
            )
        }
        val finalTotal = numberAsDouble(doc.get("total_customer_price"))
        val subtotal = numberAsDouble(doc.get("subtotal_customer_price")).takeIf { it > 0.0 } ?: finalTotal
        val discount = numberAsDouble(doc.get("discount_amount")).takeIf { it > 0.0 }
            ?: (subtotal - finalTotal).coerceAtLeast(0.0)
        val paid = numberAsDouble(doc.get("paid_amount")).takeIf { it > 0.0 }
            ?: if (doc.getString("payment_status") == "paid") finalTotal else 0.0
        return CustomerOrder(
            id = doc.id,
            orderNumber = doc.getString("order_number").orEmpty(),
            customerId = doc.getString("customer_id").orEmpty().ifBlank { fallbackCustomerId },
            customerFileNumber = doc.getString("customer_file_number").orEmpty(),
            customerName = doc.getString("customer_name").orEmpty(),
            items = items,
            subtotalCustomerPrice = subtotal,
            discountAmount = discount,
            discountPercent = numberAsDouble(doc.get("discount_percent")).takeIf { it > 0.0 }
                ?: if (subtotal > 0.0) (discount / subtotal) * 100.0 else 0.0,
            totalCustomerPrice = finalTotal,
            paymentStatus = doc.getString("payment_status") ?: "unpaid",
            paidAmount = paid.coerceAtMost(finalTotal),
            remainingAmount = if (doc.get("remaining_amount") != null) {
                numberAsDouble(doc.get("remaining_amount")).coerceAtLeast(0.0)
            } else {
                (finalTotal - paid).coerceAtLeast(0.0)
            },
            notes = doc.getString("notes").orEmpty(),
            createdAtMillis = doc.getLong("created_at_ms") ?: 0L,
            createdByUid = doc.getString("created_by_uid").orEmpty(),
            createdByEmail = doc.getString("created_by_email").orEmpty(),
            updatedAtMillis = doc.getLong("updated_at_ms") ?: 0L,
            updatedByUid = doc.getString("updated_by_uid").orEmpty(),
            editCount = (doc.getLong("edit_count") ?: 0L).toInt(),
            isVoided = doc.getBoolean("is_voided") ?: false,
            voidReason = doc.getString("void_reason").orEmpty()
        )
    }

    fun saveCustomerOrder(
        customer: Customer,
        tests: List<LabTest>,
        onResult: (Boolean, String) -> Unit
    ) {
        saveCustomerOrderAdvanced(
            customer = customer,
            tests = tests,
            discountAmount = 0.0,
            discountPercent = customer.defaultDiscountPercent,
            paymentStatus = "unpaid",
            paidAmount = 0.0,
            notes = "",
            onResult = { order, message -> onResult(order != null, message) }
        )
    }

    fun saveCustomerOrderAdvanced(
        customer: Customer,
        tests: List<LabTest>,
        discountAmount: Double,
        discountPercent: Double,
        paymentStatus: String,
        paidAmount: Double,
        notes: String,
        onResult: (CustomerOrder?, String) -> Unit
    ) {
        if (customer.isBlacklisted) {
            onResult(null, "العميل موجود في البلاك ليست. لازم المدير يفك الحظر قبل إنشاء طلب جديد")
            return
        }
        if (customer.isArchived) {
            onResult(null, "العميل مؤرشف. استرجعه الأول")
            return
        }
        if (tests.isEmpty()) {
            onResult(null, "اختار تحليل واحد على الأقل")
            return
        }
        if (!_isManager.value && _currentUserProfile.value?.canDiscount == false && discountAmount > 0.0) {
            onResult(null, "حسابك غير مصرح له بإضافة خصومات")
            return
        }

        val now = System.currentTimeMillis()
        val orderRef = firestore.collection(CUSTOMERS_COLLECTION)
            .document(customer.id).collection("orders").document()
        val items = tests.map { test ->
            val price = parsePriceInput(_customerPriceOverrides.value[test.id] ?: test.customerPrice.orEmpty()) ?: 0.0
            mapOf(
                "test_id" to test.id,
                "english_name" to test.englishName,
                "arabic_name" to test.arabicName,
                "market_name" to test.marketName,
                "customer_price" to price
            )
        }
        val subtotal = items.sumOf { numberAsDouble(it["customer_price"]) }
        val safeDiscountPercent = if (discountPercent > 0.0) discountPercent.coerceIn(0.0, 100.0) else 0.0
        val discountFromPercent = subtotal * safeDiscountPercent / 100.0
        val safeDiscount = if (safeDiscountPercent > 0.0) discountFromPercent else discountAmount.coerceIn(0.0, subtotal)
        val actualPercent = if (subtotal > 0.0) (safeDiscount / subtotal * 100.0).coerceIn(0.0, 100.0) else 0.0
        val finalTotal = (subtotal - safeDiscount).coerceAtLeast(0.0)
        val normalizedStatus = when (paymentStatus) { "paid", "partial", "unpaid" -> paymentStatus; else -> "unpaid" }
        val safePaid = when (normalizedStatus) {
            "paid" -> finalTotal
            "partial" -> paidAmount.coerceIn(0.0, finalTotal)
            else -> 0.0
        }
        val remaining = (finalTotal - safePaid).coerceAtLeast(0.0)
        val orderNumber = generateOrderNumber(now, orderRef.id)
        val uid = currentUid()
        val email = currentEmail()
        val order = CustomerOrder(
            id = orderRef.id,
            orderNumber = orderNumber,
            customerId = customer.id,
            customerFileNumber = customer.fileNumber,
            customerName = customer.name,
            items = items.map { raw ->
                CustomerOrderItem(
                    testId = (raw["test_id"] as Number).toInt(),
                    englishName = raw["english_name"].toString(),
                    arabicName = raw["arabic_name"].toString(),
                    marketName = raw["market_name"].toString(),
                    customerPrice = numberAsDouble(raw["customer_price"])
                )
            },
            subtotalCustomerPrice = subtotal,
            discountAmount = safeDiscount,
            discountPercent = actualPercent,
            totalCustomerPrice = finalTotal,
            paymentStatus = normalizedStatus,
            paidAmount = safePaid,
            remainingAmount = remaining,
            notes = notes.trim(),
            createdAtMillis = now,
            createdByUid = uid,
            createdByEmail = email,
            updatedAtMillis = now,
            updatedByUid = uid
        )
        val data = mapOf(
            "order_number" to orderNumber,
            "customer_id" to customer.id,
            "customer_file_number" to customer.fileNumber,
            "customer_name" to customer.name,
            "customer_phone" to customer.phone,
            "items" to items,
            "tests_count" to items.size,
            "subtotal_customer_price" to subtotal,
            "discount_amount" to safeDiscount,
            "discount_percent" to actualPercent,
            "total_customer_price" to finalTotal,
            "payment_status" to normalizedStatus,
            "paid_amount" to safePaid,
            "remaining_amount" to remaining,
            "notes" to notes.trim(),
            "created_at_ms" to now,
            "created_at" to FieldValue.serverTimestamp(),
            "created_by_uid" to uid,
            "created_by_email" to email,
            "updated_at_ms" to now,
            "updated_at" to FieldValue.serverTimestamp(),
            "updated_by_uid" to uid,
            "edit_count" to 0,
            "is_voided" to false,
            "void_reason" to ""
        )

        firestore.runBatch { batch ->
            batch.set(orderRef, data)
            if (safePaid > 0.0) {
                val paymentRef = orderRef.collection("payments").document()
                batch.set(
                    paymentRef,
                    mapOf(
                        "customer_id" to customer.id,
                        "order_id" to orderRef.id,
                        "amount" to safePaid,
                        "note" to "دفعة عند إنشاء الطلب",
                        "created_at_ms" to now,
                        "created_at" to FieldValue.serverTimestamp(),
                        "created_by_uid" to uid,
                        "created_by_email" to email
                    )
                )
            }
        }.addOnSuccessListener {
            loadCustomerOrders(customer.id)
            val detail = "$orderNumber • ${items.size} تحليل • إجمالي ${formatNumber(finalTotal)} • خصم ${formatNumber(safeDiscount)}"
            logAudit("order_create", "order", order.id, "إنشاء طلب", detail, customerId = customer.id, orderId = order.id)
            addCustomerActivity(customer.id, "order", "طلب جديد $orderNumber", detail)
            onResult(order, "تم حفظ الطلب $orderNumber")
        }.addOnFailureListener {
            onResult(null, "تعذر حفظ الطلب. تأكد من صلاحيات Firebase")
        }
    }

    fun updateOrderFinancials(
        customer: Customer,
        order: CustomerOrder,
        discountAmount: Double,
        discountPercent: Double,
        paymentStatus: String,
        paidAmount: Double,
        notes: String,
        onResult: (CustomerOrder?, String) -> Unit
    ) {
        if (order.isVoided) {
            onResult(null, "الطلب ملغي ولا يمكن تعديله")
            return
        }
        val subtotal = order.subtotalCustomerPrice
        val safePercent = discountPercent.coerceIn(0.0, 100.0)
        val safeDiscount = if (safePercent > 0.0) subtotal * safePercent / 100.0 else discountAmount.coerceIn(0.0, subtotal)
        val finalTotal = (subtotal - safeDiscount).coerceAtLeast(0.0)
        val normalizedStatus = when (paymentStatus) { "paid", "partial", "unpaid" -> paymentStatus; else -> "unpaid" }
        val safePaid = when (normalizedStatus) {
            "paid" -> finalTotal
            "partial" -> paidAmount.coerceIn(0.0, finalTotal)
            else -> 0.0
        }
        val remaining = (finalTotal - safePaid).coerceAtLeast(0.0)
        val now = System.currentTimeMillis()
        val orderRef = firestore.collection(CUSTOMERS_COLLECTION).document(customer.id).collection("orders").document(order.id)
        val changes = buildList {
            if (kotlin.math.abs(order.discountAmount - safeDiscount) > 0.001) add("الخصم ${formatNumber(order.discountAmount)} ← ${formatNumber(safeDiscount)}")
            if (kotlin.math.abs(order.paidAmount - safePaid) > 0.001) add("المدفوع ${formatNumber(order.paidAmount)} ← ${formatNumber(safePaid)}")
            if (order.paymentStatus != normalizedStatus) add("حالة الدفع ${order.paymentStatus} ← $normalizedStatus")
            if (order.notes.trim() != notes.trim()) add("تعديل الملاحظات")
        }.joinToString(" | ").ifBlank { "لا يوجد تغيير" }

        orderRef.update(
            mapOf(
                "discount_amount" to safeDiscount,
                "discount_percent" to if (subtotal > 0.0) (safeDiscount / subtotal * 100.0) else 0.0,
                "total_customer_price" to finalTotal,
                "payment_status" to normalizedStatus,
                "paid_amount" to safePaid,
                "remaining_amount" to remaining,
                "notes" to notes.trim(),
                "updated_at_ms" to now,
                "updated_at" to FieldValue.serverTimestamp(),
                "updated_by_uid" to currentUid(),
                "updated_by_email" to currentEmail(),
                "edit_count" to FieldValue.increment(1)
            )
        ).addOnSuccessListener {
            loadCustomerOrders(customer.id)
            logAudit("order_update", "order", order.id, "تعديل طلب ${order.orderNumber}", changes, customerId = customer.id, orderId = order.id)
            addCustomerActivity(customer.id, "order_update", "تعديل ${order.orderNumber}", changes)
            onResult(
                order.copy(
                    discountAmount = safeDiscount,
                    discountPercent = if (subtotal > 0.0) safeDiscount / subtotal * 100.0 else 0.0,
                    totalCustomerPrice = finalTotal,
                    paymentStatus = normalizedStatus,
                    paidAmount = safePaid,
                    remainingAmount = remaining,
                    notes = notes.trim(),
                    updatedAtMillis = now,
                    updatedByUid = currentUid(),
                    editCount = order.editCount + 1
                ),
                "تم تعديل الطلب مع تسجيل التغيير"
            )
        }.addOnFailureListener { onResult(null, "تعذر تعديل الطلب") }
    }

    fun collectOrderPayment(
        customer: Customer,
        order: CustomerOrder,
        amount: Double,
        note: String,
        onResult: (CustomerOrder?, String) -> Unit
    ) {
        if (!_isManager.value && _currentUserProfile.value?.canCollectPayments == false) {
            onResult(null, "حسابك غير مصرح له بتحصيل دفعات")
            return
        }
        if (order.isVoided) {
            onResult(null, "الطلب ملغي")
            return
        }
        val cleanAmount = amount.coerceAtLeast(0.0)
        if (cleanAmount <= 0.0) {
            onResult(null, "اكتب مبلغ التحصيل")
            return
        }
        val orderRef = firestore.collection(CUSTOMERS_COLLECTION).document(customer.id).collection("orders").document(order.id)
        val paymentRef = orderRef.collection("payments").document()
        val now = System.currentTimeMillis()
        val uid = currentUid()
        val email = currentEmail()

        firestore.runTransaction { tx ->
            val snap = tx.get(orderRef)
            val total = numberAsDouble(snap.get("total_customer_price"))
            val currentPaid = numberAsDouble(snap.get("paid_amount"))
            val currentRemaining = (total - currentPaid).coerceAtLeast(0.0)
            if (currentRemaining <= 0.0) throw IllegalStateException("ALREADY_PAID")
            if (cleanAmount > currentRemaining + 0.001) throw IllegalStateException("OVERPAY")
            val newPaid = (currentPaid + cleanAmount).coerceAtMost(total)
            val newRemaining = (total - newPaid).coerceAtLeast(0.0)
            val newStatus = when {
                newRemaining <= 0.001 -> "paid"
                newPaid > 0.0 -> "partial"
                else -> "unpaid"
            }
            tx.update(
                orderRef,
                mapOf(
                    "paid_amount" to newPaid,
                    "remaining_amount" to newRemaining,
                    "payment_status" to newStatus,
                    "updated_at_ms" to now,
                    "updated_at" to FieldValue.serverTimestamp(),
                    "updated_by_uid" to uid,
                    "updated_by_email" to email,
                    "edit_count" to FieldValue.increment(1)
                )
            )
            tx.set(
                paymentRef,
                mapOf(
                    "customer_id" to customer.id,
                    "order_id" to order.id,
                    "amount" to cleanAmount,
                    "note" to note.trim(),
                    "created_at_ms" to now,
                    "created_at" to FieldValue.serverTimestamp(),
                    "created_by_uid" to uid,
                    "created_by_email" to email
                )
            )
            Triple(newPaid, newRemaining, newStatus)
        }.addOnSuccessListener { result ->
            val (newPaid, newRemaining, newStatus) = result
            val updated = order.copy(
                paidAmount = newPaid,
                remainingAmount = newRemaining,
                paymentStatus = newStatus,
                updatedAtMillis = now,
                updatedByUid = uid,
                editCount = order.editCount + 1
            )
            loadCustomerOrders(customer.id)
            loadPaymentHistory(customer.id, order.id)
            val detail = "${order.orderNumber} • تحصيل ${formatNumber(cleanAmount)} • المتبقي ${formatNumber(newRemaining)}"
            logAudit("payment_collect", "payment", paymentRef.id, "تحصيل دفعة", detail, customerId = customer.id, orderId = order.id)
            addCustomerActivity(customer.id, "payment", "تحصيل دفعة", detail)
            onResult(updated, "تم تسجيل الدفعة")
        }.addOnFailureListener { error ->
            val message = when {
                error.message?.contains("ALREADY_PAID") == true -> "الطلب مدفوع بالكامل"
                error.message?.contains("OVERPAY") == true -> "المبلغ أكبر من المتبقي"
                else -> "تعذر تسجيل الدفعة"
            }
            onResult(null, message)
        }
    }

    fun loadPaymentHistory(customerId: String, orderId: String) {
        _paymentHistory.value = emptyList()
        if (customerId.isBlank() || orderId.isBlank()) return
        firestore.collection(CUSTOMERS_COLLECTION).document(customerId)
            .collection("orders").document(orderId)
            .collection("payments")
            .get(Source.SERVER)
            .addOnSuccessListener { snapshot ->
                _paymentHistory.value = snapshot.documents.map { doc ->
                    PaymentEntry(
                        id = doc.id,
                        customerId = doc.getString("customer_id").orEmpty().ifBlank { customerId },
                        orderId = doc.getString("order_id").orEmpty().ifBlank { orderId },
                        amount = numberAsDouble(doc.get("amount")),
                        note = doc.getString("note").orEmpty(),
                        createdAtMillis = doc.getLong("created_at_ms") ?: 0L,
                        createdByUid = doc.getString("created_by_uid").orEmpty(),
                        createdByEmail = doc.getString("created_by_email").orEmpty()
                    )
                }.sortedByDescending { it.createdAtMillis }
            }
    }

    fun voidOrder(customer: Customer, order: CustomerOrder, reason: String, onResult: (Boolean, String) -> Unit) {
        if (!_isManager.value) {
            onResult(false, "إلغاء الطلب متاح للمدير فقط")
            return
        }
        if (reason.trim().length < 3) {
            onResult(false, "اكتب سبب الإلغاء")
            return
        }
        val now = System.currentTimeMillis()
        firestore.collection(CUSTOMERS_COLLECTION).document(customer.id).collection("orders").document(order.id)
            .update(
                mapOf(
                    "is_voided" to true,
                    "void_reason" to reason.trim(),
                    "voided_at_ms" to now,
                    "voided_by_uid" to currentUid(),
                    "updated_at_ms" to now,
                    "updated_at" to FieldValue.serverTimestamp(),
                    "updated_by_uid" to currentUid()
                )
            )
            .addOnSuccessListener {
                loadCustomerOrders(customer.id)
                logAudit("order_void", "order", order.id, "إلغاء طلب ${order.orderNumber}", reason.trim(), customerId = customer.id, orderId = order.id)
                addCustomerActivity(customer.id, "order_void", "إلغاء ${order.orderNumber}", reason.trim())
                onResult(true, "تم إلغاء الطلب مع الاحتفاظ به في سجل المراجعة")
            }
            .addOnFailureListener { onResult(false, "تعذر إلغاء الطلب") }
    }

    // ------------------------- REPORTS -------------------------

    fun loadManagerHomeSummary(onResult: ((Boolean, String) -> Unit)? = null) {
        if (!_isManager.value) {
            onResult?.invoke(false, "لوحة المدير متاحة لعبدالرحمن فقط")
            return
        }
        _managerHomeLoading.value = true
        firestore.collectionGroup("orders").get(Source.SERVER)
            .addOnSuccessListener { snapshot ->
                val allOrders = snapshot.documents.mapNotNull { doc ->
                    val customerId = doc.reference.parent.parent?.id.orEmpty()
                    parseOrder(doc, customerId)
                }.filterNot { it.isVoided }

                val calendar = java.util.Calendar.getInstance().apply {
                    set(java.util.Calendar.HOUR_OF_DAY, 0)
                    set(java.util.Calendar.MINUTE, 0)
                    set(java.util.Calendar.SECOND, 0)
                    set(java.util.Calendar.MILLISECOND, 0)
                }
                val startToday = calendar.timeInMillis
                val todayOrders = allOrders.filter { it.createdAtMillis >= startToday }

                _managerHomeSummary.value = ReportSummary(
                    ordersCount = todayOrders.size,
                    customersCount = todayOrders.map { it.customerId }.filter { it.isNotBlank() }.distinct().size,
                    paid = todayOrders.sumOf { it.paidAmount },
                    remaining = allOrders.sumOf { it.remainingAmount }
                )
                _managerHomeLoading.value = false
                onResult?.invoke(true, "تم تحديث لوحة المدير")
            }
            .addOnFailureListener {
                _managerHomeLoading.value = false
                onResult?.invoke(false, "تعذر تحديث ملخص لوحة المدير")
            }
    }

    fun loadReports(fromMillis: Long, toMillis: Long, onResult: ((Boolean, String) -> Unit)? = null) {
        if (!_isManager.value) {
            onResult?.invoke(false, "التقارير والحسابات العامة متاحة لعبدالرحمن فقط")
            return
        }
        _reportsLoading.value = true
        firestore.collectionGroup("orders").get(Source.SERVER)
            .addOnSuccessListener { snapshot ->
                _reportOrders.value = snapshot.documents.mapNotNull { doc ->
                    val created = doc.getLong("created_at_ms") ?: 0L
                    if (created !in fromMillis..toMillis) return@mapNotNull null
                    val customerId = doc.reference.parent.parent?.id.orEmpty()
                    parseOrder(doc, customerId)
                }.filterNot { it.isVoided }.sortedByDescending { it.createdAtMillis }
                _reportsLoading.value = false
                onResult?.invoke(true, "تم تحميل التقرير")
            }
            .addOnFailureListener {
                _reportsLoading.value = false
                onResult?.invoke(false, "تعذر تحميل التقارير. تأكد من Firestore Rules")
            }
    }

    fun calculateReportSummary(orders: List<CustomerOrder> = _reportOrders.value): ReportSummary {
        val valid = orders.filterNot { it.isVoided }
        val subtotal = valid.sumOf { it.subtotalCustomerPrice }
        val discounts = valid.sumOf { it.discountAmount }
        val sales = valid.sumOf { it.totalCustomerPrice }
        val paid = valid.sumOf { it.paidAmount }
        val remaining = valid.sumOf { it.remainingAmount }
        val estimatedCost = if (_isManager.value) {
            valid.sumOf { order ->
                order.items.sumOf { item -> parsePriceInput(_lab2LabPrices.value[item.testId].orEmpty()) ?: 0.0 }
            }
        } else 0.0
        return ReportSummary(
            ordersCount = valid.size,
            customersCount = valid.map { it.customerId }.filter { it.isNotBlank() }.distinct().size,
            subtotal = subtotal,
            discounts = discounts,
            sales = sales,
            paid = paid,
            remaining = remaining,
            estimatedLabCost = estimatedCost,
            estimatedProfit = if (_isManager.value) sales - estimatedCost else 0.0
        )
    }

    // ------------------------- AUDIT -------------------------

    fun loadAuditLogs(onResult: ((Boolean, String) -> Unit)? = null) {
        if (!_isManager.value) {
            onResult?.invoke(false, "سجل المراجعة متاح للمدير فقط")
            return
        }
        firestore.collection(AUDIT_COLLECTION).get(Source.SERVER)
            .addOnSuccessListener { snapshot ->
                _auditLogs.value = snapshot.documents.map { doc ->
                    AuditLogEntry(
                        id = doc.id,
                        action = doc.getString("action").orEmpty(),
                        entityType = doc.getString("entity_type").orEmpty(),
                        entityId = doc.getString("entity_id").orEmpty(),
                        customerId = doc.getString("customer_id").orEmpty(),
                        orderId = doc.getString("order_id").orEmpty(),
                        title = doc.getString("title").orEmpty(),
                        details = doc.getString("details").orEmpty(),
                        actorUid = doc.getString("actor_uid").orEmpty(),
                        actorEmail = doc.getString("actor_email").orEmpty(),
                        createdAtMillis = doc.getLong("created_at_ms") ?: 0L
                    )
                }.sortedByDescending { it.createdAtMillis }.take(400)
                onResult?.invoke(true, "تم تحديث سجل المراجعة")
            }
            .addOnFailureListener { onResult?.invoke(false, "تعذر تحميل سجل المراجعة") }
    }

    private fun logAudit(
        action: String,
        entityType: String,
        entityId: String,
        title: String,
        details: String,
        customerId: String = "",
        orderId: String = ""
    ) {
        val now = System.currentTimeMillis()
        firestore.collection(AUDIT_COLLECTION).document().set(
            mapOf(
                "action" to action,
                "entity_type" to entityType,
                "entity_id" to entityId,
                "customer_id" to customerId,
                "order_id" to orderId,
                "title" to title,
                "details" to details.take(2000),
                "actor_uid" to currentUid(),
                "actor_email" to currentEmail(),
                "created_at_ms" to now,
                "created_at" to FieldValue.serverTimestamp()
            )
        )
    }

    // ------------------------- SEARCH / SELECTION -------------------------

    fun clearSelectedTests() {
        _selectedTests.value = emptyList()
        clearSearch()
    }

    private fun parseQueries(rawInput: String): List<String> {
        if (rawInput.isBlank()) return emptyList()
        val delimiterRegex = Regex("[\\n,،;؛]+")
        val rawTokens = rawInput.split(delimiterRegex)
        val seenNorm = mutableSetOf<String>()
        val result = mutableListOf<String>()
        for (token in rawTokens) {
            val trimmed = token.trim()
            if (trimmed.isEmpty()) continue
            val norm = normalizeText(trimmed)
            if (norm.isNotEmpty() && seenNorm.add(norm)) result.add(trimmed)
        }
        return result
    }

    fun onQueryChanged(newQuery: String) {
        _searchQuery.value = newQuery
        val trimmedInput = newQuery.trim()
        if (trimmedInput.isEmpty()) {
            _uiState.value = SearchUiState.EmptyQuery
            return
        }

        viewModelScope.launch(Dispatchers.Default) {
            val queries = parseQueries(newQuery)
            if (queries.isEmpty()) {
                _uiState.value = SearchUiState.EmptyQuery
                return@launch
            }
            val selectedIds = _selectedTests.value.map { it.id }.toSet()
            val queryGroups = mutableListOf<QueryGroup>()
            val unmatchedQueries = mutableListOf<String>()
            for (q in queries) {
                val matches = repository.searchTests(q).filter { it.id !in selectedIds }
                if (matches.isNotEmpty()) queryGroups.add(QueryGroup(query = q, candidates = matches))
                else unmatchedQueries.add(q)
            }
            _uiState.value = if (queryGroups.isEmpty()) {
                SearchUiState.NoResults(unmatchedQueries = unmatchedQueries)
            } else {
                SearchUiState.Success(query = newQuery, queryGroups = queryGroups, unmatchedQueries = unmatchedQueries)
            }
        }
    }

    fun addSelectedTest(test: LabTest) {
        if (_selectedTests.value.none { it.id == test.id }) {
            _selectedTests.value = _selectedTests.value + test
        }
        val current = _searchQuery.value.trim()
        if (current.isNotBlank()) settingsStore.addRecentSearch(current)
        clearSearch()
    }

    fun removeSelectedTest(testId: Int) {
        _selectedTests.value = _selectedTests.value.filter { it.id != testId }
        if (_searchQuery.value.isNotEmpty()) onQueryChanged(_searchQuery.value)
    }

    fun clearSearch() {
        _searchQuery.value = ""
        _uiState.value = SearchUiState.EmptyQuery
    }

    // ------------------------- HELPERS -------------------------

    private fun loadManagerPricesFromAsset(): Map<Int, String> {
        return try {
            val json = getApplication<Application>().assets
                .open("manager_lab2lab_prices.json")
                .bufferedReader(Charsets.UTF_8)
                .use { it.readText() }
            val array = JSONArray(json)
            buildMap {
                for (i in 0 until array.length()) {
                    val item = array.getJSONObject(i)
                    val id = item.optInt("id", -1)
                    if (id <= 0 || item.isNull("lab_to_lab_price")) continue
                    val formatted = formatFirestorePrice(item.get("lab_to_lab_price"))
                    if (!formatted.isNullOrBlank()) put(id, formatted)
                }
            }
        } catch (_: Exception) {
            emptyMap()
        }
    }

    private fun documentTestId(documentId: String, fallbackId: Int?): Int? =
        documentId.removePrefix("test_").toIntOrNull() ?: fallbackId

    private fun parsePriceInput(value: String): Double? {
        val normalized = value.trim().replace(",", "").replace("جنيه", "", ignoreCase = true).trim()
        return normalized.toDoubleOrNull()
    }

    private fun formatNumber(value: Double): String =
        if (value % 1.0 == 0.0) value.toLong().toString() else String.format(Locale.US, "%.2f", value).trimEnd('0').trimEnd('.')

    private fun formatFirestorePrice(value: Any?): String? = when (value) {
        null -> null
        is Byte, is Short, is Int, is Long -> value.toString()
        is Float -> formatNumber(value.toDouble())
        is Double -> formatNumber(value)
        is Number -> value.toString()
        else -> value.toString().trim().takeIf { it.isNotEmpty() && !it.equals("null", true) }
    }

    private fun numberAsDouble(value: Any?): Double = when (value) {
        is Number -> value.toDouble()
        else -> value?.toString()?.toDoubleOrNull() ?: 0.0
    }

    private fun normalizePhone(value: String): String = value.filter { it.isDigit() }

    private fun generateFileNumber(now: Long): String {
        val date = SimpleDateFormat("yyMMdd-HHmmss", Locale.US).format(Date(now))
        val suffix = (now % 1000).toString().padStart(3, '0')
        return "AK-$date-$suffix"
    }

    private fun generateOrderNumber(now: Long, documentId: String): String {
        val date = SimpleDateFormat("yyMMdd-HHmmss", Locale.US).format(Date(now))
        val suffix = documentId.takeLast(4).uppercase(Locale.US)
        return "ORD-$date-$suffix"
    }

    private fun currentUid(): String = FirebaseAuth.getInstance().currentUser?.uid.orEmpty()
    private fun currentEmail(): String = FirebaseAuth.getInstance().currentUser?.email.orEmpty()
}
