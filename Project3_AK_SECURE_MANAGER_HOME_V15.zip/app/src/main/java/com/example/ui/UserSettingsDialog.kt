package com.example.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.settings.AppSettings

@Composable
fun UserSettingsDialog(
    viewModel: LabTestsViewModel,
    settings: AppSettings,
    onDismiss: () -> Unit
) {
    var showPinEditor by remember { mutableStateOf(false) }
    var pinError by remember { mutableStateOf<String?>(null) }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(
            modifier = Modifier.fillMaxSize().padding(10.dp),
            shape = RoundedCornerShape(24.dp),
            color = if (settings.darkMode) Color(0xFF0F172A) else Color(0xFFF5F7FB)
        ) {
            Column(Modifier.fillMaxSize()) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text("إعدادات التطبيق", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = if (settings.darkMode) Color.White else Color(0xFF102A43))
                        Text("إعداداتك الشخصية على الجهاز", fontSize = 12.sp, color = Color(0xFF64748B))
                    }
                    IconButton(onClick = onDismiss) { Icon(Icons.Default.Close, contentDescription = "إغلاق") }
                }
                HorizontalDivider()

                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(14.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item {
                        SimpleSettingsCard("الأمان", Icons.Default.Lock) {
                            SettingSwitch(
                                title = "قفل التطبيق",
                                subtitle = "اطلب وسيلة حماية عند فتح التطبيق",
                                checked = settings.securityEnabled,
                                onChecked = { viewModel.updateAppSettings(settings.copy(securityEnabled = it)) }
                            )
                            if (settings.securityEnabled) {
                                Text("طريقة فتح التطبيق", fontWeight = FontWeight.Bold, color = Color(0xFF334155), modifier = Modifier.padding(top = 8.dp, bottom = 6.dp))
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedButton(
                                        onClick = {
                                            viewModel.updateAppSettings(settings.copy(unlockMode = "device"))
                                        },
                                        modifier = Modifier.weight(1f),
                                        shape = RoundedCornerShape(14.dp)
                                    ) {
                                        Icon(Icons.Default.Fingerprint, contentDescription = null)
                                        Text("  بصمة / قفل الهاتف", fontSize = 12.sp)
                                    }
                                    OutlinedButton(
                                        onClick = {
                                            if (settings.appPinConfigured) {
                                                viewModel.updateAppSettings(settings.copy(unlockMode = "pin", securityEnabled = true))
                                            } else {
                                                pinError = null
                                                showPinEditor = true
                                            }
                                        },
                                        modifier = Modifier.weight(1f),
                                        shape = RoundedCornerShape(14.dp)
                                    ) {
                                        Icon(Icons.Default.Lock, contentDescription = null)
                                        Text("  PIN للتطبيق", fontSize = 12.sp)
                                    }
                                }
                                Spacer(Modifier.height(6.dp))
                                Text(
                                    if (settings.unlockMode == "pin") "المستخدم حاليًا: PIN خاص بالتطبيق" else "المستخدم حاليًا: بصمة أو قفل الهاتف",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF006D86)
                                )
                                if (settings.unlockMode == "pin") {
                                    Spacer(Modifier.height(8.dp))
                                    OutlinedButton(onClick = { pinError = null; showPinEditor = true }, modifier = Modifier.fillMaxWidth()) {
                                        Text("تغيير الرقم السري")
                                    }
                                }

                                Spacer(Modifier.height(10.dp))
                                Text("القفل التلقائي", fontWeight = FontWeight.Bold, color = Color(0xFF334155))
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    listOf(0 to "فورًا", 60 to "دقيقة", 300 to "5 دقائق", 900 to "15 دقيقة").forEach { (seconds, label) ->
                                        OutlinedButton(
                                            onClick = { viewModel.updateAppSettings(settings.copy(autoLockSeconds = seconds)) },
                                            modifier = Modifier.weight(1f),
                                            contentPadding = PaddingValues(horizontal = 4.dp, vertical = 8.dp)
                                        ) { Text(label, fontSize = 10.sp) }
                                    }
                                }
                            }
                        }
                    }

                    item {
                        SimpleSettingsCard("المظهر", Icons.Default.Palette) {
                            SettingSwitch("الوضع الداكن", "تغيير شكل التطبيق", settings.darkMode) {
                                viewModel.updateAppSettings(settings.copy(darkMode = it))
                            }
                            Spacer(Modifier.height(8.dp))
                            Text("حجم الخط", fontWeight = FontWeight.Bold, color = Color(0xFF334155))
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                listOf(0.9f to "صغير", 1.0f to "متوسط", 1.15f to "كبير").forEach { (scale, label) ->
                                    OutlinedButton(
                                        onClick = { viewModel.updateAppSettings(settings.copy(fontScale = scale)) },
                                        modifier = Modifier.weight(1f)
                                    ) { Text(label, fontSize = 11.sp) }
                                }
                            }
                        }
                    }

                    item {
                        SimpleSettingsCard("عرض أسماء التحاليل", Icons.Default.Search) {
                            SettingSwitch("الاسم الإنجليزي", "إظهاره في نتائج البحث", settings.showEnglishName) { enabled ->
                                if (enabled || settings.showArabicName || settings.showMarketName) viewModel.updateAppSettings(settings.copy(showEnglishName = enabled))
                            }
                            SettingSwitch("الاسم العربي", "إظهاره في نتائج البحث", settings.showArabicName) { enabled ->
                                if (enabled || settings.showEnglishName || settings.showMarketName) viewModel.updateAppSettings(settings.copy(showArabicName = enabled))
                            }
                            SettingSwitch("الاسم الدارج", "إظهار الاسم المتداول عند توفره", settings.showMarketName) { enabled ->
                                if (enabled || settings.showEnglishName || settings.showArabicName) viewModel.updateAppSettings(settings.copy(showMarketName = enabled))
                            }
                        }
                    }
                }
            }
        }
    }

    if (showPinEditor) {
        SetPinDialog(
            onDismiss = { showPinEditor = false; pinError = null },
            error = pinError,
            onSave = { pin, confirm ->
                when {
                    pin.length !in 4..6 -> pinError = "اكتب من 4 إلى 6 أرقام"
                    pin != confirm -> pinError = "الرقمين غير متطابقين"
                    !viewModel.setAppPin(pin) -> pinError = "تعذر حفظ الرقم السري"
                    else -> { showPinEditor = false; pinError = null }
                }
            }
        )
    }
}

@Composable
private fun SetPinDialog(onDismiss: () -> Unit, error: String?, onSave: (String, String) -> Unit) {
    var pin by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    androidx.compose.material3.AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("تعيين PIN للتطبيق") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = pin,
                    onValueChange = { pin = it.filter(Char::isDigit).take(6) },
                    label = { Text("PIN من 4 إلى 6 أرقام") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    visualTransformation = PasswordVisualTransformation()
                )
                OutlinedTextField(
                    value = confirm,
                    onValueChange = { confirm = it.filter(Char::isDigit).take(6) },
                    label = { Text("تأكيد PIN") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    visualTransformation = PasswordVisualTransformation()
                )
                if (!error.isNullOrBlank()) Text(error, color = Color(0xFFB91C1C), fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        },
        confirmButton = { Button(onClick = { onSave(pin, confirm) }) { Text("حفظ") } },
        dismissButton = { OutlinedButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

@Composable
private fun SimpleSettingsCard(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, contentDescription = null, tint = Color(0xFF006D86))
                Text("  $title", fontWeight = FontWeight.ExtraBold, color = Color(0xFF17324D))
            }
            Spacer(Modifier.height(10.dp))
            content()
        }
    }
}

@Composable
private fun SettingSwitch(title: String, subtitle: String, checked: Boolean, onChecked: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.Bold, color = Color(0xFF334155))
            Text(subtitle, fontSize = 11.sp, color = Color(0xFF64748B))
        }
        Switch(checked = checked, onCheckedChange = onChecked)
    }
}
