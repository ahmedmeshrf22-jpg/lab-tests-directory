const { onDocumentCreated, onDocumentUpdated } = require("firebase-functions/v2/firestore");
const { setGlobalOptions } = require("firebase-functions/v2");
const { initializeApp } = require("firebase-admin/app");
const { getFirestore } = require("firebase-admin/firestore");
const { getMessaging } = require("firebase-admin/messaging");

initializeApp();

// V116 production tuning: bounded autoscaling with enough concurrency for busy clinic periods.
// Firebase still controls the underlying infrastructure/quota; these values avoid one request
// blocking notification delivery while also preventing runaway instance creation.
setGlobalOptions({ timeoutSeconds: 60, memory: "256MiB", maxInstances: 20, concurrency: 40 });

const db = getFirestore();
const messaging = getMessaging();
const MULTICAST_CHUNK = 500;

const statusAr = {
  new: "جديد",
  sent_to_lab: "قيد التنفيذ",
  processing: "قيد التنفيذ",
  ready: "مكتمل — النتيجة جاهزة",
  delivered: "مكتمل",
  cancelled: "تم إلغاء الطلب"
};

function uniq(values) {
  return [...new Set(values.filter(Boolean))];
}

async function tokensForUser(uid) {
  if (!uid) return [];
  const snap = await db.collection("users").doc(uid).collection("fcm_tokens").get();
  return uniq(snap.docs.map(d => d.get("token")));
}

async function tokensForLabOperators() {
  const users = await db.collection("users")
    .where("role", "==", "lab_operator")
    .where("enabled", "==", true)
    .get();
  const groups = await Promise.all(users.docs.map(d => tokensForUser(d.id)));
  return uniq(groups.flat());
}

async function send(tokens, title, body, data) {
  const uniqueTokens = uniq(tokens);
  if (!uniqueTokens.length) return;

  // FCM multicast accepts at most 500 registration tokens per request.
  for (let start = 0; start < uniqueTokens.length; start += MULTICAST_CHUNK) {
    const chunk = uniqueTokens.slice(start, start + MULTICAST_CHUNK);
    await messaging.sendEachForMulticast({
      tokens: chunk,
      notification: { title, body },
      data: Object.fromEntries(Object.entries(data || {}).map(([k, v]) => [k, String(v ?? "")])),
      android: {
        priority: "high",
        notification: { channelId: "order_updates" }
      }
    });
  }
}

function orderPayload(event, after, title, body) {
  return {
    title,
    body,
    order_id: event.params.orderId,
    customer_id: event.params.customerId,
    workflow_status: String(after.workflow_status || "")
  };
}

function lastHistoryStatus(order) {
  const history = Array.isArray(order.status_history) ? order.status_history : [];
  const last = history.length ? history[history.length - 1] : null;
  return String((last && last.status) || "");
}

async function notifyClinic(event, after, title, body) {
  const tokens = await tokensForUser(after.created_by_uid);
  await send(tokens, title, body, orderPayload(event, after, title, body));
}

async function notifyLab(event, after, title, body) {
  const tokens = await tokensForLabOperators();
  await send(tokens, title, body, orderPayload(event, after, title, body));
}

exports.notifyNewLabOrder = onDocumentCreated(
  "customers/{customerId}/orders/{orderId}",
  async (event) => {
    const after = event.data?.data() || {};
    const status = String(after.workflow_status || "");
    if (status !== "sent_to_lab") return;

    const orderNo = after.order_number || event.params.orderId;
    const customerName = after.customer_name || "العميل";
    const body = `${orderNo} • ${customerName} • طلب جديد قيد التنفيذ`;
    await notifyLab(event, after, "طلب جديد للمعمل", body);
  }
);

exports.notifyOrderStatusChanged = onDocumentUpdated(
  "customers/{customerId}/orders/{orderId}",
  async (event) => {
    const before = event.data?.before.data() || {};
    const after = event.data?.after.data() || {};
    const oldStatus = String(before.workflow_status || "");
    const newStatus = String(after.workflow_status || "");
    const orderNo = after.order_number || event.params.orderId;
    const customerName = after.customer_name || "العميل";

    if (oldStatus !== newStatus) {
      if (newStatus === "sent_to_lab") {
        await notifyLab(event, after, "طلب جديد للمعمل", `${orderNo} • ${customerName} • قيد التنفيذ`);
        return;
      }

      if (newStatus === "processing") {
        await notifyClinic(event, after, "تحديث الطلب", `${orderNo} • ${customerName} • المعمل استلم الطلب`);
        return;
      }

      if (["ready", "delivered"].includes(newStatus)) {
        await notifyClinic(event, after, "✅ نتيجة جديدة", `${orderNo} • ${customerName} • النتيجة جاهزة`);
        return;
      }

      if (newStatus === "cancelled") {
        const reason = String(after.void_reason || "تم إلغاء الطلب").trim();
        const body = `${orderNo} • ${customerName} • ${reason}`;
        // Cancellation is operationally important to both sides. Duplicate device tokens are
        // removed inside send(), so a manager device does not get repeated notifications.
        const [clinicTokens, labTokens] = await Promise.all([
          tokensForUser(after.created_by_uid),
          tokensForLabOperators()
        ]);
        await send(uniq([...clinicTokens, ...labTokens]), "⚠️ تم إلغاء طلب", body, orderPayload(event, after, "⚠️ تم إلغاء طلب", body));
        return;
      }
    }

    // Edits keep the workflow status unchanged. The status-history marker tells us which
    // operational side performed the edit, including Abdelrahman while impersonating a lab user.
    const editChanged = Number(after.edit_count || 0) > Number(before.edit_count || 0);
    if (!editChanged) return;

    const marker = lastHistoryStatus(after);
    if (marker === "edited_by_lab") {
      await notifyClinic(event, after, "تم تحديث الطلب بواسطة المعمل", `${orderNo} • ${customerName} • راجع التعديل`);
      return;
    }

    if (["sent_to_lab", "processing"].includes(newStatus)) {
      await notifyLab(event, after, "تم تعديل طلب", `${orderNo} • ${customerName} • تم تحديث بيانات الطلب`);
    }
  }
);
