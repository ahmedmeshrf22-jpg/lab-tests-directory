const { onDocumentCreated, onDocumentUpdated } = require("firebase-functions/v2/firestore");
const { initializeApp } = require("firebase-admin/app");
const { getFirestore } = require("firebase-admin/firestore");
const { getMessaging } = require("firebase-admin/messaging");

initializeApp();

const statusAr = {
  new: "جديد",
  sent_to_lab: "طلب جديد للمعمل",
  processing: "المعمل استلم الطلب وبدأ التنفيذ",
  ready: "النتيجة جاهزة وتم إرسالها",
  delivered: "تم التسليم"
};

async function tokensForUser(uid) {
  if (!uid) return [];
  const snap = await getFirestore().collection("users").doc(uid).collection("fcm_tokens").get();
  return snap.docs.map(d => d.get("token")).filter(Boolean);
}

async function tokensForLabOperators() {
  const users = await getFirestore().collection("users")
    .where("role", "==", "lab_operator")
    .where("enabled", "==", true)
    .get();
  const groups = await Promise.all(users.docs.map(d => tokensForUser(d.id)));
  return [...new Set(groups.flat())];
}

async function send(tokens, title, body, data) {
  if (!tokens.length) return;
  await getMessaging().sendEachForMulticast({
    tokens,
    notification: { title, body },
    data,
    android: { priority: "high", notification: { channelId: "order_updates" } }
  });
}


exports.notifyNewLabOrder = onDocumentCreated(
  "customers/{customerId}/orders/{orderId}",
  async (event) => {
    const after = event.data.data() || {};
    const status = String(after.workflow_status || "");
    if (status !== "sent_to_lab") return;

    const orderNo = after.order_number || event.params.orderId;
    const customerName = after.customer_name || "العميل";
    const tokens = await tokensForLabOperators();
    const body = `${orderNo} • ${customerName} • طلب جديد`;
    await send(tokens, "طلب جديد للمعمل", body, {
      title: "طلب جديد للمعمل",
      body,
      order_id: event.params.orderId,
      customer_id: event.params.customerId,
      workflow_status: status
    });
  }
);

exports.notifyOrderStatusChanged = onDocumentUpdated(
  "customers/{customerId}/orders/{orderId}",
  async (event) => {
    const before = event.data.before.data() || {};
    const after = event.data.after.data() || {};
    const oldStatus = String(before.workflow_status || "");
    const newStatus = String(after.workflow_status || "");
    const orderNo = after.order_number || event.params.orderId;
    const customerName = after.customer_name || "العميل";

    // New work for the lab: notify every enabled lab_operator account.
    if (oldStatus !== newStatus && newStatus === "sent_to_lab") {
      const tokens = await tokensForLabOperators();
      const body = `${orderNo} • ${customerName} • طلب جديد`;
      await send(tokens, "طلب جديد للمعمل", body, {
        title: "طلب جديد للمعمل",
        body,
        order_id: event.params.orderId,
        customer_id: event.params.customerId,
        workflow_status: newStatus
      });
      return;
    }

    // Clinic receives lab progress/results.
    if (oldStatus !== newStatus && ["processing", "ready"].includes(newStatus)) {
      const tokens = await tokensForUser(after.created_by_uid);
      const label = statusAr[newStatus] || newStatus;
      const body = `${orderNo} • ${customerName} • ${label}`;
      await send(tokens, "تحديث طلب المعمل", body, {
        title: "تحديث طلب المعمل",
        body,
        order_id: event.params.orderId,
        customer_id: event.params.customerId,
        workflow_status: newStatus
      });
      return;
    }

    // If the clinic edits an already-sent order, tell lab users without adding another status.
    const editChanged = Number(after.edit_count || 0) > Number(before.edit_count || 0);
    if (editChanged && ["sent_to_lab", "processing"].includes(newStatus)) {
      const tokens = await tokensForLabOperators();
      const body = `${orderNo} • ${customerName} • تم تعديل الطلب`;
      await send(tokens, "تم تعديل طلب", body, {
        title: "تم تعديل طلب",
        body,
        order_id: event.params.orderId,
        customer_id: event.params.customerId,
        workflow_status: newStatus
      });
    }
  }
);
