package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Percent
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.LocalOffer
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.outlined.Biotech
import androidx.compose.material.icons.outlined.SearchOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.R
import com.example.data.model.AppUserProfile
import com.example.data.model.Customer
import com.example.data.model.LabTest
import com.example.settings.LocalAppSettings
import com.example.util.PdfGenerator

@Composable
fun LabTestsApp(
    viewModel: LabTestsViewModel,
    currentUserEmail: String? = null,
    currentUserUid: String? = null,
    onLogout: (() -> Unit)? = null
) {
    // Force RTL layout for Arabic-first experience and apply manager-controlled font scaling.
    val appSettings by viewModel.appSettings.collectAsState()
    val baseDensity = LocalDensity.current
    CompositionLocalProvider(
        LocalLayoutDirection provides LayoutDirection.Rtl,
        LocalDensity provides Density(baseDensity.density, appSettings.fontScale),
        LocalAppSettings provides appSettings
    ) {
        val searchQuery by viewModel.searchQuery.collectAsState()
        val uiState by viewModel.uiState.collectAsState()
        val selectedTests by viewModel.selectedTests.collectAsState()
        val managerState by viewModel.isManager.collectAsState()
        val actualManagerState by viewModel.actualManager.collectAsState()
        val actingAsUser by viewModel.actingAsUser.collectAsState()
        val lab2LabPrices by viewModel.lab2LabPrices.collectAsState()
        val customerPriceOverrides by viewModel.customerPriceOverrides.collectAsState()
        val authenticatedManager = LabTestsViewModel.isManagerAccount(currentUserEmail, currentUserUid)
        val actualManager = actualManagerState || authenticatedManager
        val isManager = managerState
        var priceEditorTest by remember { mutableStateOf<LabTest?>(null) }
        var showManagerDashboard by remember { mutableStateOf(false) }
        var showUserSwitcher by remember { mutableStateOf(false) }
        var showSettingsDialog by remember { mutableStateOf(false) }
        var showCustomerSystem by remember { mutableStateOf(false) }
        var showOperationsV14 by remember { mutableStateOf(false) }
        var operationsInitialPage by remember { mutableStateOf("home") }
        var operationsInitialDebtsOnly by remember { mutableStateOf(false) }
        var operationsInitialRange by remember { mutableStateOf("today") }
        var showManagerHome by remember(currentUserUid, currentUserEmail) { mutableStateOf(authenticatedManager) }
        var showOrderCustomerPicker by remember { mutableStateOf(false) }
        var showOrderCheckout by remember { mutableStateOf(false) }
        var activeOrderCustomer by remember { mutableStateOf<Customer?>(null) }
        val context = LocalContext.current
        var orderStatusMessage by remember { mutableStateOf<String?>(null) }
        var orderStatusSuccess by remember { mutableStateOf(true) }

        // Android system Back follows the in-app navigation stack instead of
        // dropping the user out of the current workflow/root screen.
        BackHandler(enabled = true) {
            when {
                showUserSwitcher -> showUserSwitcher = false
                orderStatusMessage != null -> orderStatusMessage = null
                showOrderCheckout -> showOrderCheckout = false
                showOrderCustomerPicker -> showOrderCustomerPicker = false
                showCustomerSystem -> showCustomerSystem = false
                showOperationsV14 -> showOperationsV14 = false
                showManagerDashboard -> showManagerDashboard = false
                showSettingsDialog -> showSettingsDialog = false
                isManager && !showManagerHome -> showManagerHome = true
                else -> Unit
            }
        }

        LaunchedEffect(currentUserEmail, currentUserUid) {
            viewModel.onAuthenticatedUserChanged(currentUserEmail, currentUserUid)
        }

        LaunchedEffect(actingAsUser?.uid, actualManager) {
            if (actingAsUser != null) {
                showManagerHome = false
                showOperationsV14 = false
                showManagerDashboard = false
                priceEditorTest = null
            } else if (actualManager && isManager) {
                showManagerHome = true
            }
        }

        Scaffold(
            topBar = {
                TopHeader(
                    onLogout = onLogout,
                    showSettings = true,
                    onSettings = { showSettingsDialog = true },
                    showHome = isManager && !showManagerHome,
                    onHome = { showManagerHome = true }
                )
            },
            containerColor = if (appSettings.darkMode) Color(0xFF0B1220) else Color(0xFFF4F7FB)
        ) { paddingValues ->
            if (isManager && showManagerHome) {
                ManagerHomeDashboard(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(paddingValues),
                    viewModel = viewModel,
                    onNewOrder = {
                        viewModel.clearSearch()
                        showManagerHome = false
                    },
                    onCustomers = { showCustomerSystem = true },
                    onOrders = {
                        operationsInitialPage = "reports"
                        operationsInitialDebtsOnly = false
                        operationsInitialRange = "all"
                        showOperationsV14 = true
                    },
                    onReports = {
                        operationsInitialPage = "reports"
                        operationsInitialDebtsOnly = false
                        operationsInitialRange = "today"
                        showOperationsV14 = true
                    },
                    onDebts = {
                        operationsInitialPage = "reports"
                        operationsInitialDebtsOnly = true
                        operationsInitialRange = "all"
                        showOperationsV14 = true
                    },
                    onAdmin = {
                        operationsInitialPage = "home"
                        operationsInitialDebtsOnly = false
                        operationsInitialRange = "today"
                        showOperationsV14 = true
                    },
                    onSwitchUser = { showUserSwitcher = true }
                )
            } else {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(paddingValues)
                        .padding(horizontal = 14.dp)
                ) {
                    Spacer(modifier = Modifier.height(14.dp))

                    if (actualManager && actingAsUser != null) {
                        ActingAsUserBanner(
                            profile = actingAsUser!!,
                            onReturnToManager = {
                                viewModel.returnToManagerMode()
                                activeOrderCustomer = null
                                showCustomerSystem = false
                                showManagerHome = true
                            }
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                    }

                    if (!isManager) {
                        CustomerSystemCard(onClick = { showCustomerSystem = true })
                        Spacer(modifier = Modifier.height(10.dp))
                    }

                    SearchBox(
                        query = searchQuery,
                        onQueryChange = { viewModel.onQueryChanged(it) },
                        onClear = { viewModel.clearSearch() }
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    MainContent(
                        uiState = uiState,
                        selectedTests = selectedTests,
                        isManager = isManager,
                        lab2LabPrices = lab2LabPrices,
                        customerPriceOverrides = customerPriceOverrides,
                        activeOrderCustomer = activeOrderCustomer,
                        onChooseCustomer = { showOrderCustomerPicker = true },
                        onClearCustomer = { activeOrderCustomer = null },
                        onSaveCustomerOrder = {
                            if (activeOrderCustomer != null && selectedTests.isNotEmpty()) {
                                showOrderCheckout = true
                            }
                        },
                        onSelectTest = { test -> viewModel.addSelectedTest(test) },
                        onRemoveTest = { testId -> viewModel.removeSelectedTest(testId) },
                        onEditPrices = { test -> priceEditorTest = test }
                    )
                }
            }
        }

        if (showUserSwitcher && actualManager && actingAsUser == null) {
            UserSwitcherDialog(
                viewModel = viewModel,
                onDismiss = { showUserSwitcher = false },
                onUserSelected = { profile ->
                    viewModel.switchToUser(profile) { success, message ->
                        orderStatusSuccess = success
                        orderStatusMessage = message
                        if (success) {
                            showUserSwitcher = false
                            showManagerHome = false
                            activeOrderCustomer = null
                        }
                    }
                }
            )
        }

        if (showOperationsV14 && isManager) {
            OperationsV14Dialog(
                viewModel = viewModel,
                isManager = isManager,
                initialPage = operationsInitialPage,
                initialDebtsOnly = operationsInitialDebtsOnly,
                initialRange = operationsInitialRange,
                onDismiss = { showOperationsV14 = false }
            )
        }

        if (showCustomerSystem) {
            CustomerSystemDialog(
                viewModel = viewModel,
                selectedTests = selectedTests,
                onDismiss = { showCustomerSystem = false },
                onStartOrderForCustomer = { customer ->
                    activeOrderCustomer = customer
                    showCustomerSystem = false
                    orderStatusMessage = "تم اختيار ${customer.name}. اختار التحاليل واحفظ الطلب."
                    orderStatusSuccess = true
                }
            )
        }

        if (showOrderCustomerPicker) {
            CustomerOrderFlowDialog(
                viewModel = viewModel,
                selectedTests = selectedTests,
                onDismiss = { showOrderCustomerPicker = false },
                onCustomerSelected = { customer ->
                    activeOrderCustomer = customer
                    showOrderCustomerPicker = false
                    orderStatusSuccess = true
                    orderStatusMessage = "تم ربط الطلب بالعميل ${customer.name}"
                }
            )
        }

        val checkoutCustomer = activeOrderCustomer
        if (showOrderCheckout && checkoutCustomer != null) {
            ProfessionalOrderCheckoutDialog(
                customer = checkoutCustomer,
                selectedTests = selectedTests,
                customerPriceOverrides = customerPriceOverrides,
                onDismiss = { showOrderCheckout = false },
                onConfirm = { discount, discountPercent, paymentStatus, paidAmount, notes, sharePdf ->
                    viewModel.saveCustomerOrderAdvanced(
                        customer = checkoutCustomer,
                        tests = selectedTests,
                        discountAmount = discount,
                        discountPercent = discountPercent,
                        paymentStatus = paymentStatus,
                        paidAmount = paidAmount,
                        notes = notes
                    ) { order, msg ->
                        orderStatusSuccess = order != null
                        orderStatusMessage = msg
                        if (order != null) {
                            if (sharePdf) {
                                PdfGenerator.generateAndSharePdf(
                                    context = context,
                                    selectedTests = selectedTests,
                                    includeCustomerPrice = appSettings.pdfIncludeCustomerPrice,
                                    includeLab2Lab = isManager && appSettings.pdfIncludeLab2LabPrice,
                                    showTotals = appSettings.pdfShowTotals,
                                    labName = appSettings.pdfLabName,
                                    showContactInfo = appSettings.pdfShowContactInfo,
                                    contactInfo = appSettings.pdfContactInfo,
                                    lab2LabPrices = lab2LabPrices,
                                    customerPriceOverrides = customerPriceOverrides,
                                    customerName = checkoutCustomer.name,
                                    customerFileNumber = checkoutCustomer.fileNumber,
                                    customerPhone = checkoutCustomer.phone,
                                    orderNumber = order.orderNumber,
                                    orderDateMillis = order.createdAtMillis,
                                    discountAmount = order.discountAmount,
                                    finalCustomerTotal = order.totalCustomerPrice,
                                    paymentStatus = order.paymentStatus,
                                    paidAmount = order.paidAmount,
                                    remainingAmount = order.remainingAmount,
                                    orderNotes = order.notes
                                )
                            }
                            showOrderCheckout = false
                            viewModel.clearSelectedTests()
                            activeOrderCustomer = null
                        }
                    }
                }
            )
        }

        orderStatusMessage?.let { message ->
            AlertDialog(
                onDismissRequest = { orderStatusMessage = null },
                title = {
                    Text(
                        if (orderStatusSuccess) "تم" else "تعذر التنفيذ",
                        fontWeight = FontWeight.ExtraBold
                    )
                },
                text = { Text(message) },
                confirmButton = {
                    TextButton(onClick = { orderStatusMessage = null }) { Text("حسنا") }
                }
            )
        }

        if (showSettingsDialog) {
            if (isManager) {
                ManagerSettingsDialog(
                    viewModel = viewModel,
                    settings = appSettings,
                    currentUserEmail = currentUserEmail,
                    currentUserUid = currentUserUid,
                    onDismiss = { showSettingsDialog = false },
                    onOpenManagerDashboard = {
                        showSettingsDialog = false
                        showManagerDashboard = true
                    },
                    onLogout = onLogout
                )
            } else {
                UserSettingsDialog(
                    viewModel = viewModel,
                    settings = appSettings,
                    onDismiss = { showSettingsDialog = false }
                )
            }
        }

        if (isManager && showManagerDashboard) {
            ManagerDashboardDialog(
                viewModel = viewModel,
                customerPriceOverrides = customerPriceOverrides,
                lab2LabPrices = lab2LabPrices,
                onDismiss = { showManagerDashboard = false },
                onEdit = { test ->
                    showManagerDashboard = false
                    priceEditorTest = test
                }
            )
        }

        if (isManager) {
            priceEditorTest?.let { test ->
                ManagerPriceEditorDialog(
                    test = test,
                    customerPrice = customerPriceOverrides[test.id] ?: test.customerPrice.orEmpty(),
                    lab2LabPrice = lab2LabPrices[test.id].orEmpty(),
                    onDismiss = { priceEditorTest = null },
                    onSave = { customer, lab, done ->
                        viewModel.saveManagerPrices(test, customer, lab) { success, message ->
                            if (success) priceEditorTest = null
                            done(success, message)
                        }
                    }
                )
            }
        }
    }
}

@Composable
private fun TopHeader(
    onLogout: (() -> Unit)? = null,
    showSettings: Boolean = false,
    onSettings: (() -> Unit)? = null,
    showHome: Boolean = false,
    onHome: (() -> Unit)? = null
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                Brush.horizontalGradient(
                    colors = listOf(
                        Color(0xFF003A5D),
                        Color(0xFF006D86),
                        Color(0xFF008FA0)
                    )
                )
            )
            .padding(horizontal = 16.dp, vertical = 16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                modifier = Modifier.weight(1f),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(18.dp),
                    color = Color.White,
                    shadowElevation = 3.dp,
                    modifier = Modifier.size(58.dp)
                ) {
                    Box(
                        modifier = Modifier.padding(5.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.ic_clinic_logo),
                            contentDescription = "شعار عيادات العقاد",
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                    Text(
                        text = "تحاليل العقاد",
                        fontSize = 21.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.White,
                        letterSpacing = (-0.4).sp
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "دليل التحاليل والأسعار",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        color = Color(0xFFD9F4F4)
                    )
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                if (showHome && onHome != null) {
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = Color.White.copy(alpha = 0.12f)
                    ) {
                        IconButton(
                            onClick = onHome,
                            modifier = Modifier.size(44.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Home,
                                contentDescription = "الرئيسية",
                                tint = Color.White,
                                modifier = Modifier.size(21.dp)
                            )
                        }
                    }
                }

                if (showSettings && onSettings != null) {
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = Color.White.copy(alpha = 0.12f)
                    ) {
                        IconButton(
                            onClick = onSettings,
                            modifier = Modifier
                                .size(44.dp)
                                .testTag("manager_settings_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Settings,
                                contentDescription = "إعدادات التطبيق",
                                tint = Color.White,
                                modifier = Modifier.size(21.dp)
                            )
                        }
                    }
                }

                if (onLogout != null) {
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = Color.White.copy(alpha = 0.12f)
                    ) {
                        IconButton(
                            onClick = onLogout,
                            modifier = Modifier
                                .size(44.dp)
                                .testTag("logout_button")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.Logout,
                                contentDescription = "تسجيل الخروج",
                                tint = Color.White,
                                modifier = Modifier.size(21.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ManagerHomeDashboard(
    modifier: Modifier = Modifier,
    viewModel: LabTestsViewModel,
    onNewOrder: () -> Unit,
    onCustomers: () -> Unit,
    onOrders: () -> Unit,
    onReports: () -> Unit,
    onDebts: () -> Unit,
    onAdmin: () -> Unit,
    onSwitchUser: () -> Unit
) {
    val summary by viewModel.managerHomeSummary.collectAsState()
    val loading by viewModel.managerHomeLoading.collectAsState()

    LaunchedEffect(Unit) {
        viewModel.loadManagerHomeSummary()
    }

    LazyColumn(
        modifier = modifier.padding(horizontal = 14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(top = 14.dp, bottom = 28.dp)
    ) {
        item {
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = Color(0xFF17324D),
                shadowElevation = 5.dp
            ) {
                Row(
                    Modifier.fillMaxWidth().padding(18.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            text = "Abdelrahman",
                            color = Color.White,
                            fontSize = 21.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Text(
                            text = "General Manager",
                            color = Color.White.copy(alpha = 0.78f),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                    Button(
                        onClick = onSwitchUser,
                        shape = RoundedCornerShape(14.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color.White.copy(alpha = 0.14f),
                            contentColor = Color.White
                        )
                    ) {
                        Icon(Icons.Default.People, contentDescription = null, modifier = Modifier.size(17.dp))
                        Spacer(Modifier.width(5.dp))
                        Text("تبديل المستخدم", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        item {
            Text(
                text = "نظرة سريعة",
                fontSize = 13.sp,
                fontWeight = FontWeight.ExtraBold,
                color = Color(0xFF475569)
            )
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                ManagerStatChip(
                    modifier = Modifier.weight(1f),
                    label = "طلبات اليوم",
                    value = if (loading) "..." else summary.ordersCount.toString()
                )
                ManagerStatChip(
                    modifier = Modifier.weight(1f),
                    label = "تحصيل اليوم",
                    value = if (loading) "..." else "${formatTotalDisplay(summary.paid)} ج"
                )
                ManagerStatChip(
                    modifier = Modifier.weight(1f),
                    label = "المديونيات",
                    value = if (loading) "..." else "${formatTotalDisplay(summary.remaining)} ج"
                )
            }
        }

        item {
            Text(
                text = "الأقسام الرئيسية",
                fontSize = 13.sp,
                fontWeight = FontWeight.ExtraBold,
                color = Color(0xFF475569)
            )
        }

        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ManagerHomeActionCard(
                    modifier = Modifier.weight(1f),
                    icon = Icons.Default.AddCircle,
                    title = "طلب جديد",
                    subtitle = "اختيار التحاليل",
                    accent = Color(0xFF0F766E),
                    onClick = onNewOrder
                )
                ManagerHomeActionCard(
                    modifier = Modifier.weight(1f),
                    icon = Icons.Default.People,
                    title = "العملاء",
                    subtitle = "بحث وملفات العملاء",
                    accent = Color(0xFF2563EB),
                    onClick = onCustomers
                )
            }
        }

        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ManagerHomeActionCard(
                    modifier = Modifier.weight(1f),
                    icon = Icons.Default.ReceiptLong,
                    title = "الطلبات",
                    subtitle = "كل الطلبات",
                    accent = Color(0xFF7C3AED),
                    onClick = onOrders
                )
                ManagerHomeActionCard(
                    modifier = Modifier.weight(1f),
                    icon = Icons.Default.Assessment,
                    title = "التقارير",
                    subtitle = "مبيعات وتحليلات",
                    accent = Color(0xFF0369A1),
                    onClick = onReports
                )
            }
        }

        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ManagerHomeActionCard(
                    modifier = Modifier.weight(1f),
                    icon = Icons.Default.AccountBalanceWallet,
                    title = "المديونيات",
                    subtitle = "المبالغ المتبقية",
                    accent = Color(0xFFB45309),
                    onClick = onDebts
                )
                ManagerHomeActionCard(
                    modifier = Modifier.weight(1f),
                    icon = Icons.Default.AdminPanelSettings,
                    title = "الإدارة",
                    subtitle = "مستخدمين ومراجعة",
                    accent = Color(0xFF475569),
                    onClick = onAdmin
                )
            }
        }
    }
}

@Composable
private fun ActingAsUserBanner(
    profile: AppUserProfile,
    onReturnToManager: () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        color = Color(0xFFFFF7ED),
        border = BorderStroke(1.dp, Color(0xFFF59E0B).copy(alpha = 0.45f))
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Box(
                modifier = Modifier.size(36.dp).clip(CircleShape).background(Color(0xFFFFEDD5)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.People, contentDescription = null, tint = Color(0xFFC2410C), modifier = Modifier.size(19.dp))
            }
            Column(Modifier.weight(1f)) {
                Text(
                    text = "تعمل الآن بصلاحيات ${profile.displayName.ifBlank { profile.email }}",
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 12.sp,
                    color = Color(0xFF9A3412),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = "الحساب الفعلي: Abdelrahman",
                    fontSize = 9.sp,
                    color = Color(0xFF7C2D12)
                )
            }
            TextButton(onClick = onReturnToManager) {
                Text("رجوع لـ Abdelrahman", fontSize = 10.sp, fontWeight = FontWeight.ExtraBold)
            }
        }
    }
}

@Composable
private fun UserSwitcherDialog(
    viewModel: LabTestsViewModel,
    onDismiss: () -> Unit,
    onUserSelected: (AppUserProfile) -> Unit
) {
    val users by viewModel.users.collectAsState()
    var query by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(true) }
    var message by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        viewModel.loadUsers { success, result ->
            loading = false
            if (!success) message = result
        }
    }

    val filtered = remember(users, query) {
        val q = query.trim().lowercase()
        users.filter {
            it.enabled &&
                !LabTestsViewModel.isManagerAccount(it.email, it.uid) &&
                (q.isBlank() || it.displayName.lowercase().contains(q) || it.email.lowercase().contains(q))
        }
    }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(
            modifier = Modifier.fillMaxWidth(0.92f).height(560.dp),
            shape = RoundedCornerShape(24.dp),
            color = Color(0xFFF8FAFC),
            shadowElevation = 8.dp
        ) {
            Column(Modifier.fillMaxSize().padding(16.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("تبديل المستخدم", fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF17324D))
                        Text("اختر مستخدمًا لتجربة واستخدام صلاحياته", fontSize = 11.sp, color = Color(0xFF64748B))
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "إغلاق")
                    }
                }

                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    placeholder = { Text("ابحث بالاسم أو البريد") },
                    shape = RoundedCornerShape(15.dp)
                )
                Spacer(Modifier.height(10.dp))

                when {
                    loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator()
                    }
                    message != null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text(message.orEmpty(), color = Color(0xFFB91C1C), fontWeight = FontWeight.Bold)
                    }
                    filtered.isEmpty() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("لا يوجد مستخدمون نشطون", color = Color(0xFF64748B))
                    }
                    else -> LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        contentPadding = PaddingValues(bottom = 12.dp)
                    ) {
                        items(filtered, key = { it.uid }) { profile ->
                            Card(
                                onClick = { onUserSelected(profile) },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = Color.White),
                                border = BorderStroke(1.dp, Color(0xFFE5EAF0))
                            ) {
                                Row(
                                    Modifier.fillMaxWidth().padding(13.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Box(
                                        Modifier.size(42.dp).clip(CircleShape).background(Color(0xFFE7F5F7)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(Icons.Default.People, contentDescription = null, tint = Color(0xFF006D86))
                                    }
                                    Column(Modifier.weight(1f)) {
                                        Text(profile.displayName.ifBlank { profile.email }, fontWeight = FontWeight.ExtraBold, color = Color(0xFF17324D))
                                        Text(profile.email, fontSize = 10.sp, color = Color(0xFF64748B), maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    }
                                    Text("دخول", color = Color(0xFF006D86), fontWeight = FontWeight.ExtraBold, fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ManagerStatChip(
    modifier: Modifier = Modifier,
    label: String,
    value: String
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        color = Color.White,
        shadowElevation = 1.dp,
        border = BorderStroke(1.dp, Color(0xFFE5EAF0))
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = value,
                fontWeight = FontWeight.ExtraBold,
                fontSize = 15.sp,
                color = Color(0xFF17324D),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(3.dp))
            Text(
                text = label,
                fontSize = 9.sp,
                fontWeight = FontWeight.Medium,
                color = Color(0xFF64748B),
                maxLines = 1
            )
        }
    }
}

@Composable
private fun ManagerHomeActionCard(
    modifier: Modifier = Modifier,
    icon: ImageVector,
    title: String,
    subtitle: String,
    accent: Color,
    onClick: () -> Unit
) {
    Card(
        onClick = onClick,
        modifier = modifier.height(116.dp),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
        border = BorderStroke(1.dp, Color(0xFFE7ECF2))
    ) {
        Column(
            modifier = Modifier.fillMaxSize().padding(14.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            ManagerActionIcon(
                icon = icon,
                accent = accent
            )
            Column {
                Text(
                    text = title,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color(0xFF17324D)
                )
                Text(
                    text = subtitle,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Medium,
                    color = Color(0xFF64748B),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
private fun ManagerActionIcon(
    icon: ImageVector,
    accent: Color
) {
    Box(
        modifier = Modifier
            .size(46.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(accent.copy(alpha = 0.11f)),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = accent,
            modifier = Modifier.size(25.dp)
        )
    }
}

@Composable
private fun ManagerDashboardCard(onClick: () -> Unit) {
    Card(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .shadow(
                elevation = 3.dp,
                shape = RoundedCornerShape(18.dp),
                spotColor = Color(0x12000000)
            ),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFF5F3FF)),
        border = BorderStroke(1.dp, Color(0xFFDDD6FE))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFFEDE9FE)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Tune,
                    contentDescription = null,
                    tint = Color(0xFF6D28D9),
                    modifier = Modifier.size(21.dp)
                )
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "لوحة تحكم المدير",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color(0xFF4C1D95)
                )
                Text(
                    text = "اضغط لإدارة أسعار جميع التحاليل",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium,
                    color = Color(0xFF6B5A8E)
                )
            }
            Icon(
                imageVector = Icons.Default.Edit,
                contentDescription = "فتح لوحة المدير",
                tint = Color(0xFF6D28D9),
                modifier = Modifier.size(20.dp)
            )
        }
    }
}

@Composable
private fun ManagerDashboardDialog(
    viewModel: LabTestsViewModel,
    customerPriceOverrides: Map<Int, String>,
    lab2LabPrices: Map<Int, String>,
    onDismiss: () -> Unit,
    onEdit: (LabTest) -> Unit
) {
    var managerQuery by remember { mutableStateOf("") }
    val tests = remember(managerQuery) { viewModel.searchManagerTests(managerQuery) }

    BackHandler(enabled = true) { onDismiss() }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false, dismissOnBackPress = true)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp),
            shape = RoundedCornerShape(24.dp),
            color = Color(0xFFF7F8FC),
            shadowElevation = 8.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "لوحة تحكم المدير",
                            fontSize = 21.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFF3B176B)
                        )
                        Text(
                            text = "إدارة سعر العميل و Lab 2 Lab",
                            fontSize = 12.sp,
                            color = Color(0xFF6B5A8E)
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "إغلاق",
                            tint = Color(0xFF4C1D95)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = managerQuery,
                    onValueChange = { managerQuery = it },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = null
                        )
                    },
                    placeholder = { Text("ابحث باسم التحليل عربي أو إنجليزي") },
                    shape = RoundedCornerShape(16.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color(0xFF6D28D9),
                        cursorColor = Color(0xFF6D28D9),
                        focusedContainerColor = Color.White,
                        unfocusedContainerColor = Color.White
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "التحاليل: ${tests.size}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF475569)
                    )
                    Text(
                        text = "الأسعار المعدلة: ${customerPriceOverrides.size}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF6D28D9)
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(9.dp),
                    contentPadding = PaddingValues(bottom = 12.dp)
                ) {
                    items(tests, key = { it.id }) { test ->
                        val customer = customerPriceOverrides[test.id] ?: test.customerPrice ?: "—"
                        val lab = lab2LabPrices[test.id] ?: "—"

                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            border = BorderStroke(1.dp, Color(0xFFE7E8EF))
                        ) {
                            Column(modifier = Modifier.padding(13.dp)) {
                                Text(
                                    text = test.englishName,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = Color(0xFF17324D),
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                                if (test.arabicName.isNotBlank()) {
                                    Text(
                                        text = test.arabicName,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = Color(0xFF64748B),
                                        maxLines = 2,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }

                                Spacer(modifier = Modifier.height(9.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(
                                            text = "سعر العميل: $customer ج",
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFF007C88)
                                        )
                                        Text(
                                            text = "Lab 2 Lab: $lab ج",
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFF6D28D9)
                                        )
                                    }
                                    Button(
                                        onClick = { onEdit(test) },
                                        shape = RoundedCornerShape(12.dp),
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = Color(0xFF6D28D9)
                                        )
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Edit,
                                            contentDescription = null,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(5.dp))
                                        Text("تعديل")
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ManagerPriceEditorDialog(
    test: LabTest,
    customerPrice: String,
    lab2LabPrice: String,
    onDismiss: () -> Unit,
    onSave: (String, String, (Boolean, String) -> Unit) -> Unit
) {
    var customerText by remember(test.id, customerPrice) { mutableStateOf(customerPrice) }
    var labText by remember(test.id, lab2LabPrice) { mutableStateOf(lab2LabPrice) }
    var saving by remember(test.id) { mutableStateOf(false) }
    var message by remember(test.id) { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = { if (!saving) onDismiss() },
        title = {
            Column {
                Text(
                    text = "تعديل الأسعار",
                    fontWeight = FontWeight.ExtraBold,
                    color = Color(0xFF102A43)
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = test.englishName,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color(0xFF52667A)
                )
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = customerText,
                    onValueChange = { customerText = it.filter { ch -> ch.isDigit() || ch == '.' } },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("سعر العميل") },
                    suffix = { Text("جنيه") },
                    singleLine = true,
                    enabled = !saving,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    shape = RoundedCornerShape(14.dp)
                )
                OutlinedTextField(
                    value = labText,
                    onValueChange = { labText = it.filter { ch -> ch.isDigit() || ch == '.' } },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("سعر Lab 2 Lab") },
                    suffix = { Text("جنيه") },
                    singleLine = true,
                    enabled = !saving,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    shape = RoundedCornerShape(14.dp)
                )
                message?.let {
                    Text(
                        text = it,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFFB42318)
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    saving = true
                    message = null
                    onSave(customerText, labText) { success, resultMessage ->
                        saving = false
                        if (!success) message = resultMessage
                    }
                },
                enabled = !saving && customerText.isNotBlank() && labText.isNotBlank(),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6D28D9))
            ) {
                if (saving) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(18.dp),
                        strokeWidth = 2.dp,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                }
                Text("حفظ الأسعار", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss, enabled = !saving) {
                Text("إلغاء")
            }
        },
        shape = RoundedCornerShape(22.dp),
        containerColor = Color.White
    )
}

@Composable
private fun SearchBox(
    query: String,
    onQueryChange: (String) -> Unit,
    onClear: () -> Unit
) {
    val keyboardController = LocalSoftwareKeyboardController.current

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(
                elevation = 6.dp,
                shape = RoundedCornerShape(24.dp),
                spotColor = Color(0x16000000)
            ),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, Color(0xFFE4ECF4))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .clip(RoundedCornerShape(11.dp))
                        .background(Color(0xFFE7F5F7)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = null,
                        tint = Color(0xFF007B87),
                        modifier = Modifier.size(20.dp)
                    )
                }
                Spacer(modifier = Modifier.width(9.dp))
                Column {
                    Text(
                        text = "ابحث عن التحليل",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color(0xFF102A43)
                    )
                    Text(
                        text = "عربي • English • الاسم الدارج",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        color = Color(0xFF718096)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
                value = query,
                onValueChange = onQueryChange,
                enabled = true,
                readOnly = false,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("search_text_field"),
                placeholder = {
                    Text(
                        text = "مثال: CBC أو صورة دم كاملة",
                        color = Color(0xFF98A6B8),
                        fontSize = 14.sp
                    )
                },
                trailingIcon = {
                    if (query.isNotEmpty()) {
                        IconButton(
                            onClick = onClear,
                            modifier = Modifier.testTag("clear_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "مسح البحث",
                                tint = Color(0xFF64748B)
                            )
                        }
                    }
                },
                singleLine = false,
                minLines = 1,
                maxLines = 4,
                shape = RoundedCornerShape(16.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = Color(0xFFF7FAFC),
                    unfocusedContainerColor = Color(0xFFF7FAFC),
                    disabledContainerColor = Color(0xFFF7FAFC),
                    focusedBorderColor = Color(0xFF008B95),
                    unfocusedBorderColor = Color(0xFFDCE5EE),
                    focusedTextColor = Color(0xFF102A43),
                    unfocusedTextColor = Color(0xFF102A43)
                ),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Default),
                keyboardActions = KeyboardActions(onSearch = { keyboardController?.hide() })
            )

            if (query.isBlank()) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "يمكنك كتابة أكثر من تحليل؛ كل تحليل في سطر أو افصل بينهم بفاصلة.",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium,
                    color = Color(0xFF7B8794),
                    lineHeight = 16.sp
                )
            }
        }
    }
}

@Composable
private fun ResultCountChip(count: Int) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.Start,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .clip(CircleShape)
                .background(Color(0xFFE1F1FF))
                .padding(horizontal = 14.dp, vertical = 6.dp)
        ) {
            Text(
                text = "$count نتائج",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF0061A4)
            )
        }
    }
}

private fun calculatePriceTotal(tests: List<LabTest>, priceSelector: (LabTest) -> String?): Double {
    var total = 0.0
    val regex = Regex("""\d+(\.\d+)?""")
    for (test in tests) {
        val priceStr = priceSelector(test)
        if (!priceStr.isNullOrBlank()) {
            val match = regex.find(priceStr)
            val valDouble = match?.value?.toDoubleOrNull()
            if (valDouble != null) {
                total += valDouble
            }
        }
    }
    return total
}

private fun formatTotalDisplay(total: Double): String {
    return if (total % 1.0 == 0.0) {
        total.toLong().toString()
    } else {
        String.format("%.2f", total)
    }
}

@Composable
private fun MainContent(
    uiState: SearchUiState,
    selectedTests: List<LabTest>,
    isManager: Boolean,
    lab2LabPrices: Map<Int, String>,
    customerPriceOverrides: Map<Int, String>,
    activeOrderCustomer: Customer?,
    onChooseCustomer: () -> Unit,
    onClearCustomer: () -> Unit,
    onSaveCustomerOrder: () -> Unit,
    onSelectTest: (LabTest) -> Unit,
    onRemoveTest: (Int) -> Unit,
    onEditPrices: (LabTest) -> Unit
) {
    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(16.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        // 1. Selected Tests Section ("التحاليل المختارة")
        if (selectedTests.isNotEmpty()) {
            item(key = "selected_tests_section") {
                SelectedTestsSection(
                    selectedTests = selectedTests,
                    isManager = isManager,
                    lab2LabPrices = lab2LabPrices,
                    customerPriceOverrides = customerPriceOverrides,
                    activeOrderCustomer = activeOrderCustomer,
                    onChooseCustomer = onChooseCustomer,
                    onClearCustomer = onClearCustomer,
                    onSaveCustomerOrder = onSaveCustomerOrder,
                    onRemoveTest = onRemoveTest
                )
            }
        }

        // 2. Search States
        when (uiState) {
            is SearchUiState.EmptyQuery -> {
                if (selectedTests.isEmpty()) {
                    item(key = "empty_state") {
                        EmptyStateView()
                    }
                }
            }
            is SearchUiState.NoResults -> {
                item(key = "no_results_section") {
                    NoResultsSection(unmatchedQueries = uiState.unmatchedQueries)
                }
            }
            is SearchUiState.Success -> {
                item(key = "search_header") {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "نتائج البحث",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFF17324D)
                        )
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .background(Color(0xFFE7F5F7))
                                .padding(horizontal = 10.dp, vertical = 5.dp)
                        ) {
                            Text(
                                text = "${uiState.queryGroups.sumOf { it.candidates.size }} نتيجة",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF007B87)
                            )
                        }
                    }
                }

                items(uiState.queryGroups, key = { it.query }) { group ->
                    QueryGroupSection(
                        group = group,
                        isManager = isManager,
                        lab2LabPrices = lab2LabPrices,
                        customerPriceOverrides = customerPriceOverrides,
                        onSelectTest = onSelectTest,
                        onEditPrices = onEditPrices
                    )
                }

                if (uiState.unmatchedQueries.isNotEmpty()) {
                    item(key = "unmatched_queries") {
                        UnmatchedQueriesCard(unmatchedQueries = uiState.unmatchedQueries)
                    }
                }
            }
        }

        item(key = "bottom_spacer") {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
private fun SelectedTestsSection(
    selectedTests: List<LabTest>,
    isManager: Boolean,
    lab2LabPrices: Map<Int, String>,
    customerPriceOverrides: Map<Int, String>,
    activeOrderCustomer: Customer?,
    onChooseCustomer: () -> Unit,
    onClearCustomer: () -> Unit,
    onSaveCustomerOrder: () -> Unit,
    onRemoveTest: (Int) -> Unit
) {
    val settings = LocalAppSettings.current
    val totalPrice = calculatePriceTotal(selectedTests) { customerPriceOverrides[it.id] ?: it.customerPrice }
    val totalLab2LabPrice = if (isManager && settings.showLab2LabPrice) {
        calculatePriceTotal(selectedTests) { lab2LabPrices[it.id] }
    } else {
        0.0
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(
                elevation = 4.dp,
                shape = RoundedCornerShape(20.dp),
                spotColor = Color(0x1A000000)
            ),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.5.dp, Color(0xFF0061A4))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // Section Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = Color(0xFF0061A4),
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "التحاليل المختارة",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF001D35)
                    )
                }
                Box(
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(Color(0xFFE1F1FF))
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "${selectedTests.size}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0061A4)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Selected items list
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                selectedTests.forEach { test ->
                    SelectedTestRow(
                        test = test,
                        customerPrice = customerPriceOverrides[test.id] ?: test.customerPrice,
                        isManager = isManager,
                        lab2LabPrice = lab2LabPrices[test.id],
                        onRemove = { onRemoveTest(test.id) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Total Price Section - controlled from manager settings.
            if (settings.showCustomerPrice || (isManager && settings.showLab2LabPrice)) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color(0xFF0061A4))
                        .padding(14.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (settings.showCustomerPrice) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = if (isManager) "إجمالي سعر العميل" else "الإجمالي",
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                                Row(verticalAlignment = Alignment.Bottom) {
                                    Text(
                                        text = formatTotalDisplay(totalPrice),
                                        fontSize = 20.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = Color.White
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "جنيه",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White,
                                        modifier = Modifier.padding(bottom = 2.dp)
                                    )
                                }
                            }
                        }

                        if (isManager && settings.showLab2LabPrice) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "إجمالي Lab 2 Lab",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                                Row(verticalAlignment = Alignment.Bottom) {
                                    Text(
                                        text = formatTotalDisplay(totalLab2LabPrice),
                                        fontSize = 19.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = Color.White
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "جنيه",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White,
                                        modifier = Modifier.padding(bottom = 2.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))
            }

            // Customer order flow
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                color = if (activeOrderCustomer == null) Color(0xFFF8FAFC) else Color(0xFFE7F5F7),
                border = BorderStroke(1.dp, if (activeOrderCustomer == null) Color(0xFFE2E8F0) else Color(0xFF7DD3FC))
            ) {
                Column(Modifier.padding(12.dp)) {
                    if (activeOrderCustomer == null) {
                        Text(
                            "اربط التحاليل بعميل قبل حفظ الطلب",
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFF17324D)
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            "اختار عميل سابق أو أضف عميل جديد",
                            fontSize = 12.sp,
                            color = Color(0xFF64748B)
                        )
                        Spacer(Modifier.height(10.dp))
                        Button(
                            onClick = onChooseCustomer,
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF006D86))
                        ) {
                            Text("اختيار العميل", fontWeight = FontWeight.Bold)
                        }
                    } else {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("العميل المرتبط بالطلب", fontSize = 11.sp, color = Color(0xFF64748B))
                                Text(activeOrderCustomer.name, fontWeight = FontWeight.ExtraBold, color = Color(0xFF17324D))
                                Text(
                                    "${activeOrderCustomer.fileNumber} • ${activeOrderCustomer.phone}",
                                    fontSize = 11.sp,
                                    color = Color(0xFF006D86)
                                )
                            }
                            TextButton(onClick = onClearCustomer) { Text("تغيير") }
                        }
                        Spacer(Modifier.height(10.dp))
                        Button(
                            onClick = onSaveCustomerOrder,
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF15803D))
                        ) {
                            Text("حفظ الطلب في ملف العميل", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // PDF Generation Button
            val context = LocalContext.current
            Button(
                onClick = {
                    PdfGenerator.generateAndSharePdf(
                        context = context,
                        selectedTests = selectedTests,
                        includeCustomerPrice = settings.pdfIncludeCustomerPrice,
                        includeLab2Lab = isManager && settings.pdfIncludeLab2LabPrice,
                        showTotals = settings.pdfShowTotals,
                        labName = settings.pdfLabName,
                        showContactInfo = settings.pdfShowContactInfo,
                        contactInfo = settings.pdfContactInfo,
                        lab2LabPrices = lab2LabPrices,
                        customerPriceOverrides = customerPriceOverrides,
                        customerName = activeOrderCustomer?.name,
                        customerFileNumber = activeOrderCustomer?.fileNumber,
                        customerPhone = activeOrderCustomer?.phone
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("generate_pdf_button"),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF15803D)
                )
            ) {
                Icon(
                    imageVector = Icons.Default.PictureAsPdf,
                    contentDescription = "PDF Icon",
                    tint = Color.White,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "إنشاء PDF",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
        }
    }
}

@Composable
fun ProfessionalOrderCheckoutDialog(
    customer: Customer,
    selectedTests: List<LabTest>,
    customerPriceOverrides: Map<Int, String>,
    onDismiss: () -> Unit,
    onConfirm: (discount: Double, discountPercent: Double, paymentStatus: String, paidAmount: Double, notes: String, sharePdf: Boolean) -> Unit
) {
    val subtotal = calculatePriceTotal(selectedTests) { customerPriceOverrides[it.id] ?: it.customerPrice }
    var discountMode by remember(customer.id) {
        mutableStateOf(if (customer.defaultDiscountPercent > 0.0) "percent" else "amount")
    }
    var discountText by remember(customer.id) {
        mutableStateOf(
            customer.defaultDiscountPercent.takeIf { it > 0.0 }?.let {
                if (it % 1.0 == 0.0) it.toLong().toString() else String.format(java.util.Locale.US, "%.1f", it)
            }.orEmpty()
        )
    }
    var paymentStatus by remember { mutableStateOf("unpaid") }
    var paidText by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }

    val rawDiscountInput = discountText.replace(',', '.').toDoubleOrNull() ?: 0.0
    val discountPercent = if (discountMode == "percent") {
        rawDiscountInput.coerceIn(0.0, 100.0)
    } else if (subtotal > 0.0) {
        ((rawDiscountInput.coerceIn(0.0, subtotal) / subtotal) * 100.0).coerceIn(0.0, 100.0)
    } else {
        0.0
    }
    val discount = if (discountMode == "percent") {
        (subtotal * discountPercent / 100.0).coerceIn(0.0, subtotal)
    } else {
        rawDiscountInput.coerceIn(0.0, subtotal)
    }
    val finalTotal = (subtotal - discount).coerceAtLeast(0.0)
    val typedPaid = paidText.replace(',', '.').toDoubleOrNull() ?: 0.0
    val paidAmount = when (paymentStatus) {
        "paid" -> finalTotal
        "partial" -> typedPaid.coerceIn(0.0, finalTotal)
        else -> 0.0
    }
    val remaining = (finalTotal - paidAmount).coerceAtLeast(0.0)

    BackHandler(enabled = true) { onDismiss() }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false, dismissOnBackPress = true)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            shape = RoundedCornerShape(26.dp),
            color = Color(0xFFF8FAFC)
        ) {
            LazyColumn(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                contentPadding = PaddingValues(bottom = 6.dp)
            ) {
                item {
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(20.dp),
                        color = Color.White,
                        border = BorderStroke(1.dp, Color(0xFFE2E8F0))
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                modifier = Modifier.weight(1f),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(42.dp)
                                        .clip(RoundedCornerShape(13.dp))
                                        .background(Color(0xFFE0F2FE)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        Icons.Default.ReceiptLong,
                                        contentDescription = null,
                                        tint = Color(0xFF0369A1),
                                        modifier = Modifier.size(22.dp)
                                    )
                                }
                                Spacer(Modifier.width(10.dp))
                                Column {
                                    Text(
                                        "تأكيد طلب التحاليل",
                                        fontWeight = FontWeight.ExtraBold,
                                        fontSize = 19.sp,
                                        color = Color(0xFF17324D)
                                    )
                                    Text(
                                        "${customer.name} • ${customer.fileNumber}",
                                        fontSize = 12.sp,
                                        color = Color(0xFF006D86)
                                    )
                                }
                            }
                            IconButton(onClick = onDismiss) {
                                Icon(Icons.Default.Close, contentDescription = "إغلاق")
                            }
                        }
                    }
                }

                item {
                    Text(
                        "ملخص الحساب",
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 16.sp,
                        color = Color(0xFF17324D)
                    )
                    Spacer(Modifier.height(9.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        FinanceDashboardCard(
                            modifier = Modifier.weight(1f),
                            title = "قبل الخصم",
                            value = "${formatTotalDisplay(subtotal)} ج",
                            subtitle = "${selectedTests.size} تحليل",
                            icon = Icons.Default.ReceiptLong,
                            accent = Color(0xFF0369A1),
                            background = Color(0xFFEFF6FF)
                        )
                        FinanceDashboardCard(
                            modifier = Modifier.weight(1f),
                            title = "بعد الخصم",
                            value = "${formatTotalDisplay(finalTotal)} ج",
                            subtitle = "الإجمالي النهائي",
                            icon = Icons.Default.CheckCircle,
                            accent = Color(0xFF15803D),
                            background = Color(0xFFECFDF3)
                        )
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        FinanceDashboardCard(
                            modifier = Modifier.weight(1f),
                            title = "مبلغ الخصم",
                            value = "${formatTotalDisplay(discount)} ج",
                            subtitle = if (discount > 0.0) "تم تطبيق الخصم" else "بدون خصم",
                            icon = Icons.Default.LocalOffer,
                            accent = Color(0xFFB45309),
                            background = Color(0xFFFFF7ED)
                        )
                        FinanceDashboardCard(
                            modifier = Modifier.weight(1f),
                            title = "نسبة الخصم",
                            value = "${formatDashboardPercent(discountPercent)}%",
                            subtitle = if (discountMode == "percent") "إدخال بالنسبة" else "محسوبة تلقائيًا",
                            icon = Icons.Default.Percent,
                            accent = Color(0xFF7C3AED),
                            background = Color(0xFFF5F3FF)
                        )
                    }
                }

                item {
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(18.dp),
                        color = Color.White,
                        border = BorderStroke(1.dp, Color(0xFFE2E8F0))
                    ) {
                        Column(Modifier.padding(14.dp)) {
                            Text(
                                "طريقة الخصم",
                                fontWeight = FontWeight.ExtraBold,
                                color = Color(0xFF17324D)
                            )
                            Spacer(Modifier.height(9.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Button(
                                    onClick = {
                                        if (discountMode != "amount") {
                                            discountMode = "amount"
                                            discountText = if (discount > 0.0) formatTotalDisplay(discount) else ""
                                        }
                                    },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(12.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (discountMode == "amount") Color(0xFF006D86) else Color(0xFFF1F5F9),
                                        contentColor = if (discountMode == "amount") Color.White else Color(0xFF334155)
                                    )
                                ) {
                                    Icon(Icons.Default.LocalOffer, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text("مبلغ", fontWeight = FontWeight.Bold)
                                }
                                Button(
                                    onClick = {
                                        if (discountMode != "percent") {
                                            discountMode = "percent"
                                            discountText = if (discountPercent > 0.0) formatDashboardPercent(discountPercent) else ""
                                        }
                                    },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(12.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (discountMode == "percent") Color(0xFF7C3AED) else Color(0xFFF1F5F9),
                                        contentColor = if (discountMode == "percent") Color.White else Color(0xFF334155)
                                    )
                                ) {
                                    Icon(Icons.Default.Percent, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text("نسبة %", fontWeight = FontWeight.Bold)
                                }
                            }
                            Spacer(Modifier.height(10.dp))
                            OutlinedTextField(
                                value = discountText,
                                onValueChange = { value ->
                                    val clean = value.filter { it.isDigit() || it == '.' || it == ',' }
                                    discountText = clean.take(10)
                                },
                                modifier = Modifier.fillMaxWidth(),
                                label = {
                                    Text(if (discountMode == "percent") "اكتب نسبة الخصم" else "اكتب مبلغ الخصم")
                                },
                                placeholder = { Text(if (discountMode == "percent") "مثال: 10" else "مثال: 100") },
                                suffix = { Text(if (discountMode == "percent") "%" else "جنيه") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                singleLine = true
                            )
                            if (discount > 0.0) {
                                Spacer(Modifier.height(7.dp))
                                Text(
                                    if (discountMode == "percent") {
                                        "${formatDashboardPercent(discountPercent)}% = ${formatTotalDisplay(discount)} جنيه"
                                    } else {
                                        "${formatTotalDisplay(discount)} جنيه = ${formatDashboardPercent(discountPercent)}%"
                                    },
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF64748B)
                                )
                            }
                        }
                    }
                }

                item {
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(18.dp),
                        color = Color.White,
                        border = BorderStroke(1.dp, Color(0xFFE2E8F0))
                    ) {
                        Column(Modifier.padding(14.dp)) {
                            Text("حالة الدفع", fontWeight = FontWeight.ExtraBold, color = Color(0xFF17324D))
                            Spacer(Modifier.height(9.dp))
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                listOf(
                                    "unpaid" to "غير مدفوع",
                                    "partial" to "جزئي",
                                    "paid" to "مدفوع"
                                ).forEach { (value, label) ->
                                    Button(
                                        onClick = {
                                            paymentStatus = value
                                            if (value != "partial") paidText = ""
                                        },
                                        modifier = Modifier.weight(1f),
                                        shape = RoundedCornerShape(11.dp),
                                        contentPadding = PaddingValues(horizontal = 4.dp, vertical = 9.dp),
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = if (paymentStatus == value) Color(0xFF006D86) else Color(0xFFF1F5F9),
                                            contentColor = if (paymentStatus == value) Color.White else Color(0xFF334155)
                                        )
                                    ) {
                                        Text(label, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                            if (paymentStatus == "partial") {
                                Spacer(Modifier.height(10.dp))
                                OutlinedTextField(
                                    value = paidText,
                                    onValueChange = { value -> paidText = value.filter { it.isDigit() || it == '.' || it == ',' }.take(10) },
                                    modifier = Modifier.fillMaxWidth(),
                                    label = { Text("المبلغ المدفوع") },
                                    suffix = { Text("جنيه") },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                    singleLine = true
                                )
                            }
                        }
                    }
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        FinanceDashboardCard(
                            modifier = Modifier.weight(1f),
                            title = "المدفوع",
                            value = "${formatTotalDisplay(paidAmount)} ج",
                            subtitle = paymentStatusArabic(paymentStatus),
                            icon = Icons.Default.Payments,
                            accent = Color(0xFF15803D),
                            background = Color(0xFFECFDF3)
                        )
                        FinanceDashboardCard(
                            modifier = Modifier.weight(1f),
                            title = "المتبقي",
                            value = "${formatTotalDisplay(remaining)} ج",
                            subtitle = if (remaining > 0.0) "مبلغ مستحق" else "تم السداد",
                            icon = Icons.Default.AccountBalanceWallet,
                            accent = if (remaining > 0.0) Color(0xFFB91C1C) else Color(0xFF15803D),
                            background = if (remaining > 0.0) Color(0xFFFEF2F2) else Color(0xFFECFDF3)
                        )
                    }
                }

                item {
                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it.take(500) },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("ملاحظات الطلب") },
                        placeholder = { Text("اختياري") },
                        minLines = 2,
                        maxLines = 4
                    )
                }

                item {
                    Button(
                        onClick = { onConfirm(discount, discountPercent, paymentStatus, paidAmount, notes, false) },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF006D86))
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null)
                        Spacer(Modifier.width(7.dp))
                        Text("حفظ الطلب", fontWeight = FontWeight.ExtraBold)
                    }
                    Spacer(Modifier.height(8.dp))
                    Button(
                        onClick = { onConfirm(discount, discountPercent, paymentStatus, paidAmount, notes, true) },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF15803D))
                    ) {
                        Icon(Icons.Default.PictureAsPdf, contentDescription = null)
                        Spacer(Modifier.width(7.dp))
                        Text("حفظ ومشاركة PDF", fontWeight = FontWeight.ExtraBold)
                    }
                    TextButton(onClick = onDismiss, modifier = Modifier.fillMaxWidth()) { Text("إلغاء") }
                }
            }
        }
    }
}

@Composable
private fun FinanceDashboardCard(
    modifier: Modifier = Modifier,
    title: String,
    value: String,
    subtitle: String,
    icon: ImageVector,
    accent: Color,
    background: Color
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(17.dp),
        color = background,
        border = BorderStroke(1.dp, accent.copy(alpha = 0.14f))
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(7.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(30.dp)
                        .clip(RoundedCornerShape(9.dp))
                        .background(accent.copy(alpha = 0.12f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = accent,
                        modifier = Modifier.size(17.dp)
                    )
                }
                Spacer(Modifier.width(7.dp))
                Text(
                    title,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF64748B),
                    maxLines = 1
                )
            }
            Text(
                value,
                fontSize = 18.sp,
                fontWeight = FontWeight.ExtraBold,
                color = accent,
                maxLines = 1
            )
            Text(
                subtitle,
                fontSize = 10.sp,
                fontWeight = FontWeight.Medium,
                color = Color(0xFF64748B),
                maxLines = 1
            )
        }
    }
}

private fun formatDashboardPercent(value: Double): String {
    return if (value % 1.0 == 0.0) value.toLong().toString() else String.format("%.1f", value)
}

@Composable
private fun SelectedTestRow(
    test: LabTest,
    customerPrice: String?,
    isManager: Boolean,
    lab2LabPrice: String?,
    onRemove: () -> Unit
) {
    val settings = LocalAppSettings.current
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        color = Color(0xFFF8FAFC),
        border = BorderStroke(1.dp, Color(0xFFE2E8F0))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                if (settings.showEnglishName) {
                    Text(
                        text = test.englishName,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF001D35),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                if (settings.showArabicName && test.arabicName.isNotBlank()) {
                    Text(
                        text = test.arabicName,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        color = Color(0xFF64748B),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                if (settings.showMarketName && test.marketName.isNotBlank() && test.marketName != test.englishName) {
                    Text(
                        text = test.marketName,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        color = Color(0xFF64748B),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            if (settings.showCustomerPrice || (isManager && settings.showLab2LabPrice)) {
                Spacer(modifier = Modifier.width(8.dp))
                Column(horizontalAlignment = Alignment.End) {
                    if (settings.showCustomerPrice) {
                        Text(
                            text = "عميل: ${customerPrice ?: "0"} جنيه",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF004A77)
                        )
                    }
                    if (isManager && settings.showLab2LabPrice) {
                        Text(
                            text = "Lab 2 Lab: ${lab2LabPrice ?: "غير مسجل"}${if (lab2LabPrice.isNullOrBlank()) "" else " جنيه"}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF7C3AED)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.width(8.dp))
            IconButton(
                onClick = onRemove,
                modifier = Modifier
                    .size(28.dp)
                    .testTag("remove_test_${test.id}")
            ) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "إزالة",
                    tint = Color(0xFFE11D48),
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

@Composable
private fun UnmatchedQueriesCard(unmatchedQueries: List<String>) {
    if (unmatchedQueries.isEmpty()) return

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(
                elevation = 2.dp,
                shape = RoundedCornerShape(18.dp),
                spotColor = Color(0x10000000)
            ),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF1F2))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = null,
                    tint = Color(0xFFE11D48),
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "تحاليل غير موجودة",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF9F1239)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                unmatchedQueries.forEach { query ->
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color.White)
                            .padding(horizontal = 12.dp, vertical = 8.dp)
                    ) {
                        Text(
                            text = "• $query",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color(0xFF881337)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun QueryGroupSection(
    group: QueryGroup,
    isManager: Boolean,
    lab2LabPrices: Map<Int, String>,
    customerPriceOverrides: Map<Int, String>,
    onSelectTest: (LabTest) -> Unit,
    onEditPrices: (LabTest) -> Unit
) {
    Column(
        verticalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        if (group.candidates.size > 1) {
            AmbiguousHeaderCard(query = group.query, count = group.candidates.size)
        }
        group.candidates.forEach { test ->
            SearchCandidateCard(
                test = test,
                customerPrice = customerPriceOverrides[test.id] ?: test.customerPrice,
                isManager = isManager,
                lab2LabPrice = lab2LabPrices[test.id],
                onSelect = { onSelectTest(test) },
                onEditPrices = { onEditPrices(test) }
            )
        }
    }
}

@Composable
private fun AmbiguousHeaderCard(query: String, count: Int) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        color = Color(0xFFFFF7ED),
        border = BorderStroke(1.dp, Color(0xFFFFD8A8))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.FilterList,
                contentDescription = null,
                tint = Color(0xFFC2410C),
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "نتائج عدة لـ \"$query\" ($count تحاليل):",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF9A3412)
            )
        }
    }
}

@Composable
private fun SearchCandidateCard(
    test: LabTest,
    customerPrice: String?,
    isManager: Boolean,
    lab2LabPrice: String?,
    onSelect: () -> Unit,
    onEditPrices: () -> Unit
) {
    val settings = LocalAppSettings.current
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(
                elevation = 4.dp,
                shape = RoundedCornerShape(22.dp),
                spotColor = Color(0x14000000)
            ),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, Color(0xFFE5ECF2))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    if (settings.showEnglishName) {
                        Text(
                            text = test.englishName,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFF102A43),
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    if (settings.showArabicName && test.arabicName.isNotBlank()) {
                        if (settings.showEnglishName) Spacer(modifier = Modifier.height(5.dp))
                        Text(
                            text = test.arabicName,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFF52667A),
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    if (!settings.showEnglishName && !settings.showArabicName && test.marketName.isNotBlank()) {
                        Text(
                            text = test.marketName,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = Color(0xFF102A43),
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                Spacer(modifier = Modifier.width(10.dp))

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0xFFF0F4F8))
                        .padding(horizontal = 8.dp, vertical = 5.dp)
                ) {
                    Text(
                        text = "#${test.id}",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF718096)
                    )
                }
            }

            if (settings.showMarketName && test.marketName.isNotBlank() && test.marketName != test.englishName) {
                Spacer(modifier = Modifier.height(9.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "الاسم الدارج",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF7B8794)
                    )
                    Spacer(modifier = Modifier.width(7.dp))
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(9.dp))
                            .background(Color(0xFFF2F7FA))
                            .padding(horizontal = 9.dp, vertical = 5.dp)
                    ) {
                        Text(
                            text = test.marketName,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color(0xFF36536B),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            if (settings.showCustomerPrice || (isManager && settings.showLab2LabPrice)) {
                Spacer(modifier = Modifier.height(14.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (settings.showCustomerPrice) {
                        PriceBox(
                            modifier = Modifier.weight(1f),
                            title = "سعر العميل",
                            price = customerPrice,
                            backgroundColor = Color(0xFFEDF7FF),
                            borderColor = Color(0xFFCFE8F7),
                            titleColor = Color(0xFF28607E),
                            priceColor = Color(0xFF114D6B)
                        )
                    }
                    if (isManager && settings.showLab2LabPrice) {
                        PriceBox(
                            modifier = Modifier.weight(1f),
                            title = "Lab 2 Lab",
                            price = lab2LabPrice,
                            backgroundColor = Color(0xFFF3F0FF),
                            borderColor = Color(0xFFDED7FF),
                            titleColor = Color(0xFF6550A5),
                            priceColor = Color(0xFF513B93)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (isManager) {
                Button(
                    onClick = onEditPrices,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp)
                        .testTag("edit_prices_${test.id}"),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF6D28D9))
                ) {
                    Icon(
                        imageVector = Icons.Default.Edit,
                        contentDescription = null,
                        modifier = Modifier.size(17.dp)
                    )
                    Spacer(modifier = Modifier.width(7.dp))
                    Text(
                        text = "تعديل الأسعار",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
            }

            Button(
                onClick = onSelect,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(46.dp)
                    .testTag("select_test_${test.id}"),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF007E89))
            ) {
                Icon(
                    imageVector = Icons.Default.Check,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(7.dp))
                Text(
                    text = "إضافة إلى القائمة",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
private fun NoResultsSection(unmatchedQueries: List<String>) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(top = 8.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        if (unmatchedQueries.isNotEmpty()) {
            UnmatchedQueriesCard(unmatchedQueries = unmatchedQueries)
        }
        NoResultsView()
    }
}

@Composable
private fun LabTestCard(
    test: LabTest,
    isSelected: Boolean = false
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(
                elevation = if (isSelected) 4.dp else 3.dp,
                shape = RoundedCornerShape(24.dp),
                spotColor = Color(0x12000000)
            ),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) Color(0xFFF8FAFC) else Color.White
        ),
        border = if (isSelected) BorderStroke(2.dp, Color(0xFF0061A4)) else null
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // English Name
            Text(
                text = test.englishName,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF001D35),
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Arabic Name
            Row(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "الاسم العربي: ",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF64748B)
                )
                Text(
                    text = if (test.arabicName.isNotBlank()) test.arabicName else "غير مسجل",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    color = Color(0xFF1E293B)
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Market Name
            Row(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "الاسم الدارج: ",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF64748B)
                )
                Text(
                    text = if (test.marketName.isNotBlank()) test.marketName else "غير مسجل",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    color = Color(0xFF1E293B)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Price Section
            PriceBox(
                modifier = Modifier.fillMaxWidth(),
                title = "سعر العميل",
                price = test.customerPrice,
                backgroundColor = Color(0xFFF0F7FF),
                borderColor = Color(0xFFD0E4FF),
                titleColor = Color(0xFF004A77),
                priceColor = Color(0xFF004A77)
            )
        }
    }
}

@Composable
private fun PriceBox(
    modifier: Modifier = Modifier,
    title: String,
    price: String?,
    backgroundColor: Color,
    borderColor: Color,
    titleColor: Color,
    priceColor: Color
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(backgroundColor)
            .border(1.dp, borderColor, RoundedCornerShape(14.dp))
            .padding(horizontal = 12.dp, vertical = 10.dp)
    ) {
        Column {
            Text(
                text = title,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = titleColor
            )

            Spacer(modifier = Modifier.height(6.dp))

            if (!price.isNullOrBlank()) {
                Row(
                    verticalAlignment = Alignment.Bottom,
                    horizontalArrangement = Arrangement.Start
                ) {
                    Text(
                        text = price,
                        fontSize = 19.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = priceColor
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "جنيه",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = priceColor,
                        modifier = Modifier.padding(bottom = 2.dp)
                    )
                }
            } else {
                Text(
                    text = "غير مسجل",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF94A3B8)
                )
            }
        }
    }
}

@Composable
private fun EmptyStateView() {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 6.dp),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, Color(0xFFE6EDF3))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp, vertical = 34.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(72.dp)
                    .clip(RoundedCornerShape(22.dp))
                    .background(Color(0xFFE7F5F7)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Outlined.Biotech,
                    contentDescription = null,
                    tint = Color(0xFF007E89),
                    modifier = Modifier.size(36.dp)
                )
            }

            Spacer(modifier = Modifier.height(18.dp))

            Text(
                text = "ابدأ بكتابة اسم التحليل",
                fontSize = 19.sp,
                fontWeight = FontWeight.ExtraBold,
                color = Color(0xFF17324D),
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(7.dp))

            Text(
                text = "البحث يدعم العربي والإنجليزي والاسم المتداول في المعامل",
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium,
                color = Color(0xFF718096),
                textAlign = TextAlign.Center,
                lineHeight = 19.sp
            )
        }
    }
}

@Composable
private fun NoResultsView() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(80.dp)
                .clip(CircleShape)
                .background(Color(0xFFFEE2E2)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Outlined.SearchOff,
                contentDescription = null,
                tint = Color(0xFFDC2626),
                modifier = Modifier.size(40.dp)
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        Text(
            text = "لم يتم العثور على التحليل",
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF001D35),
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = "جرّب البحث باسم مختلف أو بالاسم الإنجليزي",
            fontSize = 14.sp,
            fontWeight = FontWeight.Medium,
            color = Color(0xFF64748B),
            textAlign = TextAlign.Center
        )
    }
}


private fun paymentStatusArabic(status: String): String = when (status) {
    "paid" -> "مدفوع"
    "partial" -> "جزئي"
    else -> "غير مدفوع"
}
