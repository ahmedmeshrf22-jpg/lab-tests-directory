package com.example.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun DeviceAuthorizationScreen(
    status: String,
    onRefresh: () -> Unit,
    onLogout: () -> Unit
) {
    val rejected = status == "rejected" || status == "revoked"
    val error = status == "error"

    Column(
        modifier = Modifier.fillMaxSize().padding(28.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(
            imageVector = if (rejected) Icons.Default.Block else Icons.Default.AdminPanelSettings,
            contentDescription = null,
            tint = if (rejected || error) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
        )
        Spacer(Modifier.height(16.dp))
        Text(
            text = when {
                rejected -> "الجهاز غير مصرح به"
                error -> "تعذر التحقق من الجهاز"
                else -> "في انتظار موافقة المدير"
            },
            fontSize = 23.sp,
            fontWeight = FontWeight.ExtraBold,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(10.dp))
        Text(
            text = when {
                status == "revoked" -> "تم إلغاء اعتماد هذا الجهاز. اطلب من المدير إعادة اعتماده لو هتستخدمه مرة تانية."
                status == "rejected" -> "تم رفض طلب هذا الجهاز. تواصل مع المدير لو محتاج السماح له بالدخول."
                error -> "تأكد من الإنترنت ومن نشر Firestore Rules الخاصة بتصريح الأجهزة، ثم حاول مرة أخرى."
                else -> "تم تسجيل الجهاز. المدير يقدر يعتمد الجهاز من: الإدارة ← الأجهزة المصرح بها."
            },
            textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(22.dp))
        Button(onClick = onRefresh, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Default.Refresh, contentDescription = null)
            Text("إعادة التحقق", modifier = Modifier.padding(start = 8.dp))
        }
        Spacer(Modifier.height(8.dp))
        OutlinedButton(onClick = onLogout, modifier = Modifier.fillMaxWidth()) {
            Text("تسجيل الخروج")
        }
    }
}
