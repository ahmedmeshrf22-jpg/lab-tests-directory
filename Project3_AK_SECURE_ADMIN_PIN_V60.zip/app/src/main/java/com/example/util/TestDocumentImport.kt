package com.example.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.max
import kotlin.math.roundToInt
import java.io.File
import java.io.FileOutputStream

/**
 * V40: OCR helper for extracting printed Latin lab-test names/abbreviations from
 * an image or a PDF selected on the same device. PDF pages are rendered locally
 * then passed through the bundled ML Kit Latin text recognizer.
 */
object TestDocumentImport {

    private const val MAX_PDF_PAGES = 20
    private const val MAX_RENDER_EDGE = 2000

    suspend fun readText(context: Context, uri: Uri): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            try {
                val validated = SecureFileGuard.validate(context, uri).getOrThrow()
                val text = when (validated.kind) {
                    SecureFileGuard.FileKind.PDF -> readPdf(context, uri, recognizer)
                    SecureFileGuard.FileKind.IMAGE -> readImage(context, uri, recognizer)
                }
                text.trim().takeIf { it.isNotBlank() }
                    ?: error("لم يتم التعرف على نص واضح. جرّب صورة أوضح ومباشرة للورقة")
            } finally {
                recognizer.close()
            }
        }
    }

    private fun readImage(context: Context, uri: Uri, recognizer: TextRecognizer): String {
        val bitmap = SecureFileGuard.decodeImageSafely(context, uri)

        return try {
            recognizeBitmapBestRotation(recognizer, bitmap)
        } finally {
            bitmap.recycle()
        }
    }

    private fun readPdf(context: Context, uri: Uri, recognizer: TextRecognizer): String {
        val validated = SecureFileGuard.requireKind(context, uri, SecureFileGuard.FileKind.PDF)

        // PdfRenderer needs a seekable file descriptor. Documents coming from Google Drive,
        // WhatsApp, Files providers, etc. may expose a pipe/non-seekable descriptor even though
        // the PDF opens normally elsewhere. Copy the already-validated PDF to our private cache
        // first so PdfRenderer always receives a local seekable descriptor.
        val tempPdf = File.createTempFile("lab_tests_import_", ".pdf", context.cacheDir)
        try {
            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(tempPdf).use { output ->
                    val buffer = ByteArray(32 * 1024)
                    var total = 0L
                    while (true) {
                        val read = input.read(buffer)
                        if (read < 0) break
                        total += read
                        require(total <= validated.sizeBytes + 64 * 1024L) {
                            "حجم ملف PDF تغير أثناء القراءة. أعد اختيار الملف"
                        }
                        output.write(buffer, 0, read)
                    }
                    output.flush()
                    require(total > 0L) { "ملف PDF فارغ" }
                }
            } ?: error("تعذر فتح ملف PDF")

            val descriptor = ParcelFileDescriptor.open(tempPdf, ParcelFileDescriptor.MODE_READ_ONLY)
            val collected = StringBuilder()
            try {
                descriptor.use { pfd ->
                    PdfRenderer(pfd).use { renderer ->
                        require(renderer.pageCount > 0) { "ملف PDF بدون صفحات" }
                        val count = minOf(renderer.pageCount, MAX_PDF_PAGES)
                        for (pageIndex in 0 until count) {
                            renderer.openPage(pageIndex).use { page ->
                                val scale = minOf(
                                    MAX_RENDER_EDGE.toFloat() / max(1, page.width),
                                    MAX_RENDER_EDGE.toFloat() / max(1, page.height),
                                    2.5f
                                ).coerceIn(0.5f, 2.5f)

                                val width = max(1, (page.width * scale).roundToInt())
                                val height = max(1, (page.height * scale).roundToInt())
                                val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                                try {
                                    bitmap.eraseColor(android.graphics.Color.WHITE)
                                    page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                                    val pageText = recognizeBitmapBestRotation(recognizer, bitmap).trim()
                                    if (pageText.isNotBlank()) {
                                        if (collected.isNotEmpty()) collected.append('\n')
                                        collected.append(pageText)
                                    }
                                } finally {
                                    bitmap.recycle()
                                }
                            }
                        }
                    }
                }
            } catch (e: SecurityException) {
                error("ملف PDF محمي بكلمة مرور أو لا يسمح بقراءته")
            } catch (e: IllegalArgumentException) {
                error("ملف PDF غير صالح أو مشفر بطريقة غير مدعومة")
            }
            return collected.toString()
        } finally {
            runCatching { tempPdf.delete() }
        }
    }

    private fun recognizeBitmap(recognizer: TextRecognizer, bitmap: Bitmap, rotationDegrees: Int = 0): String {
        val image = InputImage.fromBitmap(bitmap, rotationDegrees)
        return Tasks.await(recognizer.process(image)).text.orEmpty()
    }

    /**
     * Phone photos may be stored with orientation metadata instead of physically rotated pixels.
     * ML Kit receives the decoded bitmap, so try the common rotations and keep the strongest OCR result.
     */
    private fun recognizeBitmapBestRotation(recognizer: TextRecognizer, bitmap: Bitmap): String {
        val rotations = intArrayOf(0, 90, 270, 180)
        var best = ""
        var bestScore = -1
        for (rotation in rotations) {
            val text = recognizeBitmap(recognizer, bitmap, rotation)
            val score = text.count { it.isLetterOrDigit() }
            if (score > bestScore) {
                best = text
                bestScore = score
            }
            // A strong first-pass result avoids four OCR passes for normal upright images.
            if (rotation == 0 && score >= 24) break
        }
        return best
    }
}
