package com.example.util

import android.content.ContentResolver
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.OpenableColumns
import java.io.InputStream
import kotlin.math.max

/**
 * V45 defense-in-depth gate for every external image/PDF consumed by the app.
 * The app never executes imported files; it only accepts bounded content:// streams,
 * verifies the real file signature, and decodes images with memory limits.
 */
object SecureFileGuard {

    enum class FileKind { IMAGE, PDF }

    data class ValidatedInput(
        val kind: FileKind,
        val detectedMime: String,
        val sizeBytes: Long
    )

    private const val MAX_IMAGE_BYTES = 20L * 1024L * 1024L
    private const val MAX_PDF_BYTES = 30L * 1024L * 1024L
    private const val MAX_IMAGE_EDGE = 4096
    private const val MAX_IMAGE_PIXELS = 12_000_000L
    private const val MAX_DECLARED_NAME_LENGTH = 180

    private val imageMimeTypes = setOf(
        "image/jpeg",
        "image/jpg",
        "image/png",
        "image/webp"
    )

    fun validate(context: Context, uri: Uri): Result<ValidatedInput> = runCatching {
        require(uri.scheme == ContentResolver.SCHEME_CONTENT) {
            "لأمان التطبيق، مسموح فقط بالملفات المختارة من الجهاز أو التطبيقات الموثوقة"
        }

        val resolver = context.contentResolver
        val declaredMime = resolver.getType(uri)
            ?.substringBefore(';')
            ?.trim()
            ?.lowercase()
            .orEmpty()

        val displayName = queryDisplayName(resolver, uri)
        require(displayName.length <= MAX_DECLARED_NAME_LENGTH) { "اسم الملف غير صالح" }

        val header = resolver.openInputStream(uri)?.use { input -> readHeader(input, 16) }
            ?: error("تعذر فتح الملف")

        val detected = detectKind(header) ?: error("نوع الملف غير مدعوم أو محتوى الملف غير صالح")
        val detectedMime = when (detected) {
            FileKind.PDF -> "application/pdf"
            FileKind.IMAGE -> detectImageMime(header)
                ?: error("صيغة الصورة غير مدعومة. استخدم JPG أو PNG أو WEBP")
        }

        if (declaredMime.isNotBlank() && declaredMime != "application/octet-stream") {
            val declaredKind = when {
                declaredMime == "application/pdf" -> FileKind.PDF
                declaredMime in imageMimeTypes -> FileKind.IMAGE
                else -> null
            }
            require(declaredKind != null && declaredKind == detected) {
                "امتداد أو نوع الملف لا يطابق محتواه الحقيقي"
            }
        }

        val maxBytes = if (detected == FileKind.PDF) MAX_PDF_BYTES else MAX_IMAGE_BYTES
        val size = resolveSize(resolver, uri, maxBytes)
        require(size in 1..maxBytes) {
            if (detected == FileKind.PDF) {
                "ملف PDF أكبر من الحد الآمن (30 MB)"
            } else {
                "الصورة أكبر من الحد الآمن (20 MB)"
            }
        }

        ValidatedInput(detected, detectedMime, size)
    }

    fun requireKind(context: Context, uri: Uri, expected: FileKind): ValidatedInput {
        val validated = validate(context, uri).getOrThrow()
        require(validated.kind == expected) {
            if (expected == FileKind.PDF) "الملف المختار ليس PDF صالحًا" else "الملف المختار ليس صورة صالحة"
        }
        return validated
    }

    fun decodeImageSafely(context: Context, uri: Uri): Bitmap {
        requireKind(context, uri, FileKind.IMAGE)
        val resolver = context.contentResolver

        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            ?: error("تعذر فتح الصورة")

        val width = bounds.outWidth
        val height = bounds.outHeight
        require(width > 0 && height > 0) { "الصورة غير صالحة" }
        require(width <= 100_000 && height <= 100_000) { "أبعاد الصورة غير آمنة" }

        var sample = 1
        while (
            max(1, width / sample) > MAX_IMAGE_EDGE ||
            max(1, height / sample) > MAX_IMAGE_EDGE ||
            (width.toLong() / sample) * (height.toLong() / sample) > MAX_IMAGE_PIXELS
        ) {
            sample *= 2
            require(sample <= 128) { "أبعاد الصورة كبيرة جدًا" }
        }

        val options = BitmapFactory.Options().apply {
            inSampleSize = sample
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }

        val bitmap = resolver.openInputStream(uri)?.use { input ->
            BitmapFactory.decodeStream(input, null, options)
        } ?: error("تعذر قراءة الصورة")

        require(bitmap.width.toLong() * bitmap.height.toLong() <= MAX_IMAGE_PIXELS * 2L) {
            bitmap.recycle()
            "الصورة تحتاج ذاكرة أكبر من الحد الآمن"
        }

        return bitmap
    }

    private fun queryDisplayName(resolver: ContentResolver, uri: Uri): String {
        return runCatching {
            resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) cursor.getString(0).orEmpty() else ""
            }.orEmpty()
        }.getOrDefault("")
    }

    private fun resolveSize(resolver: ContentResolver, uri: Uri, limit: Long): Long {
        val fromCursor = runCatching {
            resolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use { cursor ->
                if (cursor.moveToFirst() && !cursor.isNull(0)) cursor.getLong(0) else -1L
            } ?: -1L
        }.getOrDefault(-1L)
        if (fromCursor >= 0L) return fromCursor

        val fromDescriptor = runCatching {
            resolver.openAssetFileDescriptor(uri, "r")?.use { it.length } ?: -1L
        }.getOrDefault(-1L)
        if (fromDescriptor >= 0L) return fromDescriptor

        // Some content providers do not expose a size. Count only up to the security limit.
        return resolver.openInputStream(uri)?.use { input ->
            val buffer = ByteArray(16 * 1024)
            var total = 0L
            while (true) {
                val read = input.read(buffer)
                if (read < 0) break
                total += read
                if (total > limit) return@use total
            }
            total
        } ?: -1L
    }

    private fun readHeader(input: InputStream, count: Int): ByteArray {
        val bytes = ByteArray(count)
        var offset = 0
        while (offset < count) {
            val read = input.read(bytes, offset, count - offset)
            if (read <= 0) break
            offset += read
        }
        return bytes.copyOf(offset)
    }

    private fun detectKind(header: ByteArray): FileKind? {
        if (header.size >= 5 && header.copyOfRange(0, 5).toString(Charsets.US_ASCII) == "%PDF-") {
            return FileKind.PDF
        }
        return if (detectImageMime(header) != null) FileKind.IMAGE else null
    }

    private fun detectImageMime(header: ByteArray): String? {
        if (header.size >= 3 &&
            header[0] == 0xFF.toByte() && header[1] == 0xD8.toByte() && header[2] == 0xFF.toByte()
        ) return "image/jpeg"

        if (header.size >= 8 &&
            header[0] == 0x89.toByte() && header[1] == 0x50.toByte() &&
            header[2] == 0x4E.toByte() && header[3] == 0x47.toByte() &&
            header[4] == 0x0D.toByte() && header[5] == 0x0A.toByte() &&
            header[6] == 0x1A.toByte() && header[7] == 0x0A.toByte()
        ) return "image/png"

        if (header.size >= 12 &&
            header.copyOfRange(0, 4).toString(Charsets.US_ASCII) == "RIFF" &&
            header.copyOfRange(8, 12).toString(Charsets.US_ASCII) == "WEBP"
        ) return "image/webp"

        return null
    }
}
