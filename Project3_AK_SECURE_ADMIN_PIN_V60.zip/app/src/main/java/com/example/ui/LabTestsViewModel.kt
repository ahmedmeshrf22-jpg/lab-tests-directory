package com.example.ui

import android.os.SystemClock

import android.app.Application
import android.content.Context
import android.os.Build
import android.provider.Settings
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.AppUserProfile
import com.example.data.model.AuditLogEntry
import com.example.data.model.AuthorizedDevice
import com.example.data.model.Customer
import com.example.data.model.CustomerActivityEntry
import com.example.data.model.CustomerOrder
import com.example.data.model.CustomerOrderItem
import com.example.data.model.LabTest
import com.example.data.model.PaymentEntry
import com.example.data.model.ReportSummary
import com.example.data.model.normalizeText
import com.example.data.repository.LabTestRepository
import com.example.settings.AppSettings
import com.example.settings.AppSettingsStore
import com.example.settings.ConnectivityMonitor
import com.example.settings.FirestorePerformance
import com.example.settings.PendingSyncStore
import com.example.settings.tr
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.appcheck.FirebaseAppCheck
import com.google.firebase.appcheck.playintegrity.PlayIntegrityAppCheckProviderFactory
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.SetOptions
import com.google.firebase.firestore.Source
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import org.json.JSONArray
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale


data class QueryGroup(
    val query: String,
    val candidates: List<LabTest>
)

sealed interface SearchUiState {
    object EmptyQuery : SearchUiState
    data class Success(
        val query: String,
        val queryGroups: List<QueryGroup>,
        val unmatchedQueries: List<String> = emptyList()
    ) : SearchUiState
    data class NoResults(
        val unmatchedQueries: List<String> = emptyList()
    ) : SearchUiState
}

data class SystemHealthState(
    val checking: Boolean = false,
    val firebaseReachable: Boolean? = null,
    val latencyMs: Long? = null,
    val checkedAtMillis: Long = 0L,
    val message: String = ""
)

data class AdminAlert(
    val id: String,
    val category: String,
    val titleAr: String,
    val titleEn: String,
    val detailsAr: String,
    val detailsEn: String,
    val severity: String = "info", // info | warning | critical
    val createdAtMillis: Long = 0L,
    val actorEmail: String = "",
    val isRead: Boolean = false
)

/** V32 manager-facing integrity finding. No data is deleted automatically. */
data class DataIntegrityIssue(
    val id: String,
    val type: String,
    val titleAr: String,
    val titleEn: String,
    val detailsAr: String,
    val detailsEn: String,
    val severity: String = "warning",
    val entityId: String = "",
    val documentPath: String = ""
)

data class DataIntegrityState(
    val checking: Boolean = false,
    val checkedAtMillis: Long = 0L,
    val customersScanned: Int = 0,
    val ordersScanned: Int = 0,
    val issueCount: Int = 0,
    val criticalCount: Int = 0,
    val message: String = ""
)

class LabTestsViewModel(application: Application) : AndroidViewModel(application) {

    companion object {
        const val MANAGER_EMAIL = "abdelrahman@tahali.com"
        private const val MANAGER_UID = "Wps5Y19pZSbeGooEzFfW5UFsshq2"
        private const val LAB2LAB_COLLECTION = "lab2lab_prices"
        private const val CUSTOMER_OVERRIDES_COLLECTION = "customer_price_overrides"
        private const val CUSTOMERS_COLLECTION = "customers"
        private const val USERS_COLLECTION = "users"
        private const val DEVICES_SUBCOLLECTION = "devices"
        private const val AUDIT_COLLECTION = "audit_logs"
        private const val PHONE_REGISTRY_COLLECTION = "phone_registry"
        private const val SECONDARY_AUTH_APP = "TahalilUserAdmin"
        private const val ADMIN_UNLOCK_APP = "TahalilAdminUnlock"
        private const val ADMIN_GATE_EMAIL = "tahalil.admin.gate.v60@tahali.com"
        private const val ADMIN_PIN_SALT = "TahalilAlakkad.AdminGate.v60.2026"
        private const val ADMIN_PIN_ROUNDS = 40_000
        private const val ADMIN_PIN_VERIFIER = "26178327d4bc89aa7fab9b53a968cb22a18771620398bd14c2a4b2f1f51afd1b"
        private const val SERVER_PAGE_SIZE = 750L
        private const val CUSTOMER_ACTIVITY_LIMIT = 150L
        private const val CUSTOMER_ORDERS_LIMIT = 500L
        private const val PAYMENT_HISTORY_LIMIT = 250L
        private const val AUDIT_LOG_LIMIT = 400L
        private const val HIGH_ACTIVITY_ALERT_COUNT = 20
        private const val LARGE_DEBT_ALERT = 5_000.0
        private const val CRITICAL_DEBT_ALERT = 20_000.0
        private const val INTEGRITY_ORDER_SCAN_LIMIT = 1_500L
        private const val CONFLICT_WINDOW_MS = 120_000L

        fun isManagerAccount(email: String?, uid: String? = null): Boolean {
            val normalizedEmail = email?.trim()?.lowercase()
            return normalizedEmail == MANAGER_EMAIL || uid == MANAGER_UID
        }
    }

    private val repository = LabTestRepository(application)
    private val settingsStore = AppSettingsStore(application)
    private val connectivityMonitor = ConnectivityMonitor(application)
    private val pendingSyncStore = PendingSyncStore(application)

    val appSettings: StateFlow<AppSettings> = settingsStore.settings

    // V29 centralizes Firestore tuning: persistent local cache, larger cache budget,
    // and one shared instance. This keeps reads responsive while preserving V28 offline writes.
    private val firestore: FirebaseFirestore = FirestorePerformance.get()

    private val _isOnline = MutableStateFlow(connectivityMonitor.isOnline.value)
    val isOnline: StateFlow<Boolean> = _isOnline.asStateFlow()

    val pendingSyncCount: StateFlow<Int> = pendingSyncStore.count

    private val _lastSuccessfulSyncMillis = MutableStateFlow(settingsStore.settings.value.lastSyncMillis)
    val lastSuccessfulSyncMillis: StateFlow<Long> = _lastSuccessfulSyncMillis.asStateFlow()

    private val _systemHealth = MutableStateFlow(SystemHealthState())
    val systemHealth: StateFlow<SystemHealthState> = _systemHealth.asStateFlow()

    private val adminAlertPrefs = application.getSharedPreferences("admin_alerts_v31", Context.MODE_PRIVATE)
    // V33: keep Abdulrahman's temporary user-mode selection across normal app closes/reopens.
    // This is local-only UI session state; Firebase Auth remains signed in as the manager.
    private val switchSessionPrefs = application.getSharedPreferences("manager_switch_session_v33", Context.MODE_PRIVATE)
    private val _adminAlerts = MutableStateFlow<List<AdminAlert>>(emptyList())
    val adminAlerts: StateFlow<List<AdminAlert>> = _adminAlerts.asStateFlow()
    private val _unreadAdminAlertCount = MutableStateFlow(0)
    val unreadAdminAlertCount: StateFlow<Int> = _unreadAdminAlertCount.asStateFlow()

    private val _dataIntegrityState = MutableStateFlow(DataIntegrityState())
    val dataIntegrityState: StateFlow<DataIntegrityState> = _dataIntegrityState.asStateFlow()
    private val _dataIntegrityIssues = MutableStateFlow<List<DataIntegrityIssue>>(emptyList())
    val dataIntegrityIssues: StateFlow<List<DataIntegrityIssue>> = _dataIntegrityIssues.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    // V39: holds one image/PDF shared to the app until the authenticated UI consumes it.
    private val _pendingSharedQrUri = MutableStateFlow<String?>(null)
    val pendingSharedQrUri: StateFlow<String?> = _pendingSharedQrUri.asStateFlow()

    fun queueSharedQrUri(uri: String) {
        if (uri.isNotBlank()) _pendingSharedQrUri.value = uri
    }

    fun consumeSharedQrUri(uri: String) {
        if (_pendingSharedQrUri.value == uri) _pendingSharedQrUri.value = null
    }

    private val _uiState = MutableStateFlow<SearchUiState>(SearchUiState.EmptyQuery)
    val uiState: StateFlow<SearchUiState> = _uiState.asStateFlow()

    private val _selectedTests = MutableStateFlow<List<LabTest>>(emptyList())
    val selectedTests: StateFlow<List<LabTest>> = _selectedTests.asStateFlow()

    private val _isManager = MutableStateFlow(false)
    val isManager: StateFlow<Boolean> = _isManager.asStateFlow()

    // V60: every account uses the same UI. Sensitive administration is unlocked
    // with a six-digit admin PIN. The PIN is never stored as plaintext: the app
    // validates a slow SHA-256 verifier, then signs a secondary Firebase admin-gate
    // account in with a strong password deterministically derived from that PIN.
    private val _adminUnlocked = MutableStateFlow(false)
    val adminUnlocked: StateFlow<Boolean> = _adminUnlocked.asStateFlow()
    private var adminFirebaseApp: FirebaseApp? = null
    private var adminFirestore: FirebaseFirestore? = null
    private var adminPinFailedAttempts = 0
    private var adminPinLockedUntilElapsed = 0L

    private fun hasAdminAccess(): Boolean = _actualManager.value || _adminUnlocked.value

    private fun privilegedFirestore(): FirebaseFirestore =
        if (_actualManager.value) firestore
        else adminFirestore ?: error("Admin access is not unlocked")

    private fun adminPinDigest(pin: String, purpose: String): String {
        var bytes = "$purpose|$ADMIN_PIN_SALT|$pin".toByteArray(Charsets.UTF_8)
        val digest = MessageDigest.getInstance("SHA-256")
        repeat(ADMIN_PIN_ROUNDS) { bytes = digest.digest(bytes) }
        return bytes.joinToString("") { "%02x".format(it) }
    }

    private fun derivedAdminFirebasePassword(pin: String): String =
        "Aa1!" + adminPinDigest(pin, "firebase").take(48)

    private fun completeAdminUnlock(
        app: FirebaseApp,
        auth: FirebaseAuth,
        onResult: (Boolean, String) -> Unit
    ) {
        val email = auth.currentUser?.email?.trim()?.lowercase()
        if (email != ADMIN_GATE_EMAIL) {
            auth.signOut()
            _adminUnlocked.value = false
            onResult(false, tr("تعذر التحقق من حساب الإدارة", "Unable to verify the admin account"))
            return
        }
        adminFirebaseApp = app
        val candidateFirestore = FirebaseFirestore.getInstance(app)
        // Do not show an unlocked admin UI until Firestore confirms that the
        // secondary admin identity is actually authorized by the deployed rules.
        candidateFirestore.collection(LAB2LAB_COLLECTION)
            .limit(1)
            .get(Source.SERVER)
            .addOnSuccessListener {
                adminFirestore = candidateFirestore
                _adminUnlocked.value = true
                loadManagerPriceState()
                onResult(true, tr("تم فتح خدمات الإدارة", "Administration unlocked"))
            }
            .addOnFailureListener {
                auth.signOut()
                adminFirestore = null
                _adminUnlocked.value = false
                onResult(
                    false,
                    tr(
                        "PIN صحيح لكن صلاحيات Firebase للإدارة لم يتم تفعيلها بعد",
                        "PIN is correct, but Firebase admin permissions are not active yet"
                    )
                )
            }
    }

    fun unlockAdmin(pin: String, onResult: (Boolean, String) -> Unit) {
        val cleanPin = pin.trim()
        val nowElapsed = SystemClock.elapsedRealtime()
        if (nowElapsed < adminPinLockedUntilElapsed) {
            val seconds = ((adminPinLockedUntilElapsed - nowElapsed + 999L) / 1000L).coerceAtLeast(1L)
            onResult(false, tr("محاولات كثيرة. حاول بعد $seconds ثانية", "Too many attempts. Try again in $seconds seconds"))
            return
        }
        if (cleanPin.length != 6 || cleanPin.any { !it.isDigit() }) {
            onResult(false, tr("اكتب PIN الإدارة المكون من 6 أرقام", "Enter the 6-digit admin PIN"))
            return
        }

        viewModelScope.launch {
            val verifiedAndPassword = kotlinx.coroutines.withContext(Dispatchers.Default) {
                val ok = MessageDigest.isEqual(
                    adminPinDigest(cleanPin, "verify").toByteArray(Charsets.UTF_8),
                    ADMIN_PIN_VERIFIER.toByteArray(Charsets.UTF_8)
                )
                ok to if (ok) derivedAdminFirebasePassword(cleanPin) else ""
            }
            if (!verifiedAndPassword.first) {
                _adminUnlocked.value = false
                adminPinFailedAttempts += 1
                if (adminPinFailedAttempts >= 5) {
                    adminPinFailedAttempts = 0
                    adminPinLockedUntilElapsed = SystemClock.elapsedRealtime() + 60_000L
                    onResult(false, tr("محاولات كثيرة. تم إيقاف PIN لمدة دقيقة", "Too many attempts. PIN is locked for one minute"))
                } else {
                    val left = 5 - adminPinFailedAttempts
                    onResult(false, tr("PIN الإدارة غير صحيح. متبقي $left محاولات", "Incorrect admin PIN. $left attempts remaining"))
                }
                return@launch
            }
            adminPinFailedAttempts = 0
            adminPinLockedUntilElapsed = 0L

            val app = try {
                FirebaseApp.getInstance(ADMIN_UNLOCK_APP)
            } catch (_: IllegalStateException) {
                FirebaseApp.initializeApp(
                    getApplication<Application>(),
                    FirebaseApp.getInstance().options,
                    ADMIN_UNLOCK_APP
                ) ?: run {
                    onResult(false, tr("تعذر تجهيز دخول الإدارة", "Unable to initialize admin access"))
                    return@launch
                }
            }
            adminFirebaseApp = app
            try {
                FirebaseAppCheck.getInstance(app).installAppCheckProviderFactory(
                    PlayIntegrityAppCheckProviderFactory.getInstance()
                )
            } catch (_: Exception) {
                // App Check may already be configured for this secondary app.
            }

            val auth = FirebaseAuth.getInstance(app)
            val firebasePassword = verifiedAndPassword.second
            auth.signInWithEmailAndPassword(ADMIN_GATE_EMAIL, firebasePassword)
                .addOnSuccessListener { completeAdminUnlock(app, auth, onResult) }
                .addOnFailureListener {
                    // First V60 unlock bootstraps the dedicated admin-gate account.
                    // If it already exists, Firebase rejects create and no privilege is granted.
                    auth.createUserWithEmailAndPassword(ADMIN_GATE_EMAIL, firebasePassword)
                        .addOnSuccessListener { completeAdminUnlock(app, auth, onResult) }
                        .addOnFailureListener {
                            _adminUnlocked.value = false
                            adminFirestore = null
                            onResult(
                                false,
                                tr(
                                    "تعذر فتح الإدارة. تأكد من الإنترنت وإعداد Firebase.",
                                    "Unable to unlock administration. Check internet and Firebase setup."
                                )
                            )
                        }
                }
        }
    }

    fun lockAdmin() {
        try { adminFirebaseApp?.let { FirebaseAuth.getInstance(it).signOut() } } catch (_: Exception) {}
        _adminUnlocked.value = false
        adminFirestore = null
        // PIN sessions belong to staff. The real manager remains authorized by the
        // primary Firebase account, so backgrounding must not wipe manager-only data.
        if (!_actualManager.value) {
            _lab2LabPrices.value = emptyMap()
            managerPricesLoaded = false
        }
    }

    // The authenticated account can remain Abdulrahman while the UI temporarily
    // operates with another user's permissions. This never changes Firebase Auth.
    private val _actualManager = MutableStateFlow(false)
    val actualManager: StateFlow<Boolean> = _actualManager.asStateFlow()

    private val _actingAsUser = MutableStateFlow<AppUserProfile?>(null)
    val actingAsUser: StateFlow<AppUserProfile?> = _actingAsUser.asStateFlow()

    /** null = checking, true = enabled, false = disabled by manager. */
    private val _accountEnabled = MutableStateFlow<Boolean?>(null)
    val accountEnabled: StateFlow<Boolean?> = _accountEnabled.asStateFlow()

    private val _currentUserProfile = MutableStateFlow<AppUserProfile?>(null)
    val currentUserProfile: StateFlow<AppUserProfile?> = _currentUserProfile.asStateFlow()

    /** checking / pending / approved / rejected / revoked / error */
    private val _deviceAccessStatus = MutableStateFlow("checking")
    val deviceAccessStatus: StateFlow<String> = _deviceAccessStatus.asStateFlow()

    private val _authorizedDevices = MutableStateFlow<List<AuthorizedDevice>>(emptyList())
    val authorizedDevices: StateFlow<List<AuthorizedDevice>> = _authorizedDevices.asStateFlow()

    private val _lab2LabPrices = MutableStateFlow<Map<Int, String>>(emptyMap())
    val lab2LabPrices: StateFlow<Map<Int, String>> = _lab2LabPrices.asStateFlow()

    private val _customerPriceOverrides = MutableStateFlow<Map<Int, String>>(emptyMap())
    val customerPriceOverrides: StateFlow<Map<Int, String>> = _customerPriceOverrides.asStateFlow()

    private val _customers = MutableStateFlow<List<Customer>>(emptyList())
    val customers: StateFlow<List<Customer>> = _customers.asStateFlow()

    private val _customersLoading = MutableStateFlow(false)
    val customersLoading: StateFlow<Boolean> = _customersLoading.asStateFlow()

    private val _customerOrders = MutableStateFlow<List<CustomerOrder>>(emptyList())
    val customerOrders: StateFlow<List<CustomerOrder>> = _customerOrders.asStateFlow()

    private val _customerActivity = MutableStateFlow<List<CustomerActivityEntry>>(emptyList())
    val customerActivity: StateFlow<List<CustomerActivityEntry>> = _customerActivity.asStateFlow()

    private val _paymentHistory = MutableStateFlow<List<PaymentEntry>>(emptyList())
    val paymentHistory: StateFlow<List<PaymentEntry>> = _paymentHistory.asStateFlow()

    private val _reportOrders = MutableStateFlow<List<CustomerOrder>>(emptyList())
    val reportOrders: StateFlow<List<CustomerOrder>> = _reportOrders.asStateFlow()

    private val _reportsLoading = MutableStateFlow(false)
    val reportsLoading: StateFlow<Boolean> = _reportsLoading.asStateFlow()

    private val _managerHomeSummary = MutableStateFlow(ReportSummary())
    val managerHomeSummary: StateFlow<ReportSummary> = _managerHomeSummary.asStateFlow()

    private val _managerHomeLoading = MutableStateFlow(false)
    val managerHomeLoading: StateFlow<Boolean> = _managerHomeLoading.asStateFlow()

    private val _auditLogs = MutableStateFlow<List<AuditLogEntry>>(emptyList())
    val auditLogs: StateFlow<List<AuditLogEntry>> = _auditLogs.asStateFlow()

    private val _users = MutableStateFlow<List<AppUserProfile>>(emptyList())
    val users: StateFlow<List<AppUserProfile>> = _users.asStateFlow()

    private val _systemMessage = MutableStateFlow<String?>(null)
    val systemMessage: StateFlow<String?> = _systemMessage.asStateFlow()

    private var managerPricesLoaded = false
    private var customerOverridesLoaded = false
    private var profileListener: ListenerRegistration? = null
    private var deviceAccessListener: ListenerRegistration? = null
    private var deviceRequestInFlight = false
    private var lastAuthUid: String? = null
    private var authenticatedEmail: String = ""
    private var authenticatedUid: String = ""
    private val pendingOfflineAuditKeys = mutableSetOf<String>()

    init {
        viewModelScope.launch(Dispatchers.IO) { repository.getLabTests() }
        viewModelScope.launch {
            connectivityMonitor.isOnline.collectLatest { online ->
                _isOnline.value = online
                if (online && pendingSyncStore.count.value > 0) {
                    firestore.waitForPendingWrites()
                        .addOnSuccessListener {
                            pendingSyncStore.clearAll()
                            val syncedAt = System.currentTimeMillis()
                            _lastSuccessfulSyncMillis.value = syncedAt
                            settingsStore.markSynced(syncedAt)
                            rebuildAdminAlerts()
                        }
                }
                rebuildAdminAlerts()
            }
        }
    }

    /** V30: manager-facing client health probe for connectivity, Firestore reachability and latency. */
    fun refreshSystemHealth() {
        if (!hasAdminAccess()) return

        val checkedAt = System.currentTimeMillis()
        if (!_isOnline.value) {
            _systemHealth.value = SystemHealthState(
                checking = false,
                firebaseReachable = false,
                latencyMs = null,
                checkedAtMillis = checkedAt,
                message = tr("الجهاز غير متصل بالإنترنت", "Device is offline")
            )
            rebuildAdminAlerts()
            return
        }

        _systemHealth.value = SystemHealthState(
            checking = true,
            firebaseReachable = null,
            latencyMs = null,
            checkedAtMillis = checkedAt,
            message = tr("جار فحص Firebase...", "Checking Firebase...")
        )

        val startedAt = SystemClock.elapsedRealtime()
        privilegedFirestore().collection("users")
            .document(MANAGER_UID)
            .get(Source.SERVER)
            .addOnSuccessListener {
                val latency = (SystemClock.elapsedRealtime() - startedAt).coerceAtLeast(0L)
                _systemHealth.value = SystemHealthState(
                    checking = false,
                    firebaseReachable = true,
                    latencyMs = latency,
                    checkedAtMillis = System.currentTimeMillis(),
                    message = tr("Firebase متصل ويستجيب", "Firebase is reachable")
                )
                rebuildAdminAlerts()
            }
            .addOnFailureListener { error ->
                _systemHealth.value = SystemHealthState(
                    checking = false,
                    firebaseReachable = false,
                    latencyMs = null,
                    checkedAtMillis = System.currentTimeMillis(),
                    message = error.localizedMessage?.take(120)
                        ?: tr("تعذر الوصول إلى Firebase", "Could not reach Firebase")
                )
                rebuildAdminAlerts()
            }
    }

    /** V32: scans server/local data for duplicates, arithmetic drift and conflict candidates. */
    fun refreshDataIntegrity() {
        if (!hasAdminAccess()) return
        if (_dataIntegrityState.value.checking) return

        _dataIntegrityState.value = DataIntegrityState(
            checking = true,
            message = tr("جار فحص سلامة البيانات...", "Checking data integrity...")
        )

        fun scanOrders(customersSnapshot: List<Customer>) {
            privilegedFirestore().collectionGroup("orders")
                .limit(INTEGRITY_ORDER_SCAN_LIMIT)
                .get(if (_isOnline.value) Source.SERVER else Source.CACHE)
                .addOnSuccessListener { snapshot ->
                    val issues = mutableListOf<DataIntegrityIssue>()

                    val phoneOwners = mutableMapOf<String, MutableList<Customer>>()
                    customersSnapshot.filterNot { it.isArchived }.forEach { customer ->
                        listOf(normalizePhone(customer.phone), normalizePhone(customer.alternatePhone))
                            .filter { it.isNotBlank() }
                            .distinct()
                            .forEach { phone -> phoneOwners.getOrPut(phone) { mutableListOf() } += customer }
                    }
                    phoneOwners.filterValues { it.map(Customer::id).distinct().size > 1 }.forEach { (phone, owners) ->
                        val names = owners.distinctBy { it.id }.joinToString(" • ") { "${it.name} (${it.fileNumber})" }
                        issues += DataIntegrityIssue(
                            id = "duplicate_phone_$phone",
                            type = "duplicate_customer",
                            titleAr = "رقم موبايل مكرر",
                            titleEn = "Duplicate customer phone",
                            detailsAr = "$phone مسجل لأكثر من عميل: $names",
                            detailsEn = "$phone is linked to more than one customer: $names",
                            severity = "critical"
                        )
                    }

                    val orderNumbers = mutableMapOf<String, MutableList<String>>()
                    val operationIds = mutableMapOf<String, MutableList<String>>()
                    snapshot.documents.forEach { doc ->
                        val orderNumber = doc.getString("order_number").orEmpty()
                        val customerId = doc.getString("customer_id").orEmpty()
                        val operationId = doc.getString("operation_id").orEmpty()
                        if (orderNumber.isNotBlank()) orderNumbers.getOrPut(orderNumber) { mutableListOf() } += doc.id
                        if (operationId.isNotBlank()) operationIds.getOrPut(operationId) { mutableListOf() } += doc.id

                        if (orderNumber.isBlank() || customerId.isBlank()) {
                            issues += DataIntegrityIssue(
                                id = "missing_identity_${doc.id}",
                                type = "missing_identity",
                                titleAr = "طلب ناقص البيانات الأساسية",
                                titleEn = "Order missing core identifiers",
                                detailsAr = "الطلب ${orderNumber.ifBlank { doc.id }} ناقص رقم الطلب أو معرف العميل.",
                                detailsEn = "Order ${orderNumber.ifBlank { doc.id }} is missing an order number or customer id.",
                                severity = "critical",
                                entityId = doc.id,
                                documentPath = doc.reference.path
                            )
                        }

                        val subtotal = numberAsDouble(doc.get("subtotal_customer_price"))
                        val discount = numberAsDouble(doc.get("discount_amount"))
                        val total = numberAsDouble(doc.get("total_customer_price"))
                        val paid = numberAsDouble(doc.get("paid_amount"))
                        val remaining = numberAsDouble(doc.get("remaining_amount"))
                        val expectedTotal = (subtotal - discount).coerceAtLeast(0.0)
                        val moneyMismatch = kotlin.math.abs(expectedTotal - total) > 0.02 ||
                            kotlin.math.abs((paid + remaining) - total) > 0.02 || paid < -0.001 || remaining < -0.001
                        if (moneyMismatch) {
                            issues += DataIntegrityIssue(
                                id = "money_${doc.id}",
                                type = "financial_mismatch",
                                titleAr = "عدم تطابق حسابات طلب",
                                titleEn = "Order totals mismatch",
                                detailsAr = "${orderNumber.ifBlank { doc.id }} • قبل الخصم ${formatNumber(subtotal)} • الخصم ${formatNumber(discount)} • الإجمالي ${formatNumber(total)} • المدفوع ${formatNumber(paid)} • المتبقي ${formatNumber(remaining)}",
                                detailsEn = "${orderNumber.ifBlank { doc.id }} • subtotal ${formatNumber(subtotal)} • discount ${formatNumber(discount)} • total ${formatNumber(total)} • paid ${formatNumber(paid)} • remaining ${formatNumber(remaining)}",
                                severity = "critical",
                                entityId = doc.id,
                                documentPath = doc.reference.path
                            )
                        }

                        val status = doc.getString("payment_status").orEmpty()
                        val expectedStatus = when {
                            remaining <= 0.01 && total > 0.0 -> "paid"
                            paid > 0.01 -> "partial"
                            else -> "unpaid"
                        }
                        if (status.isNotBlank() && status != expectedStatus) {
                            issues += DataIntegrityIssue(
                                id = "payment_status_${doc.id}",
                                type = "payment_status",
                                titleAr = "حالة دفع غير متطابقة",
                                titleEn = "Payment status mismatch",
                                detailsAr = "${orderNumber.ifBlank { doc.id }} حالته $status بينما الأرقام تشير إلى $expectedStatus.",
                                detailsEn = "${orderNumber.ifBlank { doc.id }} is marked $status while its amounts indicate $expectedStatus.",
                                severity = "warning",
                                entityId = doc.id,
                                documentPath = doc.reference.path
                            )
                        }
                    }

                    orderNumbers.filterValues { it.distinct().size > 1 }.forEach { (number, ids) ->
                        issues += DataIntegrityIssue(
                            id = "duplicate_order_$number",
                            type = "duplicate_order",
                            titleAr = "رقم طلب مكرر",
                            titleEn = "Duplicate order number",
                            detailsAr = "رقم الطلب $number موجود في ${ids.distinct().size} سجلات.",
                            detailsEn = "Order number $number exists in ${ids.distinct().size} records.",
                            severity = "critical"
                        )
                    }
                    operationIds.filterValues { it.distinct().size > 1 }.forEach { (operationId, ids) ->
                        issues += DataIntegrityIssue(
                            id = "duplicate_operation_$operationId",
                            type = "duplicate_operation",
                            titleAr = "معرف عملية مكرر",
                            titleEn = "Duplicate operation id",
                            detailsAr = "Operation ID $operationId ظهر في ${ids.distinct().size} طلبات.",
                            detailsEn = "Operation ID $operationId appears in ${ids.distinct().size} orders.",
                            severity = "critical"
                        )
                    }

                    // Detect two different users updating the same customer in a short time window.
                    val updateLogs = _auditLogs.value
                        .filter { it.action.startsWith("customer_update") && it.customerId.isNotBlank() }
                        .groupBy { it.customerId }
                    updateLogs.forEach { (customerId, logs) ->
                        logs.sortedBy { it.createdAtMillis }.zipWithNext().forEach { (a, b) ->
                            if (a.actorUid != b.actorUid && b.createdAtMillis - a.createdAtMillis in 0..CONFLICT_WINDOW_MS) {
                                issues += DataIntegrityIssue(
                                    id = "conflict_${customerId}_${b.createdAtMillis}",
                                    type = "edit_conflict",
                                    titleAr = "تعارض تعديل محتمل",
                                    titleEn = "Possible edit conflict",
                                    detailsAr = "تم تعديل نفس العميل بواسطة ${a.actorEmail} ثم ${b.actorEmail} خلال أقل من دقيقتين. راجع سجل المراجعة.",
                                    detailsEn = "The same customer was edited by ${a.actorEmail} then ${b.actorEmail} within two minutes. Review the audit log.",
                                    severity = "warning",
                                    entityId = customerId
                                )
                            }
                        }
                    }

                    val sortedIssues = issues.distinctBy { it.id }.sortedWith(
                        compareBy<DataIntegrityIssue> { if (it.severity == "critical") 0 else 1 }.thenBy { it.type }
                    )
                    _dataIntegrityIssues.value = sortedIssues
                    _dataIntegrityState.value = DataIntegrityState(
                        checking = false,
                        checkedAtMillis = System.currentTimeMillis(),
                        customersScanned = customersSnapshot.size,
                        ordersScanned = snapshot.documents.size,
                        issueCount = sortedIssues.size,
                        criticalCount = sortedIssues.count { it.severity == "critical" },
                        message = if (sortedIssues.isEmpty())
                            tr("لم يتم اكتشاف مشاكل في البيانات المفحوصة", "No issues were found in the scanned data")
                        else tr("تم اكتشاف ${sortedIssues.size} ملاحظة تحتاج مراجعة", "${sortedIssues.size} finding(s) need review")
                    )
                    rebuildAdminAlerts()
                }
                .addOnFailureListener { error ->
                    _dataIntegrityState.value = DataIntegrityState(
                        checking = false,
                        checkedAtMillis = System.currentTimeMillis(),
                        customersScanned = customersSnapshot.size,
                        message = error.localizedMessage?.take(140)
                            ?: tr("تعذر فحص الطلبات", "Unable to scan orders")
                    )
                }
        }

        // Ensure the conflict detector has recent audit data, then scan customers/orders.
        loadAuditLogs { _, _ ->
            if (_customers.value.isEmpty() && _isOnline.value) {
                loadCustomers { _, _ -> scanOrders(_customers.value) }
            } else {
                scanOrders(_customers.value)
            }
        }
    }

    /** V32 safe repair: recalculates order totals/status only; never deletes customer/order data. */
    fun repairIntegrityIssue(issue: DataIntegrityIssue, onResult: (Boolean, String) -> Unit) {
        if (!hasAdminAccess()) {
            onResult(false, tr("الإصلاح متاح للمدير فقط", "Repair is manager only"))
            return
        }
        if (issue.documentPath.isBlank() || issue.type !in setOf("financial_mismatch", "payment_status")) {
            onResult(false, tr("هذه الملاحظة تحتاج مراجعة يدوية", "This finding requires manual review"))
            return
        }
        val ref = privilegedFirestore().document(issue.documentPath)
        ref.get(Source.SERVER)
            .addOnSuccessListener { doc ->
                if (!doc.exists()) {
                    onResult(false, tr("السجل لم يعد موجودا", "Record no longer exists"))
                    return@addOnSuccessListener
                }
                val subtotal = numberAsDouble(doc.get("subtotal_customer_price")).coerceAtLeast(0.0)
                val discount = numberAsDouble(doc.get("discount_amount")).coerceIn(0.0, subtotal)
                val total = (subtotal - discount).coerceAtLeast(0.0)
                val paid = numberAsDouble(doc.get("paid_amount")).coerceIn(0.0, total)
                val remaining = (total - paid).coerceAtLeast(0.0)
                val status = when {
                    remaining <= 0.01 && total > 0.0 -> "paid"
                    paid > 0.01 -> "partial"
                    else -> "unpaid"
                }
                ref.set(
                    mapOf(
                        "discount_amount" to discount,
                        "discount_percent" to if (subtotal > 0.0) discount / subtotal * 100.0 else 0.0,
                        "total_customer_price" to total,
                        "paid_amount" to paid,
                        "remaining_amount" to remaining,
                        "payment_status" to status,
                        "updated_at_ms" to System.currentTimeMillis(),
                        "updated_at" to FieldValue.serverTimestamp(),
                        "updated_by_uid" to currentUid(),
                        "updated_by_email" to currentEmail(),
                        "integrity_repaired" to true
                    ),
                    SetOptions.merge()
                ).addOnSuccessListener {
                    logAudit(
                        "integrity_repair",
                        "order",
                        issue.entityId,
                        "Data Integrity Repair",
                        "Recalculated totals and payment status without deleting data.",
                        orderId = issue.entityId
                    )
                    onResult(true, tr("تم الإصلاح الآمن وإعادة حساب الأرقام", "Safe repair completed and totals recalculated"))
                    refreshDataIntegrity()
                }.addOnFailureListener {
                    onResult(false, tr("تعذر حفظ الإصلاح", "Could not save repair"))
                }
            }
            .addOnFailureListener {
                onResult(false, tr("تعذر تحميل السجل من السيرفر", "Could not load the record from server"))
            }
    }

    /** V31: manager alert center derived from existing audit/device/health/debt data.
     *  Read state stays local to the manager device, so no new Firestore collection or rules are required. */
    fun refreshAdminAlerts() {
        if (!hasAdminAccess()) return
        rebuildAdminAlerts()
        if (_isOnline.value) {
            refreshSystemHealth()
            loadAuthorizedDevices { _, _ -> rebuildAdminAlerts() }
            loadAuditLogs { _, _ -> rebuildAdminAlerts() }
            loadManagerHomeSummary { _, _ -> rebuildAdminAlerts() }
        }
    }

    fun markAdminAlertRead(alertId: String) {
        if (alertId.isBlank()) return
        val readIds = adminAlertPrefs.getStringSet("read_ids", emptySet()).orEmpty().toMutableSet()
        readIds += alertId
        adminAlertPrefs.edit().putStringSet("read_ids", readIds).apply()
        rebuildAdminAlerts()
    }

    fun markAllAdminAlertsRead() {
        val readIds = adminAlertPrefs.getStringSet("read_ids", emptySet()).orEmpty().toMutableSet()
        readIds += _adminAlerts.value.map { it.id }
        adminAlertPrefs.edit().putStringSet("read_ids", readIds).apply()
        rebuildAdminAlerts()
    }

    private fun rebuildAdminAlerts() {
        if (!hasAdminAccess()) {
            _adminAlerts.value = emptyList()
            _unreadAdminAlertCount.value = 0
            return
        }

        val now = System.currentTimeMillis()
        val readIds = adminAlertPrefs.getStringSet("read_ids", emptySet()).orEmpty()
        val alerts = mutableListOf<AdminAlert>()

        if (!_isOnline.value) {
            alerts += AdminAlert(
                id = "system_offline_${now / 3_600_000L}",
                category = "system",
                titleAr = "التطبيق يعمل بدون إنترنت",
                titleEn = "App is working offline",
                detailsAr = "العمليات الجديدة ستظل معلقة حتى عودة الاتصال ثم تتم مزامنتها تلقائيا.",
                detailsEn = "New operations will remain pending until connectivity returns, then sync automatically.",
                severity = "critical",
                createdAtMillis = now
            )
        }

        val pending = pendingSyncStore.count.value
        if (pending > 0) {
            alerts += AdminAlert(
                id = "pending_sync_${now / 3_600_000L}",
                category = "sync",
                titleAr = "عمليات في انتظار المزامنة",
                titleEn = "Operations waiting to sync",
                detailsAr = "يوجد $pending عملية لم تصل للسيرفر بعد.",
                detailsEn = "$pending operation(s) have not reached the server yet.",
                severity = if (pending >= 10) "critical" else "warning",
                createdAtMillis = now
            )
        }

        val integrity = _dataIntegrityState.value
        if (!integrity.checking && integrity.criticalCount > 0) {
            alerts += AdminAlert(
                id = "integrity_${integrity.checkedAtMillis}",
                category = "integrity",
                titleAr = "مشاكل في سلامة البيانات",
                titleEn = "Data integrity issues detected",
                detailsAr = "تم اكتشاف ${integrity.criticalCount} مشكلة مهمة من إجمالي ${integrity.issueCount} ملاحظة. افتح Data Integrity للمراجعة.",
                detailsEn = "${integrity.criticalCount} critical issue(s) were found out of ${integrity.issueCount} finding(s). Open Data Integrity for review.",
                severity = "critical",
                createdAtMillis = integrity.checkedAtMillis
            )
        }

        val health = _systemHealth.value
        if (health.firebaseReachable == false && _isOnline.value) {
            alerts += AdminAlert(
                id = "firebase_unreachable_${health.checkedAtMillis / 3_600_000L}",
                category = "system",
                titleAr = "تعذر الوصول إلى Firebase",
                titleEn = "Firebase is unreachable",
                detailsAr = health.message.ifBlank { "اتصال الإنترنت موجود لكن Firebase لم يستجب للفحص." },
                detailsEn = health.message.ifBlank { "Internet is available but Firebase did not respond to the health check." },
                severity = "critical",
                createdAtMillis = health.checkedAtMillis.takeIf { it > 0L } ?: now
            )
        } else if ((health.latencyMs ?: 0L) >= 1_200L) {
            alerts += AdminAlert(
                id = "firebase_slow_${health.checkedAtMillis / 3_600_000L}",
                category = "performance",
                titleAr = "استجابة Firebase بطيئة",
                titleEn = "Firebase response is slow",
                detailsAr = "زمن الاستجابة الحالي ${health.latencyMs} ms.",
                detailsEn = "Current response latency is ${health.latencyMs} ms.",
                severity = "warning",
                createdAtMillis = health.checkedAtMillis.takeIf { it > 0L } ?: now
            )
        }

        _authorizedDevices.value.filter { it.status == "pending" }.forEach { device ->
            alerts += AdminAlert(
                id = "device_pending_${device.uid}_${device.id}",
                category = "device",
                titleAr = "جهاز جديد ينتظر الموافقة",
                titleEn = "New device waiting for approval",
                detailsAr = "${device.email.ifBlank { device.uid }} • ${device.manufacturer} ${device.model}",
                detailsEn = "${device.email.ifBlank { device.uid }} • ${device.manufacturer} ${device.model}",
                severity = "critical",
                createdAtMillis = device.requestedAtMillis.takeIf { it > 0L } ?: now,
                actorEmail = device.email
            )
        }

        val recentCutoff = now - 7L * 24L * 60L * 60L * 1000L
        _auditLogs.value.filter { it.createdAtMillis >= recentCutoff }.forEach { log ->
            if (log.wasOffline) {
                alerts += AdminAlert(
                    id = "offline_audit_${log.id}",
                    category = "sync",
                    titleAr = "عملية تمت بدون إنترنت وتمت مزامنتها",
                    titleEn = "Offline operation synchronized",
                    detailsAr = "${log.title} • ${log.actorEmail}",
                    detailsEn = "${log.title} • ${log.actorEmail}",
                    severity = "info",
                    createdAtMillis = log.syncedAtMillis.takeIf { it > 0L } ?: log.createdAtMillis,
                    actorEmail = log.actorEmail
                )
            }

            val importantAction = log.action.contains("blacklist", true) ||
                log.action.contains("archive", true) ||
                log.action.contains("void", true) ||
                log.action.contains("revoked", true) ||
                log.action.contains("rejected", true) ||
                log.action.contains("disabled", true)
            if (importantAction) {
                alerts += AdminAlert(
                    id = "important_audit_${log.id}",
                    category = "audit",
                    titleAr = "عملية إدارية مهمة: ${log.title}",
                    titleEn = "Important admin action: ${log.title}",
                    detailsAr = log.details.ifBlank { log.actorEmail },
                    detailsEn = log.details.ifBlank { log.actorEmail },
                    severity = "critical",
                    createdAtMillis = log.createdAtMillis,
                    actorEmail = log.actorEmail
                )
            }
        }

        val oneHourAgo = now - 60L * 60L * 1000L
        _auditLogs.value
            .filter { it.createdAtMillis >= oneHourAgo && it.actorEmail.isNotBlank() }
            .groupBy { it.actorEmail.lowercase() }
            .filterValues { it.size >= HIGH_ACTIVITY_ALERT_COUNT }
            .forEach { (actor, logs) ->
                alerts += AdminAlert(
                    id = "high_activity_${actor.hashCode()}_${now / 3_600_000L}",
                    category = "activity",
                    titleAr = "نشاط مرتفع لمستخدم",
                    titleEn = "High user activity",
                    detailsAr = "$actor نفذ ${logs.size} عملية خلال آخر ساعة.",
                    detailsEn = "$actor performed ${logs.size} operations in the last hour.",
                    severity = "warning",
                    createdAtMillis = logs.maxOfOrNull { it.createdAtMillis } ?: now,
                    actorEmail = actor
                )
            }

        val debt = _managerHomeSummary.value.remaining
        if (debt >= LARGE_DEBT_ALERT) {
            alerts += AdminAlert(
                id = "debt_${(debt / 1000.0).toInt()}_${now / 86_400_000L}",
                category = "debt",
                titleAr = "إجمالي مديونيات يحتاج متابعة",
                titleEn = "Outstanding debt needs attention",
                detailsAr = "إجمالي المبالغ المتبقية حاليا ${"%.2f".format(Locale.US, debt)} EGP.",
                detailsEn = "Current outstanding balance is ${"%.2f".format(Locale.US, debt)} EGP.",
                severity = if (debt >= CRITICAL_DEBT_ALERT) "critical" else "warning",
                createdAtMillis = now
            )
        }

        val finalAlerts = alerts
            .distinctBy { it.id }
            .map { it.copy(isRead = readIds.contains(it.id)) }
            .sortedWith(
                compareBy<AdminAlert> { it.isRead }
                    .thenBy { if (it.severity == "critical") 0 else if (it.severity == "warning") 1 else 2 }
                    .thenByDescending { it.createdAtMillis }
            )

        _adminAlerts.value = finalAlerts
        _unreadAdminAlertCount.value = finalAlerts.count { !it.isRead }
    }

    override fun onCleared() {
        lockAdmin()
        profileListener?.remove()
        deviceAccessListener?.remove()
        connectivityMonitor.close()
        super.onCleared()
    }

    /** Called whenever Firebase Auth user changes. */
    fun onAuthenticatedUserChanged(email: String?, uid: String? = null) {
        settingsStore.setActiveProfile(uid ?: email?.trim()?.lowercase())

        if (email.isNullOrBlank() && uid.isNullOrBlank()) {
            // Explicit Firebase logout clears the remembered acting-user session.
            clearPersistedActingUser()
            lastAuthUid = null
            authenticatedEmail = ""
            authenticatedUid = ""
            profileListener?.remove()
            profileListener = null
            deviceAccessListener?.remove()
            deviceAccessListener = null
            deviceRequestInFlight = false
            _deviceAccessStatus.value = "checking"
            _authorizedDevices.value = emptyList()
            _adminAlerts.value = emptyList()
            _unreadAdminAlertCount.value = 0
            lockAdmin()
            _actualManager.value = false
            _actingAsUser.value = null
            _isManager.value = false
            _accountEnabled.value = null
            _currentUserProfile.value = null
            _customers.value = emptyList()
            _customerOrders.value = emptyList()
            _lab2LabPrices.value = emptyMap()
            managerPricesLoaded = false
            return
        }

        val cleanEmail = email.orEmpty().trim().lowercase()
        val cleanUid = uid.orEmpty()
        val identityChanged = authenticatedUid != cleanUid || authenticatedEmail != cleanEmail
        authenticatedEmail = cleanEmail
        authenticatedUid = cleanUid

        val manager = isManagerAccount(email, uid)
        _actualManager.value = manager

        if (identityChanged) {
            lockAdmin()
            _actingAsUser.value = null
        }

        if (manager) {
            // The real manager keeps the same unified UI, but administration opens
            // directly from the already-authenticated manager account without a PIN.
            clearPersistedActingUser()
            _actingAsUser.value = null
            _isManager.value = false
            _currentUserProfile.value = managerProfile()
            _accountEnabled.value = true
            clearManagerPriceCache()
            ensureManagerProfile(email, uid)
            if (uid.isNullOrBlank()) {
                _deviceAccessStatus.value = "error"
                return
            }
            attachDeviceAuthorization(email.orEmpty(), uid)
            loadAfterAccessGranted()
            loadManagerPriceState()
            return
        }

        _actingAsUser.value = null
        clearPersistedActingUser()
        _isManager.value = false
        clearManagerPriceCache()
        if (uid.isNullOrBlank()) {
            _deviceAccessStatus.value = "error"
            _accountEnabled.value = true
            return
        }
        attachDeviceAuthorization(email.orEmpty(), uid)

        if (lastAuthUid != uid) {
            _accountEnabled.value = null
            lastAuthUid = uid
            attachUserProfileListener(email.orEmpty(), uid)
        }
    }

    private fun currentDeviceId(): String {
        val raw = Settings.Secure.getString(
            getApplication<Application>().contentResolver,
            Settings.Secure.ANDROID_ID
        ).orEmpty().ifBlank { "unknown-android-id" }
        val material = "$raw|${getApplication<Application>().packageName}"
        return MessageDigest.getInstance("SHA-256")
            .digest(material.toByteArray())
            .joinToString("") { "%02x".format(it) }
            .take(32)
    }

    private fun attachDeviceAuthorization(email: String, uid: String) {
        deviceAccessListener?.remove()
        deviceRequestInFlight = false
        _deviceAccessStatus.value = "checking"

        val deviceId = currentDeviceId()
        val ref = firestore.collection(USERS_COLLECTION)
            .document(uid)
            .collection(DEVICES_SUBCOLLECTION)
            .document(deviceId)

        deviceAccessListener = ref.addSnapshotListener { snapshot, error ->
            if (error != null) {
                _deviceAccessStatus.value = "error"
                return@addSnapshotListener
            }

            if (snapshot == null || !snapshot.exists()) {
                if (!deviceRequestInFlight) {
                    deviceRequestInFlight = true
                    val now = System.currentTimeMillis()
                    val data = mapOf(
                        "uid" to uid,
                        "email" to email.trim().lowercase(),
                        "device_id" to deviceId,
                        "manufacturer" to Build.MANUFACTURER.orEmpty(),
                        "model" to Build.MODEL.orEmpty(),
                        "android_version" to Build.VERSION.RELEASE.orEmpty(),
                        "status" to "pending",
                        "requested_at_ms" to now,
                        "requested_at" to FieldValue.serverTimestamp(),
                        "updated_at_ms" to now,
                        "updated_at" to FieldValue.serverTimestamp()
                    )
                    ref.set(data)
                        .addOnFailureListener {
                            deviceRequestInFlight = false
                            _deviceAccessStatus.value = "error"
                        }
                }
                return@addSnapshotListener
            }

            deviceRequestInFlight = false
            _deviceAccessStatus.value = snapshot.getString("status") ?: "pending"
        }
    }

    fun recheckDeviceAuthorization() {
        if (authenticatedUid.isBlank()) {
            _deviceAccessStatus.value = "error"
            return
        }
        attachDeviceAuthorization(authenticatedEmail, authenticatedUid)
    }

    fun approveCurrentDeviceWithAdminPin(
        pin: String,
        onResult: (Boolean, String) -> Unit
    ) {
        if (authenticatedUid.isBlank()) {
            onResult(false, tr("تعذر تحديد المستخدم الحالي", "Unable to identify the current user"))
            return
        }
        unlockAdmin(pin) { unlocked, message ->
            if (!unlocked) {
                onResult(false, message)
                return@unlockAdmin
            }
            val now = System.currentTimeMillis()
            val deviceId = currentDeviceId()
            val ref = privilegedFirestore().collection(USERS_COLLECTION)
                .document(authenticatedUid)
                .collection(DEVICES_SUBCOLLECTION)
                .document(deviceId)

            ref.get(Source.SERVER)
                .addOnSuccessListener { snapshot ->
                    if (!snapshot.exists()) {
                        lockAdmin()
                        onResult(false, tr("اضغط إعادة التحقق أولا ثم حاول اعتماد الجهاز", "Check again first, then approve the device"))
                        return@addOnSuccessListener
                    }
                    ref.set(
                        mapOf(
                            "status" to "approved",
                            "approved_at_ms" to now,
                            "approved_at" to FieldValue.serverTimestamp(),
                            "approved_by_uid" to MANAGER_UID,
                            "updated_at_ms" to now,
                            "updated_at" to FieldValue.serverTimestamp()
                        ),
                        SetOptions.merge()
                    ).addOnSuccessListener {
                        lockAdmin()
                        attachDeviceAuthorization(authenticatedEmail, authenticatedUid)
                        onResult(true, tr("تم اعتماد الجهاز", "Device approved"))
                    }.addOnFailureListener {
                        lockAdmin()
                        onResult(false, tr("تعذر اعتماد الجهاز", "Unable to approve device"))
                    }
                }
                .addOnFailureListener {
                    lockAdmin()
                    onResult(false, tr("تعذر قراءة طلب الجهاز", "Unable to read the device request"))
                }
        }
    }

    fun loadAuthorizedDevices(onResult: ((Boolean, String) -> Unit)? = null) {
        if (!hasAdminAccess()) {
            onResult?.invoke(false, tr("الإجراء متاح للمدير فقط", "Manager only action"))
            return
        }
        privilegedFirestore().collectionGroup(DEVICES_SUBCOLLECTION)
            .get(Source.SERVER)
            .addOnSuccessListener { snapshot ->
                val list = snapshot.documents.mapNotNull { doc ->
                    val uid = doc.reference.parent.parent?.id ?: return@mapNotNull null
                    AuthorizedDevice(
                        id = doc.id,
                        uid = uid,
                        email = doc.getString("email").orEmpty(),
                        manufacturer = doc.getString("manufacturer").orEmpty(),
                        model = doc.getString("model").orEmpty(),
                        status = doc.getString("status") ?: "pending",
                        requestedAtMillis = doc.getLong("requested_at_ms") ?: 0L,
                        approvedAtMillis = doc.getLong("approved_at_ms") ?: 0L,
                        approvedByUid = doc.getString("approved_by_uid").orEmpty()
                    )
                }.sortedWith(
                    compareBy<AuthorizedDevice> {
                        when (it.status) {
                            "pending" -> 0
                            "approved" -> 1
                            else -> 2
                        }
                    }.thenByDescending { it.requestedAtMillis }
                )
                _authorizedDevices.value = list
                rebuildAdminAlerts()
                onResult?.invoke(true, tr("تم تحديث الأجهزة", "Devices refreshed"))
            }
            .addOnFailureListener {
                onResult?.invoke(false, tr("تعذر تحميل الأجهزة. تأكد من Firestore Rules والإنترنت", "Unable to load devices"))
            }
    }

    fun approveDevice(device: AuthorizedDevice, onResult: (Boolean, String) -> Unit) {
        if (!hasAdminAccess()) {
            onResult(false, tr("الإجراء متاح للمدير فقط", "Manager only action"))
            return
        }
        val devicesRef = privilegedFirestore().collection(USERS_COLLECTION)
            .document(device.uid)
            .collection(DEVICES_SUBCOLLECTION)

        devicesRef.get(Source.SERVER)
            .addOnSuccessListener { snapshot ->
                val now = System.currentTimeMillis()
                privilegedFirestore().runBatch { batch ->
                    snapshot.documents.forEach { doc ->
                        if (doc.id != device.id && doc.getString("status") == "approved") {
                            batch.update(
                                doc.reference,
                                mapOf(
                                    "status" to "revoked",
                                    "updated_at_ms" to now,
                                    "updated_at" to FieldValue.serverTimestamp(),
                                    "revoked_by_uid" to authenticatedUid
                                )
                            )
                        }
                    }
                    batch.set(
                        devicesRef.document(device.id),
                        mapOf(
                            "status" to "approved",
                            "approved_at_ms" to now,
                            "approved_at" to FieldValue.serverTimestamp(),
                            "approved_by_uid" to authenticatedUid,
                            "updated_at_ms" to now,
                            "updated_at" to FieldValue.serverTimestamp()
                        ),
                        SetOptions.merge()
                    )
                }.addOnSuccessListener {
                    logAudit(
                        action = "device_approved",
                        entityType = "device",
                        entityId = device.id,
                        title = "اعتماد جهاز مستخدم",
                        details = "${device.email} • ${device.manufacturer} ${device.model}"
                    )
                    loadAuthorizedDevices()
                    onResult(true, "تم اعتماد الجهاز وإلغاء أي جهاز قديم لنفس المستخدم")
                }.addOnFailureListener {
                    onResult(false, tr("تعذر اعتماد الجهاز", "Unable to approve device"))
                }
            }
            .addOnFailureListener {
                onResult(false, "تعذر قراءة أجهزة المستخدم")
            }
    }

    fun setDeviceStatus(device: AuthorizedDevice, status: String, onResult: (Boolean, String) -> Unit) {
        if (!hasAdminAccess()) {
            onResult(false, tr("الإجراء متاح للمدير فقط", "Manager only action"))
            return
        }
        val safeStatus = if (status in setOf("rejected", "revoked")) status else "revoked"
        val now = System.currentTimeMillis()
        privilegedFirestore().collection(USERS_COLLECTION)
            .document(device.uid)
            .collection(DEVICES_SUBCOLLECTION)
            .document(device.id)
            .set(
                mapOf(
                    "status" to safeStatus,
                    "updated_at_ms" to now,
                    "updated_at" to FieldValue.serverTimestamp(),
                    "updated_by_uid" to authenticatedUid
                ),
                SetOptions.merge()
            )
            .addOnSuccessListener {
                logAudit(
                    action = "device_$safeStatus",
                    entityType = "device",
                    entityId = device.id,
                    title = if (safeStatus == "rejected") "رفض جهاز" else "إلغاء اعتماد جهاز",
                    details = "${device.email} • ${device.manufacturer} ${device.model}"
                )
                loadAuthorizedDevices()
                onResult(
                    true,
                    if (safeStatus == "rejected") "تم رفض الجهاز" else "تم إلغاء اعتماد الجهاز"
                )
            }
            .addOnFailureListener {
                onResult(false, tr("تعذر تحديث حالة الجهاز", "Unable to update device status"))
            }
    }

    private fun persistActingUser(profile: AppUserProfile) {
        switchSessionPrefs.edit()
            .putString("owner_uid", authenticatedUid)
            .putString("uid", profile.uid)
            .putString("email", profile.email)
            .putString("display_name", profile.displayName)
            .putString("role", profile.role)
            .putBoolean("enabled", profile.enabled)
            .putBoolean("can_edit_customers", profile.canEditCustomers)
            .putBoolean("can_discount", profile.canDiscount)
            .putBoolean("can_collect_payments", profile.canCollectPayments)
            .putBoolean("can_view_sales_reports", profile.canViewSalesReports)
            .putLong("created_at_ms", profile.createdAtMillis)
            .putLong("updated_at_ms", profile.updatedAtMillis)
            .putLong("pin_reset_requested_at_ms", profile.pinResetRequestedAtMillis)
            .apply()
    }

    private fun restorePersistedActingUser(): AppUserProfile? {
        val ownerUid = switchSessionPrefs.getString("owner_uid", "").orEmpty()
        if (authenticatedUid.isBlank() || ownerUid != authenticatedUid) return null
        val uid = switchSessionPrefs.getString("uid", "").orEmpty()
        if (uid.isBlank()) return null
        val profile = AppUserProfile(
            uid = uid,
            email = switchSessionPrefs.getString("email", "").orEmpty(),
            displayName = switchSessionPrefs.getString("display_name", "").orEmpty(),
            role = switchSessionPrefs.getString("role", "staff") ?: "staff",
            enabled = switchSessionPrefs.getBoolean("enabled", true),
            canEditCustomers = switchSessionPrefs.getBoolean("can_edit_customers", true),
            canDiscount = switchSessionPrefs.getBoolean("can_discount", true),
            canCollectPayments = switchSessionPrefs.getBoolean("can_collect_payments", true),
            canViewSalesReports = switchSessionPrefs.getBoolean("can_view_sales_reports", false),
            createdAtMillis = switchSessionPrefs.getLong("created_at_ms", 0L),
            updatedAtMillis = switchSessionPrefs.getLong("updated_at_ms", 0L),
            pinResetRequestedAtMillis = switchSessionPrefs.getLong("pin_reset_requested_at_ms", 0L)
        )
        return profile.takeIf { it.enabled && !isManagerAccount(it.email, it.uid) }
    }

    private fun clearPersistedActingUser() {
        switchSessionPrefs.edit().clear().apply()
    }

    private fun managerProfile(): AppUserProfile = AppUserProfile(
        uid = authenticatedUid.ifBlank { MANAGER_UID },
        email = authenticatedEmail.ifBlank { MANAGER_EMAIL },
        displayName = "Abdelrahman",
        role = "super_admin",
        enabled = true,
        canEditCustomers = true,
        canDiscount = true,
        canCollectPayments = true,
        canViewSalesReports = false
    )

    private fun clearManagerPriceCache() {
        _lab2LabPrices.value = emptyMap()
        managerPricesLoaded = false
    }

    @Deprecated("V59 unified UI removed user switching")
    fun switchToUser(profile: AppUserProfile, onResult: (Boolean, String) -> Unit) {
        onResult(false, tr("تم إلغاء تبديل المستخدم. كل الحسابات تستخدم نفس واجهة التشغيل.", "User switching was removed. All accounts use the same daily workspace."))
    }

    @Deprecated("V59 unified UI removed manager mode")
    fun returnToManagerMode(onResult: ((Boolean, String) -> Unit)? = null) {
        _actingAsUser.value = null
        clearPersistedActingUser()
        _isManager.value = false
        clearManagerPriceCache()
        onResult?.invoke(true, tr("أنت بالفعل في واجهة التشغيل الموحدة", "You are already in the unified daily workspace"))
    }

    private fun loadAfterAccessGranted() {
        if (!customerOverridesLoaded) loadCustomerPriceOverrides()
        if (_customers.value.isEmpty()) loadCustomers()
    }

    private fun ensureManagerProfile(email: String?, uid: String?) {
        if (uid.isNullOrBlank()) return
        val now = System.currentTimeMillis()
        val data = mapOf(
            "email" to email.orEmpty().trim().lowercase(),
            "display_name" to "Abdelrahman",
            "role" to "super_admin",
            "enabled" to true,
            "can_edit_customers" to true,
            "can_discount" to true,
            "can_collect_payments" to true,
            "can_view_sales_reports" to false,
            "updated_at_ms" to now,
            "updated_at" to FieldValue.serverTimestamp()
        )
        firestore.collection(USERS_COLLECTION).document(uid).set(data, SetOptions.merge())
    }

    private fun attachUserProfileListener(email: String, uid: String) {
        profileListener?.remove()
        val ref = firestore.collection(USERS_COLLECTION).document(uid)

        // Create a safe default staff profile if this is a legacy user. If V14 rules have not
        // been published yet the write may fail; the listener fallback still keeps legacy access.
        ref.get(Source.SERVER)
            .addOnSuccessListener { snapshot ->
                if (!snapshot.exists()) {
                    val now = System.currentTimeMillis()
                    val defaultData = mapOf(
                        "email" to email.trim().lowercase(),
                        "display_name" to email.substringBefore('@').ifBlank { "مستخدم" },
                        "role" to "staff",
                        "enabled" to true,
                        "can_edit_customers" to true,
                        "can_discount" to true,
                        "can_collect_payments" to true,
                        "can_view_sales_reports" to false,
                        "created_at_ms" to now,
                        "created_at" to FieldValue.serverTimestamp(),
                        "updated_at_ms" to now,
                        "updated_at" to FieldValue.serverTimestamp()
                    )
                    ref.set(defaultData, SetOptions.merge())
                }
            }
            .addOnFailureListener {
                // Backward compatibility while rules are being upgraded.
                _accountEnabled.value = true
                _currentUserProfile.value = defaultStaffProfile(uid, email)
                loadAfterAccessGranted()
            }

        profileListener = ref.addSnapshotListener { snapshot, error ->
            if (error != null) {
                if (_accountEnabled.value == null) {
                    _accountEnabled.value = true
                    _currentUserProfile.value = defaultStaffProfile(uid, email)
                    loadAfterAccessGranted()
                }
                return@addSnapshotListener
            }

            val profile = if (snapshot != null && snapshot.exists()) {
                parseUserProfile(snapshot)
            } else {
                defaultStaffProfile(uid, email)
            }
            _currentUserProfile.value = profile
            _accountEnabled.value = profile.enabled
            settingsStore.applyRemotePinReset(profile.pinResetRequestedAtMillis)
            if (profile.enabled) loadAfterAccessGranted()
            else {
                _customers.value = emptyList()
                _customerOrders.value = emptyList()
            }
        }
    }

    private fun defaultStaffProfile(uid: String, email: String): AppUserProfile = AppUserProfile(
        uid = uid,
        email = email,
        displayName = email.substringBefore('@').ifBlank { "مستخدم" },
        role = "staff",
        enabled = true
    )

    private fun parseUserProfile(doc: DocumentSnapshot): AppUserProfile = AppUserProfile(
        uid = doc.id,
        email = doc.getString("email").orEmpty(),
        displayName = doc.getString("display_name").orEmpty().ifBlank { doc.getString("email").orEmpty().substringBefore('@') },
        role = doc.getString("role") ?: "staff",
        enabled = doc.getBoolean("enabled") ?: true,
        canEditCustomers = doc.getBoolean("can_edit_customers") ?: true,
        canDiscount = doc.getBoolean("can_discount") ?: true,
        canCollectPayments = doc.getBoolean("can_collect_payments") ?: true,
        canViewSalesReports = doc.getBoolean("can_view_sales_reports") ?: false,
        createdAtMillis = doc.getLong("created_at_ms") ?: 0L,
        updatedAtMillis = doc.getLong("updated_at_ms") ?: 0L,
        pinResetRequestedAtMillis = doc.getLong("pin_reset_requested_at_ms") ?: 0L
    )

    private fun loadManagerPriceState() {
        if (!managerPricesLoaded || _lab2LabPrices.value.isEmpty()) {
            val localPrices = loadManagerPricesFromAsset()
            _lab2LabPrices.value = localPrices
            managerPricesLoaded = localPrices.isNotEmpty()
        }

        privilegedFirestore().collection(LAB2LAB_COLLECTION)
            .get(Source.SERVER)
            .addOnSuccessListener { snapshot ->
                if (!hasAdminAccess()) return@addOnSuccessListener
                val serverPrices = mutableMapOf<Int, String>()
                snapshot.documents.forEach { doc ->
                    val id = documentTestId(doc.id, doc.getLong("id")?.toInt()) ?: return@forEach
                    val value = doc.get("lab_to_lab_price")
                        ?: doc.get("lab2lab_price")
                        ?: doc.get("labToLabPrice")
                        ?: doc.get("price")
                        ?: return@forEach
                    formatFirestorePrice(value)?.takeIf { it.isNotBlank() }?.let { serverPrices[id] = it }
                }
                if (serverPrices.isNotEmpty()) {
                    _lab2LabPrices.value = _lab2LabPrices.value + serverPrices
                    managerPricesLoaded = true
                }
            }
    }

    private fun loadCustomerPriceOverrides() {
        firestore.collection(CUSTOMER_OVERRIDES_COLLECTION)
            .get(Source.SERVER)
            .addOnSuccessListener { snapshot ->
                val prices = mutableMapOf<Int, String>()
                snapshot.documents.forEach { doc ->
                    val id = documentTestId(doc.id, doc.getLong("id")?.toInt()) ?: return@forEach
                    val value = doc.get("customer_price")
                        ?: doc.get("customerPrice")
                        ?: doc.get("price")
                        ?: return@forEach
                    formatFirestorePrice(value)?.takeIf { it.isNotBlank() }?.let { prices[id] = it }
                }
                _customerPriceOverrides.value = prices
                customerOverridesLoaded = true
            }
    }

    fun saveManagerPrices(
        test: LabTest,
        customerPrice: String,
        lab2LabPrice: String,
        onResult: (success: Boolean, message: String) -> Unit
    ) {
        if (!hasAdminAccess()) {
            onResult(false, tr("غير مصرح بتعديل الأسعار", "Not authorized to edit prices"))
            return
        }

        val customerNumber = parsePriceInput(customerPrice)
        val labNumber = parsePriceInput(lab2LabPrice)
        if (customerNumber == null || customerNumber < 0) {
            onResult(false, tr("اكتب سعر عميل صحيح", "Enter a valid customer price"))
            return
        }
        if (labNumber == null || labNumber < 0) {
            onResult(false, tr("اكتب سعر Lab 2 Lab صحيح", "Enter a valid Lab2Lab price"))
            return
        }

        val docId = "test_${test.id}"
        val customerRef = privilegedFirestore().collection(CUSTOMER_OVERRIDES_COLLECTION).document(docId)
        val labRef = privilegedFirestore().collection(LAB2LAB_COLLECTION).document(docId)
        val customerData = mapOf(
            "id" to test.id,
            "customer_price" to customerNumber,
            "updated_at" to FieldValue.serverTimestamp()
        )
        val labData = mapOf(
            "id" to test.id,
            "lab_to_lab_price" to labNumber,
            "updated_at" to FieldValue.serverTimestamp()
        )

        privilegedFirestore().runBatch { batch ->
            batch.set(customerRef, customerData, SetOptions.merge())
            batch.set(labRef, labData, SetOptions.merge())
        }.addOnSuccessListener {
            _customerPriceOverrides.value = _customerPriceOverrides.value + (test.id to formatNumber(customerNumber))
            _lab2LabPrices.value = _lab2LabPrices.value + (test.id to formatNumber(labNumber))
            customerOverridesLoaded = true
            managerPricesLoaded = true
            logAudit(
                action = "price_update",
                entityType = "lab_test",
                entityId = test.id.toString(),
                title = "تعديل سعر تحليل",
                details = "${test.englishName}: عميل ${formatNumber(customerNumber)} / Lab2Lab ${formatNumber(labNumber)}"
            )
            onResult(true, "تم حفظ أسعار ${test.englishName}")
        }.addOnFailureListener {
            onResult(false, "تعذر حفظ الأسعار. تأكد من الإنترنت وصلاحيات Firebase")
        }
    }

    fun updateAppSettings(settings: AppSettings) = settingsStore.save(settings)
    fun setAppPin(pin: String): Boolean = settingsStore.setAppPin(pin)
    fun verifyAppPin(pin: String): Boolean = settingsStore.verifyAppPin(pin)
    fun clearAppPin() = settingsStore.clearAppPin()
    fun resetAppSettings() = settingsStore.reset()
    fun toggleFavoriteTest(testId: Int) = settingsStore.toggleFavoriteTest(testId)
    fun useRecentSearch(query: String) = onQueryChanged(query)

    fun refreshPrices(onResult: (Boolean, String) -> Unit) {
        firestore.collection(CUSTOMER_OVERRIDES_COLLECTION)
            .get(Source.SERVER)
            .addOnSuccessListener { customerSnapshot ->
                val customerPrices = mutableMapOf<Int, String>()
                customerSnapshot.documents.forEach { doc ->
                    val id = documentTestId(doc.id, doc.getLong("id")?.toInt()) ?: return@forEach
                    val value = doc.get("customer_price") ?: doc.get("customerPrice") ?: doc.get("price") ?: return@forEach
                    formatFirestorePrice(value)?.takeIf { it.isNotBlank() }?.let { customerPrices[id] = it }
                }
                _customerPriceOverrides.value = customerPrices
                customerOverridesLoaded = true

                if (!hasAdminAccess()) {
                    settingsStore.markSynced()
                    onResult(true, tr("تم تحديث الأسعار", "Prices refreshed"))
                    return@addOnSuccessListener
                }

                privilegedFirestore().collection(LAB2LAB_COLLECTION).get(Source.SERVER)
                    .addOnSuccessListener { labSnapshot ->
                        val labPrices = mutableMapOf<Int, String>()
                        labSnapshot.documents.forEach { doc ->
                            val id = documentTestId(doc.id, doc.getLong("id")?.toInt()) ?: return@forEach
                            val value = doc.get("lab_to_lab_price")
                                ?: doc.get("lab2lab_price")
                                ?: doc.get("labToLabPrice")
                                ?: doc.get("price")
                                ?: return@forEach
                            formatFirestorePrice(value)?.takeIf { it.isNotBlank() }?.let { labPrices[id] = it }
                        }
                        if (labPrices.isNotEmpty()) {
                            _lab2LabPrices.value = _lab2LabPrices.value + labPrices
                            managerPricesLoaded = true
                        }
                        settingsStore.markSynced()
                        onResult(true, tr("تم تحديث الأسعار بنجاح", "Prices refreshed successfully"))
                    }
                    .addOnFailureListener { onResult(false, "تعذر تحديث أسعار Lab 2 Lab") }
            }
            .addOnFailureListener { onResult(false, tr("تعذر تحديث الأسعار. تأكد من الإنترنت", "Unable to refresh prices. Check internet connection")) }
    }

    fun searchManagerTests(query: String): List<LabTest> =
        if (query.isBlank()) repository.getLabTests() else repository.searchTests(query)

    fun clearLab2LabState() {
        lockAdmin()
        _isManager.value = false
        _actualManager.value = false
        _actingAsUser.value = null
        clearManagerPriceCache()
    }

    // ------------------------- USERS / ROLES -------------------------

    fun loadUsers(onResult: ((Boolean, String) -> Unit)? = null) {
        if (!hasAdminAccess()) {
            onResult?.invoke(false, tr("الإجراء متاح للمدير فقط", "Manager only action"))
            return
        }
        privilegedFirestore().collection(USERS_COLLECTION).get(Source.SERVER)
            .addOnSuccessListener { snapshot ->
                val parsed = snapshot.documents.map { parseUserProfile(it) }.toMutableList()
                if (parsed.none { it.uid == MANAGER_UID }) {
                    parsed += AppUserProfile(
                        uid = MANAGER_UID,
                        email = MANAGER_EMAIL,
                        displayName = "Abdelrahman",
                        role = "super_admin",
                        enabled = true
                    )
                }
                _users.value = parsed.sortedWith(compareByDescending<AppUserProfile> { it.uid == MANAGER_UID }.thenBy { it.displayName.lowercase() })
                onResult?.invoke(true, tr("تم تحديث المستخدمين", "Users refreshed"))
            }
            .addOnFailureListener { onResult?.invoke(false, tr("تعذر تحميل المستخدمين", "Unable to load users")) }
    }

    fun createUserAccount(
        displayName: String,
        email: String,
        password: String,
        role: String,
        onResult: (Boolean, String) -> Unit
    ) {
        if (!hasAdminAccess()) {
            onResult(false, tr("الإجراء متاح للمدير فقط", "Manager only action"))
            return
        }
        val cleanEmail = email.trim().lowercase()
        val cleanName = displayName.trim()
        if (cleanName.length < 2) {
            onResult(false, tr("اكتب اسم المستخدم", "Enter user name"))
            return
        }
        if (!cleanEmail.contains('@')) {
            onResult(false, tr("اكتب بريد إلكتروني صحيح", "Enter a valid email"))
            return
        }
        if (password.length < 6) {
            onResult(false, tr("كلمة المرور لازم تكون 6 أحرف على الأقل", "Password must be at least 6 characters"))
            return
        }

        val secondaryApp = try {
            FirebaseApp.getInstance(SECONDARY_AUTH_APP)
        } catch (_: IllegalStateException) {
            FirebaseApp.initializeApp(
                getApplication<Application>(),
                FirebaseApp.getInstance().options,
                SECONDARY_AUTH_APP
            ) ?: run {
                onResult(false, "تعذر تجهيز إنشاء المستخدم")
                return
            }
        }
        val secondaryAuth = FirebaseAuth.getInstance(secondaryApp)
        secondaryAuth.createUserWithEmailAndPassword(cleanEmail, password)
            .addOnSuccessListener { authResult ->
                val newUid = authResult.user?.uid
                if (newUid.isNullOrBlank()) {
                    secondaryAuth.signOut()
                    onResult(false, "تعذر الحصول على UID للمستخدم")
                    return@addOnSuccessListener
                }
                val now = System.currentTimeMillis()
                val normalizedRole = normalizeRole(role)
                val data = mapOf(
                    "email" to cleanEmail,
                    "display_name" to cleanName,
                    "role" to normalizedRole,
                    "enabled" to true,
                    "can_edit_customers" to true,
                    "can_discount" to true,
                    "can_collect_payments" to true,
                    "can_view_sales_reports" to false,
                    "created_at_ms" to now,
                    "created_at" to FieldValue.serverTimestamp(),
                    "updated_at_ms" to now,
                    "updated_at" to FieldValue.serverTimestamp(),
                    "created_by_uid" to currentUid()
                )
                privilegedFirestore().collection(USERS_COLLECTION).document(newUid).set(data)
                    .addOnSuccessListener {
                        secondaryAuth.signOut()
                        logAudit(
                            action = "user_create",
                            entityType = "user",
                            entityId = newUid,
                            title = tr("إضافة مستخدم", "Add User"),
                            details = "$cleanName • $cleanEmail • $normalizedRole"
                        )
                        loadUsers()
                        onResult(true, "تم إنشاء حساب $cleanName")
                    }
                    .addOnFailureListener {
                        secondaryAuth.signOut()
                        onResult(false, "تم إنشاء حساب الدخول لكن تعذر حفظ صلاحياته. راجع Firebase")
                    }
            }
            .addOnFailureListener { error ->
                secondaryAuth.signOut()
                onResult(false, error.localizedMessage ?: tr("تعذر إنشاء المستخدم", "Unable to create user"))
            }
    }

    fun updateUserAccess(
        profile: AppUserProfile,
        enabled: Boolean,
        role: String,
        canEditCustomers: Boolean,
        canDiscount: Boolean,
        canCollectPayments: Boolean,
        canViewSalesReports: Boolean,
        onResult: (Boolean, String) -> Unit
    ) {
        if (!hasAdminAccess()) {
            onResult(false, tr("الإجراء متاح للمدير فقط", "Manager only action"))
            return
        }
        if (profile.uid == MANAGER_UID) {
            onResult(false, "لا يمكن إيقاف أو خفض صلاحيات حساب المدير الأساسي")
            return
        }
        val now = System.currentTimeMillis()
        val data = mapOf(
            "enabled" to enabled,
            "role" to normalizeRole(role),
            "can_edit_customers" to true,
            "can_discount" to true,
            "can_collect_payments" to true,
            "can_view_sales_reports" to false,
            "updated_at_ms" to now,
            "updated_at" to FieldValue.serverTimestamp(),
            "updated_by_uid" to currentUid()
        )
        privilegedFirestore().collection(USERS_COLLECTION).document(profile.uid).set(data, SetOptions.merge())
            .addOnSuccessListener {
                logAudit(
                    action = "user_access_update",
                    entityType = "user",
                    entityId = profile.uid,
                    title = "تعديل صلاحيات مستخدم",
                    details = "${profile.displayName}: enabled=$enabled role=${normalizeRole(role)}"
                )
                loadUsers()
                onResult(true, "تم تحديث صلاحيات ${profile.displayName}")
            }
            .addOnFailureListener { onResult(false, tr("تعذر تحديث صلاحيات المستخدم", "Unable to update user permissions")) }
    }

    fun requestUserPinReset(profile: AppUserProfile, onResult: (Boolean, String) -> Unit) {
        if (!hasAdminAccess()) {
            onResult(false, tr("الإجراء متاح للمدير فقط", "Manager only action"))
            return
        }
        val now = System.currentTimeMillis()
        privilegedFirestore().collection(USERS_COLLECTION).document(profile.uid)
            .set(
                mapOf(
                    "pin_reset_requested_at_ms" to now,
                    "updated_at_ms" to now,
                    "updated_at" to FieldValue.serverTimestamp(),
                    "updated_by_uid" to currentUid()
                ),
                SetOptions.merge()
            )
            .addOnSuccessListener {
                logAudit(
                    action = "pin_reset_request",
                    entityType = "user",
                    entityId = profile.uid,
                    title = "طلب Reset PIN",
                    details = profile.displayName
                )
                onResult(true, "هيتم إلغاء PIN الخاص بالمستخدم عند فتح التطبيق على جهازه")
            }
            .addOnFailureListener { onResult(false, "تعذر إرسال طلب Reset PIN") }
    }

    private fun normalizeRole(role: String): String = when (role.trim().lowercase()) {
        "reception", "استقبال" -> "reception"
        "cashier", "كاشير" -> "cashier"
        "supervisor", "مشرف" -> "supervisor"
        "manager", "مدير" -> "manager"
        else -> "staff"
    }

    // ------------------------- CUSTOMERS -------------------------

    fun loadCustomers(onResult: ((Boolean, String) -> Unit)? = null) {
        if (_accountEnabled.value == false) {
            onResult?.invoke(false, tr("الحساب موقوف", "Account Disabled"))
            return
        }
        if (_customersLoading.value) return
        _customersLoading.value = true
        firestore.collection(CUSTOMERS_COLLECTION)
            .get()
            .addOnSuccessListener { snapshot ->
                _customers.value = snapshot.documents.mapNotNull { parseCustomer(it) }
                    .sortedByDescending { it.updatedAtMillis.takeIf { value -> value > 0 } ?: it.createdAtMillis }
                _customersLoading.value = false
                onResult?.invoke(true, tr("تم تحديث بيانات العملاء", "Customers refreshed"))
            }
            .addOnFailureListener {
                _customersLoading.value = false
                onResult?.invoke(false, tr("تعذر تحميل العملاء. تأكد من الإنترنت وصلاحيات Firebase", "Unable to load customers. Check connection and Firebase permissions"))
            }
    }

    /**
     * V37: Resolve a customer QR back to the same customer record.
     * The QR payload generated by PdfGenerator is stable per customer because it contains
     * the Firestore document id plus the clinic file number.
     */
    fun findCustomerByQrPayload(
        payload: String,
        onResult: (Customer?, String) -> Unit
    ) {
        val raw = payload.trim()
        if (raw.length > 512 || raw.any { it.code < 0x20 || it.code == 0x7F }) {
            onResult(null, tr("QR العميل غير صالح أو حجمه غير طبيعي", "Invalid or oversized customer QR"))
            return
        }
        if (!raw.startsWith("TAHALIL_ALAKKAD_CUSTOMER|")) {
            onResult(null, tr("الكود ده مش QR عميل صادر من تحاليل العقاد", "This is not a Tahalil Alakkad customer QR"))
            return
        }

        fun valueFor(key: String): String {
            return raw.split('|')
                .firstOrNull { it.startsWith("$key=") }
                ?.substringAfter('=')
                ?.trim()
                .orEmpty()
        }

        val customerId = valueFor("ID")
        val fileNumber = valueFor("FILE")

        if (customerId.isBlank() && fileNumber.isBlank()) {
            onResult(null, tr("QR العميل غير صالح", "Invalid customer QR"))
            return
        }

        val localMatch = _customers.value.firstOrNull { customer ->
            (customerId.isNotBlank() && customer.id == customerId) ||
                (fileNumber.isNotBlank() && customer.fileNumber == fileNumber)
        }
        if (localMatch != null) {
            onResult(localMatch, tr("تم فتح ملف العميل", "Customer file opened"))
            return
        }

        if (!_isOnline.value) {
            onResult(null, tr("العميل مش موجود في البيانات المحفوظة على الجهاز. اتصل بالإنترنت وحاول تاني", "Customer is not available in the local cache. Connect to the internet and try again"))
            return
        }

        if (customerId.isNotBlank()) {
            firestore.collection(CUSTOMERS_COLLECTION)
                .document(customerId)
                .get()
                .addOnSuccessListener { doc ->
                    val customer = if (doc.exists()) parseCustomer(doc) else null
                    if (customer != null) {
                        _customers.value = listOf(customer) + _customers.value.filterNot { it.id == customer.id }
                        onResult(customer, tr("تم فتح ملف العميل", "Customer file opened"))
                    } else if (fileNumber.isNotBlank()) {
                        findCustomerByFileNumberFromServer(fileNumber, onResult)
                    } else {
                        onResult(null, tr("ملف العميل غير موجود", "Customer file not found"))
                    }
                }
                .addOnFailureListener {
                    if (fileNumber.isNotBlank()) {
                        findCustomerByFileNumberFromServer(fileNumber, onResult)
                    } else {
                        onResult(null, tr("تعذر تحميل بيانات العميل", "Unable to load customer data"))
                    }
                }
        } else {
            findCustomerByFileNumberFromServer(fileNumber, onResult)
        }
    }

    private fun findCustomerByFileNumberFromServer(
        fileNumber: String,
        onResult: (Customer?, String) -> Unit
    ) {
        firestore.collection(CUSTOMERS_COLLECTION)
            .whereEqualTo("file_number", fileNumber)
            .limit(1)
            .get()
            .addOnSuccessListener { snapshot ->
                val customer = snapshot.documents.firstOrNull()?.let(::parseCustomer)
                if (customer != null) {
                    _customers.value = listOf(customer) + _customers.value.filterNot { it.id == customer.id }
                    onResult(customer, tr("تم فتح ملف العميل", "Customer file opened"))
                } else {
                    onResult(null, tr("ملف العميل غير موجود", "Customer file not found"))
                }
            }
            .addOnFailureListener {
                onResult(null, tr("تعذر تحميل بيانات العميل", "Unable to load customer data"))
            }
    }

    private fun parseCustomer(doc: DocumentSnapshot): Customer? {
        val name = doc.getString("name")?.trim().orEmpty()
        if (name.isBlank()) return null
        val rawTags = doc.get("tags") as? List<*>
        return Customer(
            id = doc.id,
            fileNumber = doc.getString("file_number").orEmpty(),
            name = name,
            phone = doc.getString("phone").orEmpty(),
            alternatePhone = doc.getString("alternate_phone").orEmpty(),
            age = doc.getString("age").orEmpty(),
            birthDate = doc.getString("birth_date").orEmpty(),
            gender = doc.getString("gender").orEmpty(),
            address = doc.getString("address").orEmpty(),
            notes = doc.getString("notes").orEmpty(),
            importantAlert = doc.getString("important_alert").orEmpty(),
            tags = rawTags?.mapNotNull { it?.toString()?.trim()?.takeIf(String::isNotBlank) } ?: emptyList(),
            defaultDiscountPercent = numberAsDouble(doc.get("default_discount_percent")).coerceIn(0.0, 100.0),
            createdAtMillis = doc.getLong("created_at_ms") ?: 0L,
            updatedAtMillis = doc.getLong("updated_at_ms") ?: 0L,
            createdByUid = doc.getString("created_by_uid").orEmpty(),
            updatedByUid = doc.getString("updated_by_uid").orEmpty(),
            isBlacklisted = doc.getBoolean("is_blacklisted") ?: false,
            blacklistReason = doc.getString("blacklist_reason").orEmpty(),
            blacklistedAtMillis = doc.getLong("blacklisted_at_ms") ?: 0L,
            isArchived = doc.getBoolean("is_archived") ?: false,
            archivedAtMillis = doc.getLong("archived_at_ms") ?: 0L
        )
    }

    fun saveCustomer(
        existing: Customer?,
        name: String,
        phone: String,
        alternatePhone: String = "",
        age: String,
        birthDate: String = "",
        gender: String,
        address: String = "",
        notes: String,
        importantAlert: String = "",
        tags: List<String> = emptyList(),
        defaultDiscountPercent: Double = 0.0,
        onResult: (Boolean, String) -> Unit
    ) {
        saveCustomerInternal(
            existing, name, phone, alternatePhone, age, birthDate, gender, address,
            notes, importantAlert, tags, defaultDiscountPercent
        ) { customer, message -> onResult(customer != null, message) }
    }

    fun saveCustomerAndReturn(
        name: String,
        phone: String,
        alternatePhone: String = "",
        age: String,
        birthDate: String = "",
        gender: String,
        address: String = "",
        notes: String,
        importantAlert: String = "",
        tags: List<String> = emptyList(),
        defaultDiscountPercent: Double = 0.0,
        onResult: (Customer?, String) -> Unit
    ) {
        saveCustomerInternal(
            null, name, phone, alternatePhone, age, birthDate, gender, address,
            notes, importantAlert, tags, defaultDiscountPercent, onResult
        )
    }

    private fun saveCustomerInternal(
        existing: Customer?,
        name: String,
        phone: String,
        alternatePhone: String,
        age: String,
        birthDate: String,
        gender: String,
        address: String,
        notes: String,
        importantAlert: String,
        tags: List<String>,
        defaultDiscountPercent: Double,
        onResult: (Customer?, String) -> Unit
    ) {
        val cleanName = name.trim()
        val cleanPhone = normalizePhone(phone)
        val cleanAltPhone = normalizePhone(alternatePhone)
        val cleanAge = age.trim()
        val cleanBirthDate = birthDate.trim().take(20)
        val cleanTags = tags.map { it.trim() }.filter { it.isNotBlank() }.distinct().take(10)
        val safeDefaultDiscount = defaultDiscountPercent.coerceIn(0.0, 100.0)

        if (cleanName.length < 2) {
            onResult(null, tr("اكتب اسم العميل", "Enter customer name"))
            return
        }
        if (cleanPhone.length < 8) {
            onResult(null, tr("اكتب رقم موبايل صحيح", "Enter a valid phone number"))
            return
        }
        if (cleanAltPhone.isNotBlank() && cleanAltPhone.length < 8) {
            onResult(null, tr("رقم الموبايل البديل غير صحيح", "Alternate phone is invalid"))
            return
        }
        if (cleanPhone == cleanAltPhone && cleanAltPhone.isNotBlank()) {
            onResult(null, tr("رقم الموبايل البديل مطابق للرقم الأساسي", "Alternate phone matches primary phone"))
            return
        }
        if (cleanAge.isNotBlank() && (cleanAge.toIntOrNull() == null || cleanAge.toInt() !in 0..120)) {
            onResult(null, tr("اكتب سن صحيح", "Enter a valid age"))
            return
        }
        val normalizedGender = when (gender) {
            "Male" -> "ذكر"
            "Female" -> "أنثى"
            else -> gender
        }
        if (normalizedGender !in setOf("ذكر", "أنثى")) {
            onResult(null, tr("اختر النوع", "Choose gender"))
            return
        }

        val numbersToCheck = listOf(cleanPhone, cleanAltPhone).filter { it.isNotBlank() }.distinct()
        findPotentialDuplicateCustomer(
            name = cleanName,
            age = cleanAge,
            birthDate = cleanBirthDate,
            gender = normalizedGender,
            address = address.trim(),
            existingId = existing?.id
        ) { potentialDuplicate ->
            if (potentialDuplicate != null) {
                onResult(null, duplicateCustomerMessage(potentialDuplicate))
            } else {
                findDuplicatePhone(numbersToCheck, existing?.id) { duplicate ->
                    if (duplicate != null) {
                        onResult(null, duplicatePhoneMessage(duplicate))
                    } else {
                        val now = System.currentTimeMillis()
            val customerRef = existing?.let { firestore.collection(CUSTOMERS_COLLECTION).document(it.id) }
                ?: firestore.collection(CUSTOMERS_COLLECTION).document()
            val fileNumber = existing?.fileNumber?.takeIf { it.isNotBlank() } ?: generateFileNumber(now)
            val currentUid = currentUid()
            val currentEmail = currentEmail()

            val customer = Customer(
                id = customerRef.id,
                fileNumber = fileNumber,
                name = cleanName,
                phone = phone.trim(),
                alternatePhone = alternatePhone.trim(),
                age = cleanAge,
                birthDate = cleanBirthDate,
                gender = normalizedGender,
                address = address.trim(),
                notes = notes.trim(),
                importantAlert = importantAlert.trim(),
                tags = cleanTags,
                defaultDiscountPercent = safeDefaultDiscount,
                createdAtMillis = existing?.createdAtMillis ?: now,
                updatedAtMillis = now,
                createdByUid = existing?.createdByUid ?: currentUid,
                updatedByUid = currentUid,
                isBlacklisted = existing?.isBlacklisted ?: false,
                blacklistReason = existing?.blacklistReason.orEmpty(),
                blacklistedAtMillis = existing?.blacklistedAtMillis ?: 0L,
                isArchived = existing?.isArchived ?: false,
                archivedAtMillis = existing?.archivedAtMillis ?: 0L
            )

            val data = mutableMapOf<String, Any>(
                "file_number" to fileNumber,
                "name" to cleanName,
                "name_search" to normalizeText(cleanName),
                "phone" to phone.trim(),
                "phone_normalized" to cleanPhone,
                "alternate_phone" to alternatePhone.trim(),
                "alternate_phone_normalized" to cleanAltPhone,
                "age" to cleanAge,
                "birth_date" to cleanBirthDate,
                "gender" to normalizedGender,
                "address" to address.trim(),
                "address_search" to normalizeText(address),
                "notes" to notes.trim(),
                "important_alert" to importantAlert.trim(),
                "tags" to cleanTags,
                "tags_search" to normalizeText(cleanTags.joinToString(" ")),
                "default_discount_percent" to safeDefaultDiscount,
                "updated_at_ms" to now,
                "updated_at" to FieldValue.serverTimestamp(),
                "updated_by_uid" to currentUid,
                "updated_by_email" to currentEmail
            )
            if (existing == null) {
                data["created_at_ms"] = now
                data["created_at"] = FieldValue.serverTimestamp()
                data["created_by_uid"] = currentUid
                data["created_by_email"] = currentEmail
                data["is_blacklisted"] = false
                data["blacklist_reason"] = ""
                data["blacklisted_at_ms"] = 0L
                data["is_archived"] = false
                data["archived_at_ms"] = 0L
            }

            val newNumbers = numbersToCheck.toSet()
            val oldNumbers = existing?.let {
                setOf(normalizePhone(it.phone), normalizePhone(it.alternatePhone)).filter { n -> n.isNotBlank() }.toSet()
            } ?: emptySet()

            val action = if (existing == null) "customer_create" else "customer_update"
            val title = if (existing == null) "إنشاء عميل" else tr("تعديل بيانات العميل", "Edit Customer")
            val changes = describeCustomerChanges(existing, customer)
            val detail = if (changes.isBlank()) "$cleanName • $fileNumber" else changes
            queueOfflineAuditIfNeeded(action, "customer", customer.id, title, detail, customerId = customer.id)

            val offlineAtStart = !_isOnline.value

            fun commitCustomerWrite() {
                val batchTask = firestore.runBatch { batch ->
                    batch.set(customerRef, data, SetOptions.merge())
                    newNumbers.forEach { number ->
                        val registryRef = firestore.collection(PHONE_REGISTRY_COLLECTION).document(number)
                        batch.set(
                            registryRef,
                            mapOf(
                                "customer_id" to customerRef.id,
                                "phone" to number,
                                "updated_at_ms" to now,
                                "updated_by_uid" to currentUid
                            ),
                            SetOptions.merge()
                        )
                    }
                    (oldNumbers - newNumbers).forEach { number ->
                        batch.delete(firestore.collection(PHONE_REGISTRY_COLLECTION).document(number))
                    }
                }

                if (offlineAtStart) {
                    _customers.value = listOf(customer) + _customers.value.filterNot { it.id == customer.id }
                    addCustomerActivity(customer.id, action, title, detail)
                    onResult(customer, (if (existing == null) "تم إنشاء ملف العميل $fileNumber" else "تم تحديث بيانات العميل") + " • في انتظار المزامنة")
                }

                batchTask.addOnSuccessListener {
                    _customers.value = listOf(customer) + _customers.value.filterNot { it.id == customer.id }
                    logAudit(action, "customer", customer.id, title, detail, customerId = customer.id)
                    if (!offlineAtStart) {
                        addCustomerActivity(customer.id, action, title, detail)
                        onResult(customer, if (existing == null) "تم إنشاء ملف العميل $fileNumber" else "تم تحديث بيانات العميل")
                    }
                }.addOnFailureListener {
                    if (!offlineAtStart) onResult(null, "تعذر حفظ بيانات العميل. تأكد من صلاحيات Firebase")
                    else _systemMessage.value = "تعذر مزامنة بيانات العميل ${customer.name}"
                }
            }

            // When online, reject a stale edit before it overwrites another user's newer customer edit.
            if (existing != null && !offlineAtStart) {
                customerRef.get(Source.SERVER)
                    .addOnSuccessListener { serverDoc ->
                        val serverUpdated = serverDoc.getLong("updated_at_ms") ?: existing.updatedAtMillis
                        if (serverUpdated > existing.updatedAtMillis + 1L) {
                            onResult(
                                null,
                                tr(
                                    "تم تعديل العميل بواسطة مستخدم آخر. افتح الملف من جديد قبل الحفظ.",
                                    "This customer was changed by another user. Reopen the record before saving."
                                )
                            )
                            refreshDataIntegrity()
                        } else {
                            commitCustomerWrite()
                        }
                    }
                    .addOnFailureListener {
                        onResult(null, tr("تعذر التحقق من أحدث نسخة للعميل", "Could not verify the latest customer version"))
                    }
            } else {
                commitCustomerWrite()
            }
                    }
                }
            }
        }
    }

    /** V42: strong duplicate guard beyond phone number.
     * Matches exact normalized name plus DOB, or exact normalized name + age + gender + address.
     * This intentionally avoids blocking common names on name alone.
     */
    private fun findPotentialDuplicateCustomer(
        name: String,
        age: String,
        birthDate: String,
        gender: String,
        address: String,
        existingId: String?,
        callback: (Customer?) -> Unit
    ) {
        val normName = normalizeText(name)
        val normAddress = normalizeText(address)
        fun strongMatch(customer: Customer): Boolean {
            if (customer.id == existingId || customer.isArchived) return false
            if (normalizeText(customer.name) != normName) return false
            val dobMatch = birthDate.isNotBlank() && customer.birthDate.isNotBlank() &&
                customer.birthDate.trim() == birthDate.trim()
            val profileMatch = age.isNotBlank() && address.isNotBlank() &&
                customer.age.trim() == age.trim() &&
                customer.gender.trim() == gender.trim() &&
                normalizeText(customer.address) == normAddress
            return dobMatch || profileMatch
        }
        val localDuplicate = _customers.value.firstOrNull(::strongMatch)
        if (localDuplicate != null) {
            callback(localDuplicate)
            return
        }
        if (!_isOnline.value || normName.isBlank()) {
            callback(null)
            return
        }
        firestore.collection(CUSTOMERS_COLLECTION)
            .whereEqualTo("name_search", normName)
            .limit(10)
            .get(Source.SERVER)
            .addOnSuccessListener { snapshot ->
                callback(snapshot.documents.mapNotNull(::parseCustomer).firstOrNull(::strongMatch))
            }
            .addOnFailureListener { callback(null) }
    }

    private fun duplicateCustomerMessage(customer: Customer): String {
        val file = customer.fileNumber.takeIf { it.isNotBlank() }?.let { " • ملف $it" }.orEmpty()
        return "ممكن يكون العميل موجود بالفعل: ${customer.name}$file • افتح الملف الحالي بدل إنشاء ملف مكرر"
    }

    private fun findDuplicatePhone(numbers: List<String>, existingId: String?, callback: (Customer?) -> Unit) {
        // First inspect already-loaded customers. This catches legacy V6-V13 records that do not
        // yet have phone_normalized / phone_registry fields and prevents the old "number exists but
        // search cannot find it" case from returning.
        val localDuplicate = _customers.value.firstOrNull { customer ->
            customer.id != existingId && numbers.any { number ->
                normalizePhone(customer.phone) == number || normalizePhone(customer.alternatePhone) == number
            }
        }
        if (localDuplicate != null) {
            callback(localDuplicate)
            return
        }

        fun check(index: Int, fieldIndex: Int) {
            if (index >= numbers.size) {
                callback(null)
                return
            }
            val number = numbers[index]
            val field = if (fieldIndex == 0) "phone_normalized" else "alternate_phone_normalized"
            firestore.collection(CUSTOMERS_COLLECTION)
                .whereEqualTo(field, number)
                .limit(3)
                .get(Source.SERVER)
                .addOnSuccessListener { snapshot ->
                    val duplicateDoc = snapshot.documents.firstOrNull { it.id != existingId }
                    if (duplicateDoc != null) {
                        callback(parseCustomer(duplicateDoc))
                    } else if (fieldIndex == 0) {
                        check(index, 1)
                    } else {
                        check(index + 1, 0)
                    }
                }
                .addOnFailureListener {
                    // Registry transaction is the final uniqueness guard. Continue if a legacy query
                    // temporarily fails instead of blocking all customer updates.
                    if (fieldIndex == 0) check(index, 1) else check(index + 1, 0)
                }
        }
        check(0, 0)
    }

    private fun duplicatePhoneMessage(customer: Customer): String {
        val status = when {
            customer.isArchived -> "محذوف/مؤرشف - راجع المدير"
            customer.isBlacklisted -> tr("بلاك ليست", "Blacklist")
            else -> "نشط"
        }
        val file = customer.fileNumber.takeIf { it.isNotBlank() }?.let { " • ملف $it" }.orEmpty()
        return "رقم الموبايل مسجل للعميل ${customer.name}$file • الحالة: $status"
    }

    private fun describeCustomerChanges(old: Customer?, new: Customer): String {
        if (old == null) return "${new.name} • ملف ${new.fileNumber}"
        val changes = mutableListOf<String>()
        fun changed(label: String, before: String, after: String) {
            if (before.trim() != after.trim()) changes += "$label: ${before.ifBlank { "—" }} ← ${after.ifBlank { "—" }}"
        }
        changed(tr("الاسم", "Name"), old.name, new.name)
        changed(tr("الموبايل", "Phone"), old.phone, new.phone)
        changed("الموبايل البديل", old.alternatePhone, new.alternatePhone)
        changed(tr("السن", "Age"), old.age, new.age)
        changed(tr("تاريخ الميلاد", "Date of Birth"), old.birthDate, new.birthDate)
        changed(tr("النوع", "Gender"), old.gender, new.gender)
        changed(tr("العنوان", "Address"), old.address, new.address)
        changed("الملاحظات", old.notes, new.notes)
        changed("التنبيه", old.importantAlert, new.importantAlert)
        changed("Tags", old.tags.joinToString(", "), new.tags.joinToString(", "))
        if (kotlin.math.abs(old.defaultDiscountPercent - new.defaultDiscountPercent) > 0.001) {
            changes += "خصم افتراضي: ${formatNumber(old.defaultDiscountPercent)}% ← ${formatNumber(new.defaultDiscountPercent)}%"
        }
        return changes.joinToString(" | ").ifBlank { "تم حفظ الملف بدون تغييرات جوهرية" }
    }

    fun setCustomerBlacklist(
        customer: Customer,
        blacklisted: Boolean,
        reason: String = "",
        onResult: (Boolean, String) -> Unit
    ) {
        if (!hasAdminAccess()) {
            onResult(false, tr("الإجراء متاح للمدير فقط", "Manager only action"))
            return
        }
        val now = System.currentTimeMillis()
        val data = mapOf(
            "is_blacklisted" to blacklisted,
            "blacklist_reason" to if (blacklisted) reason.trim() else "",
            "blacklisted_at_ms" to if (blacklisted) now else 0L,
            "blacklisted_by_uid" to if (blacklisted) currentUid() else "",
            "updated_at_ms" to now,
            "updated_at" to FieldValue.serverTimestamp(),
            "updated_by_uid" to currentUid()
        )
        queueOfflineAuditIfNeeded(
            action = "customer_blacklist",
            entityType = "customer",
            entityId = customer.id,
            title = if (blacklisted) tr("إضافة للبلاك ليست", "Blacklist") else tr("فك الحظر", "Remove Blacklist"),
            details = if (blacklisted) reason.trim().ifBlank { "بدون سبب مسجل" } else "إعادة العميل للحالة النشطة",
            customerId = customer.id
        )
        privilegedFirestore().collection(CUSTOMERS_COLLECTION).document(customer.id)
            .set(data, SetOptions.merge())
            .addOnSuccessListener {
                loadCustomers()
                val title = if (blacklisted) tr("إضافة للبلاك ليست", "Blacklist") else tr("فك الحظر", "Remove Blacklist")
                val detail = if (blacklisted) reason.trim().ifBlank { "بدون سبب مسجل" } else "تمت إعادة العميل للحالة النشطة"
                logAudit("customer_blacklist", "customer", customer.id, title, detail, customerId = customer.id)
                addCustomerActivity(customer.id, "blacklist", title, detail)
                onResult(true, if (blacklisted) "تمت إضافة العميل للبلاك ليست" else "تمت إزالة العميل من البلاك ليست")
            }
            .addOnFailureListener { onResult(false, "تعذر تحديث حالة العميل") }
    }

    fun setCustomerArchived(
        customer: Customer,
        archived: Boolean,
        onResult: (Boolean, String) -> Unit
    ) {
        if (!hasAdminAccess()) {
            onResult(false, tr("الإجراء متاح للمدير فقط", "Manager only action"))
            return
        }
        val now = System.currentTimeMillis()
        val data = mutableMapOf<String, Any>(
            "is_archived" to archived,
            "archived_at_ms" to if (archived) now else 0L,
            "archived_by_uid" to if (archived) currentUid() else "",
            "updated_at_ms" to now,
            "updated_at" to FieldValue.serverTimestamp(),
            "updated_by_uid" to currentUid()
        )
        if (archived) {
            data["is_blacklisted"] = false
            data["blacklist_reason"] = ""
            data["blacklisted_at_ms"] = 0L
        }
        queueOfflineAuditIfNeeded(
            action = "customer_archive",
            entityType = "customer",
            entityId = customer.id,
            title = if (archived) "أرشفة العميل" else tr("استرجاع العميل", "Restore Customer"),
            details = if (archived) "حذف آمن مع الاحتفاظ بالسجل" else "إعادة العميل للقائمة النشطة",
            customerId = customer.id
        )
        privilegedFirestore().collection(CUSTOMERS_COLLECTION).document(customer.id)
            .set(data, SetOptions.merge())
            .addOnSuccessListener {
                loadCustomers()
                val title = if (archived) "أرشفة العميل" else tr("استرجاع العميل", "Restore Customer")
                val detail = if (archived) "حذف آمن مع الاحتفاظ بالسجل" else "إعادة العميل للقائمة النشطة"
                logAudit("customer_archive", "customer", customer.id, title, detail, customerId = customer.id)
                addCustomerActivity(customer.id, "archive", title, detail)
                onResult(true, if (archived) "تم حذف العميل من القائمة مع الاحتفاظ بسجله" else "تم استرجاع العميل")
            }
            .addOnFailureListener { onResult(false, "تعذر تحديث حالة العميل") }
    }

    fun loadCustomerActivity(customerId: String) {
        _customerActivity.value = emptyList()
        if (customerId.isBlank()) return
        firestore.collection(CUSTOMERS_COLLECTION).document(customerId).collection("activity")
            .orderBy("created_at_ms", Query.Direction.DESCENDING)
            .limit(CUSTOMER_ACTIVITY_LIMIT)
            .get()
            .addOnSuccessListener { snapshot ->
                _customerActivity.value = snapshot.documents.map { doc ->
                    CustomerActivityEntry(
                        id = doc.id,
                        type = doc.getString("type").orEmpty(),
                        title = doc.getString("title").orEmpty(),
                        details = doc.getString("details").orEmpty(),
                        actorUid = doc.getString("actor_uid").orEmpty(),
                        actorEmail = doc.getString("actor_email").orEmpty(),
                        createdAtMillis = doc.getLong("created_at_ms") ?: 0L
                    )
                }.sortedByDescending { it.createdAtMillis }.take(CUSTOMER_ACTIVITY_LIMIT.toInt())
            }
    }

    private fun addCustomerActivity(customerId: String, type: String, title: String, details: String) {
        if (customerId.isBlank()) return
        val ref = firestore.collection(CUSTOMERS_COLLECTION).document(customerId).collection("activity").document()
        val now = System.currentTimeMillis()
        ref.set(
            mapOf(
                "type" to type,
                "title" to title,
                "details" to details.take(1500),
                "actor_uid" to currentUid(),
                "actor_email" to currentEmail(),
                "created_at_ms" to now,
                "created_at" to FieldValue.serverTimestamp()
            )
        )
    }

    // ------------------------- ORDERS / PAYMENTS -------------------------

    fun loadCustomerOrders(customerId: String) {
        _customerOrders.value = emptyList()
        if (customerId.isBlank()) return
        firestore.collection(CUSTOMERS_COLLECTION)
            .document(customerId)
            .collection("orders")
            .orderBy("created_at_ms", Query.Direction.DESCENDING)
            .limit(CUSTOMER_ORDERS_LIMIT)
            .get()
            .addOnSuccessListener { snapshot ->
                _customerOrders.value = snapshot.documents.mapNotNull { parseOrder(it, customerId) }
                    .sortedByDescending { it.createdAtMillis }
            }
            .addOnFailureListener { _customerOrders.value = emptyList() }
    }

    private fun parseOrder(doc: DocumentSnapshot, fallbackCustomerId: String = ""): CustomerOrder? {
        val rawItems = doc.get("items") as? List<*> ?: emptyList<Any>()
        val items = rawItems.mapNotNull { raw ->
            val map = raw as? Map<*, *> ?: return@mapNotNull null
            val testId = (map["test_id"] as? Number)?.toInt() ?: return@mapNotNull null
            CustomerOrderItem(
                testId = testId,
                englishName = map["english_name"]?.toString().orEmpty(),
                arabicName = map["arabic_name"]?.toString().orEmpty(),
                marketName = map["market_name"]?.toString().orEmpty(),
                customerPrice = numberAsDouble(map["customer_price"])
            )
        }
        val finalTotal = numberAsDouble(doc.get("total_customer_price"))
        val subtotal = numberAsDouble(doc.get("subtotal_customer_price")).takeIf { it > 0.0 } ?: finalTotal
        val discount = numberAsDouble(doc.get("discount_amount")).takeIf { it > 0.0 }
            ?: (subtotal - finalTotal).coerceAtLeast(0.0)
        val paid = numberAsDouble(doc.get("paid_amount")).takeIf { it > 0.0 }
            ?: if (doc.getString("payment_status") == "paid") finalTotal else 0.0
        return CustomerOrder(
            id = doc.id,
            orderNumber = doc.getString("order_number").orEmpty(),
            customerId = doc.getString("customer_id").orEmpty().ifBlank { fallbackCustomerId },
            customerFileNumber = doc.getString("customer_file_number").orEmpty(),
            customerName = doc.getString("customer_name").orEmpty(),
            items = items,
            subtotalCustomerPrice = subtotal,
            discountAmount = discount,
            discountPercent = numberAsDouble(doc.get("discount_percent")).takeIf { it > 0.0 }
                ?: if (subtotal > 0.0) (discount / subtotal) * 100.0 else 0.0,
            totalCustomerPrice = finalTotal,
            paymentStatus = doc.getString("payment_status") ?: "unpaid",
            workflowStatus = doc.getString("workflow_status") ?: "new",
            paidAmount = paid.coerceAtMost(finalTotal),
            remainingAmount = if (doc.get("remaining_amount") != null) {
                numberAsDouble(doc.get("remaining_amount")).coerceAtLeast(0.0)
            } else {
                (finalTotal - paid).coerceAtLeast(0.0)
            },
            notes = doc.getString("notes").orEmpty(),
            createdAtMillis = doc.getLong("created_at_ms") ?: 0L,
            createdByUid = doc.getString("created_by_uid").orEmpty(),
            createdByEmail = doc.getString("created_by_email").orEmpty(),
            updatedAtMillis = doc.getLong("updated_at_ms") ?: 0L,
            updatedByUid = doc.getString("updated_by_uid").orEmpty(),
            editCount = (doc.getLong("edit_count") ?: 0L).toInt(),
            isVoided = doc.getBoolean("is_voided") ?: false,
            voidReason = doc.getString("void_reason").orEmpty()
        )
    }

    fun saveCustomerOrder(
        customer: Customer,
        tests: List<LabTest>,
        onResult: (Boolean, String) -> Unit
    ) {
        saveCustomerOrderAdvanced(
            customer = customer,
            tests = tests,
            discountAmount = 0.0,
            discountPercent = customer.defaultDiscountPercent,
            paymentStatus = "unpaid",
            paidAmount = 0.0,
            notes = "",
            onResult = { order, message -> onResult(order != null, message) }
        )
    }

    fun saveCustomerOrderAdvanced(
        customer: Customer,
        tests: List<LabTest>,
        discountAmount: Double,
        discountPercent: Double,
        paymentStatus: String,
        paidAmount: Double,
        notes: String,
        onResult: (CustomerOrder?, String) -> Unit
    ) {
        if (customer.isBlacklisted) {
            onResult(null, "العميل موجود في البلاك ليست. لازم المدير يفك الحظر قبل إنشاء طلب جديد")
            return
        }
        if (customer.isArchived) {
            onResult(null, tr("العميل مؤرشف. استرجعه الأول", "Customer is archived. Restore it first."))
            return
        }
        if (tests.isEmpty()) {
            onResult(null, tr("اختار تحليل واحد على الأقل", "Select at least one test"))
            return
        }
        val now = System.currentTimeMillis()
        val orderRef = firestore.collection(CUSTOMERS_COLLECTION)
            .document(customer.id).collection("orders").document()
        val items = tests.map { test ->
            val price = parsePriceInput(_customerPriceOverrides.value[test.id] ?: test.customerPrice.orEmpty()) ?: 0.0
            mapOf(
                "test_id" to test.id,
                "english_name" to test.englishName,
                "arabic_name" to test.arabicName,
                "market_name" to test.marketName,
                "customer_price" to price
            )
        }
        val subtotal = items.sumOf { numberAsDouble(it["customer_price"]) }
        val safeDiscountPercent = if (discountPercent > 0.0) discountPercent.coerceIn(0.0, 100.0) else 0.0
        val discountFromPercent = subtotal * safeDiscountPercent / 100.0
        val safeDiscount = if (safeDiscountPercent > 0.0) discountFromPercent else discountAmount.coerceIn(0.0, subtotal)
        val actualPercent = if (subtotal > 0.0) (safeDiscount / subtotal * 100.0).coerceIn(0.0, 100.0) else 0.0
        val finalTotal = (subtotal - safeDiscount).coerceAtLeast(0.0)
        val normalizedStatus = when (paymentStatus) { "paid", "partial", "unpaid" -> paymentStatus; else -> "unpaid" }
        val safePaid = when (normalizedStatus) {
            "paid" -> finalTotal
            "partial" -> paidAmount.coerceIn(0.0, finalTotal)
            else -> 0.0
        }
        val remaining = (finalTotal - safePaid).coerceAtLeast(0.0)
        val orderNumber = generateOrderNumber(now, orderRef.id)
        val uid = currentUid()
        val email = currentEmail()
        val order = CustomerOrder(
            id = orderRef.id,
            orderNumber = orderNumber,
            customerId = customer.id,
            customerFileNumber = customer.fileNumber,
            customerName = customer.name,
            items = items.map { raw ->
                CustomerOrderItem(
                    testId = (raw["test_id"] as Number).toInt(),
                    englishName = raw["english_name"].toString(),
                    arabicName = raw["arabic_name"].toString(),
                    marketName = raw["market_name"].toString(),
                    customerPrice = numberAsDouble(raw["customer_price"])
                )
            },
            subtotalCustomerPrice = subtotal,
            discountAmount = safeDiscount,
            discountPercent = actualPercent,
            totalCustomerPrice = finalTotal,
            paymentStatus = normalizedStatus,
            workflowStatus = "new",
            paidAmount = safePaid,
            remainingAmount = remaining,
            notes = notes.trim(),
            createdAtMillis = now,
            createdByUid = uid,
            createdByEmail = email,
            updatedAtMillis = now,
            updatedByUid = uid
        )
        val data = mapOf(
            "order_number" to orderNumber,
            "operation_id" to orderRef.id,
            "customer_id" to customer.id,
            "customer_file_number" to customer.fileNumber,
            "customer_name" to customer.name,
            "customer_phone" to customer.phone,
            "items" to items,
            "tests_count" to items.size,
            "subtotal_customer_price" to subtotal,
            "discount_amount" to safeDiscount,
            "discount_percent" to actualPercent,
            "total_customer_price" to finalTotal,
            "payment_status" to normalizedStatus,
            "workflow_status" to "new",
            "paid_amount" to safePaid,
            "remaining_amount" to remaining,
            "notes" to notes.trim(),
            "created_at_ms" to now,
            "created_at" to FieldValue.serverTimestamp(),
            "created_by_uid" to uid,
            "created_by_email" to email,
            "updated_at_ms" to now,
            "updated_at" to FieldValue.serverTimestamp(),
            "updated_by_uid" to uid,
            "edit_count" to 0,
            "is_voided" to false,
            "void_reason" to ""
        )

        queueOfflineAuditIfNeeded(
            action = "order_create",
            entityType = "order",
            entityId = order.id,
            title = "إنشاء طلب $orderNumber",
            details = "$orderNumber • ${items.size} تحليل • إجمالي ${formatNumber(finalTotal)}",
            customerId = customer.id,
            orderId = order.id
        )

        val offlineAtStart = !_isOnline.value
        val batchTask = firestore.runBatch { batch ->
            batch.set(orderRef, data)
            if (safePaid > 0.0) {
                val paymentRef = orderRef.collection("payments").document()
                batch.set(
                    paymentRef,
                    mapOf(
                        "operation_id" to paymentRef.id,
                        "customer_id" to customer.id,
                        "order_id" to orderRef.id,
                        "amount" to safePaid,
                        "note" to "دفعة عند إنشاء الطلب",
                        "created_at_ms" to now,
                        "created_at" to FieldValue.serverTimestamp(),
                        "created_by_uid" to uid,
                        "created_by_email" to email
                    )
                )
            }
        }

        if (offlineAtStart) {
            _customerOrders.value = listOf(order) + _customerOrders.value.filterNot { it.id == order.id }
            onResult(order, "تم حفظ الطلب على الجهاز • في انتظار المزامنة عند رجوع الإنترنت")
        }

        batchTask.addOnSuccessListener {
            loadCustomerOrders(customer.id)
            val detail = "$orderNumber • ${items.size} تحليل • إجمالي ${formatNumber(finalTotal)} • خصم ${formatNumber(safeDiscount)}"
            logAudit("order_create", "order", order.id, "إنشاء طلب", detail, customerId = customer.id, orderId = order.id)
            addCustomerActivity(customer.id, "order", "طلب جديد $orderNumber", detail)
            if (!offlineAtStart) onResult(order, "تم حفظ الطلب $orderNumber")
        }.addOnFailureListener {
            if (!offlineAtStart) onResult(null, "تعذر حفظ الطلب. تأكد من صلاحيات Firebase")
            else _systemMessage.value = "تعذر مزامنة الطلب $orderNumber بعد عودة الإنترنت"
        }
    }

    /** V42 operational order status: independent from payment status. */
    fun updateOrderWorkflowStatus(
        customer: Customer,
        order: CustomerOrder,
        workflowStatus: String,
        onResult: (CustomerOrder?, String) -> Unit
    ) {
        if (order.isVoided) {
            onResult(null, tr("الطلب ملغي", "Order is voided"))
            return
        }
        val allowed = setOf("new", "sent_to_lab", "processing", "ready", "delivered")
        if (workflowStatus !in allowed) {
            onResult(null, tr("حالة الطلب غير صحيحة", "Invalid order status"))
            return
        }
        if (workflowStatus == order.workflowStatus) {
            onResult(order, tr("حالة الطلب بدون تغيير", "Order status unchanged"))
            return
        }
        val now = System.currentTimeMillis()
        val orderRef = firestore.collection(CUSTOMERS_COLLECTION)
            .document(customer.id).collection("orders").document(order.id)
        val updated = order.copy(
            workflowStatus = workflowStatus,
            updatedAtMillis = now,
            updatedByUid = currentUid(),
            editCount = order.editCount + 1
        )
        val statusAr = when (workflowStatus) {
            "sent_to_lab" -> "تم الإرسال للمعمل"
            "processing" -> "جاري التنفيذ"
            "ready" -> "النتائج جاهزة"
            "delivered" -> "تم التسليم"
            else -> "جديد"
        }
        val detail = "${order.orderNumber} • حالة التشغيل: $statusAr"
        queueOfflineAuditIfNeeded(
            action = "order_workflow_status",
            entityType = "order",
            entityId = order.id,
            title = "تحديث حالة الطلب",
            details = detail,
            customerId = customer.id,
            orderId = order.id
        )
        val offlineAtStart = !_isOnline.value
        val task = orderRef.update(
            mapOf(
                "workflow_status" to workflowStatus,
                "updated_at_ms" to now,
                "updated_at" to FieldValue.serverTimestamp(),
                "updated_by_uid" to currentUid(),
                "updated_by_email" to currentEmail(),
                "edit_count" to FieldValue.increment(1)
            )
        )
        if (offlineAtStart) {
            _customerOrders.value = _customerOrders.value.map { if (it.id == order.id) updated else it }
            addCustomerActivity(customer.id, "order_status", "تحديث حالة الطلب", detail)
            onResult(updated, "تم تحديث الحالة على الجهاز • في انتظار المزامنة")
        }
        task.addOnSuccessListener {
            _customerOrders.value = _customerOrders.value.map { if (it.id == order.id) updated else it }
            logAudit("order_workflow_status", "order", order.id, "تحديث حالة الطلب", detail, customerId = customer.id, orderId = order.id)
            if (!offlineAtStart) {
                addCustomerActivity(customer.id, "order_status", "تحديث حالة الطلب", detail)
                onResult(updated, "تم تحديث حالة الطلب")
            }
        }.addOnFailureListener {
            if (!offlineAtStart) onResult(null, tr("تعذر تحديث حالة الطلب", "Unable to update order status"))
            else _systemMessage.value = "تعذر مزامنة حالة ${order.orderNumber}"
        }
    }

    fun updateOrderFinancials(
        customer: Customer,
        order: CustomerOrder,
        discountAmount: Double,
        discountPercent: Double,
        paymentStatus: String,
        paidAmount: Double,
        notes: String,
        onResult: (CustomerOrder?, String) -> Unit
    ) {
        if (order.isVoided) {
            onResult(null, tr("الطلب ملغي ولا يمكن تعديله", "Voided order cannot be edited"))
            return
        }
        val subtotal = order.subtotalCustomerPrice
        val safePercent = discountPercent.coerceIn(0.0, 100.0)
        val safeDiscount = if (safePercent > 0.0) subtotal * safePercent / 100.0 else discountAmount.coerceIn(0.0, subtotal)
        val finalTotal = (subtotal - safeDiscount).coerceAtLeast(0.0)
        val normalizedStatus = when (paymentStatus) { "paid", "partial", "unpaid" -> paymentStatus; else -> "unpaid" }
        val safePaid = when (normalizedStatus) {
            "paid" -> finalTotal
            "partial" -> paidAmount.coerceIn(0.0, finalTotal)
            else -> 0.0
        }
        val remaining = (finalTotal - safePaid).coerceAtLeast(0.0)
        val now = System.currentTimeMillis()
        val orderRef = firestore.collection(CUSTOMERS_COLLECTION).document(customer.id).collection("orders").document(order.id)
        val changes = buildList {
            if (kotlin.math.abs(order.discountAmount - safeDiscount) > 0.001) add("الخصم ${formatNumber(order.discountAmount)} ← ${formatNumber(safeDiscount)}")
            if (kotlin.math.abs(order.paidAmount - safePaid) > 0.001) add("المدفوع ${formatNumber(order.paidAmount)} ← ${formatNumber(safePaid)}")
            if (order.paymentStatus != normalizedStatus) add("حالة الدفع ${order.paymentStatus} ← $normalizedStatus")
            if (order.notes.trim() != notes.trim()) add("تعديل الملاحظات")
        }.joinToString(" | ").ifBlank { tr("لا يوجد تغيير", "No changes") }

        queueOfflineAuditIfNeeded(
            action = "order_update",
            entityType = "order",
            entityId = order.id,
            title = "تعديل طلب ${order.orderNumber}",
            details = changes,
            customerId = customer.id,
            orderId = order.id
        )

        val offlineAtStart = !_isOnline.value
        val updatedOrder = order.copy(
            discountAmount = safeDiscount,
            discountPercent = if (subtotal > 0.0) safeDiscount / subtotal * 100.0 else 0.0,
            totalCustomerPrice = finalTotal,
            paymentStatus = normalizedStatus,
            paidAmount = safePaid,
            remainingAmount = remaining,
            notes = notes.trim(),
            updatedAtMillis = now,
            updatedByUid = currentUid(),
            editCount = order.editCount + 1
        )
        fun commitOrderUpdate() {
            val updateTask = orderRef.update(
                mapOf(
                    "discount_amount" to safeDiscount,
                    "discount_percent" to if (subtotal > 0.0) (safeDiscount / subtotal * 100.0) else 0.0,
                    "total_customer_price" to finalTotal,
                    "payment_status" to normalizedStatus,
                    "paid_amount" to safePaid,
                    "remaining_amount" to remaining,
                    "notes" to notes.trim(),
                    "updated_at_ms" to now,
                    "updated_at" to FieldValue.serverTimestamp(),
                    "updated_by_uid" to currentUid(),
                    "updated_by_email" to currentEmail(),
                    "edit_count" to FieldValue.increment(1)
                )
            )

            if (offlineAtStart) {
                _customerOrders.value = _customerOrders.value.map { if (it.id == order.id) updatedOrder else it }
                onResult(updatedOrder, "تم حفظ التعديل على الجهاز • في انتظار المزامنة")
            }

            updateTask.addOnSuccessListener {
                loadCustomerOrders(customer.id)
                logAudit("order_update", "order", order.id, "تعديل طلب ${order.orderNumber}", changes, customerId = customer.id, orderId = order.id)
                addCustomerActivity(customer.id, "order_update", "تعديل ${order.orderNumber}", changes)
                if (!offlineAtStart) onResult(updatedOrder, "تم تعديل الطلب مع تسجيل التغيير")
            }.addOnFailureListener {
                if (!offlineAtStart) onResult(null, tr("تعذر تعديل الطلب", "Unable to update order"))
                else _systemMessage.value = "تعذر مزامنة تعديل ${order.orderNumber}"
            }
        }

        if (!offlineAtStart) {
            orderRef.get(Source.SERVER)
                .addOnSuccessListener { serverDoc ->
                    val serverUpdated = serverDoc.getLong("updated_at_ms") ?: order.updatedAtMillis
                    if (serverUpdated > order.updatedAtMillis + 1L) {
                        onResult(null, tr("تم تعديل الطلب بواسطة مستخدم آخر. افتحه من جديد قبل الحفظ.", "This order was changed by another user. Reopen it before saving."))
                    } else {
                        commitOrderUpdate()
                    }
                }
                .addOnFailureListener {
                    onResult(null, tr("تعذر التحقق من أحدث نسخة للطلب", "Could not verify the latest order version"))
                }
        } else {
            commitOrderUpdate()
        }
    }

    fun collectOrderPayment(
        customer: Customer,
        order: CustomerOrder,
        amount: Double,
        note: String,
        onResult: (CustomerOrder?, String) -> Unit
    ) {
        if (order.isVoided) {
            onResult(null, tr("الطلب ملغي", "Order is voided"))
            return
        }
        val cleanAmount = amount.coerceAtLeast(0.0)
        if (cleanAmount <= 0.0) {
            onResult(null, tr("اكتب مبلغ التحصيل", "Enter payment amount"))
            return
        }
        val orderRef = firestore.collection(CUSTOMERS_COLLECTION).document(customer.id).collection("orders").document(order.id)
        val paymentRef = orderRef.collection("payments").document()
        val now = System.currentTimeMillis()
        val uid = currentUid()
        val email = currentEmail()

        val total = order.totalCustomerPrice
        val currentPaid = order.paidAmount
        val currentRemaining = order.remainingAmount.coerceAtLeast(0.0)
        if (currentRemaining <= 0.001) {
            onResult(null, tr("الطلب مدفوع بالكامل", "Order is fully paid"))
            return
        }
        if (cleanAmount > currentRemaining + 0.001) {
            onResult(null, tr("المبلغ أكبر من المتبقي", "Amount exceeds remaining balance"))
            return
        }
        val newPaid = (currentPaid + cleanAmount).coerceAtMost(total)
        val newRemaining = (total - newPaid).coerceAtLeast(0.0)
        val newStatus = when {
            newRemaining <= 0.001 -> "paid"
            newPaid > 0.0 -> "partial"
            else -> "unpaid"
        }
        val updated = order.copy(
            paidAmount = newPaid,
            remainingAmount = newRemaining,
            paymentStatus = newStatus,
            updatedAtMillis = now,
            updatedByUid = uid,
            editCount = order.editCount + 1
        )
        val detail = "${order.orderNumber} • تحصيل ${formatNumber(cleanAmount)} • المتبقي ${formatNumber(newRemaining)}"
        queueOfflineAuditIfNeeded("payment_collect", "payment", paymentRef.id, "تحصيل دفعة", detail, customerId = customer.id, orderId = order.id)
        val offlineAtStart = !_isOnline.value

        fun commitPaymentWrite() {
            val batchTask = firestore.runBatch { batch ->
                batch.update(
                    orderRef,
                    mapOf(
                        "paid_amount" to newPaid,
                        "remaining_amount" to newRemaining,
                        "payment_status" to newStatus,
                        "updated_at_ms" to now,
                        "updated_at" to FieldValue.serverTimestamp(),
                        "updated_by_uid" to uid,
                        "updated_by_email" to email,
                        "edit_count" to FieldValue.increment(1)
                    )
                )
                batch.set(
                    paymentRef,
                    mapOf(
                        "operation_id" to paymentRef.id,
                        "customer_id" to customer.id,
                        "order_id" to order.id,
                        "amount" to cleanAmount,
                        "note" to note.trim(),
                        "created_at_ms" to now,
                        "created_at" to FieldValue.serverTimestamp(),
                        "created_by_uid" to uid,
                        "created_by_email" to email
                    )
                )
            }

            if (offlineAtStart) {
                _customerOrders.value = _customerOrders.value.map { if (it.id == order.id) updated else it }
                addCustomerActivity(customer.id, "payment", "تحصيل دفعة", detail)
                onResult(updated, "تم تسجيل الدفعة على الجهاز • في انتظار المزامنة")
            }

            batchTask.addOnSuccessListener {
                loadCustomerOrders(customer.id)
                loadPaymentHistory(customer.id, order.id)
                logAudit("payment_collect", "payment", paymentRef.id, "تحصيل دفعة", detail, customerId = customer.id, orderId = order.id)
                if (!offlineAtStart) {
                    addCustomerActivity(customer.id, "payment", "تحصيل دفعة", detail)
                    onResult(updated, "تم تسجيل الدفعة")
                }
            }.addOnFailureListener {
                if (!offlineAtStart) onResult(null, tr("تعذر تسجيل الدفعة", "Unable to record payment"))
                else _systemMessage.value = "تعذر مزامنة دفعة ${order.orderNumber}"
            }
        }

        if (!offlineAtStart) {
            orderRef.get(Source.SERVER)
                .addOnSuccessListener { serverDoc ->
                    val serverUpdated = serverDoc.getLong("updated_at_ms") ?: order.updatedAtMillis
                    if (serverUpdated > order.updatedAtMillis + 1L) {
                        onResult(null, tr("بيانات الطلب اتغيرت عند مستخدم آخر. افتحه من جديد قبل التحصيل.", "The order changed on another device. Reopen it before collecting payment."))
                    } else {
                        commitPaymentWrite()
                    }
                }
                .addOnFailureListener {
                    onResult(null, tr("تعذر التحقق من أحدث نسخة للطلب", "Could not verify the latest order version"))
                }
        } else {
            commitPaymentWrite()
        }
    }

    fun loadPaymentHistory(customerId: String, orderId: String) {
        _paymentHistory.value = emptyList()
        if (customerId.isBlank() || orderId.isBlank()) return
        firestore.collection(CUSTOMERS_COLLECTION).document(customerId)
            .collection("orders").document(orderId)
            .collection("payments")
            .orderBy("created_at_ms", Query.Direction.DESCENDING)
            .limit(PAYMENT_HISTORY_LIMIT)
            .get()
            .addOnSuccessListener { snapshot ->
                _paymentHistory.value = snapshot.documents.map { doc ->
                    PaymentEntry(
                        id = doc.id,
                        customerId = doc.getString("customer_id").orEmpty().ifBlank { customerId },
                        orderId = doc.getString("order_id").orEmpty().ifBlank { orderId },
                        amount = numberAsDouble(doc.get("amount")),
                        note = doc.getString("note").orEmpty(),
                        createdAtMillis = doc.getLong("created_at_ms") ?: 0L,
                        createdByUid = doc.getString("created_by_uid").orEmpty(),
                        createdByEmail = doc.getString("created_by_email").orEmpty()
                    )
                }.sortedByDescending { it.createdAtMillis }
            }
    }

    fun voidOrder(customer: Customer, order: CustomerOrder, reason: String, onResult: (Boolean, String) -> Unit) {
        if (!hasAdminAccess()) {
            onResult(false, tr("إلغاء الطلب متاح للمدير فقط", "Voiding orders is manager only"))
            return
        }
        if (reason.trim().length < 3) {
            onResult(false, tr("اكتب سبب الإلغاء", "Enter void reason"))
            return
        }
        val now = System.currentTimeMillis()
        queueOfflineAuditIfNeeded(
            action = "order_void",
            entityType = "order",
            entityId = order.id,
            title = "إلغاء طلب ${order.orderNumber}",
            details = reason.trim(),
            customerId = customer.id,
            orderId = order.id
        )
        privilegedFirestore().collection(CUSTOMERS_COLLECTION).document(customer.id).collection("orders").document(order.id)
            .update(
                mapOf(
                    "is_voided" to true,
                    "void_reason" to reason.trim(),
                    "voided_at_ms" to now,
                    "voided_by_uid" to currentUid(),
                    "updated_at_ms" to now,
                    "updated_at" to FieldValue.serverTimestamp(),
                    "updated_by_uid" to currentUid()
                )
            )
            .addOnSuccessListener {
                loadCustomerOrders(customer.id)
                logAudit("order_void", "order", order.id, "إلغاء طلب ${order.orderNumber}", reason.trim(), customerId = customer.id, orderId = order.id)
                addCustomerActivity(customer.id, "order_void", "إلغاء ${order.orderNumber}", reason.trim())
                onResult(true, "تم إلغاء الطلب مع الاحتفاظ به في سجل المراجعة")
            }
            .addOnFailureListener { onResult(false, tr("تعذر إلغاء الطلب", "Unable to void order")) }
    }

    // ------------------------- REPORTS -------------------------

    fun loadManagerHomeSummary(onResult: ((Boolean, String) -> Unit)? = null) {
        if (!hasAdminAccess()) {
            onResult?.invoke(false, tr("لوحة المدير متاحة للمدير فقط", "Manager dashboard is manager only"))
            return
        }
        if (_managerHomeLoading.value) return
        _managerHomeLoading.value = true

        val calendar = java.util.Calendar.getInstance().apply {
            set(java.util.Calendar.HOUR_OF_DAY, 0)
            set(java.util.Calendar.MINUTE, 0)
            set(java.util.Calendar.SECOND, 0)
            set(java.util.Calendar.MILLISECOND, 0)
        }
        val startToday = calendar.timeInMillis

        // Fast path: read only today's orders and orders that still carry debt instead of downloading
        // the entire historical order collection every time the manager opens the dashboard.
        val todayQuery = privilegedFirestore().collectionGroup("orders")
            .whereGreaterThanOrEqualTo("created_at_ms", startToday)
            .orderBy("created_at_ms", Query.Direction.DESCENDING)

        todayQuery.get(Source.SERVER)
            .addOnSuccessListener { todaySnapshot ->
                val todayOrders = todaySnapshot.documents.mapNotNull { doc ->
                    val customerId = doc.reference.parent.parent?.id.orEmpty()
                    parseOrder(doc, customerId)
                }.filterNot { it.isVoided }

                val allOrdersQuery = privilegedFirestore().collectionGroup("orders")
                    .orderBy("created_at_ms", Query.Direction.DESCENDING)

                loadManagerRemainingPages(
                    baseQuery = allOrdersQuery,
                    cursor = null,
                    runningRemaining = 0.0,
                    onSuccess = { totalRemaining ->
                        _managerHomeSummary.value = ReportSummary(
                            ordersCount = todayOrders.size,
                            customersCount = todayOrders.map { it.customerId }.filter { it.isNotBlank() }.distinct().size,
                            paid = todayOrders.sumOf { it.paidAmount },
                            remaining = totalRemaining
                        )
                        _managerHomeLoading.value = false
                        rebuildAdminAlerts()
                        onResult?.invoke(true, tr("تم تحديث لوحة المدير بسرعة", "Manager dashboard refreshed"))
                    },
                    onFailure = { loadManagerHomeSummaryLegacy(onResult) }
                )
            }
            .addOnFailureListener {
                loadManagerHomeSummaryLegacy(onResult)
            }
    }


    private fun loadManagerRemainingPages(
        baseQuery: Query,
        cursor: DocumentSnapshot?,
        runningRemaining: Double,
        onSuccess: (Double) -> Unit,
        onFailure: () -> Unit
    ) {
        val pageQuery = (cursor?.let { baseQuery.startAfter(it) } ?: baseQuery).limit(SERVER_PAGE_SIZE)
        pageQuery.get(Source.SERVER)
            .addOnSuccessListener { snapshot ->
                val pageRemaining = snapshot.documents.mapNotNull { doc ->
                    val customerId = doc.reference.parent.parent?.id.orEmpty()
                    parseOrder(doc, customerId)
                }.filterNot { it.isVoided }.sumOf { it.remainingAmount }
                val total = runningRemaining + pageRemaining
                if (snapshot.size().toLong() < SERVER_PAGE_SIZE || snapshot.documents.isEmpty()) {
                    onSuccess(total)
                } else {
                    loadManagerRemainingPages(baseQuery, snapshot.documents.last(), total, onSuccess, onFailure)
                }
            }
            .addOnFailureListener { onFailure() }
    }

    private fun loadManagerHomeSummaryLegacy(onResult: ((Boolean, String) -> Unit)? = null) {
        // Safe fallback for projects where the new collection-group indexes have not been deployed yet.
        privilegedFirestore().collectionGroup("orders").get(Source.SERVER)
            .addOnSuccessListener { snapshot ->
                val allOrders = snapshot.documents.mapNotNull { doc ->
                    val customerId = doc.reference.parent.parent?.id.orEmpty()
                    parseOrder(doc, customerId)
                }.filterNot { it.isVoided }

                val calendar = java.util.Calendar.getInstance().apply {
                    set(java.util.Calendar.HOUR_OF_DAY, 0)
                    set(java.util.Calendar.MINUTE, 0)
                    set(java.util.Calendar.SECOND, 0)
                    set(java.util.Calendar.MILLISECOND, 0)
                }
                val startToday = calendar.timeInMillis
                val todayOrders = allOrders.filter { it.createdAtMillis >= startToday }

                _managerHomeSummary.value = ReportSummary(
                    ordersCount = todayOrders.size,
                    customersCount = todayOrders.map { it.customerId }.filter { it.isNotBlank() }.distinct().size,
                    paid = todayOrders.sumOf { it.paidAmount },
                    remaining = allOrders.sumOf { it.remainingAmount }
                )
                _managerHomeLoading.value = false
                rebuildAdminAlerts()
                onResult?.invoke(true, tr("تم تحديث لوحة المدير", "Manager dashboard refreshed"))
            }
            .addOnFailureListener {
                _managerHomeLoading.value = false
                onResult?.invoke(false, tr("تعذر تحديث ملخص لوحة المدير", "Unable to refresh manager dashboard"))
            }
    }

    fun loadReports(fromMillis: Long, toMillis: Long, onResult: ((Boolean, String) -> Unit)? = null) {
        if (!hasAdminAccess()) {
            onResult?.invoke(false, tr("التقارير والحسابات العامة متاحة للمدير فقط", "Global reports and accounts are manager only"))
            return
        }
        if (_reportsLoading.value) return
        _reportsLoading.value = true

        val baseQuery = privilegedFirestore().collectionGroup("orders")
            .whereGreaterThanOrEqualTo("created_at_ms", fromMillis)
            .whereLessThanOrEqualTo("created_at_ms", toMillis)
            .orderBy("created_at_ms", Query.Direction.DESCENDING)

        loadReportPages(
            baseQuery = baseQuery,
            cursor = null,
            collected = mutableListOf(),
            onSuccess = { documents ->
                _reportOrders.value = documents.mapNotNull { doc ->
                    val customerId = doc.reference.parent.parent?.id.orEmpty()
                    parseOrder(doc, customerId)
                }.filterNot { it.isVoided }.sortedByDescending { it.createdAtMillis }
                _reportsLoading.value = false
                onResult?.invoke(true, tr("تم تحميل التقرير", "Report loaded"))
            },
            onFailure = {
                loadReportsLegacy(fromMillis, toMillis, onResult)
            }
        )
    }

    private fun loadReportPages(
        baseQuery: Query,
        cursor: DocumentSnapshot?,
        collected: MutableList<DocumentSnapshot>,
        onSuccess: (List<DocumentSnapshot>) -> Unit,
        onFailure: () -> Unit
    ) {
        val pageQuery = (cursor?.let { baseQuery.startAfter(it) } ?: baseQuery).limit(SERVER_PAGE_SIZE)
        pageQuery.get(Source.SERVER)
            .addOnSuccessListener { snapshot ->
                collected.addAll(snapshot.documents)
                if (snapshot.size().toLong() < SERVER_PAGE_SIZE || snapshot.documents.isEmpty()) {
                    onSuccess(collected)
                } else {
                    loadReportPages(baseQuery, snapshot.documents.last(), collected, onSuccess, onFailure)
                }
            }
            .addOnFailureListener { onFailure() }
    }

    private fun loadReportsLegacy(
        fromMillis: Long,
        toMillis: Long,
        onResult: ((Boolean, String) -> Unit)? = null
    ) {
        privilegedFirestore().collectionGroup("orders").get(Source.SERVER)
            .addOnSuccessListener { snapshot ->
                _reportOrders.value = snapshot.documents.mapNotNull { doc ->
                    val created = doc.getLong("created_at_ms") ?: 0L
                    if (created !in fromMillis..toMillis) return@mapNotNull null
                    val customerId = doc.reference.parent.parent?.id.orEmpty()
                    parseOrder(doc, customerId)
                }.filterNot { it.isVoided }.sortedByDescending { it.createdAtMillis }
                _reportsLoading.value = false
                onResult?.invoke(true, tr("تم تحميل التقرير", "Report loaded"))
            }
            .addOnFailureListener {
                _reportsLoading.value = false
                onResult?.invoke(false, tr("تعذر تحميل التقارير. تأكد من Firestore Rules", "Unable to load reports. Check Firestore Rules"))
            }
    }

    fun calculateReportSummary(orders: List<CustomerOrder> = _reportOrders.value): ReportSummary {
        val valid = orders.filterNot { it.isVoided }
        val subtotal = valid.sumOf { it.subtotalCustomerPrice }
        val discounts = valid.sumOf { it.discountAmount }
        val sales = valid.sumOf { it.totalCustomerPrice }
        val paid = valid.sumOf { it.paidAmount }
        val remaining = valid.sumOf { it.remainingAmount }
        val estimatedCost = if (hasAdminAccess()) {
            valid.sumOf { order ->
                order.items.sumOf { item -> parsePriceInput(_lab2LabPrices.value[item.testId].orEmpty()) ?: 0.0 }
            }
        } else 0.0
        return ReportSummary(
            ordersCount = valid.size,
            customersCount = valid.map { it.customerId }.filter { it.isNotBlank() }.distinct().size,
            subtotal = subtotal,
            discounts = discounts,
            sales = sales,
            paid = paid,
            remaining = remaining,
            estimatedLabCost = estimatedCost,
            estimatedProfit = if (hasAdminAccess()) sales - estimatedCost else 0.0
        )
    }

    // ------------------------- AUDIT -------------------------

    fun loadAuditLogs(onResult: ((Boolean, String) -> Unit)? = null) {
        if (!hasAdminAccess()) {
            onResult?.invoke(false, tr("سجل المراجعة متاح للمدير فقط", "Audit log is manager only"))
            return
        }
        privilegedFirestore().collection(AUDIT_COLLECTION)
            .orderBy("created_at_ms", Query.Direction.DESCENDING)
            .limit(AUDIT_LOG_LIMIT)
            .get(Source.SERVER)
            .addOnSuccessListener { snapshot ->
                _auditLogs.value = snapshot.documents.map { doc ->
                    AuditLogEntry(
                        id = doc.id,
                        action = doc.getString("action").orEmpty(),
                        entityType = doc.getString("entity_type").orEmpty(),
                        entityId = doc.getString("entity_id").orEmpty(),
                        customerId = doc.getString("customer_id").orEmpty(),
                        orderId = doc.getString("order_id").orEmpty(),
                        title = doc.getString("title").orEmpty(),
                        details = doc.getString("details").orEmpty(),
                        actorUid = doc.getString("actor_uid").orEmpty(),
                        actorEmail = doc.getString("actor_email").orEmpty(),
                        createdAtMillis = doc.getLong("performed_at_ms") ?: doc.getLong("created_at_ms") ?: 0L,
                        syncedAtMillis = doc.getTimestamp("synced_at")?.toDate()?.time ?: 0L,
                        wasOffline = doc.getBoolean("was_offline") == true
                    )
                }.sortedByDescending { it.createdAtMillis }.take(AUDIT_LOG_LIMIT.toInt())
                rebuildAdminAlerts()
                onResult?.invoke(true, "تم تحديث سجل المراجعة")
            }
            .addOnFailureListener { onResult?.invoke(false, tr("تعذر تحميل سجل المراجعة", "Unable to load audit log")) }
    }

    private fun auditKey(action: String, entityId: String, orderId: String): String =
        "$action|$entityId|$orderId"

    private fun queueOfflineAuditIfNeeded(
        action: String,
        entityType: String,
        entityId: String,
        title: String,
        details: String,
        customerId: String = "",
        orderId: String = ""
    ) {
        if (_isOnline.value) return
        val now = System.currentTimeMillis()
        pendingOfflineAuditKeys += auditKey(action, entityId, orderId)
        pendingSyncStore.increment()
        val auditRef = firestore.collection(AUDIT_COLLECTION).document()
        auditRef.set(
            mapOf(
                "operation_id" to auditRef.id,
                "action" to "${action}_offline",
                "entity_type" to entityType,
                "entity_id" to entityId,
                "customer_id" to customerId,
                "order_id" to orderId,
                "title" to "Offline • $title",
                "details" to details.take(2000),
                "actor_uid" to currentUid(),
                "actor_email" to currentEmail(),
                "performed_at_ms" to now,
                "created_at_ms" to now,
                "was_offline" to true,
                "synced_at" to FieldValue.serverTimestamp()
            )
        )
    }

    private fun logAudit(
        action: String,
        entityType: String,
        entityId: String,
        title: String,
        details: String,
        customerId: String = "",
        orderId: String = ""
    ) {
        val key = auditKey(action, entityId, orderId)
        if (pendingOfflineAuditKeys.remove(key)) return
        val now = System.currentTimeMillis()
        val auditRef = firestore.collection(AUDIT_COLLECTION).document()
        auditRef.set(
            mapOf(
                "operation_id" to auditRef.id,
                "action" to action,
                "entity_type" to entityType,
                "entity_id" to entityId,
                "customer_id" to customerId,
                "order_id" to orderId,
                "title" to title,
                "details" to details.take(2000),
                "actor_uid" to currentUid(),
                "actor_email" to currentEmail(),
                "performed_at_ms" to now,
                "created_at_ms" to now,
                "created_at" to FieldValue.serverTimestamp(),
                "was_offline" to false,
                "synced_at" to FieldValue.serverTimestamp()
            )
        )
    }

    // ------------------------- SEARCH / SELECTION -------------------------

    fun clearSelectedTests() {
        _selectedTests.value = emptyList()
        clearSearch()
    }

    private fun parseQueries(rawInput: String): List<String> {
        if (rawInput.isBlank()) return emptyList()
        val delimiterRegex = Regex("[\\n,،;؛]+")
        val rawTokens = rawInput.split(delimiterRegex)
        val seenNorm = mutableSetOf<String>()
        val result = mutableListOf<String>()
        for (token in rawTokens) {
            val trimmed = token.trim()
            if (trimmed.isEmpty()) continue
            val norm = normalizeText(trimmed)
            if (norm.isNotEmpty() && seenNorm.add(norm)) result.add(trimmed)
        }
        return result
    }

    fun onQueryChanged(newQuery: String) {
        _searchQuery.value = newQuery
        val trimmedInput = newQuery.trim()
        if (trimmedInput.isEmpty()) {
            _uiState.value = SearchUiState.EmptyQuery
            return
        }

        viewModelScope.launch(Dispatchers.Default) {
            val queries = parseQueries(newQuery)
            if (queries.isEmpty()) {
                _uiState.value = SearchUiState.EmptyQuery
                return@launch
            }
            val selectedIds = _selectedTests.value.map { it.id }.toSet()
            val queryGroups = mutableListOf<QueryGroup>()
            val unmatchedQueries = mutableListOf<String>()
            for (q in queries) {
                val matches = repository.searchTests(q).filter { it.id !in selectedIds }
                if (matches.isNotEmpty()) queryGroups.add(QueryGroup(query = q, candidates = matches))
                else unmatchedQueries.add(q)
            }
            _uiState.value = if (queryGroups.isEmpty()) {
                SearchUiState.NoResults(unmatchedQueries = unmatchedQueries)
            } else {
                SearchUiState.Success(query = newQuery, queryGroups = queryGroups, unmatchedQueries = unmatchedQueries)
            }
        }
    }

    /**
     * V40: Match OCR text from a lab request image/PDF against the local catalogue.
     * We deliberately return catalogue objects (not raw OCR strings) so the normal
     * search UI can present exact English test names for human review before selection.
     */
    fun detectTestsFromRecognizedText(rawText: String): List<LabTest> {
        if (rawText.isBlank()) return emptyList()

        val normalizedDocument = normalizeText(rawText.replace('\n', ' '))
        if (normalizedDocument.isBlank()) return emptyList()
        val paddedDocument = " $normalizedDocument "
        val documentTokens = normalizedDocument.split(' ').filter { it.isNotBlank() }.toSet()

        data class PositionedTest(val test: LabTest, val position: Int)
        val positioned = mutableListOf<PositionedTest>()

        for (test in repository.getLabTests()) {
            val aliases = linkedSetOf(test.normEnglish, test.normMarket)
                .filter { it.isNotBlank() }

            var bestPosition = Int.MAX_VALUE
            for (alias in aliases) {
                val compact = alias.trim()
                if (compact.isBlank()) continue

                val isSingleToken = !compact.contains(' ')
                val acceptableShortToken = compact.length >= 3 || compact.any { it.isDigit() }
                val found = if (isSingleToken) {
                    acceptableShortToken && compact in documentTokens
                } else {
                    paddedDocument.contains(" $compact ")
                }

                if (found) {
                    val pos = normalizedDocument.indexOf(compact).takeIf { it >= 0 } ?: Int.MAX_VALUE
                    if (pos < bestPosition) bestPosition = pos
                }
            }

            if (bestPosition != Int.MAX_VALUE) positioned += PositionedTest(test, bestPosition)
        }

        // Extra pass: OCR often places one abbreviation/name on its own line. Exact
        // catalogue search catches punctuation variants such as ALT(SGPT), TSH, HbA1c.
        val segments = rawText
            .split(Regex("[\n,،;؛•|]+"))
            .map { it.trim() }
            .filter { it.length in 2..120 }

        val already = positioned.map { it.test.id }.toMutableSet()
        for ((index, segment) in segments.withIndex()) {
            val norm = normalizeText(segment)
            if (norm.isBlank()) continue
            val searchMatches = repository.searchTests(segment)
            val exact = searchMatches.firstOrNull { candidate ->
                candidate.normEnglish == norm || candidate.normMarket == norm || candidate.normArabic == norm
            } ?: searchMatches.singleOrNull { candidate ->
                norm.length >= 3 && candidate.normSearch.split(' ').any { it == norm }
            }
            if (exact != null && already.add(exact.id)) {
                positioned += PositionedTest(exact, normalizedDocument.indexOf(norm).takeIf { it >= 0 } ?: (100000 + index))
            }
        }

        // Abbreviations are often printed beside each other (e.g. CBC ESR CRP HbA1c).
        // Accept a single OCR token only when it uniquely resolves in the catalogue.
        for ((index, token) in normalizedDocument.split(' ').withIndex()) {
            if (token.length < 3 || token.all { it.isDigit() }) continue
            val matches = repository.searchTests(token)
            val unique = matches.singleOrNull { candidate ->
                candidate.normEnglish == token ||
                    candidate.normMarket == token ||
                    candidate.normSearch.split(' ').any { it == token }
            }
            if (unique != null && already.add(unique.id)) {
                positioned += PositionedTest(unique, index)
            }
        }

        return positioned
            .distinctBy { it.test.id }
            .sortedWith(compareBy<PositionedTest> { it.position }.thenBy { it.test.id })
            .take(100)
            .map { it.test }
    }

    fun applyRecognizedTestsToSearch(rawText: String): Int {
        val detected = detectTestsFromRecognizedText(rawText)
        if (detected.isEmpty()) return 0
        onQueryChanged(detected.joinToString("\n") { it.englishName })
        return detected.size
    }

    fun addSelectedTest(test: LabTest) {
        if (_selectedTests.value.none { it.id == test.id }) {
            _selectedTests.value = _selectedTests.value + test
        }
        val current = _searchQuery.value.trim()
        if (current.isNotBlank()) settingsStore.addRecentSearch(current)
        clearSearch()
    }

    /** V42: Load the tests from a previous order back into the active order workspace. */
    fun prepareRepeatOrder(order: CustomerOrder): Int {
        val ids = order.items.map { it.testId }.toSet()
        val matched = repository.getLabTests().filter { it.id in ids }
        _selectedTests.value = matched
        clearSearch()
        return matched.size
    }

    fun removeSelectedTest(testId: Int) {
        _selectedTests.value = _selectedTests.value.filter { it.id != testId }
        if (_searchQuery.value.isNotEmpty()) onQueryChanged(_searchQuery.value)
    }

    fun clearSearch() {
        _searchQuery.value = ""
        _uiState.value = SearchUiState.EmptyQuery
    }

    // ------------------------- HELPERS -------------------------

    private fun loadManagerPricesFromAsset(): Map<Int, String> {
        return try {
            val json = getApplication<Application>().assets
                .open("manager_lab2lab_prices.json")
                .bufferedReader(Charsets.UTF_8)
                .use { it.readText() }
            val array = JSONArray(json)
            buildMap {
                for (i in 0 until array.length()) {
                    val item = array.getJSONObject(i)
                    val id = item.optInt("id", -1)
                    if (id <= 0 || item.isNull("lab_to_lab_price")) continue
                    val formatted = formatFirestorePrice(item.get("lab_to_lab_price"))
                    if (!formatted.isNullOrBlank()) put(id, formatted)
                }
            }
        } catch (_: Exception) {
            emptyMap()
        }
    }

    private fun documentTestId(documentId: String, fallbackId: Int?): Int? =
        documentId.removePrefix("test_").toIntOrNull() ?: fallbackId

    private fun parsePriceInput(value: String): Double? {
        val normalized = value.trim().replace(",", "").replace(tr("جنيه", "EGP"), "", ignoreCase = true).trim()
        return normalized.toDoubleOrNull()
    }

    private fun formatNumber(value: Double): String =
        if (value % 1.0 == 0.0) value.toLong().toString() else String.format(Locale.US, "%.2f", value).trimEnd('0').trimEnd('.')

    private fun formatFirestorePrice(value: Any?): String? = when (value) {
        null -> null
        is Byte, is Short, is Int, is Long -> value.toString()
        is Float -> formatNumber(value.toDouble())
        is Double -> formatNumber(value)
        is Number -> value.toString()
        else -> value.toString().trim().takeIf { it.isNotEmpty() && !it.equals("null", true) }
    }

    private fun numberAsDouble(value: Any?): Double = when (value) {
        is Number -> value.toDouble()
        else -> value?.toString()?.toDoubleOrNull() ?: 0.0
    }

    private fun normalizePhone(value: String): String = value.filter { it.isDigit() }

    private fun generateFileNumber(now: Long): String {
        val date = SimpleDateFormat("yyMMdd-HHmmss", Locale.US).format(Date(now))
        val suffix = (now % 1000).toString().padStart(3, '0')
        return "AK-$date-$suffix"
    }

    private fun generateOrderNumber(now: Long, documentId: String): String {
        val date = SimpleDateFormat("yyMMdd-HHmmss", Locale.US).format(Date(now))
        val suffix = documentId.takeLast(4).uppercase(Locale.US)
        return "ORD-$date-$suffix"
    }

    private fun currentUid(): String = FirebaseAuth.getInstance().currentUser?.uid.orEmpty()
    private fun currentEmail(): String = FirebaseAuth.getInstance().currentUser?.email.orEmpty()
}
