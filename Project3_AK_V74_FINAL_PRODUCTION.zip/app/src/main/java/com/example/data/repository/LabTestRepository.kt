package com.example.data.repository

import android.content.Context
import com.example.data.model.LabTest
import com.example.data.model.normalizeText
import org.json.JSONArray
import java.io.InputStreamReader
import kotlin.math.abs

class LabTestRepository(private val context: Context) {

    @Volatile
    private var cachedTests: List<LabTest>? = null

    fun getLabTests(): List<LabTest> {
        cachedTests?.let { return it }

        return synchronized(this) {
            cachedTests?.let { return@synchronized it }

            val testsList = mutableListOf<LabTest>()
            try {
                val inputStream = context.assets.open("lab_tests_android.json")
                val jsonString = InputStreamReader(inputStream, Charsets.UTF_8).use { it.readText() }
                val jsonArray = JSONArray(jsonString)

                for (i in 0 until jsonArray.length()) {
                    val obj = jsonArray.getJSONObject(i)
                    val id = obj.optInt("id")
                    val englishName = obj.optString("english_name", "")
                    val arabicName = obj.optString("arabic_name", "")
                    val marketName = obj.optString("market_name", "")
                    val searchText = obj.optString("search_text", "")

                    val customerPriceRaw = if (obj.isNull("customer_price")) null else obj.get("customer_price").toString()
                    val customerPrice = formatPrice(customerPriceRaw)

                    testsList.add(
                        LabTest(
                            id = id,
                            englishName = englishName,
                            arabicName = arabicName,
                            marketName = marketName,
                            customerPrice = customerPrice,
                            searchText = searchText
                        )
                    )
                }
            } catch (_: Exception) {
                // Do not emit dataset details or stack traces in release logs.
            }

            cachedTests = testsList
            testsList
        }
    }

    private fun formatPrice(priceStr: String?): String? {
        if (priceStr.isNullOrBlank() || priceStr.equals("null", ignoreCase = true)) return null
        return priceStr.trim()
    }

    private data class AliasRule(
        val keys: List<String>,
        val targets: List<String>
    )

    /**
     * Existing clinic vocabulary from V66, now also typo-tolerant in V68.
     * Short medical abbreviations (ALT/AST/HCV/HBV...) remain exact-only so
     * one abbreviation cannot accidentally resolve to a different one.
     */
    private val aliasRules = listOf(
        AliasRule(listOf("rbs", "random blood sugar", "random sugar", "سكر عشوائي"), listOf("Glucose Random")),
        AliasRule(listOf("fbs", "fasting blood sugar", "fasting sugar", "سكر صائم", "سكر صايم"), listOf("Blood Glucose Fasting")),
        AliasRule(listOf("hba1c", "hb a1c", "a1c", "سكر تراكمي"), listOf("Glycated Haemoglobin (HbA1c)")),
        AliasRule(listOf("sgpt", "alt"), listOf("ALT (SGPT)")),
        AliasRule(listOf("sgot", "ast"), listOf("AST (SGOT)")),
        AliasRule(listOf("inr"), listOf("Prothrombin Time & Conc")),
        AliasRule(listOf("blood group", "blood grouping", "فصيله دم"), listOf("ABO", "Rh")),
        AliasRule(
            listOf("وظائف كبد", "انزيم كبد", "انزيمات كبد", "lft", "liver function", "liver functions"),
            listOf("ALT (SGPT)", "AST (SGOT)")
        ),
        AliasRule(
            listOf("وظائف كلي", "وظائف كليه", "kft", "kidney function", "kidney functions", "renal function", "renal functions"),
            listOf("Creatinine", "Blood Urea")
        ),
        AliasRule(listOf("hbv", "hepatitis b"), listOf("HBs Ag")),
        AliasRule(listOf("hcv", "hepatitis c"), listOf("HCV Ab")),
        AliasRule(listOf("hiv", "aids"), listOf("HIV Ab")),
        AliasRule(listOf("vit d", "vitamin d", "فيتامين د"), listOf("Vit D3 (25 Hydroxycholecalciferol)")),
        AliasRule(listOf("b12", "vit b12", "vitamin b12", "فيتامين ب12"), listOf("VIT B12 (Cyanocobalamine)")),
        AliasRule(listOf("مخزون حديد", "ferritin"), listOf("Ferritin")),
        AliasRule(listOf("lipid profile", "lipids profile", "تحليل دهون", "دهون كامله"), listOf("Lipids Profile")),
        AliasRule(listOf("وظائف غده درقيه", "thyroid function", "thyroid functions", "tft"), listOf("TSH", "Free T4"))
    )

    private fun aliasTargets(normQuery: String): List<String>? {
        val q = removeArabicArticles(normQuery)
        if (q.isBlank()) return null

        // Exact aliases always win.
        aliasRules.firstOrNull { rule ->
            rule.keys.any { alias -> removeArabicArticles(normalizeText(alias)) == q }
        }?.let { return it.targets }

        // V68: tolerate small spelling mistakes in long aliases as well.
        // Example: "وظايف كلي" still resolves to kidney-function tests.
        val best = aliasRules.mapNotNull { rule ->
            val score = rule.keys.mapNotNull { alias ->
                fuzzyPhraseDistance(q, removeArabicArticles(normalizeText(alias)))
            }.minOrNull()
            score?.let { rule to it }
        }.minByOrNull { it.second }

        return best?.first?.targets
    }

    private fun removeArabicArticles(value: String): String {
        if (value.isBlank()) return value
        return value.split(" ")
            .joinToString(" ") { token ->
                if (token.startsWith("ال") && token.length > 3) token.removePrefix("ال") else token
            }
            .trim()
    }

    /**
     * V69: compact Latin medical names for exact comparison only.
     * This makes spacing/punctuation irrelevant for abbreviations such as:
     * HBsAg == HBs Ag == HBs-Ag, without enabling broad fuzzy matching
     * for short medical abbreviations.
     */
    private fun compactLatinKey(normalizedValue: String): String? {
        if (normalizedValue.isBlank()) return null
        val isLatinMedical = normalizedValue.all { ch ->
            ch == ' ' || ch in 'a'..'z' || ch.isDigit()
        }
        if (!isLatinMedical) return null
        return normalizedValue.filter { it in 'a'..'z' || it.isDigit() }
            .takeIf { it.length >= 3 }
    }

    private fun resolveExactCatalogueNames(names: List<String>, allTests: List<LabTest>): List<LabTest> {
        val wanted = names.map(::normalizeText)
        return wanted.mapNotNull { target ->
            allTests.firstOrNull { test ->
                test.normEnglish == target || test.normMarket == target || test.normArabic == target
            }
        }.distinctBy { it.id }
    }

    private fun isArabicToken(token: String): Boolean =
        token.any { it in '\u0600'..'\u06FF' }

    /**
     * Conservative typo tolerance:
     * - Arabic 3-6 letters: one edit.
     * - Arabic 7-10 letters: two edits.
     * - Very short Latin medical abbreviations stay exact-only.
     */
    private fun maxFuzzyDistance(token: String): Int {
        if (token.isBlank()) return 0
        return if (isArabicToken(token)) {
            when {
                token.length <= 2 -> 0
                token.length <= 6 -> 1
                token.length <= 10 -> 2
                else -> 3
            }
        } else {
            when {
                token.length <= 4 -> 0
                token.length <= 7 -> 1
                token.length <= 11 -> 2
                else -> 3
            }
        }
    }

    /**
     * Arabic token variants used only for search comparison. We do not change
     * the stored catalogue text. Common regular plural suffixes are removed so
     * "فيروسات" and "فيرسات" can still reach "فيروس".
     *
     * Candidate tokens may also lose a common attached preposition such as the
     * leading ل in "لفيروس". Query tokens do not get this aggressive prefix
     * stripping, which keeps false positives down.
     */
    private fun tokenVariants(token: String, allowAttachedPrefix: Boolean): List<String> {
        if (token.isBlank()) return emptyList()

        val variants = linkedSetOf(token)
        var changed = true
        while (changed && variants.size < 12) {
            changed = false
            val snapshot = variants.toList()
            for (value in snapshot) {
                if (value.startsWith("ال") && value.length > 4) {
                    changed = variants.add(value.removePrefix("ال")) || changed
                }

                if (allowAttachedPrefix && value.length >= 6 && value.first() in listOf('ل', 'ب', 'و', 'ك')) {
                    changed = variants.add(value.drop(1)) || changed
                }

                for (suffix in listOf("ات", "ون", "ين")) {
                    if (value.endsWith(suffix) && value.length - suffix.length >= 3) {
                        changed = variants.add(value.dropLast(suffix.length)) || changed
                    }
                }
            }
        }
        return variants.toList()
    }

    private fun editDistance(a: String, b: String): Int {
        if (a == b) return 0
        if (a.isEmpty()) return b.length
        if (b.isEmpty()) return a.length

        var previous = IntArray(b.length + 1) { it }
        var current = IntArray(b.length + 1)

        for (i in 1..a.length) {
            current[0] = i
            for (j in 1..b.length) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                current[j] = minOf(
                    current[j - 1] + 1,
                    previous[j] + 1,
                    previous[j - 1] + cost
                )
            }
            val swap = previous
            previous = current
            current = swap
        }
        return previous[b.length]
    }

    private fun fuzzyTokenDistance(queryToken: String, candidateToken: String): Int? {
        var best: Int? = null

        for (queryVariant in tokenVariants(queryToken, allowAttachedPrefix = false)) {
            val maxDistance = maxFuzzyDistance(queryVariant)
            for (candidateVariant in tokenVariants(candidateToken, allowAttachedPrefix = true)) {
                if (queryVariant == candidateVariant) return 0
                if (maxDistance == 0) continue
                if (abs(queryVariant.length - candidateVariant.length) > maxDistance) continue

                val distance = editDistance(queryVariant, candidateVariant)
                if (distance <= maxDistance && (best == null || distance < best)) {
                    best = distance
                }
            }
        }
        return best
    }

    private fun fuzzyPhraseDistance(queryPhrase: String, candidatePhrase: String): Int? {
        val queryTokens = queryPhrase.split(" ").filter { it.isNotBlank() }
        val candidateTokens = candidatePhrase.split(" ").filter { it.isNotBlank() }
        if (queryTokens.isEmpty() || queryTokens.size != candidateTokens.size) return null

        var total = 0
        for (index in queryTokens.indices) {
            val distance = fuzzyTokenDistance(queryTokens[index], candidateTokens[index]) ?: return null
            total += distance
        }
        return total
    }

    private fun fuzzyCatalogueDistance(queryPhrase: String, candidateFields: List<String>): Int? {
        val queryTokens = queryPhrase.split(" ").filter { it.isNotBlank() }
        if (queryTokens.isEmpty()) return null

        val candidateTokens = linkedSetOf<String>()
        candidateFields.forEach { field ->
            removeArabicArticles(field)
                .split(" ")
                .filterTo(candidateTokens) { it.isNotBlank() }
        }
        if (candidateTokens.isEmpty()) return null

        var totalDistance = 0
        for (queryToken in queryTokens) {
            val bestDistance = candidateTokens.mapNotNull { candidateToken ->
                fuzzyTokenDistance(queryToken, candidateToken)
            }.minOrNull() ?: return null
            totalDistance += bestDistance
        }
        return totalDistance
    }

    fun searchTests(query: String): List<LabTest> {
        val trimmedQuery = query.trim()
        if (trimmedQuery.isEmpty()) return emptyList()

        val normQuery = normalizeText(trimmedQuery)
        if (normQuery.isEmpty()) return emptyList()
        val compactQuery = compactLatinKey(normQuery)

        val allTests = getLabTests()

        // Exact and typo-tolerant clinic aliases win before catalogue matching.
        aliasTargets(normQuery)?.let { targetNames ->
            val resolved = resolveExactCatalogueNames(targetNames, allTests)
            if (resolved.isNotEmpty()) return resolved
        }

        val queryWithoutArticles = removeArabicArticles(normQuery)

        data class ScoredTest(val test: LabTest, val rankScore: Int)
        val matchedTests = mutableListOf<ScoredTest>()

        for (test in allTests) {
            val normEnglish = test.normEnglish
            val normArabic = test.normArabic
            val normMarket = test.normMarket
            val normSearch = test.normSearch

            val articleFreeArabic = removeArabicArticles(normArabic)
            val articleFreeMarket = removeArabicArticles(normMarket)
            val articleFreeSearch = removeArabicArticles(normSearch)

            val compactExactMatch = compactQuery != null && (
                compactLatinKey(normEnglish) == compactQuery ||
                    compactLatinKey(normMarket) == compactQuery
                )

            val directMatch = compactExactMatch ||
                normEnglish.contains(normQuery) ||
                normArabic.contains(normQuery) ||
                normMarket.contains(normQuery) ||
                normSearch.contains(normQuery)

            val articleTolerantMatch = queryWithoutArticles.isNotBlank() && (
                articleFreeArabic.contains(queryWithoutArticles) ||
                    articleFreeMarket.contains(queryWithoutArticles) ||
                    articleFreeSearch.contains(queryWithoutArticles)
                )

            val rankScore: Int = if (directMatch || articleTolerantMatch) {
                when {
                    normEnglish == normQuery -> 1
                    normArabic == normQuery -> 2
                    normMarket == normQuery -> 3
                    compactExactMatch -> 4
                    articleFreeArabic == queryWithoutArticles || articleFreeMarket == queryWithoutArticles -> 5
                    normEnglish.split(" ").any { it == normQuery } ||
                        normArabic.split(" ").any { it == normQuery } ||
                        normMarket.split(" ").any { it == normQuery } -> 6
                    normEnglish.startsWith(normQuery) || normArabic.startsWith(normQuery) -> 7
                    normMarket.startsWith(normQuery) -> 8
                    normEnglish.contains(normQuery) || normArabic.contains(normQuery) -> 9
                    articleTolerantMatch -> 10
                    else -> 11
                }
            } else {
                val fuzzyDistance = fuzzyCatalogueDistance(
                    queryWithoutArticles,
                    listOf(normEnglish, normArabic, normMarket, normSearch)
                ) ?: continue

                // Keep fuzzy matches below all exact/substring matches.
                20 + fuzzyDistance
            }

            matchedTests.add(ScoredTest(test, rankScore))
        }

        if (matchedTests.isEmpty()) return emptyList()

        // If any exact/substring result exists, do not pollute it with fuzzy guesses.
        val exactMatches = matchedTests.filter { it.rankScore < 20 }
        val finalMatches = if (exactMatches.isNotEmpty()) {
            exactMatches
        } else {
            // For typo-only searches keep only the nearest score band. This prevents
            // a visually similar but unrelated word from appearing far below the
            // intended results (for example فيروس/فيروسات vs unrelated catalogue words).
            val bestFuzzyScore = matchedTests.minOf { it.rankScore }
            matchedTests.filter { it.rankScore <= bestFuzzyScore + 1 }
        }

        return finalMatches
            .sortedWith(compareBy<ScoredTest> { it.rankScore }.thenBy { it.test.id })
            .map { it.test }
    }
}
