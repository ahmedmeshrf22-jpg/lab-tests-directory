package com.example.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.outlined.Biotech
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.settings.appText
import com.example.util.PdfGenerator

@Composable
fun OrderPdfShareDialog(
    bundle: PdfGenerator.OrderPdfBundle,
    customerName: String,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(dismissOnBackPress = true)
    ) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = Color.White,
            border = BorderStroke(1.dp, Color(0xFFE2E8F0))
        ) {
            Column(
                modifier = Modifier.padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = appText("تم إنشاء ملفين PDF فعليًا", "Two PDF files created"),
                    fontSize = 19.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color(0xFF17324D)
                )
                Text(
                    text = appText(
                        "إيصال العميل: بيانات الحالة والتواصل + QR + الأسعار. طلب المعمل: الاسم والسن والنوع والتاريخ والتحاليل بالإنجليزية فقط بدون أسعار.",
                        "Customer receipt: patient/contact data + QR + prices. Lab request: name, age, gender, date and English test names only, with no prices."
                    ),
                    fontSize = 13.sp,
                    color = Color(0xFF64748B)
                )

                Button(
                    onClick = {
                        PdfGenerator.shareGeneratedPdf(
                            context = context,
                            file = bundle.labRequestPdf,
                            subject = "طلب تحاليل - $customerName",
                            chooserTitle = "إرسال طلب المعمل"
                        )
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF006D86))
                ) {
                    Icon(Icons.Outlined.Biotech, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text(appText("إرسال طلب المعمل", "Send Lab Request"), fontWeight = FontWeight.ExtraBold)
                }

                Button(
                    onClick = {
                        PdfGenerator.shareGeneratedPdf(
                            context = context,
                            file = bundle.customerPdf,
                            subject = "تحاليل $customerName - عيادات العقاد التخصصية",
                            chooserTitle = "إرسال PDF العميل"
                        )
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF15803D))
                ) {
                    Icon(Icons.Default.PictureAsPdf, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text(appText("إرسال PDF العميل", "Send Customer PDF"), fontWeight = FontWeight.ExtraBold)
                }

                OutlinedButton(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Row {
                        Icon(Icons.Default.Close, contentDescription = null)
                        Spacer(Modifier.width(6.dp))
                        Text(appText("إغلاق", "Close"))
                    }
                }
            }
        }
    }
}
