package com.example.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * V40: OCR helper for extracting printed Latin lab-test names/abbreviations from
 * an image or a PDF selected on the same device. PDF pages are rendered locally
 * then passed through the bundled ML Kit Latin text recognizer.
 */
object TestDocumentImport {

    private const val MAX_PDF_PAGES = 20
    private const val MAX_RENDER_EDGE = 2000

    suspend fun readText(context: Context, uri: Uri): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            try {
                val mime = context.contentResolver.getType(uri).orEmpty().lowercase()
                val isPdf = mime == "application/pdf" || uri.toString().lowercase().endsWith(".pdf")
                val text = if (isPdf) readPdf(context, uri, recognizer) else readImage(context, uri, recognizer)
                text.trim().takeIf { it.isNotBlank() }
                    ?: error("لم يتم التعرف على نص واضح داخل الملف")
            } finally {
                recognizer.close()
            }
        }
    }

    private fun readImage(context: Context, uri: Uri, recognizer: TextRecognizer): String {
        val bitmap = context.contentResolver.openInputStream(uri)?.use { input ->
            BitmapFactory.decodeStream(input)
        } ?: error("تعذر فتح الصورة")

        return try {
            recognizeBitmap(recognizer, bitmap)
        } finally {
            bitmap.recycle()
        }
    }

    private fun readPdf(context: Context, uri: Uri, recognizer: TextRecognizer): String {
        val descriptor = context.contentResolver.openFileDescriptor(uri, "r")
            ?: error("تعذر فتح ملف PDF")

        val collected = StringBuilder()
        descriptor.use { pfd ->
            PdfRenderer(pfd).use { renderer ->
                val count = minOf(renderer.pageCount, MAX_PDF_PAGES)
                for (pageIndex in 0 until count) {
                    renderer.openPage(pageIndex).use { page ->
                        val scale = minOf(
                            MAX_RENDER_EDGE.toFloat() / max(1, page.width),
                            MAX_RENDER_EDGE.toFloat() / max(1, page.height),
                            2.5f
                        ).coerceIn(0.35f, 2.5f)

                        val width = max(1, (page.width * scale).roundToInt())
                        val height = max(1, (page.height * scale).roundToInt())
                        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                        try {
                            bitmap.eraseColor(android.graphics.Color.WHITE)
                            page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                            val pageText = recognizeBitmap(recognizer, bitmap).trim()
                            if (pageText.isNotBlank()) {
                                if (collected.isNotEmpty()) collected.append('\n')
                                collected.append(pageText)
                            }
                        } finally {
                            bitmap.recycle()
                        }
                    }
                }
            }
        }
        return collected.toString()
    }

    private fun recognizeBitmap(recognizer: TextRecognizer, bitmap: Bitmap): String {
        val image = InputImage.fromBitmap(bitmap, 0)
        return Tasks.await(recognizer.process(image)).text.orEmpty()
    }
}
