package com.example.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.outlined.Biotech
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.settings.appText

private data class DailyServiceNavItem(
    val id: String,
    val titleAr: String,
    val titleEn: String,
    val icon: ImageVector,
    val action: () -> Unit
)

/** V75: daily navigation mirrors the five clear user-facing tasks on the home screen. */
@Composable
fun DailyServicesNavBar(
    active: String? = null,
    onCatalog: () -> Unit,
    onQuickImage: () -> Unit,
    onOrder: () -> Unit,
    onCustomers: () -> Unit,
    onScan: () -> Unit
) {
    val items = listOf(
        DailyServiceNavItem("catalog", "كتالوج التحاليل", "Test catalog", Icons.Outlined.Biotech, onCatalog),
        DailyServiceNavItem("quick_image", "صورة سريعة", "Quick image", Icons.Default.Image, onQuickImage),
        DailyServiceNavItem("order", "طلب جديد", "New order", Icons.Default.AddCircle, onOrder),
        DailyServiceNavItem("customers", "العملاء", "Customers", Icons.Default.People, onCustomers),
        DailyServiceNavItem("scan", "QR / صورة", "QR / Image", Icons.Default.QrCodeScanner, onScan)
    )

    Surface(
        color = Color(0xFFF8FAFC),
        border = BorderStroke(1.dp, Color(0xFFE2E8F0))
    ) {
        LazyRow(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 7.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            contentPadding = PaddingValues(horizontal = 2.dp)
        ) {
            items(items, key = { it.id }) { item ->
                val selected = active == item.id
                OutlinedButton(
                    onClick = item.action,
                    modifier = Modifier.height(38.dp),
                    shape = RoundedCornerShape(11.dp),
                    border = BorderStroke(1.dp, if (selected) Color(0xFF00B8C8) else Color(0xFFD7E0E8)),
                    colors = ButtonDefaults.outlinedButtonColors(
                        containerColor = if (selected) Color(0xFFE5FBFD) else Color.White,
                        contentColor = if (selected) Color(0xFF006D86) else Color(0xFF475569)
                    ),
                    contentPadding = PaddingValues(horizontal = 9.dp, vertical = 4.dp)
                ) {
                    Icon(item.icon, contentDescription = null)
                    Text(
                        text = appText(item.titleAr, item.titleEn),
                        modifier = Modifier.padding(start = 5.dp),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                }
            }
        }
    }
}
